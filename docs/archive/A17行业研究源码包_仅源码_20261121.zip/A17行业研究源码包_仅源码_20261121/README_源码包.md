# A17 行业研究源码包（仅源码，2026-11-21，ZIP）

本包只包含 `a17-industry-research-agent` 的源码、配置、测试和启动脚本，**不含任何数据、历史 run、报告 PDF、`.venv`、`frontend/node_modules` 或生成产物**。

## 一键启动（macOS）

在解压后的包根目录，双击：

```text
一键启动.command
```

双击后会自动完成以下步骤：

1. 在项目目录创建 Python 虚拟环境 `.venv/`
2. 安装 `requirements.txt` 中的后端依赖
3. 安装 `frontend/node_modules/` 前端依赖
4. 启动 FastAPI 后端（默认 8000）和 Vite 前端（默认 5173）
5. 前端健康检查通过后，自动打开 `http://localhost:5173/`

首次启动需要联网下载 Python 和前端依赖，耗时取决于网络。`start.sh` 还会尝试安装 Playwright Chromium 用于 PDF 排版；如果安装失败，会回退使用系统 Chrome。

如果系统阻止双击运行，可在终端执行：

```bash
cd 解压后的包根目录
chmod +x 一键启动.command
./一键启动.command
```

### 首次使用请填写 API Key

首次运行如果没有 `.env`，脚本会自动从 `.env.example` 复制一份 `.env`。界面会正常启动，但真实研报任务需要先在项目目录的 `.env` 中填写：

```text
LLM_API_KEY=你的模型 API Key
IWENCAI_API_KEY=你的问财 API Key
```

未填写前可以浏览空白工作台，但新建行业任务会在模型或数据获取阶段失败。

### 停止服务

```bash
cd a17-industry-research-agent
./start.sh --stop
```

## 包含内容

- 五智能体流水线源码：`agents_core/`、`backend/`、`frontend/src/`、`scripts/`、`docs/`、`eval/`、`remotion/` 等
- 前后端配置文件、`requirements.txt`、`frontend/package.json` 与 `package-lock.json`
- 项目根 `一键启动.command` 与 `start.command` 两个 macOS 双击入口

## 不包含内容

- **所有 `data/` 数据**：不含 `data/runs/`、`data/industry_reference/`、`data/official_financial_restatements.json`，也不含 `_保留清单.json`、报告 PDF 或 artifact revision
- Python 虚拟环境 `.venv/`
- 前端依赖 `frontend/node_modules/`
- 前端构建产物 `frontend/dist/`
- 运行日志、`.run/`、`output/`、临时评测数据、缓存
- `.env`、`.env.bak-*` 等本地凭证文件（仅保留 `.env.example`）
- 证据回查验证 run 的备份

首次启动后端时，会自动创建空的 `data/runs/`，用于存放新任务结果。因为本包不带行业基础参考数据，完整跑通新建行业任务请使用完整版源码包。

## 手动启动（可选）

```bash
cd a17-industry-research-agent
./start.sh
```

`start.sh` 会在缺少依赖时自动创建 `.venv`、安装后端依赖和前端依赖；也可以分别手动启动：

```bash
# 后端
.venv/bin/python -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000

# 前端
cd frontend
npm run dev -- --host 127.0.0.1 --port 5173
```

启动后访问 `http://127.0.0.1:5173/`，API 文档在 `http://127.0.0.1:8000/docs`。

## 环境要求

- macOS
- Python 3.11+（脚本会优先查找 `python3.11`，其次 `python3`）
- Node.js 22+ 与 npm
- 首次安装依赖时需要网络

## 说明

这是“仅源码”包，不含任何 `data/` 数据、8 个正式行业交付的报告、PDF 和完整 run 数据。需要这些交付数据时，请使用完整版 `A17行业研究源码包_20261121.zip`。
