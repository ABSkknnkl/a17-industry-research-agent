#!/usr/bin/env bash
# macOS Finder 双击入口：自动在终端里运行同目录的 start.sh。
cd "$(dirname "$0")" || exit 1
exec ./start.sh "$@"
