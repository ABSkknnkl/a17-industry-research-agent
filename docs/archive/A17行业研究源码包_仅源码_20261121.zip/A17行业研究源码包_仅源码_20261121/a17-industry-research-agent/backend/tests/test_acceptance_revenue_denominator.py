"""研发强度的分母缺口（B4c）+ 取数拒绝原因留档。

B4c 现象：半导体 SEMI-Q1 取数拿到 12/12 研发投入年度单元，但只有北方华创一家
有营业收入，研发强度只能算 1 家。

根因不是预算，是需求建模：`_annual_financial_requirements` 只在**用户原文**
出现「营业收入」时才生成 revenue 单元；而 SEMI-Q1 原文只说「研发投入数据」，
比率需求（研发投入占营业收入比例）是模型改写出来的，被丢在需求标签里没有回流。
于是分母永远不进入年度补采队列。

本夹具固定：
1. 比率需求标签里带收入词 → 按同一批实体/年份补出 revenue 单元（4×3=12）；
2. 只有研发金额、没有收入词的标签 → 不凭空增加营收单元（不放大取数）；
3. 提示实体数有上限，避免宽主题把年度单元炸成几十条；
4. 任务被拒原因写进事件流（上一轮 T2–T9 被拒原因全部丢失，只能靠猜）。
"""
from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]
for _p in ("", "agents_core", "agents_core/data-fetcher"):
    _candidate = str(_ROOT / _p) if _p else str(_ROOT)
    if _candidate not in sys.path:
        sys.path.insert(0, _candidate)

from data_fetcher.agent import DataFetcherAgent  # noqa: E402
from data_fetcher.models import Domain, ResearchRequest  # noqa: E402

SEMI_Q1 = (
    "刻蚀、薄膜沉积和清洗设备在晶圆制造中的作用及技术壁垒有何差异？请结合北方华创、中微公司、"
    "拓荆科技和盛美上海的主要产品及2023—2025年研发投入数据，分析国内半导体设备企业的技术布局"
    "与竞争优势，并区分已验证事实和推测。"
)
ENTITIES = ["北方华创", "中微公司", "拓荆科技", "盛美上海"]
YEARS = [2023, 2024, 2025]
# 与 INTENT 模型在上一轮真实运行里产出的标签逐字一致
RATIO_HINT = "2023-2025年上述公司研发投入占营业收入比例"
AMOUNT_HINT = "2023-2025年北方华创、中微公司、拓荆科技、盛美上海的研发投入金额年度序列"


def _request(entities: list[str] | None = None, focus: str = SEMI_Q1) -> ResearchRequest:
    return ResearchRequest(
        industry="半导体设备",
        focus_points=[focus],
        must_include_entities=entities or ENTITIES,
        as_of=date(2026, 11, 9),
    )


def _requirements(hints: list[str], entities: list[str] | None = None) -> list:
    return DataFetcherAgent._annual_financial_requirements(
        _request(entities), entities or ENTITIES, hints=hints
    )


def _by_metric(requirements: list, metric: str) -> list:
    return [r for r in requirements if r.metric_families[0] == metric]


def test_ratio_hint_adds_twelve_revenue_denominator_cells() -> None:
    requirements = _requirements([AMOUNT_HINT, RATIO_HINT])
    revenue = _by_metric(requirements, "revenue")
    assert len(revenue) == len(ENTITIES) * len(YEARS) == 12, revenue
    assert {r.entity_names[0] for r in revenue} == set(ENTITIES)
    assert sorted({r.period_ends[0].year for r in revenue}) == YEARS
    # 分子不被影响：仍是 12 个研发投入单元，没有因为分母而重复
    assert len(_by_metric(requirements, "rd_investment")) == 12


def test_amount_only_hint_does_not_invent_revenue_cells() -> None:
    """只问研发金额时不得凭空加营收查询——预算放开不等于滥采。"""
    requirements = _requirements([AMOUNT_HINT])
    assert not _by_metric(requirements, "revenue")
    assert len(requirements) == 12


def test_hint_entities_are_capped_to_ten() -> None:
    """宽主题下分母补采不得随实体数无限膨胀：上限 10 家 × 3 年。"""
    many = [f"样本公司{i:02d}" for i in range(14)]
    requirements = DataFetcherAgent._annual_financial_requirements(
        _request(many, focus="2023年研发投入对比"),
        many,
        hints=[RATIO_HINT],
    )
    assert len(_by_metric(requirements, "revenue")) == 10 * len(YEARS)


def test_hints_default_keeps_legacy_behaviour() -> None:
    """不传 hints 时行为与旧实现一致（已有测试依赖这个口径）。"""
    requirements = DataFetcherAgent._annual_financial_requirements(_request(), ENTITIES)
    assert len(requirements) == 12
    assert {r.metric_families[0] for r in requirements} == {"rd_investment"}


def test_task_rejection_reason_survives_event_sanitizer() -> None:
    """拒绝原因必须可追溯；query 原文仍不得进入事件流。"""
    from agents_core.event_safety import safe_event_details

    safe = safe_event_details(
        {
            "reason": "global skill-call budget would be exceeded",
            "remaining_skill_calls": 0,
            "proposed_tasks": 9,
            "query": "北方华创 2024年营业收入",
        }
    )
    assert safe["reason"] == "global skill-call budget would be exceeded"
    assert safe["remaining_skill_calls"] == 0
    assert safe["proposed_tasks"] == 9
    assert "query" not in safe


def test_event_sanitizer_truncates_and_strips_control_chars() -> None:
    from agents_core.event_safety import safe_event_details

    safe = safe_event_details({"reason": "bad\nreason" + "x" * 500})
    assert "\n" not in safe["reason"]
    assert len(safe["reason"]) == 200


def test_event_sanitizer_still_drops_unknown_fields() -> None:
    from agents_core.event_safety import safe_event_details

    safe = safe_event_details({"assessment": "模型自述", "tasks": [{"query": "x"}]})
    assert safe == {}


# ── 比率需求的可算性（B4g）─────────────────────────────────────────────────
# 数据源只给「研发投入」和「营业收入」两个字段，不提供「研发费用率」这种现成比率。
# 若把「研发费用/营业收入」当成必须命中的指标名，分子分母取齐了也永远判不通过，
# 覆盖度卡在最后一格，取数循环继续空转。


def _financial_dataset(entities: list[str], years: list[int], *, drop_revenue_for: str | None = None):
    from data_fetcher.models import ResearchRecord, SourceRef, StructuredResearchDataset

    source = SourceRef(
        task_id="annual", skill_id="hithink-finance-query", skill_version="1.0.0",
        query="probe", trace_id="trace", retrieved_at=date(2026, 11, 9),
    )
    records = []
    for entity in entities:
        for year in years:
            for metric, value in (("营业收入", 1.0e10), ("研发支出", 1.0e9)):
                if metric == "营业收入" and entity == drop_revenue_for:
                    continue
                records.append(ResearchRecord(
                    record_id=f"{entity}-{metric}-{year}", domain=Domain.FINANCIALS,
                    entity_name=entity, entity_code=None, metric=metric, value=value,
                    unit="元", unit_provenance="source_field",
                    period_end=date(year, 12, 31), period_start=date(year, 1, 1),
                    period_type="annual", source=source,
                ))
    return StructuredResearchDataset(financials=records, research_as_of=date(2026, 11, 9))


def _ratio_requirement(entities: list[str], years: list[int]):
    from data_fetcher.models import Domain as _Domain, ResearchRequirement

    return ResearchRequirement(
        requirement_id="rd_expense_ratio_series",
        label="2023-2025年四家公司研发费用率（研发费用/营业收入）年度序列",
        domain=_Domain.FINANCIALS, hard=True, min_records=len(entities) * len(years),
        entity_names=entities, period_ends=[date(year, 12, 31) for year in years],
        expected_metric_groups=[["研发费用率", "研发费用占比", "研发投入占比", "研发费用/营业收入"]],
    )


def test_ratio_requirement_is_satisfied_by_numerator_and_denominator() -> None:
    dataset = _financial_dataset(ENTITIES[:2], [2023, 2024])
    coverage = DataFetcherAgent._evaluate_requirement(
        dataset, _ratio_requirement(ENTITIES[:2], [2023, 2024])
    )
    assert coverage.passed, coverage.missing


def test_ratio_requirement_fails_when_a_denominator_is_missing() -> None:
    dataset = _financial_dataset(ENTITIES[:2], [2023], drop_revenue_for=ENTITIES[1])
    coverage = DataFetcherAgent._evaluate_requirement(
        dataset, _ratio_requirement(ENTITIES[:2], [2023])
    )
    assert not coverage.passed
    assert any("指标组" in item for item in coverage.missing)


def test_implicit_ratio_token_is_supported() -> None:
    """「研发费用率」这类不写分母的比率词，按营业收入为分母判定可算性。"""
    from data_fetcher.models import Domain as _Domain, ResearchRequirement

    dataset = _financial_dataset(ENTITIES[:1], [2023])
    requirement = ResearchRequirement(
        requirement_id="rd_ratio_implicit",
        label="北方华创 2023年研发费用率",
        domain=_Domain.FINANCIALS, hard=True, min_records=1,
        entity_names=[ENTITIES[0]], period_ends=[date(2023, 12, 31)],
        expected_metric_groups=[["研发费用率", "研发投入占比"]],
    )
    coverage = DataFetcherAgent._evaluate_requirement(dataset, requirement)
    assert coverage.passed, coverage.missing


def test_implicit_ratio_token_still_needs_revenue() -> None:
    """只有研发金额、没有营业收入时，比率仍然不可计算。"""
    from data_fetcher.models import Domain as _Domain, ResearchRequirement

    dataset = _financial_dataset(ENTITIES[:1], [2023], drop_revenue_for=ENTITIES[0])
    requirement = ResearchRequirement(
        requirement_id="rd_ratio_implicit",
        label="北方华创 2023年研发费用率",
        domain=_Domain.FINANCIALS, hard=True, min_records=1,
        entity_names=[ENTITIES[0]], period_ends=[date(2023, 12, 31)],
        expected_metric_groups=[["研发费用率"]],
    )
    coverage = DataFetcherAgent._evaluate_requirement(dataset, requirement)
    assert not coverage.passed
