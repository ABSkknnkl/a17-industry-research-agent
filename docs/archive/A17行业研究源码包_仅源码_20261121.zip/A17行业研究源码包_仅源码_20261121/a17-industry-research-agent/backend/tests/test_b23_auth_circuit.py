"""B23-T4 红测：401 全局熔断窗口。

问题（SEMI-Q4 实测）：announcement-search 一批 8 个任务并发，24 次 HTTP 401
（占该技能请求 22%）。旧逻辑虽退避 0.6s×n 并换 key，但**并发请求互不知情**，
仍在同一秒内轮流撞墙，把 3 个 key 全部烧穿后整任务失败。

期望：任一请求遇 401/403/429 记录「打击时刻」，后续请求在窗口内先排队等待。
"""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[2]
for p in (str(ROOT), str(ROOT / "agents_core"), str(ROOT / "agents_core/data-fetcher")):
    if p not in sys.path:
        sys.path.insert(0, p)

import data_fetcher.skillhub as skillhub
from data_fetcher.skillhub import (
    auth_cooldown_remaining,
    await_auth_window,
    note_auth_strike,
)


@pytest.fixture(autouse=True)
def _reset_strike():
    skillhub._AUTH_STRIKE_AT = 0.0
    yield
    skillhub._AUTH_STRIKE_AT = 0.0


def test_strike_opens_cooldown_window():
    note_auth_strike()
    remaining = auth_cooldown_remaining()
    assert 0 < remaining <= skillhub._AUTH_COOLDOWN_SECONDS


def test_cooldown_expires():
    skillhub._AUTH_STRIKE_AT = skillhub.monotonic() - skillhub._AUTH_COOLDOWN_SECONDS - 1
    assert auth_cooldown_remaining() <= 0


def test_await_window_sleeps_inside_cooldown(monkeypatch):
    """窗口内必须真的等待，且等待时长≈剩余窗口。"""
    slept: list[float] = []

    async def _fake_sleep(seconds: float) -> None:
        slept.append(seconds)

    monkeypatch.setattr(skillhub.asyncio, "sleep", _fake_sleep)
    note_auth_strike()
    asyncio.run(await_auth_window())
    assert len(slept) == 1
    assert 0 < slept[0] <= skillhub._AUTH_COOLDOWN_SECONDS


def test_await_window_no_sleep_after_expiry(monkeypatch):
    slept: list[float] = []

    async def _fake_sleep(seconds: float) -> None:
        slept.append(seconds)

    monkeypatch.setattr(skillhub.asyncio, "sleep", _fake_sleep)
    skillhub._AUTH_STRIKE_AT = skillhub.monotonic() - skillhub._AUTH_COOLDOWN_SECONDS - 1
    asyncio.run(await_auth_window())
    assert slept == []


def test_concurrent_requests_all_wait_after_strike(monkeypatch):
    """并发场景：打击发生后，多个请求都进入等待（整批一起退，不是轮流撞）。"""
    slept: list[float] = []

    async def _fake_sleep(seconds: float) -> None:
        slept.append(seconds)

    monkeypatch.setattr(skillhub.asyncio, "sleep", _fake_sleep)
    note_auth_strike()

    async def _worker():
        await await_auth_window()

    async def _main():
        await asyncio.gather(*[_worker() for _ in range(5)])

    asyncio.run(_main())
    assert len(slept) == 5, f"5 个并发请求都应等待，实际 {len(slept)}"
