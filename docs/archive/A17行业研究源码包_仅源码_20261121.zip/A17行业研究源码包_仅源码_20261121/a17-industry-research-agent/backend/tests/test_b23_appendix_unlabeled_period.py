"""B23-T11：附录异常条目的主体/期间归属规则。

问题（SEMI-Q4 第三轮实测）：`outlier_items` 有 47 条，其中行情快照类记录
（PE / 市值）在上游没有标注期间（period=None）。审计逻辑把「无期间」当成
「无法唯一归属」→ 47 条全部判「无法匹配来源」→ 附录审计硬阻塞交付。

期望：
- 无期间但 entity+metric+value 精确定位到**唯一**记录 → 允许归属，标注「未标注」；
- 无期间且候选不止一条 → 仍拦截（无法唯一定位）。
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
for p in (str(ROOT), str(ROOT / "agents_core"), str(ROOT / "agents_core/report-fusion"),
          str(ROOT / "agents_core/chapter-writer")):
    if p not in sys.path:
        sys.path.insert(0, p)

from chapter_writer.models import InterpretationReport
from report_fusion.appendix import audit_appendix


def _report(outliers: list[dict], evidence: dict) -> InterpretationReport:
    return InterpretationReport.model_validate({
        "report_id": "R-B23T11",
        "subject": "半导体设备",
        "as_of": "2026-11-10",
        "status": "completed",
        "evidence_index": evidence,
        "data_quality_appendix": {"outlier_items": outliers},
    })


def _ev(rid, entity, metric, value, unit):
    return {"record_id": rid, "domain": "companies", "entity": entity,
            "metric": metric, "value": value, "unit": unit, "period": None}


def test_unlabeled_period_with_unique_match_is_accepted():
    report = _report(
        [{"entity": "华塑控股", "metric": "pe_ttm", "period": None,
          "observed_value": "-122.589919", "evidence_ids": ["R1"]}],
        {"R1": _ev("R1", "华塑控股", "pe_ttm", -122.589919, "倍")},
    )
    _, issues = audit_appendix(report)
    assert issues == [], [i["claim"] for i in issues]


def test_unlabeled_period_with_ambiguous_candidates_is_blocked():
    """同一主体+指标有两条不同数值、都没有期间：无法唯一定位，必须拦。"""
    report = _report(
        [{"entity": "华塑控股", "metric": "pe_ttm", "period": None,
          "observed_value": "-122.589919", "evidence_ids": ["R1", "R2"]}],
        {
            "R1": _ev("R1", "华塑控股", "pe_ttm", -122.589919, "倍"),
            "R2": _ev("R2", "华塑控股", "pe_ttm", -999.0, "倍"),
        },
    )
    _, issues = audit_appendix(report)
    assert any("无法匹配来源" in i["claim"] for i in issues), issues


def test_wrong_value_still_blocked():
    report = _report(
        [{"entity": "华塑控股", "metric": "pe_ttm", "period": None,
          "observed_value": "999", "evidence_ids": ["R1"]}],
        {"R1": _ev("R1", "华塑控股", "pe_ttm", -122.589919, "倍")},
    )
    _, issues = audit_appendix(report)
    assert any("无法匹配来源" in i["claim"] for i in issues), issues
