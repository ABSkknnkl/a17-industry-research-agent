"""可比公司矩阵：comparison_scope 存在时 company_data 以 entity_code 为键（2026-11-09）。

SEMI-Q1 全链在 `data_interpret` 直接 KeyError: 'market_cap' 崩掉：
`quality_summary.comparison_scope` 一旦存在，`company_data` 用 entity_code 作键，
而市值合计却按 `company_name` 反查；`defaultdict` 会为中文名新建一个空条目，
随后取 `["metrics"]["market_cap"]` 就抛 KeyError。
这条路径是「取数完全成功、解读阶段整体失败」的单点，必须用夹具锁死。
"""
from __future__ import annotations

import pytest

from data_interpreter.engine import DeterministicAnalysisEngine
from data_interpreter.models import StructuredResearchDataset

SOURCE = {
    "task_id": "probe", "skill_id": "hithink-astock-selector", "skill_version": "1.0.0",
    "query": "probe", "trace_id": "trace", "retrieved_at": "2026-11-09T12:00:00Z",
    "status": "success", "record_count": 1,
}


def _rec(rid: str, name: str, code: str, metric: str, value, *, unit=None, domain="companies"):
    return {
        "record_id": rid, "domain": domain, "entity_name": name, "entity_code": code,
        "metric": metric, "value": value, "unit": unit, "unit_provenance": "source_field",
        "period_end": None, "period_start": None, "period_type": "unknown",
        "period_provenance": "unknown", "scope": "consolidated", "currency": "CNY",
        "published_at": None, "source": SOURCE,
    }


def _dataset(records, scope=None):
    return StructuredResearchDataset.model_validate({
        "companies": records,
        "quality_summary": {"comparison_scope": scope} if scope else {},
        "research_as_of": "2026-11-09",
    })


SCOPE = {
    "requested": ["北方华创", "中微公司"],
    "names": ["北方华创", "中微公司"],
    "codes": ["002371.SZ", "688012.SH"],
}


def test_peer_matrix_survives_code_keyed_companies() -> None:
    dataset = _dataset([
        _rec("R1", "北方华创", "002371.SZ", "entity_identity", "北方华创"),
        _rec("R2", "北方华创", "002371.SZ", "market_cap", 1800.0, unit="亿元"),
        _rec("R3", "中微公司", "688012.SH", "entity_identity", "中微公司"),
    ], scope=SCOPE)
    matrix = DeterministicAnalysisEngine().build_peer_comps_matrix(dataset, subject="半导体设备")
    assert matrix.total_market_cap == pytest.approx(1800.0)
    assert matrix.market_cap_coverage["available"] == 1


def test_peer_matrix_with_scope_and_no_market_cap_does_not_raise() -> None:
    dataset = _dataset([
        _rec("R1", "北方华创", "002371.SZ", "revenue", 298.0, unit="亿元", domain="financials"),
        _rec("R2", "中微公司", "688012.SH", "revenue", 90.0, unit="亿元", domain="financials"),
    ], scope=SCOPE)
    matrix = DeterministicAnalysisEngine().build_peer_comps_matrix(dataset, subject="半导体设备")
    assert matrix.total_market_cap is None
    assert [e.company_name for e in matrix.entries] == ["北方华创", "中微公司"]


def test_peer_matrix_without_scope_still_keys_by_name() -> None:
    """反向保护：没有 comparison_scope 时仍按实体名聚合，市值合计照常可算。"""
    dataset = _dataset([
        _rec("R1", "北方华创", "002371.SZ", "market_cap", 1800.0, unit="亿元"),
        _rec("R2", "中微公司", "688012.SH", "market_cap", 1200.0, unit="亿元"),
    ])
    matrix = DeterministicAnalysisEngine().build_peer_comps_matrix(dataset, subject="半导体设备")
    assert matrix.total_market_cap == pytest.approx(3000.0)
