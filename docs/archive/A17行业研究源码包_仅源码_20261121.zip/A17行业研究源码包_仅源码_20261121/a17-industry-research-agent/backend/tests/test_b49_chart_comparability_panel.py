"""B49 红测：平衡面板不得被判「缺少共同观测期间」。

实测（run-20261111192127，低空经济）：CHART-01/02/04 被判
「横截面样本缺少共同观测期间，不能作同期间比较」，但这三张图的契约是
**每个实体都有完整的两年**（纵横 2024+2025、宗申 2024+2025）——期间是共享的，
属于合法的分组比较。

根因在 `chart_comparability_issues` 的非时序分支：

    elif len({entity}) > 1 and len(periods) > 1:
        problems.append("横截面样本缺少共同观测期间，不能作同期间比较")

把「多期间」直接当成「期间不共享」。正确判据应是**各实体的期间集合不一致**
（非平衡面板）才不可比。该分支此前无任何测试覆盖（仅 temporal=True 有用例），
所以误判长期存在。

修法：按实体收集期间集合，只有集合不一致才报；单期间横截面、缺期间、
币种/口径不一致等既有告警一律保持。
"""

from __future__ import annotations

import pytest

import agents_core.financial_semantics as fs

MESSAGE = "横截面样本缺少共同观测期间，不能作同期间比较"


def _row(record_id: str, entity: str, period: str, **overrides) -> dict:
    year = period[:4]
    row = {
        "record_id": record_id,
        "entity": entity,
        "metric": "营业收入",
        "value": 100.0,
        "unit": "亿元",
        "period": period,
        "period_start": f"{year}-01-01",
        "period_type": "annual",
        "scope": "consolidated",
        "currency": "CNY",
        "issues": [],
    }
    row.update(overrides)
    return row


def test_balanced_panel_is_comparable() -> None:
    """两个实体各两年（完全平衡）：这是分组比较，不是「缺共同期间」。"""
    refs = [
        _row("R-1", "纵横股份", "2024-12-31"),
        _row("R-2", "纵横股份", "2025-12-31"),
        _row("R-3", "宗申动力", "2024-12-31"),
        _row("R-4", "宗申动力", "2025-12-31"),
    ]
    assert MESSAGE not in fs.chart_comparability_issues(refs, temporal=False)


def test_unbalanced_panel_is_still_rejected() -> None:
    """A 有两年、B 只有一年：期间集合不一致，必须照旧拦截。"""
    refs = [
        _row("R-1", "纵横股份", "2024-12-31"),
        _row("R-2", "纵横股份", "2025-12-31"),
        _row("R-3", "宗申动力", "2025-12-31"),
    ]
    assert MESSAGE in fs.chart_comparability_issues(refs, temporal=False)


def test_disjoint_periods_are_rejected() -> None:
    """A 只有 2024、B 只有 2025：完全无共同观测期间，必须拦截。"""
    refs = [
        _row("R-1", "纵横股份", "2024-12-31"),
        _row("R-2", "宗申动力", "2025-12-31"),
    ]
    assert MESSAGE in fs.chart_comparability_issues(refs, temporal=False)


def test_single_period_cross_section_is_comparable() -> None:
    """单期间横截面（最常见的样本对比图）：不得因本次修改被误伤。"""
    refs = [
        _row("R-1", "纵横股份", "2025-12-31"),
        _row("R-2", "宗申动力", "2025-12-31"),
        _row("R-3", "亿航智能", "2025-12-31"),
    ]
    assert fs.chart_comparability_issues(refs, temporal=False) == []


def test_missing_period_still_flagged() -> None:
    """缺期间的既有告警不受影响。"""
    broken = _row("R-2", "宗申动力", "2025-12-31")
    broken.update({"period": None, "period_start": None, "period_type": "unknown"})
    refs = [_row("R-1", "纵横股份", "2025-12-31"), broken]
    issues = fs.chart_comparability_issues(refs, temporal=False)
    assert any("缺少有效观测期间" in item for item in issues)


def test_scope_or_currency_mismatch_still_flagged() -> None:
    """口径/币种不一致的既有告警不受影响。"""
    refs = [
        _row("R-1", "纵横股份", "2025-12-31"),
        _row("R-2", "宗申动力", "2025-12-31", currency="USD"),
    ]
    issues = fs.chart_comparability_issues(refs, temporal=False)
    assert any("测量范围或币种不一致" in item for item in issues)


def test_temporal_branch_unchanged() -> None:
    """时序分支（SEMI-F1 门禁）行为不变：YTD 与年度混用仍拦截。"""
    refs = [
        _row("R-1", "北方华创", "2025-12-31"),
        _row("R-2", "北方华创", "2026-09-30", period_start="2026-01-01", period_type="ytd_q3"),
    ]
    issues = fs.chart_comparability_issues(refs, temporal=True)
    assert any("时间序列混合不同长度或定义的报告期间" in item for item in issues)


def test_real_low_altitude_contracts_pass() -> None:
    """真实缺陷数据：低空 CHART-01 的两实体×两期间面板应判为可比。"""
    refs = [
        _row("R-1", "纵横股份", "2024-12-31", metric="营业收入同比增长率", unit="%"),
        _row("R-2", "纵横股份", "2025-12-31", metric="营业收入同比增长率", unit="%"),
        _row("R-3", "宗申动力", "2024-12-31", metric="营业收入同比增长率", unit="%"),
        _row("R-4", "宗申动力", "2025-12-31", metric="营业收入同比增长率", unit="%"),
    ]
    assert MESSAGE not in fs.chart_comparability_issues(refs, temporal=False)
