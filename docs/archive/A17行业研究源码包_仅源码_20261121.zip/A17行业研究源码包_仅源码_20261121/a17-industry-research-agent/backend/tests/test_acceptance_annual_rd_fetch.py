"""SEMI-Q1 年度研发取数的回归夹具（B4 根因）。

根因：`_FINANCIAL_METRIC_TERMS` 只有「研发费用」没有「研发投入」。
`_annual_financial_requirements` 为 SEMI-Q1 生成的是 rd_investment（研发投入）单元，
`_priority_annual_tasks` 据此发出「<公司> <年>年全年 研发投入」，
但 `_validate_tasks` 用 `_query_has_financial_metrics` 判定「财务任务缺指标」，
于是 4 家公司 × 3 年 = 12 个年度单元全部被拒，dataset 里 annual=0。

本夹具固定三件事：
1. 真实题目能产出 12 个 rd_investment 年度单元；
2. 这些单元编译后的 query 仍带「研发投入」且通过指标门禁；
3. 比率口径（研发费用率/研发投入占比/研发强度）不被截断成金额口径，
   同时非财务指标（产能利用率/合同负债）仍被拒绝——不放宽门禁。
"""
from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]
for _p in ("", "agents_core", "agents_core/data-fetcher"):
    _candidate = str(_ROOT / _p) if _p else str(_ROOT)
    if _candidate not in sys.path:
        sys.path.insert(0, _candidate)

from data_fetcher.agent import (  # noqa: E402
    _compile_query,
    _FINANCIAL_METRIC_TERMS,
    _query_has_financial_metrics,
)
from data_fetcher.models import Domain, ResearchRequest  # noqa: E402

SEMI_Q1 = (
    "刻蚀、薄膜沉积和清洗设备在晶圆制造中的作用及技术壁垒有何差异？请结合北方华创、中微公司、"
    "拓荆科技和盛美上海的主要产品及2023—2025年研发投入数据，分析国内半导体设备企业的技术布局"
    "与竞争优势，并区分已验证事实和推测。"
)
ENTITIES = ["北方华创", "中微公司", "拓荆科技", "盛美上海"]
YEARS = [2023, 2024, 2025]
# 与 _priority_annual_tasks 的 labels 保持一致
_LABELS = {
    "revenue": "营业收入",
    "parent_net_profit": "归母净利润",
    "gross_margin": "销售毛利率",
    "operating_cash_flow": "经营活动产生的现金流量净额",
    "rd_expense": "研发费用",
    "rd_investment": "研发投入",
}


def _annual_requirements() -> list:
    from data_fetcher.agent import DataFetcherAgent

    request = ResearchRequest(
        industry="半导体设备",
        focus_points=[SEMI_Q1],
        must_include_entities=ENTITIES,
        as_of=date(2026, 11, 9),
    )
    return DataFetcherAgent._annual_financial_requirements(request, ENTITIES)


def test_real_semi_question_yields_twelve_rd_investment_cells() -> None:
    requirements = _annual_requirements()
    assert len(requirements) == len(ENTITIES) * len(YEARS) == 12
    assert {r.metric_families[0] for r in requirements} == {"rd_investment"}
    assert sorted({r.entity_names[0] for r in requirements}) == sorted(ENTITIES)
    assert sorted({r.period_ends[0].year for r in requirements}) == YEARS
    assert all(r.period_ends[0] == date(r.period_ends[0].year, 12, 31) for r in requirements)


def test_rd_investment_is_a_recognised_financial_metric() -> None:
    assert "研发投入" in _FINANCIAL_METRIC_TERMS
    assert "研发费用" in _FINANCIAL_METRIC_TERMS


def test_annual_rd_query_survives_compile_and_metric_guard() -> None:
    """12 个年度单元的 query 编译后必须仍可被识别为财务指标请求。"""
    for requirement in _annual_requirements():
        entity = requirement.entity_names[0]
        year = requirement.period_ends[0].year
        label = _LABELS[requirement.metric_families[0]]
        raw = f"{entity} {year}年全年 {label}"
        compiled, _ = _compile_query(raw, domain=Domain.FINANCIALS, expected_fields=[label])
        assert "研发投入" in compiled, (raw, compiled)
        assert str(year) in compiled, (raw, compiled)
        assert _query_has_financial_metrics(compiled), (raw, compiled)


def test_ratio_metrics_keep_the_ratio_suffix() -> None:
    """比率口径不得被截断成金额口径（研发费用率 ≠ 研发费用）。"""
    for metric in ("研发费用率", "研发投入占比", "研发投入比例", "研发强度", "研发投入强度"):
        compiled, _ = _compile_query(
            f"北方华创 2025年全年 {metric}", domain=Domain.FINANCIALS, expected_fields=[metric]
        )
        assert metric in compiled, (metric, compiled)
        assert _query_has_financial_metrics(compiled), (metric, compiled)


def test_amount_metric_is_not_replaced_by_ratio() -> None:
    compiled, _ = _compile_query(
        "北方华创 2025年全年 研发费用", domain=Domain.FINANCIALS, expected_fields=["研发费用"]
    )
    assert "研发费用率" not in compiled
    assert "研发费用" in compiled


def test_non_metric_financial_query_is_still_rejected() -> None:
    """放宽词表不等于放宽门禁：没有可识别财务指标的 query 仍须被拒。"""
    for metric in ("产能利用率", "合同负债", "客户集中度"):
        compiled, _ = _compile_query(
            f"北方华创 2025年全年 {metric}", domain=Domain.FINANCIALS, expected_fields=[metric]
        )
        assert not _query_has_financial_metrics(compiled), (metric, compiled)


def test_non_financial_domain_still_strips_financial_terms() -> None:
    compiled, _ = _compile_query("半导体设备 研发投入 行业趋势", domain=Domain.NEWS)
    assert "研发投入" not in compiled
    assert "行业趋势" in compiled


def test_supplier_field_name_rd_spending_maps_to_rd_investment() -> None:
    """问财返回的字段名是「研发支出」，必须并入 rd_investment 口径。"""
    from financial_semantics import metric_family

    assert metric_family("研发支出") == "rd_investment"
    assert metric_family("研发支出合计") == "rd_investment"
    assert metric_family("研发投入合计") == "rd_investment"
    # 口径不得合并：研发费用是费用化部分，不是研发投入
    assert metric_family("研发费用") == "rd_expense"


def _requirement_and_dataset(metric_name: str):
    from datetime import date as _date

    from data_fetcher.agent import DataFetcherAgent
    from data_fetcher.models import (
        Domain as _Domain,
        ResearchRecord,
        SourceRef,
        StructuredResearchDataset,
    )

    request = ResearchRequest(
        industry="半导体设备",
        focus_points=["结合北方华创2023—2023年研发投入数据分析。"],
        must_include_entities=["北方华创"],
        as_of=_date(2026, 11, 9),
    )
    requirements = DataFetcherAgent._annual_financial_requirements(request, ["北方华创"])
    assert requirements, "应至少生成一个年度单元"
    requirement = requirements[0]
    source = SourceRef(
        task_id="T1", skill_id="hithink-finance-query", skill_version="1.0.0",
        query="北方华创 2023年研发投入", trace_id="trace-1", retrieved_at=_date(2026, 11, 9),
    )
    record = ResearchRecord(
        record_id="R1", domain=_Domain.FINANCIALS, entity_name="北方华创",
        entity_code="002371.SZ", metric=metric_name, value=4409535588.51, unit="元",
        unit_provenance="source_schema", period_end=_date(2023, 12, 31),
        period_start=_date(2023, 1, 1), period_type="annual", source=source,
    )
    dataset = StructuredResearchDataset(financials=[record], research_as_of=_date(2026, 11, 9))
    return DataFetcherAgent, requirement, dataset


def test_rd_spending_record_satisfies_annual_rd_investment_requirement() -> None:
    """数据取到但字段叫「研发支出」时，覆盖判定必须认。"""
    agent, requirement, dataset = _requirement_and_dataset("研发支出")
    coverage = agent._evaluate_requirement(dataset, requirement)
    assert coverage.passed, coverage


def test_rd_expense_record_does_not_satisfy_rd_investment_requirement() -> None:
    """口径不得互相顶替：只有研发费用时不得算作研发投入已覆盖。"""
    agent, requirement, dataset = _requirement_and_dataset("研发费用")
    coverage = agent._evaluate_requirement(dataset, requirement)
    assert not coverage.passed
