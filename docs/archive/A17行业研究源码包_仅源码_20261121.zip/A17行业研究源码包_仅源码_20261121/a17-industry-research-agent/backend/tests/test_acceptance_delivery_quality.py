"""B5 交付件质量：标签、去重、字数、封面、目录页码（2026-11-09）。

对应两份基线（低空 LA-Q1 / 半导体 SEMI-Q1）实跑暴露的五处交付层缺陷：
  1. 封面副标题 = 整段 headline（低空 300 余字，且以「然而，」开头）；
     半导体 headline 干脆是空的，封面副标题留白。
  2. 摘要「核心风险提示」与「研究边界」同源，7 条里前 6 条一字不差。
  3. 单条结论 4181 字，把证据库逐条抄进摘要。
  4. 内部标识泄漏：图标题 `净资产收益率(净资产收益率(ROE))`、`pe_dynamic样本对比`，
     正文与附录出现 chain_structure / net_margin_pct / unit_unknown 等字段名。
  5. 单看 HTML 时目录页码栏全空（页码只有排版后的 PDF 才知道）。
全部为零调用离线夹具。
"""
from __future__ import annotations

import asyncio
import re
from pathlib import Path

import pytest

from report_fusion.agent import _is_substantive_metric
from report_fusion.models import ReportViewModel
from report_fusion.render import (
    CONCLUSION_LIMIT,
    _reading_text,
    clamp_sentence,
    render_html,
    render_markdown,
)


def _view(**overrides) -> ReportViewModel:
    payload = dict(
        report_id="R-B5", title="低空经济行业研究报告", subject="低空经济", as_of="2026-11-09",
        tone="professional", report_depth="standard", visual_style="deep_research",
        chart_mode="auto", delivery_status="ready_with_limits",
        executive_summary={
            "headline": "然而，" + "本次证据库中缺乏上市公司主营构成，产业链结构需求未通过。" * 12,
            "conclusions": [],
            "risks": [],
            "research_boundaries": [],
        },
        chapters=[{"chapter_id": "CH-01", "title": "行业定义与研究基础", "summary": "定义。", "sections": []},
                  {"chapter_id": "CH-02", "title": "市场规模与成长性", "summary": "规模。", "sections": []},
                  {"chapter_id": "CH-03", "title": "产业链与利润分配", "summary": "链条。", "sections": []},
                  {"chapter_id": "CH-04", "title": "竞争格局", "summary": "格局。", "sections": []},
                  {"chapter_id": "CH-07", "title": "情景、风险与研究结论", "summary": "结论。", "sections": []}],
    )
    payload.update(overrides)
    return ReportViewModel(**payload)


# ── 1. 封面副标题 ─────────────────────────────────────────────────────────────

def test_cover_subtitle_is_one_line_not_the_whole_headline() -> None:
    view = _view()
    html = render_html(view)
    subtitle = re.search(r'<div class="cover-subtitle">(.*?)</div>', html, re.S).group(1)
    assert "然而" not in subtitle
    assert len(subtitle) <= 60, subtitle
    assert subtitle.startswith("低空经济：")
    # 摘要页正文里的 headline 仍是完整研判（截到上限），不是被封面副标题替代
    body = re.search(r'<p class="chapter-summary">(.*?)</p>', html, re.S).group(1)
    assert len(body) > len(subtitle)


def test_empty_headline_still_gets_a_cover_subtitle() -> None:
    """半导体基线的 headline 是空串，封面副标题当时是空白。"""
    view = _view(executive_summary={"headline": "", "conclusions": [], "risks": [], "research_boundaries": []})
    html = render_html(view)
    assert "本次证据库" not in html
    subtitle = re.search(r'<div class="cover-subtitle">(.*?)</div>', html, re.S).group(1)
    assert subtitle.strip()
    body = re.search(r'<p class="chapter-summary">(.*?)</p>', html, re.S).group(1)
    assert body.strip(), "headline 为空时摘要页也不能留白"


# ── 2. 风险与边界去重 ─────────────────────────────────────────────────────────

def test_risks_that_repeat_research_boundaries_are_not_shown_twice() -> None:
    same = ["存在 2 组未消解的来源冲突", "超过一半的数值记录缺少可用于趋势分析的日期"]
    view = _view(executive_summary={
        "headline": "行业研判", "conclusions": [], "risks": list(same),
        "research_boundaries": list(same) + ["结论仅适用于报告列示的资料范围和研究时点"],
    })
    md = render_markdown(view)
    assert "核心风险提示" not in md, "全部重复时不应再单列风险栏"
    # 摘要区只出现一次；附录「量化结论边界」按设计会再列一遍，不在此断言内
    summary_area = md.split("## 附录一")[0]
    assert summary_area.count("存在 2 组未消解的来源冲突") == 1

    html = render_html(view)
    # 单栏版式用合并视图：每一条只出现一次
    assert html.count("存在 2 组未消解的来源冲突") == 1


def test_unique_risks_survive_the_dedupe() -> None:
    view = _view(executive_summary={
        "headline": "行业研判", "conclusions": [],
        "risks": ["空域管理改革进度低于预期", "存在 2 组未消解的来源冲突"],
        "research_boundaries": ["存在 2 组未消解的来源冲突"],
    })
    rendered = render_html(view)
    assert "空域管理改革进度低于预期" in rendered
    assert rendered.count("存在 2 组未消解的来源冲突") == 1


# ── 3. 超长结论 ───────────────────────────────────────────────────────────────

def test_overlong_conclusion_is_clamped_without_inventing_numbers() -> None:
    dump = "；".join(f"江航装备2021-12-31（年度，合并报表）毛利率为{43.6072 + i:.4f}%" for i in range(120))
    view = _view(executive_summary={
        "headline": "行业研判",
        "conclusions": [{"text": dump, "evidence_ids": [], "confidence": "medium"}],
        "risks": [], "research_boundaries": [],
    })
    md = render_markdown(view)
    line = next(x for x in md.splitlines() if x.startswith("- ■ "))
    assert len(line) <= CONCLUSION_LIMIT + 40, len(line)
    assert dump not in md

    # 截断不能把 "43.6072" 切成 "43"——那会凭空造出一个无据数字
    clamped = clamp_sentence(dump, CONCLUSION_LIMIT)
    source_numbers = set(re.findall(r"\d+(?:\.\d+)?", dump))
    for number in re.findall(r"\d+(?:\.\d+)?", clamped):
        assert number in source_numbers, f"截断产生了新数字 {number}"


def test_short_conclusion_is_untouched() -> None:
    text = "四家公司研发强度均高于 15%，中微公司 2025 年升至 30.23%。"
    assert clamp_sentence(text, CONCLUSION_LIMIT) == text


# ── 4. 内部标识 ───────────────────────────────────────────────────────────────

@pytest.mark.parametrize(("raw", "expected"), [
    ("chain_structure", "产业链结构"),
    ("requirement_evidence_matrix", "需求—证据矩阵"),
    ("financial_ratios", "财务比率"),
    ("net_margin_pct", "净利率"),
    ("roe_pct", "净资产收益率(ROE)"),
    ("unit_unknown", "单位待确认"),
    ("pe_dynamic", "市盈率(动态)"),
])
def test_internal_identifiers_are_translated_for_readers(raw: str, expected: str) -> None:
    assert expected in _reading_text(f"证据显示 {raw} 口径受限。")


def test_internal_identifiers_do_not_reach_markdown_or_html() -> None:
    leaky = (
        "requirement_evidence_matrix显示chain_structure要求未通过，缺少chain_segment、"
        "main_business等指标组；financial_ratios中net_margin_pct与roe_pct为空，"
        "pe_dynamic（合并报表，CNY，倍）单位unit_unknown。"
    )
    view = _view(
        executive_summary={"headline": leaky, "conclusions": [{"text": leaky, "evidence_ids": []}],
                           "risks": [leaky], "research_boundaries": [leaky]},
        chapters=[{"chapter_id": "CH-01", "title": "行业定义与研究基础", "summary": leaky,
                   "sections": [{"section_id": "S-1-1", "title": "定义", "paragraphs": [
                       {"paragraph_id": "P-1-1", "kind": "analysis", "text": leaky, "evidence_ids": []}],
                       "uncertainties": [leaky]}]}],
    )
    for output in (render_markdown(view), render_html(view)):
        for token in ("chain_structure", "requirement_evidence_matrix", "chain_segment",
                      "main_business", "financial_ratios", "net_margin_pct", "roe_pct",
                      "pe_dynamic", "unit_unknown"):
            assert token not in output, token
        assert "产业链结构" in output and "净利率" in output


def test_chart_titles_do_not_self_nest_roe() -> None:
    from chart_generator.render import clean_chart_title, clean_metric_label

    assert clean_metric_label("roe") == "净资产收益率(ROE)"
    assert clean_chart_title("低空经济净资产收益率(ROE)趋势（2021-12-31至2025-12-31）") == \
        "低空经济净资产收益率(ROE)趋势（2021-12-31至2025-12-31）"
    # 旧产物里已经写坏的双层嵌套要能折回去
    assert clean_chart_title("低空经济净资产收益率(净资产收益率(ROE))趋势") == \
        "低空经济净资产收益率(ROE)趋势"


def test_metric_labels_cover_dynamic_pe_and_pct_suffixes() -> None:
    from chart_generator.render import clean_metric_label
    from report_fusion.render import _format_metric_label

    assert clean_metric_label("pe_dynamic") == "市盈率(动态)"
    assert clean_metric_label("roe_pct") == "净资产收益率(ROE)"
    assert _format_metric_label("pe_dynamic") == "市盈率(动态)"
    assert _format_metric_label("gross_margin_pct") == "毛利率"
    assert _format_metric_label("net_profit_yoy") == "净利同比增长率"
    assert _format_metric_label("单季度_营业收入") == "单季度营业收入"


def test_search_metadata_is_not_shown_as_evidence() -> None:
    for junk in ("summary", "source_original", "entity_identity", "index", "name", "status",
                 "traceability_type", "site_authority", "index_time", "data_version"):
        assert not _is_substantive_metric(junk), junk
    for fact in ("pe_dynamic", "gross_margin", "revenue", "经营范围", "单季度_营业收入"):
        assert _is_substantive_metric(fact), fact


# ── 5. 目录页码回填 ───────────────────────────────────────────────────────────

TOC_HTML = '''<style>@page{size:A4;margin:16mm}section{break-before:page}
.toc-chapter,.toc-section{display:flex}.pg{margin-left:40px}</style>
<section class="cover">封面</section>
<section class="toc-page"><ol class="toc">
<li class="toc-chapter"><a href="#ch-1">第一章</a><span class="leader"></span><span class="pg"></span></li>
<li class="toc-section"><a href="#sec-1">第一节</a><span class="leader"></span><span class="pg"></span></li>
</ol></section>
<section id="ch-1"><h1>第一章</h1>正文</section>
<section id="sec-1"><h2>第一节</h2>正文</section>'''


def _browser_available() -> bool:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        return Path(p.chromium.executable_path).is_file() or Path('/Applications/Google Chrome.app').is_dir()


def test_html_toc_page_numbers_match_the_rendered_pdf() -> None:
    if not _browser_available():
        pytest.skip("PDF browser unavailable")
    from report_fusion.pdf import backfill_toc_pages, render_pdf

    pdf = asyncio.run(render_pdf(TOC_HTML))
    filled = backfill_toc_pages(TOC_HTML, pdf)
    assert filled != TOC_HTML
    numbers = re.findall(r'<span class="pg">(\d+)</span>', filled)
    assert len(numbers) == 2, filled
    assert numbers == [str(int(n)) for n in numbers]

    import pymupdf
    with pymupdf.open(stream=pdf, filetype="pdf") as doc:
        destinations = {}
        for page in doc:
            for link in page.get_links():
                if link.get("nameddest"):
                    destinations[link["nameddest"]] = str(link["page"] + 1)
    assert numbers == [destinations["ch-1"], destinations["sec-1"]]


def test_toc_backfill_leaves_html_alone_when_pages_cannot_be_resolved() -> None:
    from report_fusion.pdf import backfill_toc_pages

    assert backfill_toc_pages(TOC_HTML, b"not a pdf") == TOC_HTML
    assert backfill_toc_pages("<html>no toc</html>", b"not a pdf") == "<html>no toc</html>"


# ── 摘要导语可读化（B7）────────────────────────────────────────────────────
# reconcile_text 的审计替换句「2023-01-01至2023-12-31（年度，合并报表，CNY，元）
# 已覆盖样本4家，…」事实齐全，但占据摘要第一句时读者先看三行口径样板。
# 导语层压缩：判断在前、口径收进括号、多年度同结论合并为一句。

def test_headline_rank_segments_are_merged_into_one_judgment() -> None:
    from report_fusion.render import _readable_headline

    raw = ("；".join(
        f"{y}-01-01至{y}-12-31（年度，合并报表，CNY，元）已覆盖样本4家，"
        f"营业收入最高为北方华创，负值企业为无（仅限该期间、范围和币种的已覆盖样本）"
        for y in (2023, 2024, 2025)
    ) + "。产业链关键瓶颈在于上游零部件的国产化配套能力。")
    out = _readable_headline(raw)
    assert out.startswith("2023–2025年，4家样本公司营业收入最高为北方华创，无负值企业")
    assert "（年度合并报表口径）" in out
    assert "已覆盖样本" not in out
    assert out.count("北方华创") == 1


def test_headline_leading_connective_and_audit_boilerplate_are_stripped() -> None:
    from report_fusion.render import _readable_headline

    raw = ("但本次证据库在产业链结构维度存在关键缺口：主营构成数据缺失。"
           "该测量期间或比较结论缺乏可核对的结构化观察值，暂不作判断。")
    out = _readable_headline(raw)
    assert out.startswith("证据库在产业链结构维度存在关键缺口")
    assert "暂不作判断" not in out


def test_headline_without_rank_segments_is_untouched() -> None:
    from report_fusion.render import _readable_headline

    raw = "低空经济2025年产业规模预计突破万亿元，eVTOL整机进入适航审定阶段。"
    assert _readable_headline(raw) == raw
