"""P0-1 数值证据绑定的量级感知修复（2026-11-09 审计）。

实测：数据集按元存 396597441913.60，正文写「3,965.97亿元」，旧 R3 字面
子串匹配永远绑不上，数值语义校验把全部金额判「无据」（SEMI-Q1 277 条
unsupported_quantity 中真无出处≈0）。修复后绑定走量级变体。
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
for p in (str(ROOT), str(ROOT / "agents_core"), str(ROOT / "agents_core/chapter-writer")):
    if p not in sys.path:
        sys.path.insert(0, p)

from datetime import date

from agents_core.financial_semantics import quantity_issues
from chapter_writer.agent import magnitude_variants


def _rec(value, unit="元", metric="总市值", entity="北方华创", period="2026-11-09"):
    return {"value": str(value), "unit": unit, "metric": metric,
            "entity": entity, "period": period, "record_id": "R1"}


def test_yuan_value_binds_yi_yuan_text() -> None:
    variants = magnitude_variants("396597441913.60", "元")
    assert "3965.97亿元" in variants and "3,965.97亿元" in variants


def test_quantity_issues_accepts_scaled_amount() -> None:
    rec = _rec(396597441913.60)
    text = "截至2026-11-09，北方华创总市值为3,965.97亿元。"
    # 绑定后 refs 非空：换算等值 + 实体 + 期间全部对得上，不应再报无据
    issues = quantity_issues(text, [rec])
    assert [i for i in issues if i["code"] == "unsupported_quantity"] == [], issues


def test_quantity_issues_still_flags_wrong_amount() -> None:
    rec = _rec(396597441913.60)
    text = "截至2026-11-09，北方华创总市值为9,999.99亿元。"
    issues = quantity_issues(text, [rec])
    assert any(i["code"] == "unsupported_quantity" for i in issues), "错值必须仍被拦下"


def test_binding_fix_reduces_real_false_positives() -> None:
    """用 SEMI-Q1 真实被标记的金额做回放：修复后应可通过校验。"""
    # 审计实录：正文「8,754.69亿元」是四家市值之和（派生），单条记录无法支撑，
    # 仍应标记；「3,965.97亿元」是北方华创单家市值，修复后应放行。
    rec = _rec(396597441913.60)
    ok_text = "北方华创总市值为3,965.97亿元。"
    assert quantity_issues(ok_text, [rec]) == [] or all(
        i["code"] != "unsupported_quantity" for i in quantity_issues(ok_text, [rec]))
    derived_text = "四家公司总市值合计为8,754.69亿元。"
    issues = quantity_issues(derived_text, [rec])
    assert any(i["code"] == "unsupported_quantity" for i in issues)
