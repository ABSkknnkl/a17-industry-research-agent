"""自动补救引擎测试：智能体代替用户逐项处置补救工作台待办。

覆盖：chain_relation 范围确认、coverage 补采成功/无果降级边界声明、
chapter_gap 证据改写/历史失败后直接边界声明、source_conflict 只补采不裁决、
端点启动/重复启动守卫。
"""
import asyncio
import json

import pytest

from backend.app.core.storage import StorageManager
from backend.app.engine import auto_remediation
from backend.app.schemas.workflow import StageResult, WorkflowState

RUN = "run-test"
AS_OF = "2026-11-15"


class FakeEngine:
    def __init__(self, search_records=None):
        self._locks: dict[str, asyncio.Lock] = {}
        self._running_tasks: dict[str, asyncio.Task] = {}
        self.search_records = search_records or []
        self.search_calls: list[dict] = []

    def _run_lock(self, run_id: str) -> asyncio.Lock:
        return self._locks.setdefault(run_id, asyncio.Lock())

    async def _fetch_supplement_with_audit(self, run_id, stage, demand, as_of, **kwargs):
        self.search_calls.append({"demand": demand, "as_of": str(as_of)})
        return [dict(row) for row in self.search_records]


def make_state(chapter_issues=None) -> WorkflowState:
    return WorkflowState(
        project_id="p", run_id=RUN, revision=1, status="waiting_review",
        current_stage="report_fusion",
        stage_results={
            "chapter_write": StageResult(stage="chapter_write", status="approved", revision=1,
                data={"quality": {"issues": chapter_issues or []}}),
            "report_fusion": StageResult(stage="report_fusion", status="waiting_review", revision=1,
                data={"research_as_of": AS_OF, "quality": {"passed": False}}),
        },
    )


def make_run(tmp_path, *, dataset=None, chapter_issues=None, chapter_audit=None,
             evidence_index=None, sections=("SEC-07-03",)):
    store = StorageManager(tmp_path)
    run_dir = store.get_run_dir(RUN)
    art = run_dir / "artifacts"
    art.mkdir(parents=True, exist_ok=True)
    base_dataset = {"conflicts": [], "quality_summary": {}}
    base_dataset.update(dataset or {})
    (art / "dataset.json").write_text(json.dumps(base_dataset, ensure_ascii=False), encoding="utf-8")
    chapter_sections = [{"section_id": sid, "paragraphs": []} for sid in sections]
    (art / "chapter_result.json").write_text(json.dumps({
        "chapters": [{"chapter_id": "CH-07", "sections": chapter_sections,
                      "content_audit": chapter_audit or []}],
    }, ensure_ascii=False), encoding="utf-8")
    (art / "interpretation_report.json").write_text(json.dumps({
        "evidence_index": evidence_index or {},
    }, ensure_ascii=False), encoding="utf-8")
    (run_dir / "input_data.json").write_text(json.dumps({"review_stages": []}), encoding="utf-8")
    store.save_state(make_state(chapter_issues))
    return store


def stub_apply(monkeypatch, store, *, final_status="completed", on_apply=None):
    """Replace the real apply with a stub that bumps the revision and flips status."""
    calls = []

    async def fake_apply(run_id, expected_revision, action_ids, idempotency_key, *, store=None, engine=None):
        calls.append({"expected_revision": expected_revision, "action_ids": list(action_ids)})
        if on_apply:
            on_apply(calls[-1])
        state = store.load_state(run_id)
        store.save_state(state.model_copy(update={
            "revision": expected_revision + 1,
            "status": final_status,
            "current_stage": "report_fusion",
        }, deep=True))
        return object()

    monkeypatch.setattr(auto_remediation, "apply_remediation", fake_apply)
    return calls


def read_log(store) -> dict:
    return json.loads((store.get_run_dir(RUN) / "remediation" / "auto_log.json").read_text(encoding="utf-8"))


def test_chain_relation_auto_confirms_scope(tmp_path, monkeypatch):
    store = make_run(tmp_path, dataset={
        "industry_chain": [{"record_id": "C1"}],
        "conflicts": [],
    })
    # 直接把 chain_relation 缺口写进 chapter 质检问题，让快照构建出该项。
    state = store.load_state(RUN)
    state.stage_results["report_fusion"].data["quality"]["issues"] = ["产业链关系未完整核验：缺少可核验的工序关系"]
    store.save_state(state)
    engine = FakeEngine()
    calls = stub_apply(monkeypatch, store)

    log = asyncio.run(auto_remediation.run_auto_remediation(RUN, store=store, engine=engine))

    assert log["final_status"] == "completed"
    assert len(calls) == 1
    rows = json.loads((store.get_run_dir(RUN) / "remediation" / "actions.json").read_text(encoding="utf-8"))
    assert [row["type"] for row in rows] == ["accept_chain_scope"]
    assert all(row["actor"] == auto_remediation.ACTOR for row in rows)
    assert read_log(store)["rounds"][0]["decisions"][0]["decision"] == "accept_chain_scope"


def test_coverage_search_success_merges_records(tmp_path, monkeypatch):
    dataset = {"quality_summary": {"requirement_evidence_matrix": [
        {"requirement": {"requirement_id": "req-1", "label": "营业收入", "domain": "financials",
                          "entity_names": ["甲公司"], "period_ends": ["2024-12-31"]},
         "coverage": {"passed": False, "requirement_id": "req-1"}},
    ]}}
    store = make_run(tmp_path, dataset=dataset)
    engine = FakeEngine(search_records=[{"record_id": "R-NEW", "domain": "financials",
                                          "entity_name": "甲公司", "metric": "revenue",
                                          "value": 12.0, "unit": "亿元", "period_end": "2024-12-31"}])
    calls = stub_apply(monkeypatch, store)

    log = asyncio.run(auto_remediation.run_auto_remediation(RUN, store=store, engine=engine))

    assert log["final_status"] == "completed"
    assert engine.search_calls and "甲公司" in engine.search_calls[0]["demand"]["query_hint"]
    assert calls[0]["action_ids"], "补采成功后应直接进入应用"
    rows = json.loads((store.get_run_dir(RUN) / "remediation" / "actions.json").read_text(encoding="utf-8"))
    assert rows[0]["type"] == "supplement_search" and rows[0]["status"] == "ready"


def test_coverage_search_no_data_falls_back_to_limit_claim(tmp_path, monkeypatch):
    dataset = {"quality_summary": {"requirement_evidence_matrix": [
        {"requirement": {"requirement_id": "req-2", "label": "毛利率", "domain": "financials",
                          "entity_names": ["乙公司"], "period_ends": ["2023-12-31"]},
         "coverage": {"passed": False, "requirement_id": "req-2"}},
    ]}}
    store = make_run(tmp_path, dataset=dataset)
    engine = FakeEngine(search_records=[])
    calls = stub_apply(monkeypatch, store)

    log = asyncio.run(auto_remediation.run_auto_remediation(RUN, store=store, engine=engine))

    assert log["final_status"] == "completed"
    rows = json.loads((store.get_run_dir(RUN) / "remediation" / "actions.json").read_text(encoding="utf-8"))
    ready = [row for row in rows if row["status"] == "ready"]
    assert [row["type"] for row in ready] == ["limit_claim"]
    prepared = ready[0]["prepared"]
    assert prepared["target_id"] == "P-07-03-99" and prepared["template"] == "coverage"
    assert ready[0]["request"]["payload"]["reason"] == prepared["reason"], "payload 与 prepared 必须一致，否则 apply 校验失败"


def test_two_coverage_gaps_share_one_boundary_submission(tmp_path, monkeypatch):
    matrix = [
        {"requirement": {"requirement_id": key, "label": label, "domain": "financials"},
         "coverage": {"passed": False, "requirement_id": key}}
        for key, label in (("req-1", "毛利率"), ("req-2", "营业收入"))
    ]
    store = make_run(tmp_path, dataset={"quality_summary": {"requirement_evidence_matrix": matrix}})
    calls = stub_apply(monkeypatch, store)
    engine = FakeEngine()
    saved_progress = []
    fetch = engine._fetch_supplement_with_audit

    async def capture_progress(*args, **kwargs):
        saved_progress.append(len(read_log(store)["rounds"][-1]["decisions"]))
        return await fetch(*args, **kwargs)

    engine._fetch_supplement_with_audit = capture_progress
    log = asyncio.run(auto_remediation.run_auto_remediation(RUN, store=store, engine=engine))

    assert saved_progress == [0, 1]
    assert len(calls) == 1 and len(calls[0]["action_ids"]) == 1
    assert [row["decision"] for row in log["rounds"][0]["decisions"]] == ["limit_claim", "shared_boundary"]


def test_auto_does_not_reopen_a_verified_scoped_report(tmp_path, monkeypatch):
    store = make_run(tmp_path, chapter_issues=["CH-07 P-07-03-01 因质量问题被整段移除（缺少原文。）"])
    state = store.load_state(RUN)
    state.stage_results["report_fusion"].data.update(
        delivery_status="ready_scoped", delivery_blocked=False, verification_status="verified",
        quality={"passed": True},
    )
    store.save_state(state)
    engine = FakeEngine()
    calls = stub_apply(monkeypatch, store)

    log = asyncio.run(auto_remediation.run_auto_remediation(RUN, store=store, engine=engine))

    assert log["final_status"] == "already_deliverable"
    assert not calls and not engine.search_calls
    assert store.load_state(RUN).revision == state.revision


def test_chapter_gap_declares_boundary_not_rewrite(tmp_path, monkeypatch):
    """实证结论：自动改写在逐句核验下通过率为 0，自动通道只做边界声明，不再改写正文。"""
    chapter_issues = ["CH-07 P-07-03-01 因质量问题被整段移除（因判断缺乏独立依据。）"]
    audit = [{"location": "P-07-03-01", "original": "该环节集中度为 88.0%", "evidence_ids": ["R-EV1"]}]
    evidence_index = {"R-EV1": {"record_id": "R-EV1", "domain": "reports", "title": "行业白皮书",
                                 "metric": "industry_concentration", "value": "85%"}}
    store = make_run(tmp_path, chapter_issues=chapter_issues, chapter_audit=audit,
                     evidence_index=evidence_index)

    async def no_llm(system, user, **kwargs):  # pragma: no cover - 必须不再调用改写
        raise AssertionError("自动通道不应再尝试 LLM 改写")

    monkeypatch.setattr(auto_remediation, "_llm_json", no_llm)
    engine = FakeEngine(search_records=[])
    calls = stub_apply(monkeypatch, store)

    log = asyncio.run(auto_remediation.run_auto_remediation(RUN, store=store, engine=engine))

    assert log["final_status"] == "completed"
    rows = json.loads((store.get_run_dir(RUN) / "remediation" / "actions.json").read_text(encoding="utf-8"))
    ready = [row for row in rows if row["status"] == "ready"]
    assert [row["type"] for row in ready] == ["limit_claim"]
    assert all(row["type"] != "revise_paragraph" for row in rows), "自动通道不再改写正文"


def test_chapter_gap_attribution_needs_human(tmp_path, monkeypatch):
    """融合层「企业归属缺少来源」类段落：自动通道诚实跳过，等人工补来源。"""
    chapter_issues = ["CH-07 P-07-03-01 人工修订未通过复验：数值语义未通过"]
    store = make_run(tmp_path, chapter_issues=chapter_issues)
    state = store.load_state(RUN)
    state.stage_results["report_fusion"].data["quality"]["issues"] = [
        "P-03-03-03 企业产业链归属缺少对应来源，行业分类或财务指标不能证明环节归属，请核对并补充依据"]
    store.save_state(state)
    engine = FakeEngine(search_records=[])
    calls = stub_apply(monkeypatch, store, final_status="waiting_review")

    log = asyncio.run(auto_remediation.run_auto_remediation(RUN, store=store, engine=engine))

    rows = json.loads((store.get_run_dir(RUN) / "remediation" / "actions.json").read_text(encoding="utf-8"))
    assert all(row["type"] != "revise_paragraph" for row in rows), "自动通道不再改写正文"
    skips = [d for r in log["rounds"] for d in r.get("decisions", [])
             if d.get("decision") == "skip" and "人工补充" in str(d.get("detail", ""))]
    assert skips, "归属缺据项每轮都应被诚实跳过"


def test_purge_rejected_auto_rewrites(tmp_path, monkeypatch):
    from agents_core.remediation_boundaries import LIMITATIONS

    store = make_run(tmp_path)
    art = store.resolve_artifact_dir(RUN)
    (art / "remediation_revisions.json").write_text(json.dumps([
        {"target_kind": "paragraph", "target_id": "P-01-01-01", "text": "旧改写",
         "evidence_refs": ["R1"], "reason": "智能体依据既有证据改写段落。", "status": "pending_recheck"},
        {"target_kind": "methodology", "target_id": "P-01-01-01", "text": LIMITATIONS["coverage"],
         "evidence_refs": [], "reason": "自动补采未获得可核验数据，智能体改以研究边界声明披露该资料缺口。",
         "status": "pending_recheck", "template": "coverage"},
        {"target_kind": "paragraph", "target_id": "P-09-09-09", "text": "人工改写",
         "evidence_refs": ["R2"], "reason": "用户手工修订", "status": "pending_recheck"},
    ], ensure_ascii=False), encoding="utf-8")
    engine = FakeEngine(search_records=[])
    stub_apply(monkeypatch, store, final_status="waiting_review")

    log = asyncio.run(auto_remediation.run_auto_remediation(RUN, store=store, engine=engine))

    rows = json.loads((art / "remediation_revisions.json").read_text(encoding="utf-8"))
    kinds = sorted((row["target_kind"], row.get("reason") or "") for row in rows)
    assert ("paragraph", "用户手工修订") in kinds, "人工修订必须保留"
    assert ("methodology", LIMITATIONS["coverage"]) in kinds or any(r[0] == "methodology" for r in kinds)
    assert all(not (k == "paragraph" and r == "智能体依据既有证据改写段落。") for k, r in kinds)
    assert log["cleanup"]["purged_rejected_rewrites"] == 1


def test_chapter_gap_failed_revision_then_boundary(tmp_path, monkeypatch):
    chapter_issues = ["CH-07 P-07-03-01 人工修订未通过复验：数值语义未通过"]
    audit = [{"location": "P-07-03-01", "original": "集中度为 88.0%", "evidence_ids": ["R-EV1"]}]
    evidence_index = {"R-EV1": {"record_id": "R-EV1", "domain": "reports", "title": "白皮书"}}
    store = make_run(tmp_path, chapter_issues=chapter_issues, chapter_audit=audit,
                     evidence_index=evidence_index)
    log_path = store.get_run_dir(RUN) / "remediation"
    log_path.mkdir(parents=True, exist_ok=True)
    (log_path / "auto_log.json").write_text(json.dumps(
        {"rounds": [{"round": 1, "revision": 1, "decisions": []}], "rejected_revisions": ["P-07-03-01"]},
        ensure_ascii=False), encoding="utf-8")

    async def fail_llm(system, user, **kwargs):  # pragma: no cover - must not be called
        raise AssertionError("历史失败的段落不应再尝试改写")

    monkeypatch.setattr(auto_remediation, "_llm_json", fail_llm)
    engine = FakeEngine(search_records=[])
    calls = stub_apply(monkeypatch, store)

    log = asyncio.run(auto_remediation.run_auto_remediation(RUN, store=store, engine=engine))

    rows = json.loads((store.get_run_dir(RUN) / "remediation" / "actions.json").read_text(encoding="utf-8"))
    ready = [row for row in rows if row["status"] == "ready"]
    assert [row["type"] for row in ready] == ["limit_claim"]
    assert all(row["type"] != "supplement_search" for row in rows), "改写已失败的段落不应再补采"
    assert ready[0]["request"]["payload"]["reason"] == ready[0]["prepared"]["reason"]


def test_source_conflict_only_searches_and_never_decides(tmp_path, monkeypatch):
    dataset = {
        "financials": [
            {"record_id": "R1", "entity_name": "甲公司", "entity_code": "002085.SZ", "metric": "roe",
             "value": 8.36, "unit": "%", "period_end": "2024-12-31"},
            {"record_id": "R2", "entity_name": "甲公司", "entity_code": "002085.SZ", "metric": "roe",
             "value": 8.4, "unit": "%", "period_end": "2024-12-31"},
        ],
        "conflicts": [{"conflict_key": "c1", "entity": "甲公司", "metric": "roe",
                        "period": "2024-12-31", "record_ids": ["R1", "R2"]}],
    }
    store = make_run(tmp_path, dataset=dataset)
    engine = FakeEngine(search_records=[])
    calls = stub_apply(monkeypatch, store, final_status="waiting_review")

    log = asyncio.run(auto_remediation.run_auto_remediation(RUN, store=store, engine=engine))

    assert log["final_status"] == "waiting_review"
    assert calls == [], "无自动可解动作时不应触发应用"
    remaining = {row["category"] for row in log["remaining_manual"]}
    assert "source_conflict" in remaining


def test_auto_endpoint_guards_and_start(tmp_path, monkeypatch):
    from fastapi.testclient import TestClient
    from backend.app.api import routes
    from backend.app.main import app

    store = make_run(tmp_path)
    monkeypatch.setattr(routes, "storage", store)

    async def fake_runner(run_id):  # instant no-op
        return {}

    monkeypatch.setattr(routes, "_auto_remediation_runner", fake_runner)
    client = TestClient(app)
    body = client.post("/api/v1/runs/run-test/remediation/auto")
    assert body.status_code == 200 and body.json()["started"] is True
    status = client.get("/api/v1/runs/run-test/remediation/auto").json()
    assert status["running"] is False and status["final_status"] is None

    running_state = store.load_state(RUN).model_copy(update={"status": "running"}, deep=True)
    store.save_state(running_state)
    conflict = client.post("/api/v1/runs/run-test/remediation/auto")
    assert conflict.status_code == 409


def test_identical_limit_claim_not_resubmitted(tmp_path, monkeypatch):
    from agents_core.remediation_boundaries import LIMITATIONS

    dataset = {"quality_summary": {"requirement_evidence_matrix": [
        {"requirement": {"requirement_id": "req-3", "label": "毛利率", "domain": "financials",
                          "entity_names": ["乙公司"], "period_ends": ["2023-12-31"]},
         "coverage": {"passed": False, "requirement_id": "req-3"}},
    ]}}
    store = make_run(tmp_path, dataset=dataset)
    art = store.resolve_artifact_dir(RUN)
    (art / "remediation_revisions.json").write_text(json.dumps([{
        "target_kind": "methodology", "target_id": "P-07-03-99",
        "text": LIMITATIONS["coverage"], "evidence_refs": [],
        "reason": "自动补采未获得可核验数据，智能体改以研究边界声明披露该资料缺口。",
        "status": "pending_recheck", "template": "coverage",
    }], ensure_ascii=False), encoding="utf-8")
    engine = FakeEngine(search_records=[])
    calls = stub_apply(monkeypatch, store, final_status="waiting_review")

    log = asyncio.run(auto_remediation.run_auto_remediation(RUN, store=store, engine=engine))

    assert log["final_status"] == "waiting_review"
    assert calls == [], "已应用过的相同边界声明不应再次触发应用"
    assert log["rounds"][0]["decisions"][0]["decision"] == "already_applied"


def test_chain_scope_confirmed_only_once(tmp_path, monkeypatch):
    store = make_run(tmp_path, dataset={"industry_chain": [{"record_id": "C1"}], "conflicts": []})
    state = store.load_state(RUN)
    state.stage_results["report_fusion"].data["quality"]["issues"] = ["产业链关系未完整核验：缺少可核验的工序关系"]
    store.save_state(state)
    log_dir = store.get_run_dir(RUN) / "remediation"
    log_dir.mkdir(parents=True, exist_ok=True)
    (log_dir / "auto_log.json").write_text(json.dumps({
        "rounds": [{"round": 1, "revision": 1, "decisions": [
            {"issue_id": "chain-x", "category": "chain_relation", "decision": "accept_chain_scope"}]}],
    }, ensure_ascii=False), encoding="utf-8")
    engine = FakeEngine(search_records=[])
    calls = stub_apply(monkeypatch, store, final_status="waiting_review")

    log = asyncio.run(auto_remediation.run_auto_remediation(RUN, store=store, engine=engine))

    assert calls == []
    last_round = log["rounds"][-1]
    chain_decision = next(d for d in last_round["decisions"] if d["category"] == "chain_relation")
    assert chain_decision["decision"] == "skip"
    assert "不再重复提交" in chain_decision["detail"]
