"""无据数字分诊回归（2026-11-09）。

背景：两次基线里 `unsupported_quantity` 占质量条目 80%+，其中三类并非编造：
  A 计数/物理量纲（"样本仅 3 家""1000 米以下空域"）
  B 全库有证、段落未绑定（PB 6.6 倍来自估值表）
  C 披露/归因语境（"双值冲突未仲裁""非本报告测算""超出 1% 容差"）

本文件锁定三条边界：
  1. A/C 不再产出 unsupported_quantity；
  2. B 由 `_split_uncited` 判为 uncited_quantity，不阻断交付；
  3. 真正无据的数字（含派生指标无计算记录）一条都不能放过。

全部离线、零配额。
"""
from __future__ import annotations

from agents_core.financial_semantics import quantity_issues


def test_evidence_hashes_are_not_treated_as_financial_numbers():
    text = '证据库中记录 R-799b1daad664f9fd9b57、R-10958c9bf44075f9f6b9 是检索元数据。'
    assert not quantity_issues(text, [])
    assert quantity_issues(text + ' 中国移动营业收入999亿元。', [])


def test_financial_coverage_claim_is_checked_against_new_period():
    new = {'record_id': 'R-new', 'domain': 'financials', 'entity': '中国移动', 'metric': 'revenue',
           'value': 1009309000000, 'unit': '元', 'period': '2023-12-31', 'period_type': 'annual',
           'scope': 'consolidated', 'currency': 'CNY'}
    issue = quantity_issues('中国移动财务仅覆盖2021与2025两个年度，2022-2024年度缺失。', [], universe=[new])
    assert any(row['code'] == 'contradictory_coverage' for row in issue)
    assert not any(row['code'] == 'contradictory_coverage' for row in quantity_issues(
        '中国移动2022-2024年度净利润缺失。', [], universe=[new]))
from report_fusion.agent import _split_uncited


def _codes(text: str, refs=None) -> list[str]:
    return [item["code"] for item in quantity_issues(text, refs or [], location="probe")]


# ── A 计数与物理量纲 ──────────────────────────────────────────────────────
def test_space_definition_metres_is_not_a_financial_claim():
    assert _codes("低空经济是以1000米以下（可延伸至3000米）低空空域为依托的综合性经济形态。") == []


def test_sample_count_is_not_an_unsupported_quantity():
    assert _codes("本报告证券范围限定为3家样本公司，样本代表性存在边界。") == []


# ── C 披露与归因 ─────────────────────────────────────────────────────────
def test_attributed_forecast_is_not_treated_as_fabricated():
    assert _codes("2026年市场规模预计突破1万亿元，但该预测为国家发改委口径，非本报告测算。") == []


def test_parenthetical_institution_counts_as_attribution():
    assert _codes("eVTOL细分市场2023年9.8亿元、预计2024年17.2亿元（中商产业研究院）。") == []


def test_conflict_disclosure_is_not_an_unsupported_quantity():
    assert _codes("行业PE存在70.78倍与74.18倍双值冲突未仲裁。") == []


def test_tolerance_parameter_is_not_a_claim():
    assert _codes("数值超出1%容差或已被上游标记为冲突。") == []


# ── D 真缺口必须保留 ────────────────────────────────────────────────────
def test_unsourced_market_size_still_fails():
    assert _codes("2026年市场规模为1万亿元。") == ["unsupported_quantity"]


def test_derived_median_without_calculation_still_fails():
    assert _codes("估值对标统一采用PB中位数8.52倍。") == ["unsupported_quantity"]


def test_gross_margin_change_without_evidence_still_fails():
    assert "unsupported_quantity" in _codes("公司2025年毛利率下降3个百分点。")


# ── B 未绑定 vs 真无据 ──────────────────────────────────────────────────
PB = {"record_id": "R-PB", "entity": "盛美上海", "metric": "pb", "value": 6.645,
      "unit": "倍", "period": "2026-11-06", "period_type": "point", "scope": "consolidated"}
REV = {"record_id": "R-REV", "entity": "盛美上海", "metric": "revenue", "value": 20.24,
       "unit": "亿元", "period": "2026-09-30", "period_type": "quarter", "scope": "consolidated"}


def test_claim_supported_elsewhere_in_index_is_uncited_not_unsupported():
    blocking, uncited = _split_uncited("盛美上海 PB（倍） 6.6倍", [REV], [PB, REV], location="probe")
    assert blocking == []
    assert [item["claim"] for item in uncited] == ["6.6倍"]


def test_claim_missing_from_whole_index_stays_blocking():
    blocking, uncited = _split_uncited("盛美上海 PB（倍） 12.3倍", [REV], [PB, REV], location="probe")
    assert [item["claim"] for item in blocking] == ["12.3倍"]
    assert uncited == []
