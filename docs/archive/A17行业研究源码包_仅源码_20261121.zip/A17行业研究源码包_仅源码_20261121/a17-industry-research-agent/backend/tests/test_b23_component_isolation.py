"""B23-T9 红测：组件隔离应留痕但不阻塞（比例过高除外）。

问题（SEMI-Q4 新 run 实测）：指标卡缺证据绑定时，章节层把卡删掉、重新审计
通过，但仍把「指标卡「X」数值缺少证据绑定」写成「段落资料缺口：…」——
而该前缀会被升级为章级 issue，导致 `quality.passed=False`、报告永久
「受限草稿」。终态其实 33/33 张卡全部有证据绑定（被删的卡已不在交付件里）。

期望：
- 少量隔离（≤50%）→ 记「组件隔离」warning（不进 issues），章节可通过；
- 大面积隔离（>50%）→ 仍判未通过（防止「删光换通过」）。
"""

from __future__ import annotations

import asyncio
import json

from chapter_writer import ChapterWriterAgent, ChapterWritingRequest
from chapter_writer.models import InterpretationReport, OutlineChapter, OutlineSection

OUTLINE = [
    OutlineChapter(
        chapter_id=f"CH-{i:02d}",
        title=f"第{i}章",
        sections=[
            OutlineSection(section_id=f"SEC-{i:02d}-0{j}", title=f"节{j}", purpose="目的")
            for j in range(1, 4)
        ],
    )
    for i in range(1, 8)
]

TARGET_CHAPTER = "CH-01"
TARGET_SECTION = "SEC-01-01"


def _report() -> InterpretationReport:
    return InterpretationReport.model_validate(
        {
            "report_id": "R-B23T9",
            "subject": "测试行业",
            "as_of": "2026-09-01",
            "status": "completed",
            "insights": [],
            "evidence_index": {
                "R1": {"record_id": "R1", "domain": "industry", "entity": "测试行业",
                       "metric": "市场规模", "value": 100, "unit": "亿元", "period": "2026-06-30"}
            },
        }
    )


class _CardLLM:
    """目标节：无证据段落 + N 张缺绑定卡；其余节正常。"""

    is_available = True

    def __init__(self, unbound_cards: int, bound_cards: int = 0) -> None:
        self.unbound_cards = unbound_cards
        self.bound_cards = bound_cards

    async def generate_json(self, _system, user):
        payload = json.loads(user) if isinstance(user, str) else user
        outline = payload["outline"]
        cid = outline["chapter_id"]
        sections = []
        for sec in outline["sections"]:
            hit = cid == TARGET_CHAPTER and sec["section_id"] == TARGET_SECTION
            cards = []
            if hit:
                for i in range(self.unbound_cards):
                    cards.append({"label": f"缺据卡{i}", "value": str(10 + i), "unit": "亿元",
                                  "period": "2026-06-30", "evidence_ids": []})
                for i in range(self.bound_cards):
                    cards.append({"label": f"有据卡{i}", "value": str(20 + i), "unit": "亿元",
                                  "period": "2026-06-30", "evidence_ids": ["R1"]})
            sections.append({
                "section_id": sec["section_id"],
                "title": sec["title"],
                "purpose": sec.get("purpose", "目的"),
                "key_points": ["要点"],
                "paragraphs": [{
                    "paragraph_id": f"P-{cid[-2:]}-{sec['section_id'][-2:]}-01",
                    "kind": "analysis",
                    # 目标节不放数字，避免数值缺陷干扰本用例
                    "text": (f"第{cid[-2:]}章第{sec['section_id'][-2:]}节按既有证据梳理行业结构。"),
                    "evidence_ids": ["R1"],
                }],
                "chart_ids": [],
                "uncertainties": [],
                "metric_cards": cards,
                "comparison_table": None,
                "callouts": [],
                "layout_hint": "text_only",
            })
        return {"chapter_id": cid, "title": outline["title"], "summary": "本章摘要。", "sections": sections}


def _run(unbound: int, bound: int = 0):
    agent = ChapterWriterAgent(llm=_CardLLM(unbound, bound))
    return asyncio.run(
        agent.run(ChapterWritingRequest(report=_report(), outline=OUTLINE), save_artifacts=False)
    )


def test_small_component_isolation_does_not_block_chapter():
    """1 张坏卡 + 3 张好卡（隔离率 25%）：应通过，只留「组件隔离」warning。"""
    result = _run(unbound=1, bound=3)
    issues_text = "；".join(str(i) for i in result.quality.issues)
    assert "数值缺少证据绑定" not in issues_text, f"已隔离的卡仍进 issue：{issues_text}"
    assert result.quality.passed is True, result.quality.issues
    warnings_text = "；".join(result.warnings or [])
    assert "组件隔离" in warnings_text or "缺少证据绑定" in warnings_text, warnings_text


def test_mass_isolation_still_blocks():
    """全部卡都缺绑定（隔离率 100%）：必须仍判未通过。"""
    result = _run(unbound=3, bound=0)
    assert result.quality.passed is False, result.quality.issues
    issues_text = "；".join(str(i) for i in result.quality.issues)
    assert "段落资料缺口" in issues_text, issues_text
