"""B31 红测：指标卡的派生值（净现比等）要能绑到计算输入证据。

实测（stageprobe-...-b30pool）：CH-01 剩 7 个隔离里 3 个是「中微/拓荆/盛美
净现比」——这些值不在原始证据里，只在 `financial_ratios.calculations`
（`operating_cash_flow / parent_net_profit`）里，`_bind_metric_card`
只查原始记录，于是绑不上 → 整卡隔离。

B27 已让**段落审计**认派生值（`verified_calculations`），指标卡这条通道当时
漏了。这里补齐：派生值命中后绑定到它的**输入记录 id**（那两个真证据），
报告读者仍可逐条回溯，而不是绑一个看不见的「derived:」伪 id。
"""

from __future__ import annotations

from chapter_writer import ChapterWriterAgent, ChapterWritingRequest
from chapter_writer.models import ChapterDraft, InterpretationReport, OutlineChapter, OutlineSection

OUTLINE = [
    OutlineChapter(
        chapter_id="CH-01", title="第1章",
        sections=[
            OutlineSection(section_id=f"SEC-01-0{j}", title=f"节{j}", purpose="目的")
            for j in (1, 2, 3)
        ],
    )
]

EVIDENCE = {
    "R-ocf": {
        "record_id": "R-ocf", "domain": "financials", "entity": "中微公司",
        "metric": "operating_cash_flow", "value": 2_000_000_000.0, "unit": "元",
        "period": "2025-12-31", "period_type": "annual", "scope": "consolidated",
    },
    "R-np": {
        "record_id": "R-np", "domain": "financials", "entity": "中微公司",
        "metric": "parent_net_profit", "value": 1_840_000_000.0, "unit": "元",
        "period": "2025-12-31", "period_type": "annual", "scope": "consolidated",
    },
}

FINANCIAL_RATIOS = [{
    "company": "中微公司",
    "calculations": {
        "cash_to_net_profit": {
            "value": 1.0870869565217391,
            "formula": "operating_cash_flow/parent_net_profit",
            "input_record_ids": ["R-ocf", "R-np"],
            "period_end": "2025-12-31", "period_type": "annual",
            "scope": "consolidated", "currency": "CNY", "unit": "倍",
        }
    },
}]


class _NoopLLM:
    is_available = False

    async def generate_json(self, *_a, **_k):  # pragma: no cover
        raise AssertionError("本用例只验证审计，不调用模型")


def _chapter(card: dict) -> ChapterDraft:
    return ChapterDraft.model_validate({
        "chapter_id": "CH-01", "title": "第1章", "summary": "摘要", "used_fallback": False,
        "sections": [{
            "section_id": f"SEC-01-0{j}", "title": f"节{j}",
            "paragraphs": [{"paragraph_id": f"P-01-0{j}-01", "text": f"第{j}节正文。", "evidence_ids": []}],
            "metric_cards": [card] if j == 1 else [],
        } for j in (1, 2, 3)],
    })


def _audit(card: dict):
    agent = ChapterWriterAgent(llm=_NoopLLM())
    agent._card_evidence_pool = dict(EVIDENCE)
    chapter = _chapter(card)
    issues = agent._audit_chapter(
        chapter, OUTLINE[0], set(EVIDENCE), {},
        context={"evidence": {}, "financial_ratios": FINANCIAL_RATIOS},
        global_facts=None,
    )
    return chapter, issues


def test_derived_metric_card_binds_to_its_input_records():
    """净现比 1.09 倍由两条原始记录算出 → 应绑到那两条，而不是被隔离。"""
    card, issues = _audit({"label": "中微公司净现比", "value": "1.09", "unit": "倍",
                           "period": "2025-12-31", "evidence_ids": []})

    assert not any("指标卡" in str(i) for i in issues), issues
    bound = card.sections[0].metric_cards[0].evidence_ids
    assert set(bound) == {"R-ocf", "R-np"}, bound


def test_derived_metric_card_with_wrong_value_is_still_flagged():
    """反向守卫：1.5 倍不是 1.087 的舍入，仍须记为缺绑定。"""
    _card, issues = _audit({"label": "中微公司净现比", "value": "1.5", "unit": "倍",
                            "period": "2025-12-31", "evidence_ids": []})

    assert any("指标卡「中微公司净现比」" in str(i) for i in issues), issues


def test_derived_metric_card_for_other_entity_is_still_flagged():
    """反向守卫：主体不符不许借计算记录冒领。"""
    _card, issues = _audit({"label": "拓荆科技净现比", "value": "1.09", "unit": "倍",
                            "period": "2025-12-31", "evidence_ids": []})

    assert any("指标卡「拓荆科技净现比」" in str(i) for i in issues), issues
