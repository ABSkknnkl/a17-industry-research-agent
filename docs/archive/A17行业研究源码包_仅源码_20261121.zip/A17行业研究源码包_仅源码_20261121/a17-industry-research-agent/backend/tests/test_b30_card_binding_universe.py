"""B30 红测：指标卡应在全量证据索引里绑定，而不是只看本章检索子集。

实测（run-20261110190908 + stageprobe-...-b29bind）：

- 同一张卡「盛美上海毛利率 48.32%」在 CH-04 绑上了（本章检索到了该记录），
  在 CH-05 却被判「数值缺少证据绑定」并整卡隔离——因为 `_audit_chapter`
  把绑定池限定为 `context["evidence"]`（本章检索子集）。
- 结果 4 个章节触发「组件隔离比例过高」（57%–80%），报告内容大面积缺失。

设计取舍：卡片绑定放宽到**全量索引**，但核验标准不放宽——仍由
`quantity_issues` 校验实体/期间/指标族/数值容差，错值主体不符照样绑不上。
段落正文仍限定在本章检索子集（那是防跑题，不是防错值）。
"""

from __future__ import annotations

import json

from chapter_writer import ChapterWriterAgent, ChapterWritingRequest
from chapter_writer.models import ChapterDraft, InterpretationReport, OutlineChapter, OutlineSection

OUTLINE = [
    OutlineChapter(
        chapter_id="CH-01", title="第1章",
        sections=[
            OutlineSection(section_id=f"SEC-01-0{j}", title=f"节{j}", purpose="目的")
            for j in (1, 2, 3)
        ],
    )
]


def _report(with_index: bool = True) -> InterpretationReport:
    index = {
        "R-margin": {
            "record_id": "R-margin", "domain": "financials", "entity": "盛美上海",
            "metric": "gross_margin", "value": 48.318, "unit": "%",
            "period": "2025-12-31", "scope": "consolidated",
        }
    } if with_index else {}
    return InterpretationReport.model_validate({
        "report_id": "R-B30", "subject": "测试行业", "as_of": "2026-09-01",
        "status": "completed", "insights": [], "evidence_index": index,
    })


class _NoopLLM:
    is_available = False

    async def generate_json(self, *_a, **_k):  # pragma: no cover - 不走到这里
        raise AssertionError("本用例只验证审计，不调用模型")


def _chapter(card: dict) -> ChapterDraft:
    return ChapterDraft.model_validate({
        "chapter_id": "CH-01", "title": "第1章", "summary": "摘要", "used_fallback": False,
        "sections": [{
            "section_id": f"SEC-01-0{j}", "title": f"节{j}",
            "paragraphs": [{"paragraph_id": f"P-01-0{j}-01", "text": "正文。", "evidence_ids": []}],
            "metric_cards": [card] if j == 1 else [],
        } for j in (1, 2, 3)],
    })


def _audit(card: dict, context_evidence: dict, index_pool: dict | None = None) -> list[str]:
    agent = ChapterWriterAgent(llm=_NoopLLM())
    if index_pool is not None:
        agent._card_evidence_pool = index_pool
    return agent._audit_chapter(
        _chapter(card), OUTLINE[0], set(json.loads(json.dumps(index_pool or {}))),
        {}, context={"evidence": context_evidence}, global_facts=None,
    )


CARD = {"label": "盛美上海毛利率", "value": "48.3", "unit": "%",
        "period": "2025-12-31", "evidence_ids": []}


def test_card_binds_against_full_index_when_chapter_subset_lacks_record():
    """本章没检索到该记录，但索引里有：应绑定，不应隔离。"""
    pool = _report().evidence_index
    pool = {k: v.model_dump(mode="json") for k, v in pool.items()}

    issues = _audit(CARD, context_evidence={}, index_pool=pool)

    assert not any("指标卡" in str(i) for i in issues), issues


def test_card_without_any_matching_record_is_still_flagged():
    """反向守卫：全量索引里也没有匹配记录时，仍须记为缺绑定。"""
    pool = {k: v.model_dump(mode="json") for k, v in _report().evidence_index.items()}
    bad = {**CARD, "value": "55.5"}

    issues = _audit(bad, context_evidence={}, index_pool=pool)

    assert any("指标卡「盛美上海毛利率」" in str(i) for i in issues), issues


def test_card_for_wrong_entity_is_still_flagged():
    """反向守卫：主体不符不许借全量索引冒领。"""
    pool = {k: v.model_dump(mode="json") for k, v in _report().evidence_index.items()}
    bad = {**CARD, "label": "中微公司毛利率"}

    issues = _audit(bad, context_evidence={}, index_pool=pool)

    assert any("指标卡「中微公司毛利率」" in str(i) for i in issues), issues
