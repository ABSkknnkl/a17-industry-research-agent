"""B47-1 红测：指标名内部的空白必须归一后再查别名表。

实测（run-20261111153609，SEMI-N1）：数据集里 `financials` 有 10 条
`metric="研发费用 / 营业收入"`（斜杠两侧带空格，9.34%/12.24% 等），
而 `_FORMULA_FAMILY_ALIASES` 登记的是紧凑写法 `研发费用/营业收入`。
`metric_family` 只做 `.strip()`（仅去首尾空白），内部空格原样保留 →
精确表不中、formula 子串也不中 → 族判定退化为原字符串 →
需求 `rd_expense_ratio_series` 报「缺少指标组：研发费用率/研发费用占比/
研发投入占营业收入比例/R&D expense ratio」。

数据明明在，是归一断了。同一 bug 也影响英文别名（`revenue growth`
遇到双空格即失配）。

修法：查表时对两侧都做「去全部空白（含全角空格）」的比较，不改变任何
既有精确别名的语义，也不引入通用子串匹配（B33 教训：不能让「营业收入」
误吃「营业收入同比增长率」）。
"""

from __future__ import annotations

from agents_core.financial_semantics import metric_family


def test_halfwidth_spaces_around_slash_map_to_rd_ratio() -> None:
    """问财字段名的真实写法：斜杠两侧带半角空格。"""
    assert metric_family("研发费用 / 营业收入") == "rd_ratio"


def test_asymmetric_and_fullwidth_spaces_map_to_rd_ratio() -> None:
    assert metric_family("研发费用/ 营业收入") == "rd_ratio"
    assert metric_family("研发费用 /营业收入") == "rd_ratio"
    assert metric_family("研发费用　/　营业收入") == "rd_ratio"  # 全角空格


def test_formula_label_with_entity_and_period_prefix_still_matches() -> None:
    """卡片 label 常带实体名与期间前缀（B33 场景），空白归一并不能破坏子串匹配。"""
    assert metric_family("中微公司研发费用 / 营业收入（2026前三季度）") == "rd_ratio"


def test_english_alias_survives_extra_whitespace() -> None:
    """英文别名同样按去空白比较：'revenue growth' 遇双空格/首尾空白不应失配。"""
    assert metric_family("revenue  growth") == "revenue_yoy"
    assert metric_family(" revenue growth rate ") == "revenue_yoy"


def test_exact_aliases_keep_their_semantics() -> None:
    """回归护栏：空白归一不得让既有精确别名互相吞噬。"""
    assert metric_family("营业收入") == "revenue"
    assert metric_family("营业收入同比增长率") == "revenue_yoy"
    assert metric_family("研发费用") == "rd_expense"
    assert metric_family("研发费用率") == "rd_ratio"
    # B33 教训：复合词「净利率同比增长率」是变化值，不得当成水平值 net_margin
    assert metric_family("净利率同比增长率") != "net_margin"


def test_unknown_metric_still_round_trips() -> None:
    """未知指标保持原样返回（调用方按原字符串兜底），不得被归一出错值。"""
    assert metric_family("某个不存在的指标") == "某个不存在的指标"
