"""产业链意图透传回归（2026-11-09）。

背景：低空 LA-Q1 基线 run 的 `chain_delivery.requested=true`，但产业链图仍被
`industry_chain_not_requested` 抑制。根因是意图判定结果只用于交付裁定，
没有回写给 `ChartGenerationRequest`，图表 Agent 侧又用 subject 重算，
题目里的"产业链"因此丢失。

覆盖：
  C01 请求模型必须能携带题目原文（focus_points）。
  C02 题目含"产业链"→ 判定为需要产业链图。
  C03 系统默认注入的关注点不算用户意图。
  C04 半导体 SEMI-Q1 不含产业链诉求 → 不得误触发。
  C05 判定结果必须回写给请求（防"算了但没用"再次发生）。

全部离线、零配额。
"""
from __future__ import annotations

import inspect
from types import SimpleNamespace

from chart_generator.chain_intent import user_wants_industry_chain
from chart_generator.models import ChartGenerationRequest

from backend.app.agents.adapters import _requested_chain

LA_Q1 = (
    "中国低空经济产业链中，工业级无人机、eVTOL、低空运营服务和基础设施分别包含哪些业务？"
    "请根据公开主营业务证据识别代表性上市公司，区分实际经营企业与仅有概念关联的企业，"
    "并构建可供人工审核修订的产业链结构。"
)
SEMI_Q1 = (
    "刻蚀、薄膜沉积和清洗设备在晶圆制造中的作用及技术壁垒有何差异？"
    "请结合北方华创、中微公司、拓荆科技和盛美上海的主要产品及2023—2025年研发投入数据，"
    "分析国内半导体设备企业的技术布局与竞争优势，并区分已验证事实和推测。"
)


def test_request_model_carries_focus_points():
    assert "focus_points" in ChartGenerationRequest.model_fields
    assert ChartGenerationRequest.model_fields["focus_points"].default is None


def test_la_question_requests_industry_chain():
    assert user_wants_industry_chain("低空经济", [LA_Q1]) is True


def test_defaulted_focus_is_not_user_intent():
    # 系统默认注入的 focus_points（含"产业链"）不得被当作需求
    assert user_wants_industry_chain("低空经济", ["产业链", "龙头财务"], defaulted_focus=True) is False


def test_semi_question_does_not_request_industry_chain():
    assert user_wants_industry_chain("半导体设备", [SEMI_Q1]) is False


def test_adapter_resolves_intent_from_input_data():
    request = SimpleNamespace(
        report=SimpleNamespace(subject="低空经济"),
        want_industry_chain=None,
        defaulted_focus=False,
        preferences=SimpleNamespace(requested_types=[]),
    )
    assert _requested_chain({"focus_questions": [LA_Q1]}, request) is True

    request.report.subject = "半导体设备"
    assert _requested_chain({"focus_questions": [SEMI_Q1]}, request) is False


def test_resolved_intent_is_written_back_to_request():
    """防回归：判定结果不得只停留在局部变量里。"""
    source = inspect.getsource(inspect.getmodule(_requested_chain))
    assert "chart_request.want_industry_chain = chain_requested" in source
