"""B28 红测：把产物修到「可正式交付」的两处判定修正。

背景（run-20261110175930 + stageprobe-20261110182948 实测）：融合层已经给出
`agent_status=completed / hard_blocked=false / delivery_status=ready /
consistency_passed=true`，唯独 `quality.passed=false` 一路传导到
`state_machine.py:150`，把报告钉死在「报告存在未解决的质量或交付缺口」。

而 `quality.passed=false` 的来源有两处失真：

**失真一（S1）**：7 条 issue 里含 25 个「指标卡「X」数值缺少证据绑定」条目，
但交付件实测 **0 张无绑定卡片**——这些卡早已被 `chapter_component_isolation`
删除。`chapter_writer/agent.py:632` 的 `unresolved = list(quarantined)` 把
「已处置的隔离」当成了「未解决的残留」。

**失真二（S2）**：另有 12 段被整段移除（占正文 11.5%）。融合层 T10 已按
`loss_ratio <= 0.2` 判定「这是正常取舍」，但这只删掉了 issues 里的
`_CHAPTER_QUALITY_BLOCK`，没有传导到 `chapter_claims_recovered`——该字段
仍是 False，于是 `adapters.py:1944` 又把 `fusion_passed` 打回 False。

期望：
1. 隔离项不进 issues（只留 content_audit + warning）；
2. 隔离率 >50% 仍判未通过（防「删光换通过」，这条是安全网）；
3. 内容损失 ≤20% 且无兜底稿 → `chapter_claims_recovered=True`；
4. 内容损失 >20% 或存在兜底稿 → 仍 False（安全网）。
"""

from __future__ import annotations

import asyncio
import json

import pytest

from chapter_writer import ChapterWriterAgent, ChapterWritingRequest
from chapter_writer.models import InterpretationReport, OutlineChapter, OutlineSection

OUTLINE = [
    OutlineChapter(
        chapter_id=f"CH-{i:02d}",
        title=f"第{i}章",
        sections=[
            OutlineSection(section_id=f"SEC-{i:02d}-0{j}", title=f"节{j}", purpose="目的")
            for j in range(1, 4)
        ],
    )
    for i in range(1, 8)
]


def _report() -> InterpretationReport:
    return InterpretationReport.model_validate(
        {
            "report_id": "R-B28",
            "subject": "测试行业",
            "as_of": "2026-09-01",
            "status": "completed",
            "insights": [],
            "evidence_index": {
                "R1": {
                    "record_id": "R1",
                    "domain": "industry",
                    "entity": "测试行业",
                    "metric": "市场规模",
                    "value": 100,
                    "unit": "亿元",
                    "period": "2026-06-30",
                }
            },
        }
    )


class _LLM:
    """CH-01/SEC-01-01 同时产出「坏卡 + 无据段落」，用于复现真实的组合场景。"""

    is_available = True

    def __init__(self, unbound_cards: int = 1, bound_cards: int = 2, bad_paragraph: bool = True) -> None:
        self.unbound_cards = unbound_cards
        self.bound_cards = bound_cards
        self.bad_paragraph = bad_paragraph

    async def generate_json(self, _system, user):
        payload = json.loads(user) if isinstance(user, str) else user
        outline = payload["outline"]
        cid = outline["chapter_id"]
        sections = []
        for sec in outline["sections"]:
            hit = cid == "CH-01" and sec["section_id"] == "SEC-01-01"
            cards = []
            if hit:
                for i in range(self.unbound_cards):
                    cards.append({"label": f"缺据卡{i}", "value": str(10 + i), "unit": "亿元",
                                  "period": "2026-06-30", "evidence_ids": []})
                for i in range(self.bound_cards):
                    cards.append({"label": f"有据卡{i}", "value": "100", "unit": "亿元",
                                  "period": "2026-06-30", "evidence_ids": ["R1"]})
            text = "本节按既有证据梳理行业结构。"
            if hit and self.bad_paragraph:
                # 20% 在证据（市场规模 100 亿元）里无对应记录 → 整段移除
                text = "2025 年该行业营业收入同比增长 20%，景气度上行。"
            sections.append(
                {
                    "section_id": sec["section_id"],
                    "title": sec["title"],
                    "purpose": sec.get("purpose", "目的"),
                    "key_points": ["要点"],
                    "paragraphs": [{
                        "paragraph_id": f"P-{cid[-2:]}-{sec['section_id'][-2:]}-01",
                        "kind": "analysis",
                        "text": text,
                        "evidence_ids": [],
                    }],
                    "chart_ids": [],
                    "uncertainties": [],
                    "metric_cards": cards,
                    "comparison_table": None,
                    "callouts": [],
                    "layout_hint": "text_only",
                }
            )
        return {"chapter_id": cid, "title": outline["title"], "summary": "本章摘要。", "sections": sections}


def _run(unbound: int = 1, bound: int = 2, bad_paragraph: bool = True):
    agent = ChapterWriterAgent(llm=_LLM(unbound, bound, bad_paragraph))
    return asyncio.run(
        agent.run(ChapterWritingRequest(report=_report(), outline=OUTLINE), save_artifacts=False)
    )


# ---------------------------------------------------------------- S1

def test_isolated_cards_do_not_appear_in_issues():
    """卡片已隔离（从交付件删除），就不能再以「缺少证据绑定」出现在 issue 里。"""
    result = _run(unbound=1, bound=2)

    issues_text = "；".join(str(i) for i in result.quality.issues)
    assert "指标卡「缺据卡0」" not in issues_text, issues_text
    assert "指标卡" not in issues_text, issues_text
    # 段落被移除是真实内容缺口，必须继续留痕
    assert "因质量问题被整段移除" in issues_text, issues_text


def test_isolation_ratio_over_half_still_blocks():
    """安全网：全部卡片都被隔离（100%）时仍判未通过，防「删光换通过」。"""
    result = _run(unbound=3, bound=0, bad_paragraph=False)

    assert result.quality.passed is False, result.quality.issues
    issues_text = "；".join(str(i) for i in result.quality.issues)
    assert "组件隔离比例过高" in issues_text, issues_text


# ---------------------------------------------------------------- S2 / S3

def _chapter(used_fallback: bool = False):
    from report_fusion.models import ChapterDraft

    draft = ChapterDraft.model_validate({
        "chapter_id": "CH-01", "title": "第一章", "summary": "摘要",
        "sections": [{"section_id": "SEC-01-01", "title": "节", "paragraphs": [
            {"paragraph_id": "P-01-01-01", "text": "剩余正文。", "evidence_ids": ["R1"]}
        ]}],
    })
    draft.used_fallback = used_fallback
    return draft


GAP_ISSUES = ["段落资料缺口：CH-01 P-01-01-02 因质量问题被整段移除（数值语义未通过）"]


def _recovered(chapters, audit, issues, loss_tolerated):
    from report_fusion.agent import _chapter_claims_recovered

    return _chapter_claims_recovered(chapters, audit, issues, loss_tolerated=loss_tolerated)


def test_loss_within_tolerance_counts_as_recovered():
    """损失 ≤20% 已由融合层判定为正常取舍 → 必须传导为「可交付」。"""
    audit = [{"code": "fusion_claim_isolation", "disposition": "isolated"}]

    assert _recovered([_chapter()], audit, GAP_ISSUES, loss_tolerated=True) is True


def test_loss_beyond_tolerance_is_not_recovered():
    """损失 >20%：融合层不会给容忍，recovered 必须保持 False。"""
    audit = [{"code": "fusion_claim_isolation", "disposition": "isolated"}]

    assert _recovered([_chapter()], audit, GAP_ISSUES, loss_tolerated=False) is False


def test_fallback_chapter_never_counts_as_recovered():
    """有确定性兜底稿时不享受容忍：那是另一类问题。"""
    audit = [{"code": "fusion_claim_isolation", "disposition": "isolated"}]

    assert _recovered([_chapter(used_fallback=True)], audit, GAP_ISSUES, loss_tolerated=True) is False


def test_no_chapter_issue_is_not_recovered():
    """没有章节 issue 时 recovered 无意义，保持 False（不制造假豁免）。"""
    assert _recovered([_chapter()], [], [], loss_tolerated=True) is False
