"""B32-D4 红测：聚合卡（样本合计/中位数）要能绑到子集的全部输入记录。

实测（run-20261110192721）：「样本总市值」「样本PB中位数」「成熟盈利梯队
PE(TTM)中位数」这类聚合卡被隔离——它们的值不在任何单条记录里，而在
**样本子集**的求和/中位数里。B32 审计侧已能核验子集统计（`sample_universe`），
卡片绑定通道当时漏了。

绑定目标：子集的**全部输入记录**（25 家市值合计 → 25 条市值记录），
读者可逐条回溯，而不是绑一个看不见的合计值。
"""

from __future__ import annotations

import json

from chapter_writer import ChapterWriterAgent, ChapterWritingRequest
from chapter_writer.models import ChapterDraft, InterpretationReport, OutlineChapter, OutlineSection

OUTLINE = [
    OutlineChapter(
        chapter_id="CH-01", title="第1章",
        sections=[
            OutlineSection(section_id=f"SEC-01-0{j}", title=f"节{j}", purpose="目的")
            for j in (1, 2, 3)
        ],
    )
]


def _evidence() -> dict[str, dict]:
    ev: dict[str, dict] = {}
    # 4 家样本 + 1 家非样本（E），市值与 PB 各一条
    for i, (n, cap, pb) in enumerate([("A", 100, 10), ("B", 200, 20), ("C", 300, 30), ("D", 400, 40), ("E", 500, 50)]):
        ev[f"R-cap-{n}"] = {"record_id": f"R-cap-{n}", "domain": "financials", "entity": n,
                            "metric": "market_cap", "value": cap, "unit": "亿元",
                            "period": "2026-11-10", "period_type": "point"}
        ev[f"R-pb-{n}"] = {"record_id": f"R-pb-{n}", "domain": "financials", "entity": n,
                           "metric": "pb", "value": pb, "unit": "倍",
                           "period": "2026-11-10", "period_type": "point"}
    return ev


def _ratios() -> list[dict]:
    return [{"company": n, "valuation_tier": t} for n, t in [
        ("A", "成熟盈利"), ("B", "成熟盈利"), ("C", "成熟盈利"), ("D", "早期亏损"),
    ]]


class _NoopLLM:
    is_available = False

    async def generate_json(self, *_a, **_k):  # pragma: no cover
        raise AssertionError("本用例只验证审计，不调用模型")


def _audit(card: dict):
    agent = ChapterWriterAgent(llm=_NoopLLM())
    ev = _evidence()
    agent._card_evidence_pool = dict(ev)
    chapter = ChapterDraft.model_validate({
        "chapter_id": "CH-01", "title": "第1章", "summary": "摘要", "used_fallback": False,
        "sections": [{
            "section_id": f"SEC-01-0{j}", "title": f"节{j}",
            "paragraphs": [{"paragraph_id": f"P-01-0{j}-01", "text": f"第{j}节正文。", "evidence_ids": []}],
            "metric_cards": [card] if j == 1 else [],
        } for j in (1, 2, 3)],
    })
    issues = agent._audit_chapter(
        chapter, OUTLINE[0], set(ev), {},
        context={"evidence": {}, "financial_ratios": _ratios()},
        global_facts=None,
    )
    return chapter, issues


def test_sample_market_cap_card_binds_to_all_sample_records():
    """「4 家样本总市值 1000 亿元」= A+B+C+D → 应绑到 4 条市值记录。"""
    card, issues = _audit({"label": "4 家样本总市值", "value": "1,000", "unit": "亿元",
                           "period": "2026-11-10", "evidence_ids": []})

    assert not any("指标卡" in str(i) for i in issues), issues
    bound = set(card.sections[0].metric_cards[0].evidence_ids)
    assert bound == {"R-cap-A", "R-cap-B", "R-cap-C", "R-cap-D"}, bound


def test_sample_pb_median_card_binds_to_all_sample_records():
    """「4 家样本 PB 中位数 25 倍」= median(10,20,30,40) → 应绑到 4 条 PB 记录。"""
    card, issues = _audit({"label": "4 家样本 PB 中位数", "value": "25", "unit": "倍",
                           "period": "2026-11-10", "evidence_ids": []})

    assert not any("指标卡" in str(i) for i in issues), issues
    bound = set(card.sections[0].metric_cards[0].evidence_ids)
    assert bound == {"R-pb-A", "R-pb-B", "R-pb-C", "R-pb-D"}, bound


def test_aggregate_card_with_wrong_value_is_still_flagged():
    """反向守卫：合计写错（1500 是全库 5 家的和）→ 仍隔离。"""
    _card, issues = _audit({"label": "4 家样本总市值", "value": "1,500", "unit": "亿元",
                            "period": "2026-11-10", "evidence_ids": []})

    assert any("指标卡「4 家样本总市值」" in str(i) for i in issues), issues


def test_aggregate_card_without_sample_word_keeps_current_behavior():
    """不含「样本/梯队」措辞的卡不走聚合通道（避免误绑）。"""
    _card, issues = _audit({"label": "行业规模", "value": "1,500", "unit": "亿元",
                            "period": "2026-11-10", "evidence_ids": []})

    assert any("指标卡「行业规模」" in str(i) for i in issues), issues
