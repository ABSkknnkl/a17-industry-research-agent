"""B23-T6 红测：无可核验观测时不得生成「暂不作判断」占位句。

问题（SEMI-Q4 实测）：`reconcile_text` 把可测量句替换成事实罗列；当没有任何
可核验观测时，写入「该测量期间或比较结论缺乏可核对的结构化观察值，暂不作
判断。」——而同一段落后面紧跟具体数字，自相矛盾；同一函数还会把
「A 营收是 B 的 3.18 倍」改写成「6 家样本公司中营业收入最高为 A」——
换了话题、甚至换成别家公司的数据。

期望：无观测可列时**保留原句**并标记 `unresolved`（交给下游无据拦截），
不再输出占位句；有观测时维持事实罗列（status=reconciled）。
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
for p in (str(ROOT), str(ROOT / "agents_core"), str(ROOT / "agents_core/data-analysis")):
    if p not in sys.path:
        sys.path.insert(0, p)

from data_interpreter.measurement_facts import reconcile_text

PLACEHOLDER = "暂不作判断"


def _facts(observations=None):
    return {
        "observations": observations or [],
        "comparisons": [],
        "coverage": [],
        "rankings": [],
        "conflicts": [],
    }


def _obs(rid, entity, metric, value, period="2025-12-31", unit="亿元"):
    return {
        "record_id": rid, "entity": entity, "metric": metric, "value": value,
        "unit": unit, "period": period, "period_start": "2025-01-01",
        "period_type": "annual", "scope": "consolidated", "currency": "CNY",
        "conflicted": False,
    }


def test_no_observable_keeps_original_instead_of_placeholder():
    """原句涉 2024 年、证据只有 2025 年：无可列观测 → 保留原句，不出占位。"""
    facts = _facts([_obs("R1", "中微公司", "营业收入", 100.0)])
    checks: list[dict] = []
    text = "中微公司2024年营业收入为999亿元。"
    out = reconcile_text(text, facts, checks, location="executive_summary")
    assert PLACEHOLDER not in out, f"不得输出占位句：{out}"
    assert "999亿元" in out, f"原句应保留：{out}"
    assert checks and checks[0]["status"] == "unresolved", checks


def test_supported_observation_still_renders_fact():
    """有可核验观测时保持事实罗列（既有行为，status=reconciled）。"""
    facts = _facts([_obs("R1", "中微公司", "营业收入", 100.0)])
    checks: list[dict] = []
    text = "中微公司2025年营业收入为100亿元。"
    out = reconcile_text(text, facts, checks, location="executive_summary")
    assert checks and checks[0]["status"] == "reconciled", checks
    assert "100" in out


def test_unmeasurable_sentence_passes_through():
    """不含数值/测量词的纯叙述句原样保留（既有行为）。"""
    facts = _facts([_obs("R1", "中微公司", "营业收入", 100.0)])
    checks: list[dict] = []
    text = "行业景气度取决于下游资本开支节奏。"
    assert reconcile_text(text, facts, checks, location="x") == text
    assert checks == []
