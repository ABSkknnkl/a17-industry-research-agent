"""B24 红测：营业成本必须进货币金额族（否则轴标「亿元」而值是「元」，放大 1e8）。

问题（SEMI-Q4 第六轮实测 run-20261110144915）：图 CHART-01「半导体设备营业成本样本
对比」的 yAxis.name='亿元'，但 series.data=[7534139015.56, 23571041381.7, ...] 是元
原值——图上 75 亿成本被画成 75 亿「亿元」。融合层契约校验发现「图中数值无法由证据
按声明单位换算」并剔除了该图，因此没有污染交付，但导致「声明 ready 却缺图形」阻塞。

根因：METRIC_REGISTRY 有营业收入/归母净利润/研发费用/经营现金流等 33 个指标，唯独
没有「营业成本」；resolve_metric_meta 的兜底关键词表是
("收入","利润","资金","额","费用","资产","负债","市值","cash","profit","revenue")，
「营业成本」一个都不含 → 落进 GENERAL_NUMERIC、preferred_unit="" → 单位换算整条
链路被跳过（normalize_financial_value 只在 CURRENCY_AMOUNT 分支换算），而轴标签由
determine_series_currency_unit 按数值量级判成「亿元」。轴对、数错。

期望：
1. 「营业成本」及其同义写法归 currency_amount / 亿元；
2. 元 → 亿元换算生效；
3. 缺 raw_unit 时仍「不可比较」（V8 语义：不按量级猜倍率，防 1 万倍错误）；
4. 「营业成本率」不得被误并入金额族；
5. 营业成本与营业收入同量纲 → 必须合并单轴，不许拆双轴。
"""

from __future__ import annotations

from chart_generator.metric_guard import DimensionGuard, MetricDimension, resolve_metric_meta

# SEMI-Q4 第六轮 CHART-01 的真实观测值（单位：元）
OPERATING_COSTS_YUAN = [7534139015.56, 23571041381.7, 4240523945.89, 3507229312.66]


def test_operating_cost_is_currency_amount():
    meta = resolve_metric_meta("营业成本")
    assert meta.dimension == MetricDimension.CURRENCY_AMOUNT, meta
    assert meta.preferred_unit == "亿元", meta
    assert meta.canonical_name == "营业成本", meta


def test_operating_cost_aliases_share_one_family():
    """同义写法必须落到同一 metric code，避免同口径指标被拆成两个族。"""
    codes = {
        name: resolve_metric_meta(name).code
        for name in ("营业成本", "主营业务成本", "销售成本",
                     "operating_cost", "cost_of_revenue", "cost_of_sales")
    }
    assert len(set(codes.values())) == 1, codes
    assert next(iter(codes.values())) == "operating_cost", codes


def test_operating_cost_yuan_to_yi_conversion():
    """真实数据回归：元 → 亿元，中微公司 75.34 亿元。"""
    converted = [
        DimensionGuard.normalize_financial_value(v, "营业成本", raw_unit="元", target_unit="亿元")[0]
        for v in OPERATING_COSTS_YUAN
    ]
    assert converted[0] == 75.34139, converted
    assert converted[1] == 235.710414, converted
    assert all(abs(v) < 1e4 for v in converted), converted


def test_operating_cost_series_unit_and_values_agree():
    """轴单位与数据必须自洽：声明亿元时最大值应是百亿量级，不是 235 亿个「亿元」。"""
    unit = DimensionGuard.determine_series_currency_unit(OPERATING_COSTS_YUAN, ["元"] * 4)
    assert unit == "亿元", unit
    converted = [
        DimensionGuard.normalize_financial_value(v, "营业成本", raw_unit="元", target_unit=unit)[0]
        for v in OPERATING_COSTS_YUAN
    ]
    assert max(converted) == 235.710414, converted


def test_operating_cost_without_raw_unit_stays_incomparable():
    """缺来源单位不得按量级猜倍率（V8 安全语义），返回空单位表示不可比较。"""
    value, unit = DimensionGuard.normalize_financial_value(OPERATING_COSTS_YUAN[0], "营业成本")
    assert value == OPERATING_COSTS_YUAN[0], (value, unit)
    assert unit == "", unit


def test_operating_cost_ratio_not_treated_as_amount():
    """「营业成本率」是比率，不能因为含「成本」被并进金额族。"""
    meta = resolve_metric_meta("营业成本率")
    assert meta.dimension == MetricDimension.PERCENTAGE_RATIO, meta
    assert meta.preferred_unit == "%", meta


def test_operating_cost_and_revenue_must_share_one_axis():
    """营业成本与营业收入同量纲：应合并单轴，拆双轴属于同类指标误拆。"""
    ok, reason = DimensionGuard.is_dual_axis_compatible("营业成本", "营业收入")
    assert ok is False, reason
    assert "维度相同" in reason, reason
