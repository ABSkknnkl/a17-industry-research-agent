"""追溯调整线索的精确度（B4f）。

2026-11-09 半导体取数实测：4 家公司的年报公告正文里有两类标准模板文字

1. 「（二）公司对重大会计差错更正原因及影响的分析说明」——只有标题没有内容；
2. 「1、前期会计差错更正 (1).追溯重述法 (2).未来适用法」——选项清单。

旧实现用「全文命中 更正/追溯调整/重述 + 财务词」判定，于是这两类模板把
4 家公司 × 3 年 × 全部指标（营收、归母净利润、研发投入）24 条年度记录全部标成
`pending_restatement`，年度需求覆盖 0/24，取数循环空转重试到 no_progress。

本夹具固定收窄后的三条判据：
1. 空标题/勾选项模板不产生线索；
2. 真实发生过的追溯调整只影响**窗口内年度**与**窗口内科目**，不殃及其它年度与指标；
3. 线索本身仍然留档（即便只重分类了成本、没有命中任何财务记录）。

另有一条语义回归：解释第18号只重分类「营业成本/销售费用」，不得据此拦营业收入。
"""
from __future__ import annotations

import sys
from datetime import date, datetime, timezone
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]
for _p in ("", "agents_core", "agents_core/data-fetcher"):
    _candidate = str(_ROOT / _p) if _p else str(_ROOT)
    if _candidate not in sys.path:
        sys.path.insert(0, str(_candidate))

from data_fetcher.fusion import DataFusion  # noqa: E402
from data_fetcher.models import Domain, EventRecord, SkillResult, SourceRef  # noqa: E402

ENTITY = "北方华创"
CODE = "002371.SZ"
YEARS = (2023, 2024, 2025)


def _financials() -> SkillResult:
    row = {"股票代码": CODE, "股票简称": ENTITY}
    for year in YEARS:
        row[f"营业收入[{year}-12-31]"] = 1.0e10 + year
        row[f"归母净利润[{year}-12-31]"] = 1.0e9 + year
        row[f"销售毛利率[{year}-12-31]"] = 40.0
        row[f"研发支出[{year}-12-31]"] = 1.0e9
    return SkillResult(
        task_id="finance",
        skill_name="hithink-finance-query",
        skill_id="hithink-finance-query",
        skill_version="1",
        domain=Domain.FINANCIALS,
        query="北方华创 年度财务",
        trace_id="trace",
        retrieved_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
        success=True,
        records=[row],
    )


def _source() -> SourceRef:
    return SourceRef(
        task_id="ann",
        skill_id="announcement-search",
        skill_version="1",
        query="",
        trace_id="ann-trace",
        retrieved_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
    )


def _dataset(body: str, *, title: str = f"{ENTITY}：2024年年度报告", announce: date | None = None):
    dataset = DataFusion().fuse([_financials()], date(2026, 11, 9))
    dataset.events = [
        EventRecord(
            record_id="clue",
            entity_name=ENTITY,
            entity_code=CODE,
            title=title,
            event_type="announcement",
            announce_date=announce or date(2025, 4, 26),
            body=body,
            source=_source(),
            raw_fields={"url": "http://static.cninfo.com.cn/finalpage/2025-04-26/1223309278.PDF"},
        )
    ]
    return dataset


def _pending(dataset) -> dict:
    """只看 pending_restatement：unit_unknown 是另一条缺陷（B4d），不混进本夹具。"""
    return {
        (record.metric, record.period_end.year): "pending_restatement" in record.issues
        for record in dataset.financials
    }


HEADER_TEMPLATE = (
    "四、公司董事会对会计师事务所“非标准意见审计报告”的说明 "
    "五、公司对会计政策、会计估计变更或重大会计差错更正原因和影响的分析说明 "
    "（一）公司对会计政策、会计估计变更原因及影响的分析说明 "
    "（二）公司对重大会计差错更正原因及影响的分析说明 "
    "（三）与前任会计师事务所进行的沟通情况 （四）审批程序及其他说明"
)

OPTION_TEMPLATE = (
    "十八、 其他重要事项 1、前期会计差错更正 (1).追溯重述法 (2).未来适用法 "
    "2、重要债务重组 3、资产置换 (1).非货币性资产交换 (2).其他资产置换 4、年金计划"
)

COST_ONLY_RESTATEMENT = (
    "《企业会计准则解释第18号》“关于不属于单项履约义务的保证类质量保证的会计处理”规定，"
    "本公司对可比期间信息进行追溯调整。 营业成本 105,379,992.37 销售费用 -105,379,992.37"
)


def test_header_only_template_produces_no_clue() -> None:
    dataset = _dataset(HEADER_TEMPLATE)
    assert DataFusion._mark_unverified_restatement_clues(dataset, date(2026, 11, 9), []) == []
    assert not any(_pending(dataset).values())


def test_option_list_template_produces_no_clue() -> None:
    dataset = _dataset(OPTION_TEMPLATE)
    assert DataFusion._mark_unverified_restatement_clues(dataset, date(2026, 11, 9), []) == []
    assert not any(_pending(dataset).values())


def test_cost_only_restatement_does_not_block_revenue_or_rd() -> None:
    """解释第18号重分类成本，不等于营业收入/研发投入被重述。"""
    dataset = _dataset(COST_ONLY_RESTATEMENT)
    clues = DataFusion._mark_unverified_restatement_clues(dataset, date(2026, 11, 9), [])
    assert clues and clues[0]["status"] == "pending_verification"
    assert clues[0]["metric_scopes"] == ["gross_margin"]
    assert clues[0]["affected_years"] == [2023]
    pending = _pending(dataset)
    for year in YEARS:
        assert not pending[("revenue", year)]
        assert not pending[("parent_net_profit", year)]
        assert not pending[("rd_investment", year)]
    # 只有被重述年度的成本口径被标记
    assert pending[("gross_margin", 2023)]
    assert not pending[("gross_margin", 2024)]


def test_restatement_year_is_narrowed_to_the_context_window() -> None:
    """正文别处提到 2024/2025，不代表这两年被追溯调整。"""
    body = (
        "本报告期 2024年度 营业收入同比增长。预计 2025年度 研发投入继续增加。"
        "公司对 2023年度 营业成本进行追溯调整，调增营业成本 71,262,948.94 元。"
    )
    dataset = _dataset(body)
    DataFusion._mark_unverified_restatement_clues(dataset, date(2026, 11, 9), [])
    pending = _pending(dataset)
    assert pending[("gross_margin", 2023)]
    assert not pending[("gross_margin", 2024)]
    assert not pending[("gross_margin", 2025)]


def test_restatement_without_year_defaults_to_comparative_period() -> None:
    """年报句子没写年度时，追溯调整对象是标题年度的上一年（2024 年报 → 2023）。"""
    dataset = _dataset(
        "公司对可比期间信息进行追溯调整，调增营业成本 1,000,000.00 元。",
        announce=date(2025, 4, 26),
    )
    DataFusion._mark_unverified_restatement_clues(dataset, date(2026, 11, 9), [])
    pending = _pending(dataset)
    assert pending[("gross_margin", 2023)]
    assert not pending[("gross_margin", 2024)]
    assert not pending[("gross_margin", 2025)]


def test_standalone_correction_notice_defaults_to_announced_year() -> None:
    """单独更正公告（非年报）没写年度时，对象是公告所指年度（发布年上一年）。"""
    dataset = _dataset(
        "公司对相关财务信息进行更正，调减营业成本 1,000,000.00 元。",
        title="关于财务信息更正的公告",
        announce=date(2025, 4, 26),
    )
    DataFusion._mark_unverified_restatement_clues(dataset, date(2026, 11, 9), [])
    pending = _pending(dataset)
    assert pending[("gross_margin", 2024)]
    assert not pending[("gross_margin", 2023)]
