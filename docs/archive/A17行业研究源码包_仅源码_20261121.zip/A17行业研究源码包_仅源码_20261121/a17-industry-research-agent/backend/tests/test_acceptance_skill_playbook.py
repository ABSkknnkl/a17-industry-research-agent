"""问财技能使用手册（PLAYBOOK）的回归夹具（S1）。

背景：规划模型原先只拿到技能名、一行描述和一个「SKILL.md 文件路径」——路径它读不到。
更糟的是系统提示里写的两个参数（arguments.time_range / arguments.sort_by）网关根本不接收，
模型照着做也拿不到想要的数据，看起来就像"不会用技能"。

本夹具锁定：
1. 关键技能都带 PLAYBOOK，且能加载进 SkillSpec；
2. 手册里声明"可用参数"必须落在网关真实接收的集合内（query/page/limit/size）；
3. 手册里的正面示例必须能被编译层正常编译（不许写一条自己都编译不过的例子）；
4. 规划提示不再教模型使用 time_range / sort_by，且明确告知二者无效；
5. 暴露给模型的技能清单带 playbook，且不含文件路径。
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

_ROOT = Path(__file__).resolve().parents[2]
for _p in ("", "agents_core", "agents_core/data-fetcher"):
    _candidate = str(_ROOT / _p) if _p else str(_ROOT)
    if _candidate not in sys.path:
        sys.path.insert(0, _candidate)

from data_fetcher.agent import (  # noqa: E402
    PLANNER_SYSTEM_PROMPT,
    DataFetcherAgent,
    _compact_playbook,
)
from data_fetcher.config import Settings  # noqa: E402
from data_fetcher.skillhub import SkillHub  # noqa: E402

# 网关 payload 真正会发送的参数（见 IwencaiGateway.call）
GATEWAY_ARGUMENTS = {"query", "page", "limit", "size", "is_cache", "expand_index"}
CORE_SKILLS = (
    "hithink-finance-query",
    "hithink-astock-selector",
    "hithink-industry-query",
    "hithink-macro-query",
    "announcement-search",
    "report-search",
    "news-search",
)


@pytest.fixture(scope="module")
def hub() -> SkillHub:
    return SkillHub()


def test_core_skills_expose_playbook(hub: SkillHub) -> None:
    for name in CORE_SKILLS:
        spec = hub.catalog.get(name)
        assert spec is not None, f"技能未注册: {name}"
        assert spec.playbook, f"{name} 缺少 PLAYBOOK.json"
        assert spec.playbook.get("purpose"), f"{name} 手册缺少 purpose"


def test_playbook_only_declares_arguments_the_gateway_accepts(hub: SkillHub) -> None:
    """手册不能教模型使用网关不接收的参数。"""
    for name in CORE_SKILLS:
        playbook = hub.catalog[name].playbook
        declared = set((playbook.get("arguments") or {}).keys())
        assert declared, f"{name} 手册未声明参数"
        assert declared <= GATEWAY_ARGUMENTS, f"{name} 声明了网关不支持的参数: {declared - GATEWAY_ARGUMENTS}"


def test_playbook_good_examples_compile(hub: SkillHub) -> None:
    """正面示例必须能通过编译层——手册与代码不能各说一套。"""
    from data_fetcher.agent import _compile_query

    for name in CORE_SKILLS:
        playbook = hub.catalog[name].playbook
        examples = (playbook.get("examples") or {}).get("good") or []
        assert examples, f"{name} 至少需要一条正面示例"
        domain = hub.catalog[name].domain
        for raw in examples:
            compiled, _ = _compile_query(raw, domain=domain)
            assert compiled.strip(), f"{name} 示例编译为空: {raw!r}"


def test_planner_prompt_stops_teaching_unsupported_arguments() -> None:
    assert "写入 arguments.time_range" not in PLANNER_SYSTEM_PROMPT
    assert "写入 arguments.sort_by" not in PLANNER_SYSTEM_PROMPT
    # 必须明确告知这两个参数无效，否则模型仍会照旧写法试
    assert "arguments.time_range 不会生效" in PLANNER_SYSTEM_PROMPT
    assert "arguments.sort_by 不会生效" in PLANNER_SYSTEM_PROMPT


def test_available_skills_carries_playbook_not_file_path(hub: SkillHub) -> None:
    agent = object.__new__(DataFetcherAgent)
    agent.skillhub = hub
    catalog = agent._available_skills()
    by_name = {item["name"]: item for item in catalog}
    finance = by_name["hithink-finance-query"]
    assert finance["playbook"], "财务技能未把手册传给规划模型"
    assert "skill_document" not in finance, "不应再把文件路径当技能说明"
    assert finance["playbook"]["query_rules"], "手册压缩后不应丢失 query 规则"
    assert len(finance["playbook"]["query_rules"]) <= 4, "压缩后规则条数应有上限"


def test_compact_playbook_caps_size() -> None:
    bloated = {
        "purpose": "x" * 100,
        "arguments": {"query": "必填"},
        "query_rules": [f"rule-{index}" for index in range(10)],
        "avoid": [f"avoid-{index}" for index in range(10)],
        "examples": {"good": [f"good-{index}" for index in range(5)], "bad": [{"query": "b", "why": "w"}]},
        "fields": {f"f{index}": "v" for index in range(6)},
        "limits": ["l1", "l2", "l3"],
    }
    compact = _compact_playbook(bloated)
    assert len(compact["query_rules"]) == 4
    assert len(compact["avoid"]) == 4
    assert len(compact["good_examples"]) == 2
    assert len(compact["bad_examples"]) == 1
    assert len(compact["field_names"]) <= 3
    assert len(compact["limits"]) == 1
