"""B42：chain_delivery 透出认证视图字段（release_status + evidence_tier_summary）。

背景（B40 前后端同步检查）：B36-P3/P7 之后，前端需要渲染「产业链认证卡」
（release_status、证据分级统计、accepted_participations 等），但 fusion 阶段
data.chain_delivery 只有 accepted_participations/verified_relations 计数，没有
bundle 的 release_status 与 evidence.source_tier 分布——前端无从展示，
人工认证状态在审阅页不可见，certify 通路缺 UI 依据。

修复：
  D1 `adapters._evidence_tier_summary(evidence)` 纯函数统计三档分布。
  D2 bundle 分支回写 `chain_delivery["release_status"]` 与
     `chain_delivery["evidence_tier_summary"]`（无 bundle 分支不写，前端容错）。

全部离线、零配额。
"""
from __future__ import annotations

import inspect

from chain_research.models import ChainEvidence

from backend.app.agents import adapters


def _ev(eid: str, tier: str) -> ChainEvidence:
    return ChainEvidence(
        evidence_id=eid,
        document_id="doc_1",
        title="t",
        content_hash=f"hash_{eid}",
        source_family="static.cninfo.com.cn",
        source_tier=tier,  # type: ignore[arg-type]
        locator="p1",
        quote="原文摘录",
    )


def test_evidence_tier_summary_counts_all_tiers():
    evidence = [_ev("e1", "primary"), _ev("e2", "primary"), _ev("e3", "secondary"),
                _ev("e4", "secondary"), _ev("e5", "secondary"), _ev("e6", "unverified")]
    assert adapters._evidence_tier_summary(evidence) == {
        "primary": 2, "secondary": 3, "unverified": 1,
    }


def test_evidence_tier_summary_empty():
    assert adapters._evidence_tier_summary([]) == {
        "primary": 0, "secondary": 0, "unverified": 0,
    }


def test_chain_delivery_writes_release_status_and_tier_summary():
    """防「算了但没回写」：bundle 分支必须把两个键写进 chain_delivery。"""
    source = inspect.getsource(adapters)
    assert 'chain_delivery["release_status"] = cb.quality.release_status' in source, (
        "chain_delivery 必须回写 bundle.quality.release_status（前端认证卡数据源）"
    )
    assert 'chain_delivery["evidence_tier_summary"] = _evidence_tier_summary(cb.evidence)' in source, (
        "chain_delivery 必须回写证据分级统计（前端 badge 数据源）"
    )


def test_release_status_only_written_inside_bundle_branch():
    """无 bundle 分支不得写 release_status（键缺失即前端容错信号）。"""
    source = inspect.getsource(adapters)
    writes = [ln for ln in source.splitlines() if 'chain_delivery["release_status"]' in ln]
    assert len(writes) == 1, "release_status 只能有一个回写点（bundle 分支内）"
    assert "cb.quality" in writes[0]
