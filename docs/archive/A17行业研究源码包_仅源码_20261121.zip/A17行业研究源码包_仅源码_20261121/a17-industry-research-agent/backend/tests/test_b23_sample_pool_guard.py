"""B23-T5 红测：图表数据需求不得指向污染样本。

问题（SEMI-Q4 实测）：`_extract_data_demands` 在 comps_matrix 无 entries 时，
把 `evidence_index` 里**所有**实体塞进需求——包括 astock-selector 概念匹配
误捞的无关公司（深纺织A、深天马A、佛山照明、风华高科…）。这些公司只在
companies 域有行情行，没有财务口径记录，却成了「核心龙头多期财务走势」
的查询对象。

期望：兜底只取「有财务/估值口径记录」的实体，按记录数降序取前 8。
"""

from __future__ import annotations

import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
for p in (str(ROOT), str(ROOT / "agents_core"), str(ROOT / "agents_core/chart-generator")):
    if p not in sys.path:
        sys.path.insert(0, p)

from chart_generator.agent import ChartGeneratorAgent
from chart_generator.models import SuppressedChart


def _ev(entity, metric):
    return SimpleNamespace(entity=entity, metric=metric)


def _report(entries, evidence):
    return SimpleNamespace(
        subject="半导体设备",
        comps_matrix={"entries": entries},
        evidence_index={f"R{i}": ev for i, ev in enumerate(evidence)},
    )


def _suppressed():
    return [SuppressedChart(
        title="核心龙头多期财务走势", requested_type="combo",
        reason_code="no_time_series", reason="缺多期序列", evidence_ids=[],
    )]


def _demand_entities(entries, evidence) -> list[str]:
    agent = ChartGeneratorAgent.__new__(ChartGeneratorAgent)
    request = SimpleNamespace(report=_report(entries, evidence))
    demands = agent._extract_data_demands(request, _suppressed())
    assert demands, "应至少产出一条数据需求"
    return list(demands[0].entities)


def test_fallback_skips_entities_without_financial_records():
    """只有文本/行情列名的实体不进需求（它们是概念匹配噪音）。"""
    evidence = [
        _ev("北方华创", "revenue"), _ev("北方华创", "market_cap"),
        _ev("中微公司", "revenue"), _ev("中微公司", "market_cap"),
        _ev("拓荆科技", "revenue"), _ev("拓荆科技", "market_cap"),
        # 噪音：只有列名 metric（title/latest_price）
        _ev("深纺织A", "title"), _ev("深天马A", "title"), _ev("佛山照明", "latest_price"),
        _ev("风华高科", "latest_price"),
    ]
    entities = _demand_entities([], evidence)
    for noise in ("深纺织A", "深天马A", "佛山照明", "风华高科"):
        assert noise not in entities, f"噪音实体 {noise} 混入数据需求：{entities}"
    assert "北方华创" in entities and "中微公司" in entities


def test_fallback_ranks_by_financial_record_count():
    """证据更多的实体优先，避免被零星记录挤占名额。"""
    evidence = [_ev("北方华创", "revenue")] * 5 + [_ev("中微公司", "revenue")] * 2
    entities = _demand_entities([], evidence)
    assert entities[0] == "北方华创", entities


def test_comps_matrix_entries_still_win():
    """有 comps_matrix 时以它为准，不受兜底过滤影响。"""
    entries = [{"entity_name": "北方华创"}, {"entity_name": "中微公司"}]
    evidence = [_ev("深纺织A", "title")]
    entities = _demand_entities(entries, evidence)
    assert entities == ["北方华创", "中微公司"], entities
