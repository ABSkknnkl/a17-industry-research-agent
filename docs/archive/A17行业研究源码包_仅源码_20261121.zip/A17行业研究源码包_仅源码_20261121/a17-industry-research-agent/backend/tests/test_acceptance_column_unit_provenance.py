"""网关列级单位的落库（B4d）。

现象：半导体取数拿到 4 家公司 × 3 年的营业收入（220.79 亿等真实值），但落库记录
`unit=None / unit_provenance=unknown`，被 AB-1 排除量化，研发强度的分母永远不可用。

根因：问财 `/v1/query2data` 的每列单位（`columns[].unit = "元"/"%"`）是**回包
schema 的一部分**，不在行数据里；解析时只读 `datas`，这份元数据被整段丢掉。
`%` 类指标因为值本身带百分号才侥幸保住单位。

本夹具固定：
1. 列级 unit 作为 source_field 证据写入记录（不是"金额默认元"的猜测）；
2. 有了单位之后，年度营业收入需求可以被验收通过；
3. 没有 columns 元数据时仍然落 unknown——不退回"金额一律当元"的旧口径。
"""
from __future__ import annotations

import sys
from datetime import date, datetime, timezone
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]
for _p in ("", "agents_core", "agents_core/data-fetcher"):
    _candidate = str(_ROOT / _p) if _p else str(_ROOT)
    if _candidate not in sys.path:
        sys.path.insert(0, _candidate)

from data_fetcher.agent import DataFetcherAgent  # noqa: E402
from data_fetcher.fusion import DataFusion  # noqa: E402
from data_fetcher.models import (  # noqa: E402
    Domain,
    ResearchRequirement,
    SkillResult,
)

ROW = {
    "股票代码": "002371.SZ",
    "股票简称": "北方华创",
    "营业收入[20231231]": 22079458092.37,
    "研发支出[20231231]": 4409535588.51,
    "营业收入同比增长率[20231231]": 50.322,
}
COLUMNS = [
    {"index_name": "股票代码", "key": "股票代码", "type": "STR"},
    {"index_name": "营业收入", "key": "营业收入[20231231]", "type": "DOUBLE", "unit": "元"},
    {"index_name": "研发投入", "key": "研发支出[20231231]", "type": "DOUBLE", "unit": "元"},
    {"index_name": "营业收入(同比增长率)", "key": "营业收入同比增长率[20231231]", "type": "DOUBLE", "unit": "%"},
]


def _result(payload: dict | None) -> SkillResult:
    return SkillResult(
        task_id="annual",
        skill_name="hithink-finance-query",
        skill_id="hithink-finance-query",
        skill_version="1",
        domain=Domain.FINANCIALS,
        query="北方华创 2023年营业收入 2023年研发投入",
        trace_id="trace",
        retrieved_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
        success=True,
        records=[dict(ROW)],
        raw_payload=payload,
    )


def _record(dataset, metric: str):
    return next(record for record in dataset.financials if record.metric == metric)


def test_column_unit_is_recorded_as_source_field() -> None:
    dataset = DataFusion().fuse([_result({"columns": COLUMNS, "datas": [ROW]})], date(2026, 11, 9))
    revenue = _record(dataset, "revenue")
    assert revenue.unit == "元"
    assert revenue.unit_provenance == "source_field"
    rd = _record(dataset, "rd_investment")
    assert rd.unit == "元" and rd.unit_provenance == "source_field"
    yoy = _record(dataset, "revenue_yoy")
    assert yoy.unit == "%"


def test_revenue_requirement_passes_once_unit_is_known() -> None:
    dataset = DataFusion().fuse([_result({"columns": COLUMNS, "datas": [ROW]})], date(2026, 11, 9))
    requirement = ResearchRequirement(
        requirement_id="annual_probe",
        label="北方华创 2023年全年 revenue",
        domain=Domain.FINANCIALS,
        entity_names=["北方华创"],
        period_ends=[date(2023, 12, 31)],
        metric_families=["revenue"],
        requires_period_end=True,
    )
    coverage = DataFetcherAgent._evaluate_requirement(dataset, requirement)
    assert coverage.passed, coverage


def test_missing_column_metadata_keeps_unit_unknown() -> None:
    """没有列定义时不得把金额默认成元：宁缺勿猜。"""
    dataset = DataFusion().fuse([_result(None)], date(2026, 11, 9))
    revenue = _record(dataset, "revenue")
    assert revenue.unit is None
    assert revenue.unit_provenance == "unknown"
    assert "unit_unknown" in revenue.issues
