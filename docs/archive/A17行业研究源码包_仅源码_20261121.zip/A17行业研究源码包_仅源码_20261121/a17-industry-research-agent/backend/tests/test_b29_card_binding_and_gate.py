"""B29 红测：交付闸门的安全网 + 指标卡舍入绑定。

背景（run-20261110190908 全链路实测）：

1. **安全网被自己的豁免吞掉**：CH-01/03/05/07 出现「组件隔离比例过高」
   （57%–80%），本该按 D3 拦截，但 `_chapter_claims_recovered` 的
   `loss_tolerated` 通道只要「段落损失 ≤20%」就返回 True，不区分
   issue 里是否还有隔离率过高这类硬缺口 → 报告仍被判 ready。
   实测：报告带 27 个被删组件（4 章过半）却标记为「可正式交付」。

2. **指标卡因「舍入」绑不上**：被隔离的卡如「中科飞测PB」在证据里是
   17.779 倍，卡片写「17.8倍」；`magnitude_variants` 对百分比/倍数只
   生成 2 位与 4 位小数（"17.78"/"17.7790"），1 位小数的写法永远匹配
   不上 → 绑不上 → 隔离。而 `quantity_issues` 本身是能认的
   （17.8 ✅ / 18 ✅ / 17.6 ❌），说明是前置预筛过严，不是核验标准问题。
"""

from __future__ import annotations

import pytest

from chapter_writer.agent import _bind_metric_card, magnitude_variants

# ---------------------------------------------------------------- 安全网


def _chapter(used_fallback: bool = False):
    from report_fusion.models import ChapterDraft

    draft = ChapterDraft.model_validate({
        "chapter_id": "CH-01", "title": "第一章", "summary": "摘要",
        "sections": [{"section_id": "SEC-01-01", "title": "节", "paragraphs": [
            {"paragraph_id": "P-01-01-01", "text": "剩余正文。", "evidence_ids": ["R1"]}
        ]}],
    })
    draft.used_fallback = used_fallback
    return draft


GAP_ONLY = ["段落资料缺口：CH-01 P-01-01-02 因质量问题被整段移除（数值语义未通过）"]
GAP_WITH_ISOLATION = [
    "段落资料缺口：CH-01 CH-01 组件隔离比例过高（4/7）：SEC-01-01 指标卡「样本总市值」数值缺少证据绑定；"
    "P-01-01-02 因质量问题被整段移除（数值语义未通过）"
]


def _recovered(issues, loss_tolerated):
    from report_fusion.agent import _chapter_claims_recovered

    return _chapter_claims_recovered(
        [_chapter()], [], issues, loss_tolerated=loss_tolerated,
    )


def test_loss_tolerance_does_not_mask_high_isolation():
    """损失容忍不能覆盖「组件隔离比例过高」——删掉过半组件不是正常取舍。"""
    assert _recovered(GAP_WITH_ISOLATION, loss_tolerated=True) is False


def test_loss_tolerance_still_applies_to_paragraph_gaps():
    """回归守卫：只有段落损失时，容忍通道照旧成立（B28 的结论不能被推翻）。"""
    assert _recovered(GAP_ONLY, loss_tolerated=True) is True


def test_isolation_without_tolerance_stays_blocked():
    """没有容忍时本来就不放行，补一条防呆。"""
    assert _recovered(GAP_WITH_ISOLATION, loss_tolerated=False) is False


# ---------------------------------------------------------------- 舍入绑定


@pytest.mark.parametrize("value,unit,expected", [
    (17.779, "倍", "17.8"),
    (48.318, "%", "48.3"),
    (64.106, "%", "64.1"),
])
def test_ratio_variants_cover_one_decimal(value, unit, expected):
    """比率类（%/倍）必须生成 1 位小数写法：模型常按 1 位小数写卡。"""
    assert expected in magnitude_variants(value, unit)


@pytest.mark.parametrize("value,unit,expected", [
    (17.779, "倍", "18"),
    (48.318, "%", "48"),
])
def test_ratio_variants_cover_integer(value, unit, expected):
    """整数写法同样合法（四舍五入到个位），也要能进候选。"""
    assert expected in magnitude_variants(value, unit)


def _evidence(value: float, unit: str, entity: str = "中科飞测", metric: str = "pb") -> dict:
    return {
        "R1": {
            "record_id": "R1", "domain": "financials", "entity": entity, "metric": metric,
            "value": value, "unit": unit, "period": "2026-11-10", "scope": "consolidated",
        }
    }


def test_card_with_one_decimal_rounding_binds():
    """卡片写 17.8 倍，证据是 17.779 倍 → 应绑定（舍入不是错值）。"""
    ev = _evidence(17.779, "倍")
    from chapter_writer.agent import _evidence_variants_cache

    bound = _bind_metric_card("中科飞测PB", "17.8", "倍", ev, {"R1"}, _evidence_variants_cache(ev))
    assert bound == ["R1"]


def test_card_with_wrong_value_still_unbound():
    """反向守卫：17.6 倍与 17.779 倍相差 1%，属错值，不许借变体冒领。"""
    ev = _evidence(17.779, "倍")
    from chapter_writer.agent import _evidence_variants_cache

    bound = _bind_metric_card("中科飞测PB", "17.6", "倍", ev, {"R1"}, _evidence_variants_cache(ev))
    assert bound == []


def test_card_for_other_entity_stays_unbound():
    """主体不符不许绑定：盛美上海的卡片不能借中科飞测的记录。"""
    ev = _evidence(17.779, "倍")
    from chapter_writer.agent import _evidence_variants_cache

    bound = _bind_metric_card("盛美上海PB", "17.8", "倍", ev, {"R1"}, _evidence_variants_cache(ev))
    assert bound == []
