"""技能调用预算「不设业务上限」的回归夹具（B4c）。

背景：SEMI-Q1 单跑取数时 24 次预算被 12 个年度研发单元 + 4 次公告核对吃满，
导致另外 3 家公司的营收一次都没查，研发强度无法计算。

改法：`ResearchRequest.max_skill_calls` 默认 `None` = 不设业务上限；
真正的边界保留为 max_iterations、max_execution_seconds、查询签名去重与 no_progress。

本夹具锁定四件事：
1. 默认请求不带预算；
2. 无预算时剩余次数是「足够大」而不是负无穷或报错；
3. 显式给预算时旧语义不变（仍然会耗尽）；
4. 同一批 12 个年度单元，无预算时可一次全部接收（旧行为是 8 条封顶）。
"""
from __future__ import annotations

import sys
from datetime import date
from hashlib import sha256
from pathlib import Path

import pytest

_ROOT = Path(__file__).resolve().parents[2]
for _p in ("", "agents_core", "agents_core/data-fetcher"):
    _candidate = str(_ROOT / _p) if _p else str(_ROOT)
    if _candidate not in sys.path:
        sys.path.insert(0, _candidate)

from data_fetcher.agent import (  # noqa: E402
    DataFetcherAgent,
    _remaining_skill_calls,
)
from data_fetcher.models import (  # noqa: E402
    Domain,
    ResearchRecord,
    ResearchRequest,
    SkillTask,
    SourceRef,
    StructuredResearchDataset,
)
from data_fetcher.skillhub import SkillHub  # noqa: E402

ENTITIES = ["北方华创", "中微公司", "拓荆科技", "盛美上海"]
YEARS = [2023, 2024, 2025]
SEMI_Q1 = (
    "刻蚀、薄膜沉积和清洗设备在晶圆制造中的作用及技术壁垒有何差异？请结合北方华创、中微公司、"
    "拓荆科技和盛美上海的主要产品及2023—2025年研发投入数据，分析国内半导体设备企业的技术布局"
    "与竞争优势，并区分已验证事实和推测。"
)


def _request(**kwargs) -> ResearchRequest:
    return ResearchRequest(
        industry="半导体设备",
        focus_points=[SEMI_Q1],
        must_include_entities=ENTITIES,
        as_of=date(2026, 11, 9),
        **kwargs,
    )


def _dataset() -> StructuredResearchDataset:
    source = SourceRef(
        task_id="T0", skill_id="hithink-basicinfo-query", skill_version="1.0.0",
        query="批量基础信息", trace_id="trace-0", retrieved_at=date(2026, 11, 7),
    )
    return StructuredResearchDataset(companies=[
        ResearchRecord(
            record_id=f"C{index}", domain=Domain.COMPANIES, entity_name=name,
            entity_code=f"00{index}.SZ", metric="主营业务", value="半导体设备", source=source,
        )
        for index, name in enumerate(ENTITIES)
    ])


def _annual_tasks(request: ResearchRequest) -> tuple[list[SkillTask], list]:
    requirements = DataFetcherAgent._annual_financial_requirements(request, ENTITIES)
    tasks = []
    for requirement in requirements:
        entity = requirement.entity_names[0]
        year = requirement.period_ends[0].year
        tasks.append(SkillTask(
            task_id="annual_" + sha256(f"{entity}|{year}-12-31".encode()).hexdigest()[:12],
            skill_name="hithink-finance-query",
            arguments={"query": f"{entity} {year}年全年 研发投入"},
            purpose="年度研发投入",
            expected_fields=["研发投入"],
            requirement_ids=[requirement.requirement_id],
        ))
    return tasks, requirements


def test_default_request_carries_no_skill_call_budget() -> None:
    assert _request().max_skill_calls is None


def test_remaining_calls_is_effectively_unbounded_without_budget() -> None:
    request = _request()
    assert _remaining_skill_calls(request, 0) > 10_000
    assert _remaining_skill_calls(request, 24) > 10_000
    # 不设预算不等于负数：用过很多次仍应为正
    assert _remaining_skill_calls(request, 500) > 0


def test_explicit_budget_keeps_old_semantics() -> None:
    request = _request(max_skill_calls=5)
    assert _remaining_skill_calls(request, 0) == 5
    assert _remaining_skill_calls(request, 4) == 1
    assert _remaining_skill_calls(request, 5) == 0


def test_zero_budget_is_rejected() -> None:
    with pytest.raises(Exception):
        _request(max_skill_calls=0)


def test_annual_cells_are_not_capped_by_budget_when_unbounded() -> None:
    """12 个年度单元在同一轮里应全部被接收；旧预算下只能收 8 条。"""
    request = _request()
    tasks, requirements = _annual_tasks(request)
    agent = object.__new__(DataFetcherAgent)
    agent.skillhub = SkillHub()
    accepted, errors = agent._validate_tasks(
        tasks,
        dataset=_dataset(),
        remaining=_remaining_skill_calls(request, 0),
        used_task_ids=set(),
        completed_signatures=set(),
        successful_task_ids=set(),
        requirements=requirements,
        must_include_entities=ENTITIES,
    )
    assert len(accepted) == 12, [e.message for e in errors]
    assert not errors
