"""B23-T2 红测：供应链上下游需求的域与可接受技能必须自洽。

问题（SEMI-Q4 实测）：`_baseline_requirements` 造出的 `supply_chain_relations`
需求 `domain=INDUSTRY_CHAIN`，可接受技能却是 announcement/report/news-search——
这三类记录落在 NEWS/REPORTS 域。于是：
1. `records_for(INDUSTRY_CHAIN)` 只拿到 business-query 的结构化行，全部被
   `source_mismatch` 拒掉 → 该需求 0 证据、必 FAIL（离线回放实测：换到
   NEWS 域立刻 PASS，753 条证据）。
2. 更糟的是连坐：`_coverage` 用「同域所有 hard 需求是否全过」判域覆盖，
   这个永假需求把整个 industry_chain 域判成 missing_domains，即使该域
   有 707 条合格记录。
"""

from __future__ import annotations

import sys
from datetime import date
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
for p in (str(ROOT), str(ROOT / "agents_core"), str(ROOT / "agents_core/data-fetcher")):
    if p not in sys.path:
        sys.path.insert(0, p)

from data_fetcher.agent import DataFetcherAgent
from data_fetcher.models import Domain, ResearchRequirement


def _request(focus: list[str]):
    return SimpleNamespace(focus_points=focus, data_requirements=[])


def _supply_requirement() -> ResearchRequirement:
    reqs = DataFetcherAgent._baseline_requirements(
        _request(["半导体设备 供应链上下游关系与供应商、客户结构"]),
        [Domain.INDUSTRY_CHAIN, Domain.NEWS],
    )
    return next(r for r in reqs if r.requirement_id == "supply_chain_relations")


def _news_rec(rid: str = "N1", text: str = "公司披露主要供应商与客户结构，前五大客户集中度较高"):
    return SimpleNamespace(
        record_id=rid,
        domain=Domain.NEWS,
        entity_name=None,
        entity_code=None,
        metric="title",
        value=text,
        unit=None,
        period_end=date(2025, 6, 30),
        period_type="point",
        published_at=date(2025, 6, 30),
        issues=[],
        source=SimpleNamespace(skill_id="announcement-search", status="verified", query="q"),
        raw_fields={"summary": text},
    )


def _chain_rec(rid: str = "C1"):
    return SimpleNamespace(
        record_id=rid,
        domain=Domain.INDUSTRY_CHAIN,
        entity_name="北方华创",
        entity_code="002371.SZ",
        metric="业务收入",
        value=100000000,
        unit="元",
        period_end=date(2025, 12, 31),
        period_type="annual",
        published_at=None,
        issues=[],
        source=SimpleNamespace(skill_id="hithink-business-query", status="verified", query="q"),
        raw_fields={},
    )


def _dataset(chain_records, news_records):
    def records_for(domain):
        if domain == Domain.INDUSTRY_CHAIN:
            return list(chain_records)
        if domain == Domain.NEWS:
            return list(news_records)
        return []

    return SimpleNamespace(records_for=records_for, companies=[], conflicts=[], research_as_of=None)


def test_supply_chain_requirement_targets_a_text_domain():
    """需求必须落在文本域（NEWS），而不是只装结构化业务行的 INDUSTRY_CHAIN。

    否则「可接受技能 ∈ {announcement, report, news}」与「域内记录全来自
    business-query」互斥，需求在数学上不可能通过。
    """
    req = _supply_requirement()
    assert req.domain == Domain.NEWS, (
        f"supply_chain_relations 的域是 {req.domain}，与可接受技能 "
        f"{req.acceptable_skill_ids} 不在同一域，需求永远无法满足"
    )


def test_supply_chain_requirement_passes_with_real_text_evidence():
    req = _supply_requirement()
    dataset = _dataset([_chain_rec()], [_news_rec()])
    coverage = DataFetcherAgent._evaluate_requirement(dataset, req)
    assert coverage.passed, coverage.missing
    assert coverage.evidence_count >= 1


def test_supply_chain_requirement_still_blocks_without_text_evidence():
    """只有结构化业务行、没有供应商/客户文本时必须仍然 FAIL（不放松门禁）。"""
    req = _supply_requirement()
    unrelated = _news_rec("N2", "公司发布年度业绩预告，营业收入同比增长")
    dataset = _dataset([_chain_rec()], [unrelated])
    coverage = DataFetcherAgent._evaluate_requirement(dataset, req)
    assert not coverage.passed, "无供应商/客户文本证据时不应放行"


def test_industry_chain_domain_is_not_collateral_damage():
    """供应链需求通过后，industry_chain 域覆盖不得被连坐判缺。"""
    reqs = DataFetcherAgent._baseline_requirements(
        _request(["半导体设备 供应链上下游关系与供应商、客户结构"]),
        [Domain.INDUSTRY_CHAIN, Domain.NEWS],
    )
    dataset = _dataset([_chain_rec()], [_news_rec()])
    coverage = DataFetcherAgent._coverage(dataset, [Domain.INDUSTRY_CHAIN, Domain.NEWS], reqs)
    assert Domain.INDUSTRY_CHAIN not in coverage.missing_domains, coverage.missing_domains
