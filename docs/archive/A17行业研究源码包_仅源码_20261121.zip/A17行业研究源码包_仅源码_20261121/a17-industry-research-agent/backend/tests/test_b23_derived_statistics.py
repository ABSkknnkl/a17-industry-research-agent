"""B23-T3 红测：派生统计量核验通道（合计/中位数/区间）。

问题（SEMI-Q4 实测）：报告核心结论大量使用派生量——「样本总市值 16,548.65
亿元」「PE 中位数 54.8 倍」「毛利率中枢 40.95%」——这些值不可能由单条证据
支撑，旧校验一律判 unsupported。该 run 因此产生 160 条 unsupported_quantity，
12 张指标卡被融合层删除，`formal_verified=false`，报告永久「受限草稿」。

设计：用**同族同期成分重建**统计量，匹配则放行。
安全约束（必须同时满足）：
- 成分必须同 metric family、同期间（year 匹配）、单位可换算
- 合计/中位数要求成分 ≥3；区间要求 ≥2
- 重建值与断言值在容差（绝对容差 或 1% 相对）内
- 占比不重建（需分子分母配对，另行处理，保持拦截）
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
for p in (str(ROOT), str(ROOT / "agents_core")):
    if p not in sys.path:
        sys.path.insert(0, p)

from agents_core.financial_semantics import quantity_issues


def _rec(rid: str, entity: str, metric: str, value: float, unit: str = "元",
         period: str = "2025-12-31") -> dict:
    return {"record_id": rid, "entity": entity, "metric": metric, "value": value,
            "unit": unit, "period": period, "period_type": "annual"}


_CAPS = [
    _rec("R1", "北方华创", "总市值", 3.9659e11),
    _rec("R2", "中微公司", "总市值", 2.2e11),
    _rec("R3", "盛美上海", "总市值", 1.5e11),
]
# 合计 = 7.6659e11 元 = 7665.9 亿元


def _codes(text: str, refs: list[dict]) -> list[str]:
    return [i["code"] for i in quantity_issues(text, refs, universe=refs)]


# ── 合计 ────────────────────────────────────────────────────────────────────

def test_true_sum_is_accepted():
    codes = _codes("样本总市值合计 7,665.9亿元。", _CAPS)
    assert codes == [], codes


def test_wrong_sum_is_blocked():
    codes = _codes("样本总市值合计 12,000亿元。", _CAPS)
    assert "unsupported_quantity" in codes


def test_sum_needs_at_least_three_components():
    """只有 2 个成分时不足以证明「样本合计」，必须保持拦截。"""
    codes = _codes("样本总市值合计 6,165.9亿元。", _CAPS[:2])
    assert "unsupported_quantity" in codes


# ── 中位数 ──────────────────────────────────────────────────────────────────

_PE = [
    _rec("P1", "北方华创", "市盈率(TTM)", 55.14, "倍"),
    _rec("P2", "中微公司", "市盈率(TTM)", 43.19, "倍"),
    _rec("P3", "盛美上海", "市盈率(TTM)", 62.50, "倍"),
]


def test_true_median_is_accepted():
    codes = _codes("样本市盈率中位数 55.14倍。", _PE)
    assert codes == [], codes


def test_wrong_median_is_blocked():
    codes = _codes("样本市盈率中位数 30.00倍。", _PE)
    assert "unsupported_quantity" in codes


# ── 区间 ────────────────────────────────────────────────────────────────────

_GROWTH = [
    _rec("G1", "北方华创", "营业收入同比增长率", -1.77, "%"),
    _rec("G2", "中微公司", "营业收入同比增长率", 36.62, "%"),
    _rec("G3", "拓荆科技", "营业收入同比增长率", 60.42, "%"),
]


def test_value_inside_range_is_accepted():
    codes = _codes("样本营收增速介于 -1.77% 至 60.42% 区间。", _GROWTH)
    assert codes == [], codes


def test_value_outside_range_is_blocked():
    codes = _codes("样本营收增速介于 -50.00% 至 60.42% 区间。", _GROWTH)
    assert "unsupported_quantity" in codes


# ── 安全边界 ────────────────────────────────────────────────────────────────

def test_share_is_not_reconstructed():
    """占比需要分子/分母配对，本通道不放行（避免用任意同族值凑比例）。"""
    codes = _codes("头部两强合计占比 38.4%。", _CAPS)
    assert "unsupported_quantity" in codes


def test_family_mismatch_is_blocked():
    """市值合计不能支撑营收断言。"""
    codes = _codes("样本营业收入合计 7,665.9亿元。", _CAPS)
    assert "unsupported_quantity" in codes


def test_without_family_hint_nothing_is_reconstructed():
    """上下文没有指标词时不做重建，避免任意数值碰巧命中。"""
    codes = _codes("样本合计 7,665.9亿元。", _CAPS)
    assert "unsupported_quantity" in codes
