"""样本主题解析与角色去重回归（2026-11-09）。

背景：半导体基线 `sample_roles=[]`，三档样本分级整体失效——原因不是缺少机制，
而是"半导体设备"与参考库主题"半导体/集成电路"不相等，解析失败后静默返回空；
下游契约是"sample_roles 为空不过滤"，于是概念股被当核心样本。

同时 `sample_roles` 按 company 行追加，低空 425 条只对应 68 家（约 6 倍重复），
会污染核心样本数、估值横截面与图表样本。

覆盖：
  T01 精确 / 别名 / 分段包含 三种解析路径；
  T02 解析不到必须返回 None（调用方显式告警，不得静默降级）；
  T03 角色去重保留最高档并合并证据；
  T04 不去重不得改变实体数量语义。

全部离线、零配额。
"""
from __future__ import annotations

from data_fetcher.fusion import _dedupe_sample_roles, resolve_theme_name
from data_fetcher.models import SampleRole

THEMES = [
    {"theme_name": "半导体/集成电路"},
    {"theme_name": "低空经济"},
    {"theme_name": "人形机器人/智能制造"},
    {"theme_name": "新能源汽车"},
]


def test_exact_theme_name_resolves():
    assert resolve_theme_name(THEMES, "低空经济") == "低空经济"


def test_domain_wording_maps_to_segmented_theme():
    # 用户说"半导体设备"，参考库叫"半导体/集成电路"
    assert resolve_theme_name(THEMES, "半导体设备") == "半导体/集成电路"


def test_alias_still_works():
    assert resolve_theme_name(THEMES, "具身智能") == "人形机器人/智能制造"


def test_normalized_match_ignores_separators_and_spaces():
    assert resolve_theme_name(THEMES, "半导体 / 集成电路") == "半导体/集成电路"


def test_unknown_theme_returns_none_instead_of_silent_empty():
    assert resolve_theme_name(THEMES, "不存在的主题") is None


def test_role_dedupe_keeps_highest_tier_and_merges_evidence():
    roles = [
        SampleRole(entity_name="甲", role="concept_background", reason="概念", evidence_ids=["e1"]),
        SampleRole(entity_name="甲", role="core_verified", reason="实际经营", evidence_ids=["e2"]),
        SampleRole(entity_name="乙", role="pending_verification", reason="待核验", evidence_ids=[]),
    ]
    out = {item.entity_name: item for item in _dedupe_sample_roles(roles)}
    assert set(out) == {"甲", "乙"}
    assert out["甲"].role == "core_verified"
    assert out["甲"].evidence_ids == ["e1", "e2"]
    assert out["乙"].role == "pending_verification"


def test_dedupe_does_not_downgrade_core_verified():
    roles = [
        SampleRole(entity_name="丙", role="core_verified", reason="", evidence_ids=["a"]),
        SampleRole(entity_name="丙", role="concept_background", reason="", evidence_ids=["b"]),
    ]
    out = _dedupe_sample_roles(roles)
    assert len(out) == 1 and out[0].role == "core_verified"
