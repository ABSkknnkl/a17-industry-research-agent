"""B23-T8 红测：引用列表截断 + 去掉冗余固定附加句。

问题（SEMI-Q4 实测）：
1. 单条结论挂 **77 个来源**（全文 354 次来源引用），引用失去定位意义；
2. `reconcile_text` 在涉增速句子后固定追加「增长率的变化不直接代表收入
   或利润金额的变化」——每句都挂一遍，纯噪音，且把摘要撑成模板串。
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
for p in (str(ROOT), str(ROOT / "agents_core"), str(ROOT / "agents_core/data-analysis"),
          str(ROOT / "agents_core/report-fusion")):
    if p not in sys.path:
        sys.path.insert(0, p)

from data_interpreter.measurement_facts import reconcile_text
from report_fusion.render import _citations

MAX_SHOWN = 8


def test_citations_truncate_long_lists():
    lookup = {f"R{i}": i for i in range(1, 80)}
    out = _citations([f"R{i}" for i in range(1, 78)], lookup)
    assert len(out) < 120, f"引用列表过长：{out[:160]}"
    assert "等77项" in out or "等 77 项" in out, out
    assert out.count("来源") == MAX_SHOWN, out


def test_citations_short_list_unchanged():
    lookup = {"R1": 1, "R2": 2}
    assert _citations(["R1", "R2"], lookup) == "[来源1,来源2]"


def test_citations_empty():
    assert _citations([], {"R1": 1}) == ""


def test_no_redundant_growth_disclaimer():
    facts = {
        "observations": [{
            "record_id": "R1", "entity": "北方华创", "metric": "营业收入同比增长率",
            "value": -1.77, "unit": "%", "period": "2025-12-31", "period_start": "2025-01-01",
            "period_type": "annual", "scope": "consolidated", "currency": "CNY", "conflicted": False,
        }],
        "comparisons": [], "coverage": [], "rankings": [], "conflicts": [],
    }
    checks: list[dict] = []
    out = reconcile_text(
        "北方华创2025年营业收入同比增长率为-1.77%。", facts, checks, location="executive_summary"
    )
    assert "增长率的变化不直接代表" not in out, out
    assert "-1.77" in out, out
