from __future__ import annotations

import asyncio
import json
from datetime import date
from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import pytest

from backend.app.agents.adapters import FiveAgentsAdapter
from backend.app.core.storage import storage
from backend.app.engine.state_machine import assess_stage_progression
from backend.app.schemas.workflow import StageResult


_DOMAINS = (
    "industry",
    "companies",
    "financials",
    "macro",
    "industry_chain",
    "reports",
    "news",
)


class _Dataset:
    def __init__(self, **domains):
        for domain in _DOMAINS:
            setattr(self, domain, list(domains.get(domain, [])))
        self.events = list(domains.get("events", []))
        self.quality_summary = {}

    def all_records(self):
        return [record for domain in _DOMAINS for record in getattr(self, domain)]


def _coverage_report(
    status="completed",
    *,
    appendix=None,
    anomalies=None,
    validations=None,
):
    return SimpleNamespace(
        status=status,
        data_quality_appendix=appendix or {},
        anomalies=list(anomalies or []),
        cross_validations=list(validations or []),
        analysis_facts={},
        semantic_checks=[],
        comps_matrix=None,
        warnings=[],
    )


def _build_coverage(dataset, report, chain_context=None):
    from backend.app.agents.coverage import build_dimension_coverage

    return build_dimension_coverage(dataset, report, chain_context)


def _by_dimension(rows):
    return {row["dimension"]: row for row in rows}


def test_event_only_evidence_is_partial_not_quantitatively_covered():
    dataset = _Dataset(events=[SimpleNamespace(record_id="E-1")])
    rows = _by_dimension(_build_coverage(dataset, _coverage_report("partial")))

    assert rows["macro_policy"]["status"] == "partial"
    assert rows["finance"]["status"] == "missing"
    assert rows["industry"]["status"] == "missing"
    assert rows["competition"]["status"] == "missing"
    assert rows["risk"]["status"] == "missing"
    assert all(row["status"] != "covered" for row in rows.values())


def test_empty_dataset_has_no_covered_dimensions():
    rows = _build_coverage(_Dataset(), _coverage_report("failed"))
    assert {row["status"] for row in rows} == {"missing"}


def test_financial_and_macro_gaps_are_explicit():
    dataset = _Dataset(
        industry=[object()],
        companies=[object()],
        industry_chain=[object()],
    )
    rows = _by_dimension(
        _build_coverage(dataset, _coverage_report(anomalies=[SimpleNamespace()]))
    )

    assert rows["finance"]["status"] == "missing"
    assert rows["macro_policy"]["status"] == "missing"
    assert rows["industry"]["status"] == "covered"
    assert rows["competition"]["status"] == "covered"


def test_unmet_financial_requirement_downgrades_coverage():
    dataset = _Dataset(financials=[object()])
    report = _coverage_report(
        appendix={
            "requested_financial_coverage": [
                {"domain": "financials", "passed": False, "missing": ["2025 年营业收入"]}
            ]
        }
    )
    rows = _by_dimension(_build_coverage(dataset, report))
    assert rows["finance"]["status"] == "partial"
    assert "2025" in rows["finance"]["reason"]


def test_complete_evidence_and_actual_risk_review_can_be_covered():
    dataset = _Dataset(
        industry=[object()],
        companies=[object()],
        financials=[object()],
        macro=[object()],
        industry_chain=[object()],
    )
    rows = _by_dimension(
        _build_coverage(dataset, _coverage_report(anomalies=[SimpleNamespace()]))
    )
    assert all(row["status"] == "covered" for row in rows.values())


def test_no_anomalies_does_not_prove_risk_review_completed():
    dataset = _Dataset(financials=[object()])
    rows = _by_dimension(_build_coverage(dataset, _coverage_report()))
    assert rows["risk"]["status"] == "missing"
    assert "无异常" in rows["risk"]["reason"]


def _analysis_report(status: str):
    from data_interpreter.models import DataQualityAssessment, InterpretationReport

    return InterpretationReport(
        report_id=f"REP-{status.upper()}",
        subject="测试行业",
        as_of=date(2026, 11, 16),
        status=status,
        semantic_status="skipped",
        executive_summary="仅用于状态契约测试",
        data_quality=DataQualityAssessment(
            record_count=0,
            numeric_record_count=0,
            dated_numeric_record_count=0,
            source_count=0,
            records_with_issues=0,
            conflict_count=0,
            analyzability_score=0.0,
            limitations=["没有量化记录"],
        ),
        warnings=["量化记录缺失"],
    )


def _seed_analysis_input(tmp_path, monkeypatch, run_id: str):
    monkeypatch.setattr(storage, "base_dir", tmp_path)
    run_dir = storage.get_run_dir(run_id)
    artifact_dir = run_dir / "artifacts"
    artifact_dir.mkdir(parents=True, exist_ok=True)
    (artifact_dir / "dataset.json").write_text(
        json.dumps({"subject": "测试行业", "events": []}), encoding="utf-8"
    )
    (run_dir / "input_data.json").write_text(
        json.dumps({"input_data": {"industry_topic": "测试行业"}}), encoding="utf-8"
    )
    return artifact_dir


@pytest.mark.parametrize("status", ["partial", "failed"])
def test_analysis_adapter_preserves_native_status_quality_and_warnings(
    tmp_path, monkeypatch, status
):
    run_id = f"analysis-native-{status}"
    _seed_analysis_input(tmp_path, monkeypatch, run_id)

    with patch(
        "data_interpreter.agent.DataInterpreterAgent.run", new_callable=AsyncMock
    ) as run:
        run.return_value = _analysis_report(status)
        result = asyncio.run(
            FiveAgentsAdapter.run_data_interpreter(run_id=run_id, industry="测试行业")
        )

    assert result.data["agent_status"] == status
    assert result.data["quality"]["passed"] is False
    assert result.data["quality"]["record_count"] == 0
    assert result.data["warnings"] == ["量化记录缺失"]
    assert result.status == ("failed" if status == "failed" else "waiting_review")
    if status == "failed":
        assert result.error
        assert assess_stage_progression(result, "data_interpret") == (
            False,
            result.error,
        )


def test_analysis_native_failure_cannot_use_events_to_reach_downstream():
    result = StageResult(
        stage="data_interpret",
        status="waiting_review",
        data={
            "agent_status": "failed",
            "domains": {"events": 2},
            "total_records": 2,
        },
        error="分析执行失败",
    )
    allowed, reason = assess_stage_progression(result, "data_interpret")
    assert allowed is False
    assert reason == "分析执行失败"


def test_analysis_adapter_returns_the_published_comparable_company_matrix(tmp_path, monkeypatch):
    from data_interpreter.models import PeerCompsEntry, PeerCompsMatrix

    run_id = "analysis-peer-comps"
    artifact_dir = _seed_analysis_input(tmp_path, monkeypatch, run_id)
    report = _analysis_report("completed")
    report.comps_matrix = PeerCompsMatrix(
        entries=[PeerCompsEntry(company_name="比亚迪", company_code="002594.SZ", pe_ttm=0)],
    )

    with patch("data_interpreter.agent.DataInterpreterAgent.run", new_callable=AsyncMock) as run:
        run.return_value = report
        result = asyncio.run(
            FiveAgentsAdapter.run_data_interpreter(run_id=run_id, industry="测试行业")
        )

    published = json.loads((artifact_dir / "interpretation_report.json").read_text(encoding="utf-8"))
    assert result.data["comps_matrix"] == published["comps_matrix"]
    assert result.data["comps_matrix"]["entries"][0]["company_name"] == "比亚迪"


def _seed_chart_input(tmp_path, monkeypatch, run_id: str, chart_options: dict):
    artifact_dir = _seed_analysis_input(tmp_path, monkeypatch, run_id)
    (artifact_dir / "interpretation_report.json").write_text(
        json.dumps(
            {
                "report_id": "REP-CHART",
                "subject": "测试行业",
                "as_of": "2026-11-16",
                "status": "completed",
                "key_metrics": [],
                "trends": [],
                "insights": [],
                "content_outline": [],
                "evidence_index": {},
                "warnings": [],
            }
        ),
        encoding="utf-8",
    )
    run_dir = storage.get_run_dir(run_id)
    (run_dir / "input_data.json").write_text(
        json.dumps(
            {
                "input_data": {
                    "industry_topic": "测试行业",
                    "chart_generate_options": chart_options,
                }
            }
        ),
        encoding="utf-8",
    )


def test_explicit_no_chart_mode_is_a_successful_result(tmp_path, monkeypatch):
    run_id = "chart-explicit-none"
    _seed_chart_input(tmp_path, monkeypatch, run_id, {"chart_mode": "none"})
    result = asyncio.run(FiveAgentsAdapter.run_chart_generator(run_id=run_id))

    assert result.status == "waiting_review"
    assert result.data["agent_status"] == "completed"
    assert result.data["chart_mode"] == "none"
    assert result.data["quality"]["passed"] is True
    assert result.data["warnings"] == []
    assert assess_stage_progression(result, "chart_generate")[0] is True


@pytest.mark.parametrize("native_status", ["partial", "failed"])
def test_chart_adapter_preserves_requested_shortfall_and_failure(
    tmp_path, monkeypatch, native_status
):
    from chart_generator.models import ChartGenerationResult, ChartQualityReport

    run_id = f"chart-requested-{native_status}"
    _seed_chart_input(
        tmp_path,
        monkeypatch,
        run_id,
        {"requested_chart_count": 2, "want_industry_chain": False},
    )
    chart_result = ChartGenerationResult(
        run_id=run_id,
        source_report_id="REP-CHART",
        subject="测试行业",
        as_of=date(2026, 11, 16),
        status=native_status,
        charts=[],
        quality=ChartQualityReport(
            passed=False,
            ready_count=0,
            suppressed_count=0,
            issues=["没有合格图表"],
        ),
        warnings=["没有合格图表"],
    )

    with patch("chart_generator.agent.ChartGeneratorAgent.run", new_callable=AsyncMock) as run:
        run.return_value = chart_result
        result = asyncio.run(FiveAgentsAdapter.run_chart_generator(run_id=run_id))

    assert result.data["agent_status"] == native_status
    assert result.data["quality"]["passed"] is False
    assert result.data["quality"]["requested_count"] == 2
    assert "没有合格图表" in result.data["warnings"]
    assert result.status == ("failed" if native_status == "failed" else "waiting_review")
    if native_status == "partial":
        assert assess_stage_progression(result, "chart_generate")[0] is True
    else:
        assert result.error
        assert assess_stage_progression(result, "chart_generate")[0] is False


def test_analysis_artifact_contains_persisted_dimension_coverage(tmp_path, monkeypatch):
    run_id = "analysis-dimension-artifact"
    artifact_dir = _seed_analysis_input(tmp_path, monkeypatch, run_id)
    with patch("data_interpreter.agent.DataInterpreterAgent.run", new_callable=AsyncMock) as run:
        run.return_value = _analysis_report("completed")
        result = asyncio.run(
            FiveAgentsAdapter.run_data_interpreter(run_id=run_id, industry="测试行业")
        )
    payload = json.loads((artifact_dir / "interpretation_report.json").read_text(encoding="utf-8"))
    assert payload["dimension_coverage"], "A2 产物缺少六维覆盖"
    assert len(payload["dimension_coverage"]) == 6
    assert result.data["dimension_coverage"] == payload["dimension_coverage"]
