"""B34：比率型数据需求不得被自身 metric_families 过滤器卡死。

Q1（run-20261110203258）实测：意图模型生成的「四家公司研发投入强度（研发费用/营业收入）对比」
需求带 ``metric_families=["rd_ratio"]``（派生比率族），而 ``_evaluate_requirement`` 用它过滤
records —— 证据库里只有分子（rd_expense/rd_investment）和分母（revenue）的**原始**记录，
派生比率不存在于证据中 → 过滤后 records 为空 → ``observed`` 恒空 →
``_ratio_alternative_satisfied`` 永远 False → 需求 fail →「必需研究数据缺口」硬阻塞。
数据明明齐备（4 家 × 2023/2024/2025 年报 rd + revenue 全在）。

第二处：该需求 label 不含年份且 period_ends 为空 → 比率备择在组期间时得到空集，同样恒 False。

修法：比率型需求（metric_terms 可拆出分子/分母）跳过本族过滤，期间回落到
「观察集中实际出现的期间」；满足条件仍是逐 (实体, 期间) 核对分子分母齐备，
不能靠放宽蒙混。反向守卫：缺分母/只有分子/非比率需求的行为不变。
"""
from __future__ import annotations

from datetime import date

from data_fetcher.models import Domain, ResearchRecord, ResearchRequirement, SourceRef, StructuredResearchDataset
from data_fetcher.agent import DataFetcherAgent

ENTITIES = ["北方华创", "中微公司"]
YEARS = [2023, 2024]

# Q1 原样形态：意图模型给了派生比率族、没绑期间、label 不含年份
FAMILIES = ["rd_ratio"]
GROUPS = [["研发费用率", "研发投入占比", "研发强度", "研发费用/营业收入"]]
LABEL = "四家公司研发投入强度（研发费用/营业收入）对比"


def _dataset(entities: list[str], years: list[int], *, drop_revenue_for: str | None = None,
             drop_all_revenue: bool = False) -> StructuredResearchDataset:
    source = SourceRef(
        task_id="annual", skill_id="hithink-finance-query", skill_version="1.0.0",
        query="probe", trace_id="trace", retrieved_at=date(2026, 11, 9),
    )
    records: list[ResearchRecord] = []
    for entity in entities:
        for year in years:
            for metric, value in (("营业收入", 1.0e10), ("研发支出", 1.0e9)):
                if metric == "营业收入" and (drop_all_revenue or entity == drop_revenue_for):
                    continue
                records.append(ResearchRecord(
                    record_id=f"{entity}-{metric}-{year}", domain=Domain.FINANCIALS,
                    entity_name=entity, entity_code=None, metric=metric, value=value,
                    unit="元", unit_provenance="source_field",
                    period_end=date(year, 12, 31), period_start=date(year, 1, 1),
                    period_type="annual", source=source,
                ))
    return StructuredResearchDataset(financials=records, research_as_of=date(2026, 11, 9))


def _ratio_requirement(entities: list[str], *, min_records: int = 4) -> ResearchRequirement:
    return ResearchRequirement(
        requirement_id="rd_intensity_ratio", label=LABEL,
        domain=Domain.FINANCIALS, hard=True, min_records=min_records,
        entity_names=entities, period_ends=[],
        expected_metric_groups=GROUPS, metric_families=FAMILIES,
    )


# ---------------------------------------------------------------- 红测目标


def test_ratio_requirement_with_declared_family_and_no_years_passes() -> None:
    """分子分母逐家逐年齐备：即使需求带派生比率族且未绑期间，也应判可算。"""
    coverage = DataFetcherAgent._evaluate_requirement(_dataset(ENTITIES, YEARS), _ratio_requirement(ENTITIES))
    assert coverage.passed, coverage.missing


def test_ratio_requirement_without_entities_counts_qualifying_pairs() -> None:
    """未点名实体：按实际配对到的（实体×期间）计数，≥min_records 即可算。"""
    req = _ratio_requirement([], min_records=4)
    coverage = DataFetcherAgent._evaluate_requirement(_dataset(ENTITIES, YEARS), req)
    assert coverage.passed, coverage.missing


# ---------------------------------------------------------------- 反向守卫


def test_ratio_requirement_missing_denominator_for_one_entity_still_blocks() -> None:
    """一家缺分母：该（实体×期间）格子不齐，仍拦。"""
    dataset = _dataset(ENTITIES, YEARS, drop_revenue_for="中微公司")
    coverage = DataFetcherAgent._evaluate_requirement(dataset, _ratio_requirement(ENTITIES))
    assert not coverage.passed, coverage.missing


def test_ratio_requirement_with_only_numerator_blocks() -> None:
    """分母全缺：比率不可算，仍拦。"""
    dataset = _dataset(ENTITIES, YEARS, drop_all_revenue=True)
    coverage = DataFetcherAgent._evaluate_requirement(dataset, _ratio_requirement(ENTITIES, min_records=1))
    assert not coverage.passed, coverage.missing


def test_non_ratio_family_requirement_keeps_family_filter() -> None:
    """非比率需求不受影响：声明的族没有记录时照常 fail（防扩散守卫）。"""
    req = ResearchRequirement(
        requirement_id="gm_series", label="毛利率年度序列",
        domain=Domain.FINANCIALS, hard=True, min_records=1,
        entity_names=ENTITIES, period_ends=[],
        expected_metric_groups=[["毛利率"]], metric_families=["gross_margin"],
    )
    coverage = DataFetcherAgent._evaluate_requirement(_dataset(ENTITIES, YEARS), req)
    assert not coverage.passed, coverage.missing
