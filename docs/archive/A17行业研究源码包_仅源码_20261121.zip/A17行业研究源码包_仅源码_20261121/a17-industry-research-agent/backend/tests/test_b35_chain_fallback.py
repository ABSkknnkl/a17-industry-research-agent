"""B35/B36：v2 链路研究不可用时降级 legacy 环节分类。

背景（run-20261110210759 explore 实测）：路由成功升级 evidence_v2，但搜索通道未配置
→ chain_research RuntimeError → bundle 缺失 → chart 阶段刻意「未回退」→ 产业链图 0 张，
比 profile_guided 还差。

B36（2026-11-11）：豆包 provider 已彻底移除，检索底座 = 问财；门控条件从
DOUBAO_SEARCH_API_KEY 存在性改为问财 key（IWENCAI_API_KEY/BACKUP）存在性。

两层修复：
1. 路由层：prefer_v2 升级 evidence_v2 需要问财 key 可用；缺失则留在 legacy，
   快照 notes 记录原因（不写环境变量名原文——快照有 secret-token 扫描）。
2. 运行时：v2 已路由但 bundle 缺失且用户要求链图 → 不再抑制 legacy，回退产环节分类图，
   chain_delivery 标注 v2_fallback 与原因。

安全边界：不碰核验语义与交付闸门——chain_delivery=partial 依旧硬阻塞，只是「任何环境
不劣于旧版」。
"""
from __future__ import annotations

from datetime import date

from backend.app.engine.state_machine import resolve_execution_snapshot
from backend.app.schemas.workflow import RunCreateRequest


def _explore_request() -> RunCreateRequest:
    return RunCreateRequest.model_validate({
        "project_id": "p-b35",
        "input_data": {
            "industry_topic": "无专用画像的主题",
            "chart_generate_options": {"want_industry_chain": True},
            "data_fetch_options": {"chain_research_strategy": "explore"},
        },
    })


# ---------------------------------------------------------------- 路由层


def test_routing_without_search_key_stays_legacy_with_reason(monkeypatch) -> None:
    """问财 key 缺失：explore 不升级 evidence_v2，快照 notes 说明原因。"""
    monkeypatch.delenv("CHAIN_ENGINE", raising=False)
    monkeypatch.delenv("IWENCAI_API_KEY", raising=False)
    monkeypatch.delenv("IWENCAI_API_KEY_BACKUP", raising=False)
    snapshot = resolve_execution_snapshot(_explore_request())
    assert snapshot.chain_engine == ""
    assert snapshot.chain_requested is True
    assert any("问财检索未配置" in note for note in (snapshot.notes or [])), snapshot.notes


def test_routing_with_search_key_upgrades_to_v2(monkeypatch) -> None:
    """问财 key 存在：explore 照旧升级 evidence_v2，无降级 note。"""
    monkeypatch.delenv("CHAIN_ENGINE", raising=False)
    monkeypatch.setenv("IWENCAI_API_KEY", "test-wencai-key")
    monkeypatch.delenv("IWENCAI_API_KEY_BACKUP", raising=False)
    snapshot = resolve_execution_snapshot(_explore_request())
    assert snapshot.chain_engine == "evidence_v2"
    assert not any("问财检索未配置" in note for note in (snapshot.notes or [])), snapshot.notes


# ---------------------------------------------------------------- 运行时（纯函数真值表）


def _mode(use_chain_v2: bool, chain_requested: bool, bundle_present: bool) -> dict[str, bool]:
    from backend.app.agents.adapters import _resolve_chain_chart_mode

    return _resolve_chain_chart_mode(use_chain_v2, chain_requested, bundle_present)


def test_mode_v2_requested_bundle_missing_falls_back_to_legacy() -> None:
    """B35 核心场景：v2 已路由 + 要链图 + bundle 缺失 → 回退 legacy（不再产空链图）。"""
    mode = _mode(True, True, False)
    assert mode["fallback_legacy"] is True
    assert mode["suppress_legacy_chart"] is False


def test_mode_v2_bundle_present_keeps_v2() -> None:
    """bundle 在：照常走 v2，抑制 legacy。"""
    mode = _mode(True, True, True)
    assert mode["fallback_legacy"] is False
    assert mode["suppress_legacy_chart"] is True


def test_mode_v2_not_requested_suppresses_legacy_without_fallback() -> None:
    """v2 路由但没要链图：无所谓回退，legacy 链图本就不该出。"""
    mode = _mode(True, False, False)
    assert mode["fallback_legacy"] is False
    assert mode["suppress_legacy_chart"] is True


def test_mode_legacy_engine_untouched() -> None:
    """profile_guided（engine=""）：行为与旧版完全一致。"""
    mode = _mode(False, True, False)
    assert mode["fallback_legacy"] is False
    assert mode["suppress_legacy_chart"] is False
