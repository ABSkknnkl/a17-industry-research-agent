"""B27 红测：派生值的两条核验通道漏了「跨段可用」与「按子句判类型」。

问题（2026-11-10 完整链路 run-20261110175930 + 融合段回放实测，179 条
`unsupported_quantity` 里 62 条来自这两处）：

**簇 A｜派生比值只认本段绑定的证据（44 条）**
`verified_calculations` 要求派生计算的 `input_record_ids` 必须落在「本段/本表绑定的
evidence_ids」里。SEC-02-03 的净现比表只绑了 6 条（中微、北方华创的现金流与净利润），
不含拓荆科技、盛美上海的输入记录——于是表里明明写着拓荆 3.92、盛美 0.17（`financial_ratios`
里 `cash_to_net_profit` 精确等于 3.9205693 / 0.1710995），却因为「本段没绑那两条输入」
被判无据。数值本身完全可重建，只是绑定不完整。

**簇 B｜一段话里同时有合计与中位数时，只认一个（18 条）**
`_verified_derived_statistic` 用**整段**上下文判定统计量类型，且中位数优先：

    本章…样本总市值13,453.67亿元，成熟盈利标的PE(TTM)中位数52.63倍、PB中位数9.05倍…

`_DERIVED_MEDIAN` 先命中「中位数」→ kind='median'，于是「13,453.67亿元 合计」永远
走不到 sum 分支。实测该值 = 25 家 `market_cap_billion` 之和 13453.67，分毫不差。

期望：
1. 派生比值可按「全库可重建」支撑断言（entity + metric族 + 期间仍须各自对上）；
2. 统计量类型按**数值所在子句**判定，而不是整段；
3. 错值照拦：把合计值当中位数、或写一个重建不出来的值，都必须保持拦截。
"""

from __future__ import annotations

import json

from financial_semantics import quantity_issues
from report_fusion.agent import _audit_numeric_components
from report_fusion.models import ChapterDraft, ReportFusionRequest


def _ev(rid, entity, metric, value, unit, period="2025-12-31"):
    return {
        "record_id": rid,
        "domain": "financials",
        "entity": entity,
        "metric": metric,
        "value": value,
        "unit": unit,
        "period": period,
        "period_start": "2025-01-01" if period.endswith("12-31") else None,
        "period_type": "annual" if period.endswith("12-31") else "point",
        "scope": "consolidated",
        "currency": "CNY",
    }


# --- 簇 A：拓荆/盛美的净现比输入记录存在，但表格不绑定它们 ---
CASH_EVIDENCE = {
    "R-zs-ocf": _ev("R-zs-ocf", "中微公司", "operating_cash_flow", 20e8, "元"),
    "R-zs-np": _ev("R-zs-np", "中微公司", "parent_net_profit", 18.4e8, "元"),
    "R-bj-ocf": _ev("R-bj-ocf", "北方华创", "operating_cash_flow", 30e8, "元"),
    "R-bj-np": _ev("R-bj-np", "北方华创", "parent_net_profit", 77.6e8, "元"),
    # 下面两条是拓荆的输入：存在于全库，但不在表格绑定集合里
    "R-tj-ocf": _ev("R-tj-ocf", "拓荆科技", "operating_cash_flow", 15e8, "元"),
    "R-tj-np": _ev("R-tj-np", "拓荆科技", "parent_net_profit", 3.826e8, "元"),
}

def _calc(entity, ocf, np, value):
    return {
        "company": entity,
        "calculations": {
            "cash_to_net_profit": {
                "value": value,
                "formula": "operating_cash_flow/parent_net_profit",
                "input_record_ids": [ocf, np],
                "period_end": "2025-12-31",
                "period_type": "annual",
                "scope": "consolidated",
                "currency": "CNY",
                "unit": "倍",
            }
        },
    }


FINANCIAL_RATIOS = [
    _calc("中微公司", "R-zs-ocf", "R-zs-np", 1.0870860908396243),
    _calc("北方华创", "R-bj-ocf", "R-bj-np", 0.3863540891798159),
    _calc("拓荆科技", "R-tj-ocf", "R-tj-np", 3.9205693182080363),
]


def _table_request(table, bound_ids, evidence, ratios=None):
    return ReportFusionRequest.model_validate(
        {
            "report": {
                "report_id": "r",
                "subject": "半导体设备",
                "as_of": "2026-11-10",
                "status": "completed",
                "evidence_index": evidence,
                "comps_matrix": {"entries": []},
                "financial_ratios": ratios or [],
            },
            "chapters": {
                "run_id": "c",
                "subject": "半导体设备",
                "as_of": "2026-11-10",
                "status": "completed",
                "chapters": [
                    {
                        "chapter_id": "CH-02",
                        "title": "财务质量",
                        "summary": "本章比较净现比。",
                        "sections": [
                            {
                                "section_id": "SEC-02-03",
                                "title": "现金流质量",
                                "paragraphs": [],
                                "comparison_table": table,
                            }
                        ],
                    }
                ],
            },
            "options": {"formats": ["markdown"], "enable_editorial_llm": False},
        }
    )


def test_derived_ratio_supported_by_global_inputs():
    """表格只绑了别家的证据，但拓荆的净现比在全库可精确重建 → 不该判无据。"""
    table = {
        "title": "净现比（2025-12-31）",
        "columns": ["公司", "净现比（倍）"],
        "rows": [["中微公司", "1.09"], ["北方华创", "0.39"], ["拓荆科技", "3.92"]],
        "evidence_ids": ["R-zs-ocf", "R-zs-np", "R-bj-ocf", "R-bj-np"],
    }
    req = _table_request(table, table["evidence_ids"], CASH_EVIDENCE, FINANCIAL_RATIOS)

    issues = _audit_numeric_components(req.chapters.chapters, None, req, sanitize=False)

    claims = "；".join(issue["claim"] for issue in issues)
    assert "3.92" not in claims, claims


def test_wrong_derived_ratio_still_blocks():
    """放宽绑定不等于放宽数值：重建不出来的净现比必须仍被拦。"""
    table = {
        "title": "净现比（2025-12-31）",
        "columns": ["公司", "净现比（倍）"],
        "rows": [["拓荆科技", "9.99"]],
        "evidence_ids": ["R-zs-ocf", "R-zs-np"],
    }
    req = _table_request(table, table["evidence_ids"], CASH_EVIDENCE, FINANCIAL_RATIOS)

    issues = _audit_numeric_components(req.chapters.chapters, None, req, sanitize=False)

    claims = "；".join(issue["claim"] for issue in issues)
    assert "9.99" in claims, claims


# --- 簇 B：同段混排合计与中位数，应按各自子句判定 ---
CAP_EVIDENCE = {}
CAPS = [("甲", 20e9), ("乙", 15e9), ("丙", 10e9), ("丁", 5e9)]
for i, (name, cap) in enumerate(CAPS):
    CAP_EVIDENCE[f"R-cap{i}"] = _ev(f"R-cap{i}", name, "market_cap", cap, "元", "2026-11-10")
PE_EVIDENCE = {}
for i, (name, pe) in enumerate([("甲", 10.0), ("乙", 20.0), ("丙", 30.0), ("丁", 40.0)]):
    PE_EVIDENCE[f"R-pe{i}"] = _ev(f"R-pe{i}", name, "pe_ttm", pe, "倍", "2026-11-10")

MIXED = "以4家A股样本公司为证券范围，样本总市值500亿元，成熟盈利标的PE(TTM)中位数25倍。"


def _mixed_refs():
    return list(CAP_EVIDENCE.values()) + list(PE_EVIDENCE.values())


def test_sum_and_median_in_one_sentence_resolve_by_clause():
    """同一句里合计与中位数并存：两个数值都要能各自找到自己的重建通道。"""
    refs = _mixed_refs()

    issues = quantity_issues(MIXED, refs, universe=refs)

    claims = "；".join(issue["claim"] for issue in issues)
    assert "500亿元" not in claims, claims
    assert "25倍" not in claims, claims


def test_median_value_cannot_ride_the_sum_clause():
    """把合计值冒充中位数：子句里写的是「总市值」，不能靠中位数通道放行。"""
    refs = _mixed_refs()
    text = "样本总市值500亿元，同一样本PE(TTM)中位数500倍。"

    issues = quantity_issues(text, refs, universe=refs)

    claims = "；".join(issue["claim"] for issue in issues)
    assert "500倍" in claims, claims
