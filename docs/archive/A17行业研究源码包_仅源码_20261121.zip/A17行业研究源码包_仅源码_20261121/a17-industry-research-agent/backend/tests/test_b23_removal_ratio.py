"""B23-T10：内容损失分级的解析层。

融合层（report_fusion）按「实质内容损失率」决定是否阻塞交付：
- 损失 <=20% -> 记 warning，报告可正式交付；
- 损失 >20% -> 仍阻塞（防「删光换通过」）；
- 原因只有「与其他段落重复」的移除不算损失（去重是好事）。

这里测解析函数本身；章节层「有拦截就 passed=False」的语义保持不变
（既有 V8 安全测试依赖它）。
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
for p in (str(ROOT), str(ROOT / "agents_core")):
    if p not in sys.path:
        sys.path.insert(0, p)

from agents_core.financial_semantics import substantive_removal_ids


def test_numeric_removal_counts_as_loss():
    text = "段落资料缺口：CH-01 P-01-01-01 因质量问题被整段移除（数值语义未通过）"
    assert substantive_removal_ids(text) == ["P-01-01-01"]


def test_duplicate_only_removal_is_not_loss():
    text = "段落资料缺口：CH-02 P-02-01-01 因质量问题被整段移除（与其他段落重复）"
    assert substantive_removal_ids(text) == []


def test_mixed_reasons_count_as_loss():
    text = ("段落资料缺口：CH-03 P-03-01-01 因质量问题被整段移除"
            "（数字缺少证据支撑、数值语义未通过）")
    assert substantive_removal_ids(text) == ["P-03-01-01"]


def test_multiple_entries_parsed():
    text = ("段落资料缺口：CH-04 P-04-01-01 因质量问题被整段移除（数值语义未通过）；"
            "P-04-02-01 因质量问题被整段移除（与其他段落重复）；"
            "P-04-03-01 因质量问题被整段移除（因果判断缺少独立依据）")
    assert substantive_removal_ids(text) == ["P-04-01-01", "P-04-03-01"]


def test_empty_and_unrelated_text():
    assert substantive_removal_ids("") == []
    assert substantive_removal_ids("组件隔离：CH-01 指标卡「X」数值缺少证据绑定") == []
