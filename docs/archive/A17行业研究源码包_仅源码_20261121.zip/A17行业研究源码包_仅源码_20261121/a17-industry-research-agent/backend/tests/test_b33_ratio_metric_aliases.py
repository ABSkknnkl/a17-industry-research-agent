"""B33 红测：比率卡的 formula 措辞要能映射到派生指标族。

实测（run-20261110203258，SEMI-Q1）：卡片「中微公司研发费用/营业收入
（2026前三季度）19.65%」的值在 `financial_ratios.calculations.rd_ratio`
里精确存在（19.6488…%，2026-09-30，输入记录齐全），但
`metric_family('研发费用/营业收入')` 返回原样、与 canonical `rd_ratio`
对不上 → B31 派生绑定通道接不住 → CH-06 六张比率卡全被隔离（57%）→
B29 安全网正确拦截 → 整题 blocked。

连带：融合层「必需研究数据缺口：研发投入强度对比」也是同一根因的误报——
数据明明在，是绑定断了。

修法：`metric_family` 增加 formula 写法的**子串**别名（含「/」的比率
表达），只收枚举白名单，不做通用子串匹配（避免「营业收入」误吃
「营业收入同比增长率」）。卡片 label 常带实体名/期间前缀，所以必须是
子串而非精确匹配。
"""

from __future__ import annotations

from agents_core.financial_semantics import metric_family, quantity_issues

RD_RATIO_REC = {
    "record_id": "derived:R-ocf/R-rev", "entity": "中微公司", "metric": "rd_ratio",
    "value": 19.64885969112658, "unit": "%", "period": "2026-09-30",
    "period_type": "ytd_q3", "scope": "consolidated",
}

# 北方华创的研发强度不同（12.24%）：用于验证「主体不符」拦截需要
# universe 里认识这个实体（实体校验只对已知实体生效——既有设计）。
NF_RD_RATIO_REC = {
    "record_id": "derived:R-nf1/R-nf2", "entity": "北方华创", "metric": "rd_ratio",
    "value": 12.236743764430713, "unit": "%", "period": "2026-09-30",
    "period_type": "ytd_q3", "scope": "consolidated",
}


# ---------------------------------------------------------------- metric_family


def test_formula_text_maps_to_rd_ratio():
    """「研发费用/营业收入」→ rd_ratio（Q1 卡片的实际写法）。"""
    assert metric_family("研发费用/营业收入") == "rd_ratio"


def test_formula_with_entity_prefix_still_maps():
    """带实体名与期间前缀的完整卡片措辞也能映射（子串匹配）。"""
    assert metric_family("中微公司研发费用/营业收入（2026前三季度）") == "rd_ratio"


def test_cash_ratio_formula_maps():
    """净现比的 formula 写法同样映射（B27 通道已用它，补齐 family 侧）。"""
    assert metric_family("经营活动现金流/归母净利润") == "cash_to_net_profit"
    assert metric_family("经营现金流/净利润") == "cash_to_net_profit"


def test_existing_exact_aliases_take_priority():
    """既有精确别名不被子串匹配破坏：同比增长率不得误判为 revenue。"""
    assert metric_family("营业收入同比增长率") == "revenue_yoy"
    assert metric_family("营业收入") == "revenue"
    assert metric_family("研发费用率") == "rd_ratio"


def test_plain_metric_without_slash_unchanged():
    """不含 formula 写法的普通词保持原样（不扩大子串匹配范围）。"""
    assert metric_family("本土化率") == "本土化率"


# ---------------------------------------------------------------- quantity_issues 通道


def test_ratio_card_clause_passes_against_derived_record():
    """端到端：卡片子句 + 派生记录 → family 对上、值舍入可容 → 无 issue。"""
    text = "中微公司研发费用/营业收入（2026前三季度）：19.65%"
    assert quantity_issues(text, [RD_RATIO_REC]) == []


def test_ratio_card_wrong_value_still_blocks():
    """反向守卫：19.0% 不是 19.6488 的舍入（差 3%+），仍拦。"""
    text = "中微公司研发费用/营业收入（2026前三季度）：19.0%"
    issues = quantity_issues(text, [RD_RATIO_REC])
    assert any(i.get("code") == "unsupported_quantity" for i in issues), issues


def test_ratio_card_other_entity_still_blocks():
    """反向守卫：把中微的强度写到北方华创头上，universe 里两家都有 → 拦。"""
    text = "北方华创研发费用/营业收入（2026前三季度）：19.65%"
    issues = quantity_issues(text, [RD_RATIO_REC], universe=[RD_RATIO_REC, NF_RD_RATIO_REC])
    assert any(i.get("code") == "unsupported_quantity" for i in issues), issues
