"""B32 红测：样本清单固化——让子集统计可核验。

背景（B27 已论证）：报告里「样本总市值 13,453.67 亿元」是 **25 家样本**的
合计，但证据池有 38 家（合计 31,488 亿）。审计按全库求和得到错误答案，
按子集猜等于替报告编口径——所以这些聚合卡一直被隔离。

用户口径（2026-11-10 已确认）：
- 样本 = `financial_ratios` 的 company 名单（25 家）
- 梯队 = `financial_ratios.valuation_tier`
- 报告必须显式声明成分数（「25 家样本合计」「成熟盈利 7 家中位数」）

本文件验证：审计能按样本清单过滤后重建子集统计，且成分数/值/梯队不符仍拦。
"""

from __future__ import annotations

import pytest

from agents_core.financial_semantics import quantity_issues

# 5 家有市值记录，但只有 4 家进 financial_ratios（样本）
MARKET_CAP = [
    {"record_id": f"R-{n}", "domain": "financials", "entity": n,
     "metric": "market_cap", "value": v, "unit": "亿元", "period": "2026-11-10"}
    for n, v in [("A", 100), ("B", 200), ("C", 300), ("D", 400), ("E", 500)]
]

# 样本 = A/B/C/D 四家（financial_ratios 名单），E 有市值但不在样本里
# 梯队：A/B/C 成熟盈利，D 早期亏损
FINANCIAL_RATIOS = [{"company": n, "valuation_tier": t} for n, t in [
    ("A", "成熟盈利"), ("B", "成熟盈利"), ("C", "成熟盈利"), ("D", "早期亏损"),
]]

PB = [
    {"record_id": f"R-pb-{n}", "domain": "financials", "entity": n,
     "metric": "pb", "value": v, "unit": "倍", "period": "2026-11-10"}
    for n, v in [("A", 10), ("B", 20), ("C", 30), ("D", 40), ("E", 50)]
]


def _issues(text, evidence, ratios=FINANCIAL_RATIOS):
    return quantity_issues(text, evidence, universe=evidence, sample_universe=ratios)


# ---------------------------------------------------------------- 合计


def test_sample_sum_with_declared_count_passes():
    """4 家样本总市值合计 1000 亿 = A(100)+B(200)+C(300)+D(400)，应通过。"""
    assert _issues("4 家样本总市值合计 1000 亿元", MARKET_CAP) == []


def test_sample_sum_with_wrong_value_still_blocks():
    """子集凑和：600 是 A+B+C 三家的和，却声称 4 家样本合计 → 拦。

    这是 B32 要防的核心作弊：挑好看的公司凑合计，少算一家。
    """
    issues = _issues("4 家样本总市值合计 600 亿元", MARKET_CAP)
    assert any(i.get("code") == "unsupported_quantity" for i in issues), issues


def test_full_pool_sum_does_not_impersonate_sample_sum():
    """1500 亿是全部 5 家的合计，不是 4 家样本的——不许借全库蒙混。"""
    issues = _issues("4 家样本总市值合计 1500 亿元", MARKET_CAP)
    assert any(i.get("code") == "unsupported_quantity" for i in issues), issues


def test_declared_count_mismatch_blocks():
    """声称 5 家但样本清单只有 4 家：成分数不足，仍拦（即使合计值 1000 是对的）。"""
    issues = _issues("5 家样本总市值合计 1000 亿元", MARKET_CAP)
    assert any(i.get("code") == "unsupported_quantity" for i in issues), issues


# ---------------------------------------------------------------- 中位数


def test_sample_median_passes():
    """4 家样本 PB 中位数 25 倍 = median(10,20,30,40)，应通过。"""
    assert _issues("4 家样本 PB 中位数 25 倍", PB) == []


def test_full_pool_median_does_not_impersonate_sample_median():
    """全量 5 家 PB 中位数是 30，但样本只有 4 家（中位数 25）→ 30 应被拦。"""
    issues = _issues("4 家样本 PB 中位数 30 倍", PB)
    assert any(i.get("code") == "unsupported_quantity" for i in issues), issues


# ---------------------------------------------------------------- 梯队


def test_tier_median_passes():
    """成熟盈利 3 家（A/B/C）PB 中位数 20 倍 = median(10,20,30)，应通过。"""
    assert _issues("成熟盈利 3 家 PB 中位数 20 倍", PB) == []


def test_tier_median_wrong_value_blocks():
    """成熟盈利梯队 PB 中位数写成 25（把 D 算进去了）→ 仍拦。"""
    issues = _issues("成熟盈利 3 家 PB 中位数 25 倍", PB)
    assert any(i.get("code") == "unsupported_quantity" for i in issues), issues


# ---------------------------------------------------------------- 无样本清单时


def test_no_sample_universe_keeps_current_behavior():
    """不传 sample_universe 时行为与现状一致（全库），不回归。"""
    # 全库 5 家中位数 30，无样本清单 → 按全库算，30 应通过
    assert quantity_issues("5 家 PB 中位数 30 倍", PB, universe=PB) == []
