"""B23-T1 红测：章节修复后，终态质量结论不得携带已解决段落问题。

问题（SEMI-Q4 实测）：`_write_chapter` 在修复轮把**修复前**该段落的报错无条件
塞进 `unresolved`（agent.py:613），段落随后被裁剪/清空，但旧报错仍写入
`quality.issues`。结果 issue 列出 229 条「数值语义未通过」，终态重跑只有
10 段真不通过——虚高 20 倍，让报告永久停在「受限草稿」。

期望语义：
- 段落被裁剪但仍有内容（部分保留）→ 被裁掉的子句报错**不得**进终态 issue
- 段落被整段清空 → 这是真内容缺口，可以留痕（一句概述，不是逐条数字报错）
- 终态仍存在的报错（重审计剩余）→ 必须进 issue
"""

from __future__ import annotations

import asyncio
import json

from chapter_writer import ChapterWriterAgent, ChapterWritingRequest
from chapter_writer.models import InterpretationReport, OutlineChapter, OutlineSection

OUTLINE = [
    OutlineChapter(
        chapter_id=f"CH-{i:02d}",
        title=f"第{i}章",
        sections=[
            OutlineSection(section_id=f"SEC-{i:02d}-0{j}", title=f"节{j}", purpose="目的")
            for j in range(1, 4)
        ],
    )
    for i in range(1, 8)
]

TARGET_CHAPTER = "CH-01"
TARGET_SECTION = "SEC-01-01"
TARGET_PID = "P-01-01-01"


def _report() -> InterpretationReport:
    return InterpretationReport.model_validate(
        {
            "report_id": "R-B23",
            "subject": "测试行业",
            "as_of": "2026-09-01",
            "status": "completed",
            "insights": [],
            "evidence_index": {
                "R1": {
                    "record_id": "R1",
                    "domain": "industry",
                    "entity": "测试行业",
                    "metric": "市场规模",
                    "value": 100,
                    "unit": "亿元",
                    "period": "2026-06-30",
                }
            },
        }
    )


class _ScriptedLLM:
    """目标段落写被测文本，其余段落写无数字的填充文案。"""

    is_available = True

    def __init__(self, text: str, evidence_ids: list[str] | None = None) -> None:
        self.text = text
        self.evidence_ids = evidence_ids or []

    async def generate_json(self, _system, user):
        payload = json.loads(user) if isinstance(user, str) else user
        outline = payload["outline"]
        cid = outline["chapter_id"]
        sections = []
        for sec in outline["sections"]:
            hit = cid == TARGET_CHAPTER and sec["section_id"] == TARGET_SECTION
            sections.append(
                {
                    "section_id": sec["section_id"],
                    "title": sec["title"],
                    "purpose": sec.get("purpose", "目的"),
                    "key_points": ["要点"],
                    "paragraphs": [
                        {
                            "paragraph_id": TARGET_PID if hit else f"P-{cid[-2:]}-99-01",
                            "kind": "analysis",
                            "text": self.text if hit else f"第{cid[-2:]}章按既有证据梳理行业现状与结构。",
                            "evidence_ids": list(self.evidence_ids) if hit else [],
                        }
                    ],
                    "chart_ids": [],
                    "uncertainties": [],
                    "metric_cards": [],
                    "comparison_table": None,
                    "callouts": [],
                    "layout_hint": "text_only",
                }
            )
        return {
            "chapter_id": cid,
            "title": outline["title"],
            "summary": "本章摘要。",
            "sections": sections,
        }


def _run(text: str, evidence_ids: list[str] | None = None):
    agent = ChapterWriterAgent(llm=_ScriptedLLM(text, evidence_ids))
    return asyncio.run(
        agent.run(ChapterWritingRequest(report=_report(), outline=OUTLINE), save_artifacts=False)
    )


def _target(result):
    return next(
        p
        for c in result.chapters
        for s in c.sections
        for p in s.paragraphs
        if p.paragraph_id == TARGET_PID
    )


def test_trimmed_paragraph_does_not_leak_resolved_errors_into_quality():
    """部分保留的段落：被裁掉的旧报错（20%/45%）不得出现在终态 issue 里。"""
    result = _run("2025 年公司营业收入同比增长 20%，毛利率提升至 45%。本节按既有证据梳理行业结构。")
    issues_text = "；".join(str(i) for i in result.quality.issues)
    # 段落被裁剪后仍保留定性句
    target = _target(result)
    assert target.text.strip(), "定性句应被保留"
    assert "20%" not in issues_text, f"已裁掉的旧报错泄漏到终态 issue：{issues_text}"
    assert "45%" not in issues_text, f"已裁掉的旧报错泄漏到终态 issue：{issues_text}"


def test_fully_isolated_paragraph_still_reports_gap():
    """整段被清空 = 真内容缺口，必须留痕（但不能是逐条数字报错）。"""
    result = _run("2025 年公司营业收入同比增长 20%。")
    issues_text = "；".join(str(i) for i in result.quality.issues)
    assert "段落资料缺口" in issues_text
    assert "20%" not in issues_text, f"移除留痕不应复述旧数字报错：{issues_text}"
    assert result.quality.passed is False


def test_final_remaining_defect_is_reported():
    """终态仍存在的问题必须进 issue（防止修复过度掩盖）。"""
    # 有证据但数值错配：R1 是 100 亿元，写 999 亿元
    result = _run("行业市场规模达到 999 亿元。", evidence_ids=["R1"])
    issues_text = "；".join(str(i) for i in result.quality.issues)
    assert "999" in issues_text or "段落资料缺口" in issues_text, issues_text
