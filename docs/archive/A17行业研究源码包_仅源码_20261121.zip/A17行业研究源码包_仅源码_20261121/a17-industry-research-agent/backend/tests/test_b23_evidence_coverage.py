"""B23-T7 红测：evidence_coverage 应为「有证据绑定的段落占比」。

问题（SEMI-Q4 实测）：旧口径 `引用证据数 / 全库证据数` 天然是个位数——
该 run 交了 2.36%，SEMI-Q3 双跑 3.64% / 2.94%。这个数字被写进
ChapterQualityReport.evidence_coverage，读起来像「章节只有 2% 有据」，
实际是「引用了全库 2% 的证据」，两个完全不同的概念。

期望：改为「至少有一条证据绑定的段落数 / 有内容的段落数」，取值 0..1。
"""

from __future__ import annotations

import asyncio
import json

from chapter_writer import ChapterWriterAgent, ChapterWritingRequest
from chapter_writer.models import InterpretationReport, OutlineChapter, OutlineSection

OUTLINE = [
    OutlineChapter(
        chapter_id=f"CH-{i:02d}",
        title=f"第{i}章",
        sections=[
            OutlineSection(section_id=f"SEC-{i:02d}-0{j}", title=f"节{j}", purpose="目的")
            for j in range(1, 4)
        ],
    )
    for i in range(1, 8)
]


def _report(evidence_ids: list[str]) -> InterpretationReport:
    return InterpretationReport.model_validate(
        {
            "report_id": "R-B23T7",
            "subject": "测试行业",
            "as_of": "2026-09-01",
            "status": "completed",
            "insights": [],
            "evidence_index": {
                eid: {
                    "record_id": eid,
                    "domain": "industry",
                    "entity": "测试行业",
                    "metric": "市场规模",
                    "value": 100 + idx,
                    "unit": "亿元",
                    "period": "2026-06-30",
                }
                for idx, eid in enumerate(evidence_ids)
            },
        }
    )


class _AllBoundLLM:
    """所有段落都绑第一条证据，文本无数字（避免触发数值缺陷）。"""

    is_available = True

    async def generate_json(self, _system, user):
        payload = json.loads(user) if isinstance(user, str) else user
        outline = payload["outline"]
        cid = outline["chapter_id"]
        sections = []
        for sec in outline["sections"]:
            sections.append(
                {
                    "section_id": sec["section_id"],
                    "title": sec["title"],
                    "purpose": sec.get("purpose", "目的"),
                    "key_points": ["要点"],
                    "paragraphs": [
                        {
                            "paragraph_id": f"P-{cid[-2:]}-{sec['section_id'][-2:]}-01",
                            "kind": "analysis",
                            "text": f"第{cid[-2:]}章第{sec['section_id'][-2:]}节按既有证据梳理行业现状与结构。",
                            "evidence_ids": ["R1"],
                        }
                    ],
                    "chart_ids": [],
                    "uncertainties": [],
                    "metric_cards": [],
                    "comparison_table": None,
                    "callouts": [],
                    "layout_hint": "text_only",
                }
            )
        return {
            "chapter_id": cid,
            "title": outline["title"],
            "summary": "本章摘要。",
            "sections": sections,
        }


def test_coverage_is_paragraph_binding_ratio():
    evidence_ids = ["R1", "R2", "R3", "R4", "R5"]
    agent = ChapterWriterAgent(llm=_AllBoundLLM())
    result = asyncio.run(
        agent.run(
            ChapterWritingRequest(report=_report(evidence_ids), outline=OUTLINE),
            save_artifacts=False,
        )
    )
    # 22 个段落全部绑定了 R1；按段落覆盖率应为 1.0
    assert result.quality.evidence_coverage == 1.0, (
        f"段落全部有证据时覆盖率应为 1.0，实际 {result.quality.evidence_coverage}"
    )
