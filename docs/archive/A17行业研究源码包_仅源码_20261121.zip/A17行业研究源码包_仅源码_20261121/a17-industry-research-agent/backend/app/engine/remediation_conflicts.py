from __future__ import annotations

import hashlib
import json
import re
from datetime import date, datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from backend.app.engine.remediation_sources import load_source, verify_excerpt
from backend.app.schemas.remediation import RemediationItem


_METRIC_TERMS = {
    "revenue": ("营业收入", "营业总收入", "营收", "revenue"),
    "parent_net_profit": ("归母净利润", "归属于母公司股东的净利润", "parent net profit"),
    "net_profit": ("净利润", "net profit"),
    "gross_margin": ("毛利率", "gross margin"),
    "net_margin": ("净利率", "net margin"),
    "roe": ("净资产收益率", "roe", "return on equity"),
    "operating_cash_flow": ("经营活动产生的现金流量净额", "经营现金流", "operating cash flow"),
    "rd_expense": ("研发费用", "研发投入", "研发支出", "r&d"),
}


def _roe_basis(text: str) -> str:
    text = text.casefold()
    if "非加权" in text or "unweighted" in text:
        return "unweighted"
    if "加权" in text or "weighted" in text:
        return "weighted"
    return "unspecified"


def _number_with_unit(text: str, value: Any, unit: str) -> bool:
    try:
        expected = Decimal(str(value).replace(",", ""))
        if not expected.is_finite():
            return False
    except InvalidOperation:
        return False
    escaped = re.escape(unit.strip())
    for match in re.finditer(rf"(?<![\d.])([-+]?\d[\d,]*(?:\.\d+)?)\s*{escaped}(?![A-Za-z])", text, re.IGNORECASE):
        try:
            if Decimal(match.group(1).replace(",", "")) == expected:
                return True
        except InvalidOperation:
            continue
    return False


def _narrative_value_match(excerpt: str, data: dict[str, Any], year: int, metric: str) -> bool:
    """Require a value and its complete measurement context in one statement."""
    unit = str(data.get("unit") or "").strip()
    if not unit:
        return False
    try:
        value = Decimal(str(data.get("value")).replace(",", ""))
    except InvalidOperation:
        return False
    if not value.is_finite():
        return False
    entity = re.sub(r"\s+", "", str(data.get("entity_name") or "")).casefold()
    scopes = {"consolidated": ("合并", "集团", "consolidated"), "parent": ("母公司", "parent")}
    currencies = {"CNY": ("cny", "rmb", "人民币"), "USD": ("usd", "美元"), "HKD": ("hkd", "港元")}
    scope = str(data.get("scope") or "")
    currency = str(data.get("currency") or "").upper()
    clauses = re.split(r"[。；;!?！？，]|(?<!\d)\.(?!\d)|(?<!\d),(?!\d)", excerpt)
    for clause in clauses:
        compact = re.sub(r"\s+", "", clause).casefold()
        if not entity or entity not in compact or set(re.findall(r"(?<!\d)20\d{2}(?!\d)", clause)) != {str(year)}:
            continue
        raw_metric = " ".join(str(key) for key in (data.get("raw_fields") or {})
                              if "收益率" in str(key) or "roe" in str(key).casefold())
        if metric == "roe" and raw_metric and _roe_basis(raw_metric) != _roe_basis(compact):
            continue
        if scope not in scopes or not any(term in compact for term in scopes[scope]):
            continue
        if any(term in compact for name, terms in scopes.items() if name != scope for term in terms):
            continue
        if unit not in {"%", "％", "百分比", "倍"}:
            if not any(term in compact for term in currencies.get(currency, ())):
                continue
            if any(term in compact for name, terms in currencies.items() if name != currency for term in terms):
                continue
        for match in re.finditer(rf"(?<![\d.])([-+]?\d[\d,]*(?:\.\d+)?)\s*{re.escape(unit)}(?![A-Za-z])", clause, re.IGNORECASE):
            if Decimal(match.group(1).replace(",", "")) != value:
                continue
            prefix = re.sub(r"\s+", "", clause[:match.start()]).casefold()
            hits = [(found.start(), len(normalized), family) for family, terms in _METRIC_TERMS.items()
                    for term in terms if (normalized := re.sub(r"\s+", "", term).casefold())
                    for found in re.finditer(re.escape(normalized), prefix)]
            if hits and max(hits, key=lambda hit: (hit[0] + hit[1], hit[1]))[2] == metric:
                return True
    return False


def _annual_table_value(text: str, terms: tuple[str, ...], year: int, value: Any, unit: str,
                        scope: str, currency: str) -> bool:
    """Accept only a directly readable, ordered year-header/metric-row table."""
    lines = [re.sub(r"\s+", "", line).casefold() for line in text.splitlines() if line.strip()]
    names = {re.sub(r"\s+", "", term).casefold() for term in terms if term}
    try:
        expected = Decimal(str(value).replace(",", ""))
    except InvalidOperation:
        return False
    heading_pattern = re.compile(r"(?:合并|母公司).*(?:利润表|资产负债表|现金流量表)|(?:consolidated|parent).*(?:incomestatement|balancesheet|cashflowstatement)")
    scope_terms = {"consolidated": ("合并", "consolidated"), "parent": ("母公司", "parent")}
    currency_terms = {"CNY": ("cny", "rmb", "人民币"), "USD": ("usd", "美元"), "HKD": ("hkd", "港元")}
    for position, line in enumerate(lines):
        label = re.sub(r"^[一二三四五六七八九十\d]+[、.．]", "", line)
        headings = [index for index, prior in enumerate(lines[:position]) if heading_pattern.search(prior)]
        if not headings:
            continue
        header = "".join(lines[headings[-1]:position])
        if scope not in scope_terms or not any(term in header for term in scope_terms[scope]):
            continue
        if any(term in header for name, terms_for_scope in scope_terms.items() if name != scope for term in terms_for_scope):
            continue
        if unit not in {"%", "％", "百分比", "倍"} and not any(term in header for term in currency_terms.get(currency, ())):
            continue
        if any(term in header for name, terms_for_currency in currency_terms.items() if name != currency for term in terms_for_currency):
            continue
        unit_match = re.search(r"单位(?:为|[:：])?(?:人民币|cny|rmb|usd|hkd)?(万亿元|千万元|百万元|亿元|万元|千元|元)", header)
        if unit_match is None:
            unit_match = re.search(r"unit(?:of|[:：])?(?:cny|rmb|usd|hkd)?(million|thousand)", header)
        declared_unit = unit_match.group(1) if unit_match else ""
        if label not in names or re.sub(r"\s+", "", unit).casefold() != declared_unit:
            continue
        years = []
        for prior in reversed(lines[:position]):
            match = re.fullmatch(r"(20\d{2})(?:年(?:度)?|annual)", prior)
            if match:
                years.append(int(match.group(1)))
            elif years:
                break
        years.reverse()
        if not 1 <= len(years) <= 5 or len(set(years)) != len(years) or year not in years:
            continue
        values = []
        for token in lines[position + 1:position + len(years) + 3]:
            if re.fullmatch(r"(?:note\d+|[一二三四五六七八九十]+[（(]\d+[）)])", token):
                continue
            if not re.fullmatch(r"[-+]?\d[\d,]*(?:\.\d+)?", token):
                break
            values.append(Decimal(token.replace(",", "")))
        if len(values) == len(years) and values[years.index(year)] == expected:
            return True
    return False


def _validate_evidence(run_dir: Path, data: dict[str, Any], as_of: date) -> dict[str, Any]:
    source_id = str(data.get("source_id") or "")
    page = data.get("page")
    excerpt = str(data.get("excerpt") or "").strip()
    if isinstance(page, bool) or not isinstance(page, int) or not verify_excerpt(run_dir, source_id, page, excerpt):
        raise ValueError("原文摘录与指定 PDF 页不匹配")
    source = load_source(run_dir, source_id)
    if not source.published_at:
        raise ValueError("材料缺少发布日期，暂不能用于核验")
    try:
        published = date.fromisoformat(source.published_at)
        period = date.fromisoformat(str(data.get("period_end") or ""))
    except ValueError as exc:
        raise ValueError("材料日期或财务期间无效") from exc
    if published > as_of or period > as_of:
        raise ValueError("材料或财务期间晚于研究截止日期")
    from backend.app.engine.remediation_sources import publication_date_verified
    date_verified = publication_date_verified(run_dir, source, page, as_of)
    text = re.sub(r"\s+", "", excerpt).casefold()
    entity = re.sub(r"\s+", "", str(data.get("entity_name") or "")).casefold()
    code = str(data.get("entity_code") or "").split(".")[0]
    identity_page = None
    if entity and entity not in text and re.fullmatch(r"\d{6}", code):
        from backend.app.engine.remediation_sources import read_source_page

        for page_number in range(1, min(source.page_count or 0, 5) + 1):
            cover = re.sub(r"\s+", "", read_source_page(run_dir, source_id, page_number).text).casefold()
            if entity in cover and re.search(rf"(?:公司代码|证券代码|股票代码|companycode)[：:]?{re.escape(code)}(?!\d)", cover):
                identity_page = page_number
                break
    if not entity or (entity not in text and identity_page is None):
        raise ValueError("摘录或同一文件封面中缺少匹配的公司名称和代码")
    if str(period.year) not in text:
        raise ValueError("摘录中缺少匹配的财务年度")
    from agents_core.financial_semantics import metric_family
    metric = metric_family(str(data.get("metric") or ""))
    terms = _METRIC_TERMS.get(metric, (str(data.get("metric") or ""),))
    if not any(term and re.sub(r"\s+", "", term).casefold() in text for term in terms):
        raise ValueError("摘录中缺少匹配的财务指标")
    raw_fields = data.get("raw_fields") or {}
    raw_metric = " ".join(str(k) for k in raw_fields if "收益率" in str(k) or "roe" in str(k).casefold()).casefold()
    if metric == "roe" and raw_metric:
        if _roe_basis(raw_metric) != _roe_basis(text):
            raise ValueError("净资产收益率的加权口径不一致")
    unit = str(data.get("unit") or "").strip()
    narrative_match = _narrative_value_match(excerpt, data, period.year, metric)
    if not unit or not (narrative_match or _annual_table_value(excerpt, terms, period.year, data.get("value"), unit,
                                                               str(data.get("scope") or ""), str(data.get("currency") or "").upper())):
        raise ValueError("摘录中的数值或单位不匹配")
    scope = str(data.get("scope") or "")
    scope_terms = {"consolidated": ("合并", "集团", "consolidated"), "parent": ("母公司", "parent")}
    if scope not in scope_terms or not any(term in text for term in scope_terms[scope]):
        raise ValueError("摘录中缺少匹配的合并或母公司口径")
    currency = str(data.get("currency") or "").upper()
    currency_terms = {"CNY": ("cny", "rmb", "人民币"), "USD": ("usd", "美元"), "HKD": ("hkd", "港元")}
    if unit not in {"%", "％", "百分比", "倍"} and not any(term in text for term in currency_terms.get(currency, ())):
        raise ValueError("摘录中缺少匹配的币种")
    return {"source_id": source.source_id, "title": source.title, "source_url": source.source_url,
            "source_locator": f"PDF 第{page}页", "document_sha256": source.sha256,
            "identity_locator": f"PDF 第{identity_page}页" if identity_page else f"PDF 第{page}页",
            "published_at": source.published_at if date_verified else None,
            "declared_published_at": source.published_at, "publication_date_verified": date_verified,
            "publisher_verified": source.publisher_verified,
            "official_origin_verified": source.official_origin_verified,
            "literal_excerpt": excerpt}


def prepare_financial_record(run_dir: Path, data: dict[str, Any], as_of: date) -> dict[str, Any]:
    required = ("entity_name", "metric", "period_end", "unit", "scope", "currency")
    if any(not str(data.get(key) or "").strip() for key in required) or data.get("value") is None:
        raise ValueError("请完整填写公司、指标、期间、数值和口径")
    try:
        period = date.fromisoformat(str(data["period_end"]))
    except ValueError as exc:
        raise ValueError("请填写有效的年度截止日期") from exc
    if (period.month, period.day) != (12, 31):
        raise ValueError("目前只支持录入 12 月 31 日结束的年度数据")
    citation = _validate_evidence(run_dir, data, as_of)
    identity = {key: data.get(key) for key in (*required, "entity_code", "value")}
    identity["source_id"] = citation["source_id"]
    record_id = "R-" + hashlib.sha256(json.dumps(identity, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:20]
    original_value, original_unit = data["value"], str(data["unit"]).strip()
    scale = {"百万元": 1_000_000, "千万元": 10_000_000, "千元": 1_000,
             "million": 1_000_000, "million cny": 1_000_000}.get(original_unit.casefold())
    value, unit = original_value, original_unit
    if scale and str(data["currency"]).upper() == "CNY":
        amount = Decimal(str(original_value).replace(",", "")) * scale
        value = int(amount) if amount == amount.to_integral_value() else float(amount)
        unit = "元"
    citation = {**citation, "original_value": original_value, "original_unit": original_unit}
    record = {
        "record_id": record_id, "domain": "financials", "entity_name": data["entity_name"],
        "entity_code": data.get("entity_code"), "metric": data["metric"], "value": value,
        "unit": unit, "unit_provenance": "source_field", "period_end": data["period_end"],
        "period_type": "annual", "period_provenance": "manual_source", "scope": data["scope"],
        "currency": data["currency"], "published_at": citation["published_at"],
        "source": {"task_id": "remediation", "skill_id": "user-document", "skill_version": "1",
                   "query": str(data["metric"]), "trace_id": citation["source_id"],
                   "retrieved_at": datetime.now(timezone.utc).isoformat(), "status": "human_review"},
        "raw_fields": citation, "issues": (["user_supplied_source_unverified", "unverified_publication_date", "missing_published_at"]
                                         if not citation["publication_date_verified"] else []),
    }
    return {"record": record, "source": citation}


def prepare_conflict_decision(run_dir: Path, item: RemediationItem, selected_record_id: str,
                              source_id: str | None, page: int, excerpt: str, reason: str,
                              as_of: date | None = None) -> dict[str, Any]:
    if item.category != "source_conflict" or not reason.strip():
        raise ValueError("请选择冲突记录并填写裁决理由")
    conflict = item.context.get("conflict") or {}
    records = item.context.get("records", [])
    record = next((r for r in records if r.get("record_id") == selected_record_id), None)
    if not record or selected_record_id not in conflict.get("record_ids", []):
        raise ValueError("选择的记录不属于该冲突")
    if set(conflict.get("record_ids", [])) != {r.get("record_id") for r in records}:
        raise ValueError("冲突候选不完整，无法核对口径")
    from agents_core.financial_semantics import metric_family

    def basis(row: dict[str, Any]) -> tuple[Any, ...]:
        family = metric_family(str(row.get("metric") or ""))
        qualifier = ""
        if family == "roe":
            name = " ".join([str(row.get("metric") or ""), *(
                str(k) for k in (row.get("raw_fields") or {}) if "收益率" in str(k) or "roe" in str(k).lower()
            )]).casefold()
            if "非加权" in name or "unweighted" in name:
                qualifier = "unweighted"
            elif "加权" in name or "weighted" in name:
                qualifier = "weighted"
            else:
                qualifier = "unspecified"
        return (row.get("entity_code") or row.get("entity_name"), family, row.get("period_end"),
                row.get("period_start"), row.get("period_type"), row.get("unit"), row.get("scope"),
                row.get("currency"), qualifier)

    if len({basis(row) for row in records}) != 1:
        raise ValueError("候选数据的指标或财务口径不一致，请先核实字段定义，不能直接裁决")
    if as_of is None:
        raise ValueError("缺少研究截止日期")
    citation = _validate_evidence(run_dir, {**record, "source_id": source_id, "page": page, "excerpt": excerpt}, as_of)
    return {"conflict_key": conflict["conflict_key"], "selected_record_id": selected_record_id,
            "reason": reason.strip(), "source": citation, "conflict": conflict}


def conflict_item_after_merge(item: RemediationItem, dataset: Any) -> RemediationItem:
    """Rebuild an existing conflict against the exact dataset being committed."""
    original = item.context.get("conflict") or {}
    key = original.get("conflict_key")
    conflict = next((row for row in dataset.conflicts if row.conflict_key == key), None)
    if not conflict or not set(original.get("record_ids", [])).issubset(conflict.record_ids):
        raise ValueError("原冲突候选或财务口径已变化，无法合并裁决")
    records = {row.record_id: row.model_dump(mode="json") for row in dataset.all_records()}
    if not set(conflict.record_ids).issubset(records):
        raise ValueError("冲突候选记录不完整")
    return item.model_copy(update={"context": {**item.context, "conflict": conflict.model_dump(mode="json"),
                                               "records": [records[key] for key in conflict.record_ids]}})
