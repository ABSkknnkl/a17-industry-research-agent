from __future__ import annotations

"""自动补救引擎：由智能体代替用户逐项处置「处理质检问题」工作台里的待办。

设计原则（与人工补救同一条完整性底线）：
- 只做诚实动作：段落改写只能引用当前证据目录中已有条目；无法核验的内容一律降级为
  研究边界声明（limit_claim）或范围确认（accept_chain_scope / accept_announcement_scope）；
- 不伪造：永不自动构造 enter_financial_record / attach_source / resolve_conflict——
  这三类需要人工上传原文并逐页核验，智能体只做定向补采把候选数据摆上桌；
- 全程留痕：每轮的决策、提交的动作、应用结果写入 run_dir/remediation/auto_log.json。
"""

import asyncio
import json
import logging
import re
import uuid
from datetime import date, datetime
from pathlib import Path
from typing import Any

from backend.app.engine.remediation_actions import (
    RemediationConflict, create_search_action, execute_search_action, load_actions,
    save_actions, save_candidate, validate_request,
)
from backend.app.engine.remediation_apply import apply_remediation
from backend.app.engine.remediation_evidence import prepare_limitation
from backend.app.engine.remediation_issues import build_remediation_snapshot
from backend.app.schemas.remediation import ActionRequest, RemediationItem, RemediationSnapshot
from backend.app.schemas.workflow import WorkflowState

logger = logging.getLogger(__name__)

MAX_ROUNDS = 3
MAX_ACTIONS_PER_ROUND = 30
STAGE_TIMEOUT_S = 45 * 60
SEARCH_TIMEOUT_S = 15 * 60
POLL_INTERVAL_S = 5.0
ACTOR = "auto-remediation-v1"

_DOMAIN_BY_REQUIREMENT = {
    "financials": "financials",
    "industry_chain": "industry_chain",
    "macro": "macro",
    "competitors": "competitors",
}


def _read_log(run_dir: Path) -> dict[str, Any]:
    path = run_dir / "remediation" / "auto_log.json"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _write_log(run_dir: Path, log: dict[str, Any]) -> None:
    from backend.app.engine.remediation_sources import _atomic_write

    path = run_dir / "remediation"
    path.mkdir(parents=True, exist_ok=True)
    _atomic_write(path / "auto_log.json", json.dumps(log, ensure_ascii=False, indent=2).encode("utf-8"))


async def _llm_json(system: str, user: str, *, timeout_s: int = 120) -> dict[str, Any] | None:
    """Direct chat-completions call with JSON output; returns None on any failure."""
    import httpx
    from agents_core.call_ledger import thinking_supported
    from chain_research.service import json_object
    from chart_generator.config import Settings

    try:
        settings = Settings.from_env()
        if not settings.llm_api_key:
            return None
        body: dict[str, Any] = {
            "model": settings.llm_model, "temperature": 0.1, "max_tokens": 2048,
            "response_format": {"type": "json_object"},
            "messages": [{"role": "system", "content": system},
                         {"role": "user", "content": user}],
        }
        if thinking_supported(settings.llm_model):
            body["thinking"] = {"type": "disabled"}
        async with httpx.AsyncClient(timeout=timeout_s, trust_env=False) as client:
            response = await client.post(settings.llm_base_url.rstrip("/") + "/chat/completions",
                headers={"Authorization": "Bearer " + settings.llm_api_key}, json=body)
            response.raise_for_status()
            result = json_object(response.json()["choices"][0]["message"]["content"])
        return result if isinstance(result, dict) else None
    except Exception as exc:  # noqa: BLE001 - LLM failure must never break the loop
        logger.warning("auto_remediation LLM call failed: %s", type(exc).__name__)
        return None


def _requirement_entities(item: RemediationItem) -> list[str]:
    requirement = item.context.get("requirement") or {}
    names = requirement.get("entity_names") if isinstance(requirement, dict) else None
    return [str(name) for name in (names or []) if name][:20]


def _requirement_years(item: RemediationItem) -> list[str]:
    requirement = item.context.get("requirement") or {}
    periods = requirement.get("period_ends") if isinstance(requirement, dict) else None
    return sorted({str(p)[:4] for p in (periods or []) if p})


async def _generate_search_query(item: RemediationItem, as_of: date) -> tuple[str, str] | None:
    """Return (query_hint, domain) for supplement_search, or None when not automatable."""
    if item.category == "source_conflict":
        conflict = item.context.get("conflict") or {}
        entities = [str(conflict.get("entity") or "")] if conflict.get("entity") else []
        metric = str(conflict.get("metric") or "")
        period = str(conflict.get("period") or "")[:10]
        query = f"{entities[0]} {metric} {period[:4]}年 年报 财务数据".strip()
        return (query[:200] if query.strip() else None), "financials"
    requirement = item.context.get("requirement") or {}
    domain = _DOMAIN_BY_REQUIREMENT.get(str(requirement.get("domain") or "")) if isinstance(requirement, dict) else None
    if domain is None:
        return None
    label = str(requirement.get("label") or item.title or "")[:120] if isinstance(requirement, dict) else item.title
    entities = _requirement_entities(item)
    years = _requirement_years(item)
    fallback = " ".join([*entities, label, " ".join(years)]).strip()[:200]
    prompt_user = json.dumps({
        "issue_title": item.title, "issue_detail": item.detail[:300],
        "requirement_label": label, "entities": entities, "years": years,
        "as_of": as_of.isoformat(),
    }, ensure_ascii=False)
    result = await _llm_json(
        "你是研报数据补采助手。为问财检索生成一条中文查询，用于补齐缺失数据。"
        "要求：必须包含实体名称和指标词；不要发明实体；长度不超过 60 字。"
        '输出 JSON：{"query": "..."}',
        prompt_user)
    query = str((result or {}).get("query") or "").strip()
    if not query and not fallback:
        return None
    return (query or fallback)[:200], domain


def _load_evidence_index(artifact_dir: Path) -> dict[str, Any]:
    try:
        report = json.loads((artifact_dir / "interpretation_report.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    index = report.get("evidence_index")
    return index if isinstance(index, dict) else {}


def _available_evidence_ids(run_dir: Path, artifact_dir: Path, state_revision: int) -> set[str]:
    available = set(_load_evidence_index(artifact_dir))
    for candidate in load_actions(run_dir):
        if (candidate.get("status") == "ready" and candidate.get("type") in ("attach_source", "enter_financial_record")
                and candidate.get("request", {}).get("expected_revision") == state_revision):
            available.update(candidate.get("candidate_record_ids") or [])
    return available


def _existing_revisions(artifact_dir: Path) -> dict[str, dict[str, Any]]:
    """Previously staged paragraph/methodology revisions keyed by kind:target."""
    try:
        rows = json.loads((artifact_dir / "remediation_revisions.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return {f"{row.get('target_kind')}:{row.get('target_id')}": row
            for row in rows if isinstance(row, dict) and row.get("target_id")}


def _chapters_with_boundary(artifact_dir: Path) -> set[str]:
    """Chapters that already contain a methodology boundary paragraph.

    边界声明文本固定，同一章两条即触发融合查重；段落号每轮重排，
    故按「章」收集已有声明，保证每章至多一条。
    """
    try:
        chapters = json.loads((artifact_dir / "chapter_result.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return set()
    out: set[str] = set()
    for chapter in chapters.get("chapters", []) if isinstance(chapters, dict) else []:
        chapter_id = str(chapter.get("chapter_id") or "")
        for section in chapter.get("sections", []) if isinstance(chapter, dict) else []:
            if not isinstance(section, dict):
                continue
            if any(isinstance(para, dict)
                   and (para.get("kind") == "methodology"
                        or str(para.get("paragraph_id") or "").endswith("-LIMIT"))
                   for para in section.get("paragraphs", []) or []):
                out.add(chapter_id)
                break
    return out


_AUTO_REWRITE_REASON = "智能体依据既有证据改写段落。"


def _purge_rejected_auto_rewrites(artifact_dir: Path) -> int:
    """Drop staged auto paragraph rewrites that already failed re-validation.

    They deterministically fail again on every chapter re-run and each failure
    adds another「人工修订未通过复验」issue. Methodology boundary notes and any
    human-authored revisions are preserved.
    """
    path = artifact_dir / "remediation_revisions.json"
    try:
        rows = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return 0
    if not isinstance(rows, list):
        return 0
    kept = [row for row in rows
            if not (isinstance(row, dict) and row.get("target_kind") == "paragraph"
                    and row.get("reason") == _AUTO_REWRITE_REASON)]
    removed = len(rows) - len(kept)
    if removed:
        from backend.app.engine.remediation_sources import _atomic_write

        _atomic_write(path, json.dumps(kept, ensure_ascii=False, indent=2).encode("utf-8"))
    return removed


def _dedup_methodology_revisions(artifact_dir: Path) -> int:
    """Keep one boundary note per chapter.

    边界声明使用同一模板文本，同一章内多条会触发融合层「段落内容重复」硬阻塞；
    段落号每轮重写后还会重排。按 target_id 推导章节，仅保留每章第一条。
    """
    path = artifact_dir / "remediation_revisions.json"
    try:
        rows = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return 0
    if not isinstance(rows, list):
        return 0
    seen_sections: set[str] = set()
    kept: list[dict[str, Any]] = []
    removed = 0
    for row in rows:
        if not isinstance(row, dict) or row.get("target_kind") != "methodology":
            kept.append(row)
            continue
        target = str(row.get("target_id") or "")
        chapter = target[2:4] if re.fullmatch(r"P-\d{2}-\d{2}-\d{2}", target) else target
        if chapter in seen_sections:
            removed += 1
            continue
        seen_sections.add(chapter)
        kept.append(row)
    if removed:
        from backend.app.engine.remediation_sources import _atomic_write

        _atomic_write(path, json.dumps(kept, ensure_ascii=False, indent=2).encode("utf-8"))
    return removed


def _scope_already_confirmed(log: dict[str, Any]) -> bool:
    for row in log.get("rounds", []) if isinstance(log, dict) else []:
        if isinstance(row, dict):
            for decision in row.get("decisions", []):
                if isinstance(decision, dict) and decision.get("decision") == "accept_chain_scope":
                    return True
    return False


def _invalidate_stale_auto_actions(run_dir: Path) -> None:
    """Auto actions left ready/pending by a crashed earlier run would make items look
    submitted forever — void them so the fresh run can resubmit cleanly."""
    rows = load_actions(run_dir)
    changed = False
    for row in rows:
        if row.get("actor") == ACTOR and row.get("status") in ("ready", "pending"):
            row["status"] = "failed"
            row["error"] = "自动处理已重启，该候选作废并重新提交。"
            changed = True
    if changed:
        save_actions(run_dir, rows)


def _section_exists(artifact_dir: Path, target: str) -> bool:
    section_id = f"SEC-{target[2:4]}-{target[5:7]}"
    try:
        chapters = json.loads((artifact_dir / "chapter_result.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False
    return any(section.get("section_id") == section_id
               for chapter in chapters.get("chapters", []) if isinstance(chapter, dict)
               for section in chapter.get("sections", []) if isinstance(section, dict))


async def _submit_ready(state: WorkflowState, run_dir: Path, item: RemediationItem,
                        req_type: str, payload: dict[str, Any], summary: str,
                        result: dict[str, Any] | None = None) -> str:
    req = ActionRequest(expected_revision=state.revision, expected_fingerprint=item.fingerprint,
                        idempotency_key="auto-" + uuid.uuid4().hex, type=req_type, payload=payload)  # type: ignore[arg-type]
    validate_request(state, run_dir, item.issue_id, req)
    action = save_candidate(state, run_dir, item.issue_id, req, status="ready",
                            summary=summary, result=result, actor=ACTOR)
    return action.action_id


async def _run_search(state: WorkflowState, run_id: str, run_dir: Path, item: RemediationItem,
                      store: Any, engine: Any, query: str, domain: str) -> str | None:
    """Create and execute a supplement_search action; return its action_id when ready."""
    entities = _requirement_entities(item) if item.category == "coverage" else []
    if item.category == "source_conflict":
        conflict = item.context.get("conflict") or {}
        entities = [str(conflict.get("entity") or "")] if conflict.get("entity") else []
    payload = {"query_hint": query, "entities": entities, "domain": domain}
    req = ActionRequest(expected_revision=state.revision, expected_fingerprint=item.fingerprint,
                        idempotency_key="auto-" + uuid.uuid4().hex,
                        type="supplement_search", payload=payload)
    action = create_search_action(state, run_dir, item.issue_id, req)
    await asyncio.wait_for(
        execute_search_action(run_id, run_dir, action.action_id, engine._fetch_supplement_with_audit,
                              lambda: store.load_state(run_id), engine._run_lock(run_id)),
        timeout=SEARCH_TIMEOUT_S)
    rows = {row.get("action_id"): row for row in load_actions(run_dir)}
    return action.action_id if rows.get(action.action_id, {}).get("status") == "ready" else None


async def _handle_item(run_id: str, state: WorkflowState, run_dir: Path, artifact_dir: Path,
                       item: RemediationItem, store: Any, engine: Any,
                       as_of: date, decisions: list[dict[str, Any]],
                       failed_revisions: set[str], existing: dict[str, dict[str, Any]],
                       scope_done: bool, boundary_chapters: set[str],
                       planned_boundaries: set[str]) -> list[str]:
    """Return action_ids created for this item (only ready ones survive upstream)."""
    actions: list[str] = []
    record: dict[str, Any] = {"issue_id": item.issue_id, "category": item.category}

    if item.category == "chain_relation":
        if scope_done:
            record["decision"] = "skip"
            record["detail"] = "本任务此前已确认过交付范围且复验未通过，不再重复提交；需人工补充工序证据。"
        elif "accept_chain_scope" in item.actions:
            actions.append(await _submit_ready(
                state, run_dir, item, "accept_chain_scope", {"classification_only": True},
                "智能体自动确认：仅交付有证据支持的环节分类，工序关系缺口如实披露。"))
            record["decision"] = "accept_chain_scope"
        else:
            record["decision"] = "skip"
            record["detail"] = "范围确认不可用（此前收窄复验未通过），需人工补充工序原文。"
        decisions.append(record)
        return actions

    if item.category == "coverage":
        if "accept_announcement_scope" in item.actions:
            actions.append(await _submit_ready(
                state, run_dir, item, "accept_announcement_scope", {"accept_limitation": True},
                "智能体自动确认：公告检索缺口作为报告限制披露。"))
            record["decision"] = "accept_announcement_scope"
            decisions.append(record)
            return actions
        if "supplement_search" in item.actions:
            planned = await _generate_search_query(item, as_of)
            if planned:
                query, domain = planned
                search_id = await _run_search(state, run_id, run_dir, item, store, engine, query, domain)
                if search_id:
                    record["decision"] = "supplement_search"
                    record["action_id"] = search_id
                    decisions.append(record)
                    return [search_id]
                record["search"] = "no_new_data"
        if "limit_claim" in item.actions:
            target = str(item.context.get("boundary_target") or "")
            chapter_id = f"CH-{target[2:4]}" if re.fullmatch(r"P-\d{2}-\d{2}-\d{2}", target) else ""
            if chapter_id and _section_exists(artifact_dir, target) and chapter_id not in boundary_chapters:
                reason = "自动补采未获得可核验数据，智能体改以研究边界声明披露该资料缺口。"
                prepared = prepare_limitation(target, "coverage", reason)
                if target in planned_boundaries:
                    record["decision"] = "shared_boundary"
                elif existing.get(f"methodology:{target}") == prepared:
                    record["decision"] = "already_applied"
                else:
                    actions.append(await _submit_ready(
                        state, run_dir, item, "limit_claim",
                        {"target_id": target, "template": "coverage", "reason": reason},
                        "智能体已写入研究边界声明。", result={"prepared": prepared}))
                    planned_boundaries.add(target)
                    record["decision"] = "limit_claim"
        if not record.get("decision"):
            record["decision"] = "skip"
        decisions.append(record)
        return actions

    if item.category == "chapter_gap":
        paragraph = next((ref for ref in item.refs if ref.startswith("P-")), "")
        if not paragraph:
            record["decision"] = "skip"
            decisions.append(record)
            return actions
        # 实证结论（2026-11-15）：LLM 段落改写在「逐句证据核验」下的通过率为 0
        # （20/20 全部被拒），每次失败还会新增一条问题项。因此自动通道不再改写
        # 正文，只做两类诚实动作：
        # ① 融合层硬阻塞（企业归属缺来源/研发记录不可引用）→ 跳过，需人工补来源；
        # ② 「段落已被移除」类缺口 → 用研究边界声明披露（幂等，已应用则跳过）。
        fusion_sourced = ("缺少对应来源" in str(item.detail or "")
                          or "研发原始记录不可引用" in str(item.detail or ""))
        if fusion_sourced:
            record["decision"] = "skip"
            record["detail"] = "该段落缺企业归属/研发来源，需要人工补充原文佐证；自动改写已证实无法通过逐句核验。"
            decisions.append(record)
            return actions
        if "limit_claim" in item.actions:
            chapter_id = f"CH-{paragraph[2:4]}"
            reason = "智能体补采未获得可核验依据，改以研究边界声明披露该段落缺口。"
            prepared = prepare_limitation(paragraph, "coverage", reason)
            if paragraph in planned_boundaries:
                record["decision"] = "shared_boundary"
            elif existing.get(f"methodology:{paragraph}") == prepared or chapter_id in boundary_chapters:
                record["decision"] = "already_applied"
            else:
                actions.append(await _submit_ready(
                    state, run_dir, item, "limit_claim",
                    {"target_id": paragraph, "template": "coverage", "reason": reason},
                    "智能体已写入研究边界声明。", result={"prepared": prepared}))
                planned_boundaries.add(paragraph)
                record["decision"] = "limit_claim"
        if not record.get("decision"):
            record["decision"] = "skip"
        decisions.append(record)
        return actions

    if item.category == "source_conflict":
        if "supplement_search" in item.actions:
            planned = await _generate_search_query(item, as_of)
            if planned:
                query, domain = planned
                search_id = await _run_search(state, run_id, run_dir, item, store, engine, query, domain)
                if search_id:
                    record["decision"] = "supplement_search"
                    record["action_id"] = search_id
                    record["detail"] = "已补采候选数据；冲突裁决仍需人工原文佐证，智能体不会代替裁决。"
                    decisions.append(record)
                    return [search_id]
        record["decision"] = "skip"
        record["detail"] = "来源冲突需要人工上传原文佐证后裁决，智能体不代替裁决。"
        decisions.append(record)
        return actions

    record["decision"] = "skip"
    decisions.append(record)
    return actions


async def _wait_terminal(store: Any, run_id: str, engine: Any, *, timeout_s: float = STAGE_TIMEOUT_S) -> WorkflowState | None:
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout_s
    while True:
        state = store.load_state(run_id)
        if state is None:
            return None
        if state.status in ("completed", "failed", "cancelled", "waiting_review"):
            running = engine._running_tasks.get(run_id)
            if running is None or running.done():
                return state
        if loop.time() > deadline:
            return state
        await asyncio.sleep(POLL_INTERVAL_S)


def _failed_revision_targets(run_dir: Path) -> set[str]:
    """Paragraphs whose earlier agent revision failed re-validation — prefer boundary next time."""
    failed: set[str] = set()
    log = _read_log(run_dir)
    for row in log.get("rejected_revisions", []) if isinstance(log, dict) else []:
        if isinstance(row, str):
            failed.add(row)
    return failed


def _collect_rejected_revisions(run_dir: Path, artifact_dir: Path) -> list[str]:
    """Record paragraphs rejected during chapter re-validation so the next round declares boundaries."""
    try:
        chapters = json.loads((artifact_dir / "chapter_result.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    rejected = []
    for chapter in chapters.get("chapters", []) if isinstance(chapters, dict) else []:
        for audit in chapter.get("content_audit", []) if isinstance(chapter, dict) else []:
            if (isinstance(audit, dict) and audit.get("code") == "user_paragraph_revision"
                    and audit.get("disposition") == "rejected"
                    and isinstance(audit.get("location"), str)):
                rejected.append(audit["location"])
    return sorted(set(rejected))


async def run_auto_remediation(run_id: str, *, store: Any, engine: Any,
                               max_rounds: int = MAX_ROUNDS) -> dict[str, Any]:
    from agents_core.artifact_paths import resolve_artifact_dir

    run_dir = store.get_run_dir(run_id)
    log = _read_log(run_dir)
    if not log.get("rounds"):
        log = {"run_id": run_id, "actor": ACTOR, "rounds": []}
    log["started_at"] = datetime.now().isoformat()
    log["round_start"] = len(log["rounds"])
    for key in ("fatal_error", "final_status", "finished_at", "remaining_manual"):
        log.pop(key, None)
    _write_log(run_dir, log)
    failed_revisions = set(_failed_revision_targets(run_dir))
    final_status: str | None = None
    purged = 0
    try:
        for round_no in range(1, max_rounds + 1):
            state = await _wait_terminal(store, run_id, engine)
            if state is None or state.status != "waiting_review":
                final_status = state.status if state else "missing"
                break
            fusion = state.stage_results.get("report_fusion")
            data = fusion.data if fusion else {}
            if (state.current_stage == "report_fusion" and data.get("delivery_status") == "ready_scoped"
                    and data.get("delivery_blocked") is False and data.get("verification_status") == "verified"
                    and (data.get("quality") or {}).get("passed") is True):
                final_status = "already_deliverable"
                break
            artifact_dir = resolve_artifact_dir(run_dir)
            if round_no == 1:
                _invalidate_stale_auto_actions(run_dir)
                purged = _purge_rejected_auto_rewrites(artifact_dir)
                deduped = _dedup_methodology_revisions(artifact_dir)
                if purged or deduped:
                    log.setdefault("cleanup", {})
                    log["cleanup"]["purged_rejected_rewrites"] = purged
                    log["cleanup"]["deduped_boundary_notes"] = deduped
            snapshot = build_remediation_snapshot(state, run_dir)
            existing = _existing_revisions(artifact_dir)
            boundary_chapters = _chapters_with_boundary(artifact_dir)
            scope_done = _scope_already_confirmed(log)
            decisions: list[dict[str, Any]] = []
            created: list[str] = []
            planned_boundaries: set[str] = set()
            round_log = {"round": round_no, "revision": state.revision, "decisions": decisions}
            log["rounds"].append(round_log)
            _write_log(run_dir, log)
            taken = 0
            for item in snapshot.items:
                if taken >= MAX_ACTIONS_PER_ROUND:
                    break
                if item.status in ("resolved", "submitted") or not item.actions or item.category == "other":
                    continue
                taken += 1
                try:
                    created.extend(await _handle_item(
                        run_id, state, run_dir, artifact_dir, item, store, engine,
                        date.fromisoformat(str(state.stage_results["report_fusion"].data.get("research_as_of"))),
                        decisions, failed_revisions, existing, scope_done, boundary_chapters, planned_boundaries))
                except (RemediationConflict, ValueError, OSError, asyncio.TimeoutError, KeyError) as exc:
                    decisions.append({"issue_id": item.issue_id, "category": item.category,
                                      "decision": "error", "detail": f"{type(exc).__name__}: {exc}"})
                _write_log(run_dir, log)
            rows = {row.get("action_id"): row for row in load_actions(run_dir)}
            ready_ids = [aid for aid in dict.fromkeys(created) if rows.get(aid, {}).get("status") == "ready"]
            round_log["ready_action_ids"] = ready_ids
            _write_log(run_dir, log)
            if not ready_ids:
                final_status = "waiting_review"
                break
            await apply_remediation(run_id, state.revision, ready_ids, "auto-" + uuid.uuid4().hex,
                                    store=store, engine=engine)
            new_state = await _wait_terminal(store, run_id, engine)
            round_log["post_status"] = new_state.status if new_state else "missing"
            round_log["post_revision"] = new_state.revision if new_state else None
            if new_state:
                fusion_row = (new_state.stage_results or {}).get("report_fusion")
                round_log["post_error"] = str(getattr(fusion_row, "error", "") or "")[:400]
            if new_state and new_state.revision > state.revision:
                rejected = _collect_rejected_revisions(run_dir, resolve_artifact_dir(run_dir))
                if rejected:
                    failed_revisions.update(rejected)
                    log.setdefault("rejected_revisions", [])
                    log["rejected_revisions"] = sorted(set(log["rejected_revisions"]) | set(rejected))
                _write_log(run_dir, log)
            if not new_state or new_state.status in ("completed", "failed", "cancelled"):
                final_status = new_state.status if new_state else "missing"
                break
            if not new_state.revision > state.revision:
                final_status = "stalled"
                break
        else:
            final_status = "max_rounds"
    finally:
        log["finished_at"] = datetime.now().isoformat()
        log["final_status"] = final_status
        try:
            latest = store.load_state(run_id)
            snapshot = build_remediation_snapshot(latest, run_dir) if latest else None
            log["remaining_manual"] = [
                {"issue_id": item.issue_id, "category": item.category, "title": item.title}
                for item in (snapshot.items if snapshot else [])
                if item.status not in ("resolved",) and item.category in ("source_conflict", "chain_relation", "chapter_gap", "coverage")
                and item.actions
            ]
        except Exception:  # noqa: BLE001 - log enrichment must not fail the runner
            pass
        _write_log(run_dir, log)
    return log
