from __future__ import annotations

import asyncio
import hashlib
import json
import shutil
import uuid
from datetime import date, datetime
from pathlib import Path
from typing import Any

from backend.app.engine.remediation_actions import RemediationConflict, _filter_search_records, load_actions
from backend.app.engine.remediation_issues import build_remediation_snapshot
from backend.app.engine.remediation_sources import _atomic_write
from backend.app.schemas.remediation import RemediationApplyResult
from backend.app.schemas.workflow import StageResult


def _digest(action_ids: list[str], expected_revision: int) -> str:
    return hashlib.sha256(json.dumps({"action_ids": sorted(action_ids), "revision": expected_revision}, sort_keys=True).encode()).hexdigest()


async def apply_remediation(run_id: str, expected_revision: int, action_ids: list[str], idempotency_key: str,
                            *, store: Any, engine: Any) -> RemediationApplyResult:
    """Stage a new artifact tree and state, then publish them with one pointer switch."""
    from backend.app.agents.adapters import merge_supplemental_records
    from backend.app.engine.remediation_conflicts import conflict_item_after_merge, prepare_conflict_decision, prepare_financial_record
    from backend.app.engine.remediation_evidence import (integrate_verified_chain_binding, prepare_chain_binding, prepare_limitation,
                                                        prepare_document_record, prepare_text_revision)
    from agents_core.conflict_resolution import make_resolution, project_dataset
    from data_fetcher.agent import DataFetcherAgent
    from data_fetcher.models import ResearchRecord, ResearchRequirement, StructuredResearchDataset

    if not idempotency_key or not action_ids or len(set(action_ids)) != len(action_ids):
        raise ValueError("请选择不重复的补齐操作并提供请求标识")
    async with engine._run_lock(run_id):
        state = store.load_state(run_id)
        if state is None:
            raise ValueError("任务不存在")
        run_dir = store.get_run_dir(run_id)
        current_artifacts = store.resolve_artifact_dir(run_id)
        request_digest = _digest(action_ids, expected_revision)
        pointer_path = run_dir / "artifact_pointer.json"
        pointer = json.loads(pointer_path.read_text(encoding="utf-8")) if pointer_path.exists() else {"current": "artifacts", "history": {}}
        marker_dirs = {current_artifacts}
        for revision in (pointer.get("history") or {}):
            if str(revision).isdigit():
                marker_dirs.add(store.resolve_artifact_dir(run_id, int(revision)))
        for artifact_dir in marker_dirs:
            marker_path = artifact_dir / "remediation_commit.json"
            if not marker_path.exists():
                continue
            marker = json.loads(marker_path.read_text(encoding="utf-8"))
            if marker.get("idempotency_key") == idempotency_key:
                if marker.get("request_digest") != request_digest:
                    raise RemediationConflict("该请求标识已用于不同操作")
                from backend.app.schemas.workflow import WorkflowState
                previous = WorkflowState.model_validate(marker["result_state"]) if marker.get("result_state") else state
                return RemediationApplyResult(state=previous, affected_stages=marker["affected_stages"])
        if state.revision != expected_revision or state.current_stage != "report_fusion" or state.status != "waiting_review":
            raise RemediationConflict("任务版本或审核状态已变化，请刷新后重试")
        running = engine._running_tasks.get(run_id)
        if running is not None and not running.done():
            raise RemediationConflict("任务正在执行，请等待完成")
        rows = load_actions(run_dir)
        selected = [next((row for row in rows if row.get("action_id") == aid), None) for aid in action_ids]
        if any(row is None or row.get("status") != "ready" for row in selected):
            raise ValueError("存在未完成或不可应用的补齐操作")
        snapshot = build_remediation_snapshot(state, run_dir)
        items = {item.issue_id: item for item in snapshot.items}
        for row in selected:
            item = items.get(row["issue_id"])
            if item is None or item.fingerprint != row.get("expected_fingerprint"):
                raise RemediationConflict("问题或输入数据已变化，请重新核对")
            if row.get("type") not in ("supplement_search", "enter_financial_record", "resolve_conflict", "revise_paragraph", "attach_source", "limit_claim", "accept_chain_scope", "accept_announcement_scope"):
                raise ValueError("该类型的补齐尚未完成复验接入")

        scope_actions = [row for row in selected if row.get("type") == "accept_chain_scope"]
        announcement_actions = [row for row in selected if row.get("type") == "accept_announcement_scope"]
        if (len(scope_actions) > 1 or any(
            items[row["issue_id"]].category != "chain_relation"
            or row.get("request", {}).get("payload", {}).get("classification_only") is not True
            for row in scope_actions
        )):
            raise ValueError("产业链交付范围确认无效")

        fusion = state.stage_results.get("report_fusion")
        as_of_text = fusion.data.get("research_as_of") if fusion else None
        if not as_of_text:
            raise ValueError("缺少研究截止日期")
        as_of = date.fromisoformat(str(as_of_text))
        dataset = StructuredResearchDataset.model_validate_json((current_artifacts / "dataset.json").read_text(encoding="utf-8"))
        announcement_ids: list[str] = []
        if announcement_actions:
            from backend.app.engine.scoped_delivery import eligible_automatic_announcement, merge_announcement_choices
            try:
                raw_input = json.loads((run_dir / "input_data.json").read_text(encoding="utf-8"))
            except (OSError, ValueError):
                raise ValueError("原始研究要求不可用，无法确认公告检索范围") from None
            raw_dataset = dataset.model_dump(mode="json")
            for action in announcement_actions:
                item = items[action["issue_id"]]
                rid = item.refs[0] if item.refs else ""
                if (item.category != "coverage" or action.get("request", {}).get("payload", {}).get("accept_limitation") is not True
                        or not eligible_automatic_announcement(raw_dataset, raw_input, rid)):
                    raise ValueError("公告检索范围已变化或属于用户明确要求")
                announcement_ids.append(rid)
            try:
                previous_scope = json.loads((current_artifacts / "announcement_scope_decision.json").read_text(encoding="utf-8"))
            except (OSError, ValueError):
                previous_scope = None
            announcement_ids = merge_announcement_choices(previous_scope, run_id, state.revision,
                (current_artifacts / "dataset.json").read_bytes(), announcement_ids)
            for row in dataset.quality_summary.get("requirement_evidence_matrix") or []:
                if row.get("requirement", {}).get("requirement_id") in announcement_ids:
                    row["requirement"]["origin"] = "automatic_announcement"
        existing_ids = {record.record_id for record in dataset.all_records()}
        if any(not set(conflict.record_ids).issubset(existing_ids) for conflict in dataset.conflicts):
            raise ValueError("原始冲突记录不完整，不能安全更新数据集")
        records = [ResearchRecord.model_validate(record) for row in selected if row["type"] == "supplement_search"
                   for record in _filter_search_records(run_dir, state, row["issue_id"], row.get("candidate_records", []), as_of)]
        chain_bundle = None
        chain_documents: dict[str, str] = {}
        for row in selected:
            if row["type"] == "enter_financial_record":
                payload = row["request"]["payload"]
                prepared = prepare_financial_record(run_dir, payload, as_of)
                if not prepared["source"]["publication_date_verified"]:
                    raise ValueError("材料发布日期尚未核实，不能应用")
                if prepared["record"]["record_id"] not in row.get("candidate_record_ids", []):
                    raise RemediationConflict("财务候选内容已变化，请重新核对")
                records.append(ResearchRecord.model_validate(prepared["record"]))
            elif row["type"] == "attach_source":
                if items[row["issue_id"]].category == "chain_relation":
                    from chain_research.models import ChainKnowledgeBundle

                    payload = row["request"]["payload"]
                    candidate = prepare_chain_binding(run_dir, items[row["issue_id"]], str(payload.get("source_id") or ""),
                        payload.get("page"), str(payload.get("excerpt") or ""), str(payload.get("subject_id") or ""),
                        str(payload.get("object_id") or ""), as_of)
                    if candidate != row.get("prepared"):
                        raise RemediationConflict("工序或原文已变化，请重新核验")
                    if chain_bundle is None:
                        chain_path = current_artifacts / "chain" / "v2" / "bundle.json"
                        chain_bundle = ChainKnowledgeBundle.model_validate_json(chain_path.read_text(encoding="utf-8"))
                    chain_bundle, document_id = integrate_verified_chain_binding(chain_bundle, candidate, row.get("verdict") or {})
                    chain_documents[document_id] = candidate["source"]["literal_excerpt"]
                    continue
                payload = row["request"]["payload"]
                record = prepare_document_record(run_dir, str(payload.get("source_id") or ""), payload.get("page"),
                                                 str(payload.get("excerpt") or ""), as_of)
                if not record["raw_fields"]["publication_date_verified"]:
                    raise ValueError("材料发布日期尚未核实，不能应用")
                if record["record_id"] not in row.get("candidate_record_ids", []):
                    raise RemediationConflict("原文候选已变化，请重新核对")
                records.append(ResearchRecord.model_validate(record))
        added = merge_supplemental_records(dataset, {}, records, as_of)
        decisions = []
        for row in selected:
            if row["type"] != "resolve_conflict":
                continue
            payload = row["request"]["payload"]
            item = items[row["issue_id"]]
            selected_id = str(payload.get("selected_record_id") or "")
            if selected_id not in {record.get("record_id") for record in item.context.get("records", [])}:
                if not any(candidate["type"] == "enter_financial_record" and candidate["issue_id"] == row["issue_id"]
                           and selected_id in candidate.get("candidate_record_ids", []) for candidate in selected):
                    raise ValueError("冲突裁决依赖的财务候选必须同时选择并应用")
            if added:
                item = conflict_item_after_merge(item, dataset)
            prepared = prepare_conflict_decision(
                run_dir, item, str(payload.get("selected_record_id") or ""), payload.get("source_id"),
                payload.get("page"), str(payload.get("excerpt") or ""), str(payload.get("reason") or ""), as_of,
            )
            if not prepared["source"]["publication_date_verified"]:
                raise ValueError("材料发布日期尚未核实，不能应用")
            if prepared != row.get("prepared"):
                raise RemediationConflict("冲突候选或依据已变化，请重新核对后提交")
            decisions.append(make_resolution(dataset, prepared))
        if decisions:
            dataset.quality_summary.setdefault("remediation_decisions", []).extend(decisions)
            _, _, valid = project_dataset(dataset)
            if not all(decision in valid for decision in decisions):
                raise ValueError("存在重叠或已变化的冲突，不能应用裁决")
            matrix = dataset.quality_summary.get("requirement_evidence_matrix") or []
            for row in matrix:
                requirement = ResearchRequirement.model_validate(row["requirement"])
                row["coverage"] = DataFetcherAgent._evaluate_requirement(dataset, requirement).model_dump(mode="json")
            coverage = [row["coverage"] for row in matrix]
            extras = [row for row in dataset.quality_summary.get("requested_requirement_coverage", [])
                      if row.get("requirement_id") not in {item.get("requirement_id") for item in coverage}]
            dataset.quality_summary["requested_requirement_coverage"] = coverage + extras
            dataset.quality_summary["requested_financial_coverage"] = [row for row in coverage if str(row.get("requirement_id", "")).startswith("annual_")]
        revisions_path = current_artifacts / "remediation_revisions.json"
        revisions = json.loads(revisions_path.read_text(encoding="utf-8")) if revisions_path.exists() else []
        if not isinstance(revisions, list):
            raise ValueError("段落修订记录损坏，不能覆盖")
        previous = {f"{item.get('target_kind')}:{item.get('target_id')}": item for item in revisions if isinstance(item, dict) and item.get("target_id")}
        revised = False
        report_path = current_artifacts / "interpretation_report.json"
        report = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else {}
        available = set((report.get("evidence_index") or {}).keys()) | set(added)
        targets = set()
        for row in selected:
            if row["type"] not in ("revise_paragraph", "limit_claim"):
                continue
            payload = row["request"]["payload"]
            target = str(payload.get("target_id") or "")
            if row["type"] == "limit_claim":
                if items[row["issue_id"]].category == "chapter_gap" and target not in items[row["issue_id"]].refs:
                    raise ValueError("研究边界目标已变化")
                if items[row["issue_id"]].category == "coverage" and target != items[row["issue_id"]].context.get("boundary_target"):
                    raise ValueError("研究边界位置已变化")
                prepared = prepare_limitation(target, str(payload.get("template") or ""), str(payload.get("reason") or ""))
                if prepared != row.get("prepared"):
                    raise RemediationConflict("研究边界已变化，请重新核对")
                key = f"methodology:{target}"
                if key in targets:
                    raise ValueError("同一位置不能重复选择研究边界")
                targets.add(key)
                revised |= previous.get(key) != prepared
                previous[key] = prepared
                continue
            refs = payload.get("evidence_refs") or []
            key = f"paragraph:{target}"
            if target not in items[row["issue_id"]].refs or key in targets or not isinstance(refs, list) or set(refs) - available:
                raise ValueError("段落修订目标或证据引用已失效")
            targets.add(key)
            prepared = prepare_text_revision("paragraph", target, str(payload.get("text") or ""), refs,
                                             str(payload.get("reason") or ""))
            revised |= previous.get(key) != prepared
            previous[key] = prepared
        if not added and not decisions and not revised and not chain_documents and not scope_actions and not announcement_actions:
            raise ValueError("没有符合要求的新数据或裁决；原版本保持不变")

        if scope_actions:
            from data_fetcher.fusion import DataFusion
            dataset.conflicts = DataFusion()._find_conflicts(dataset)
            dataset.quality_summary["conflict_count"] = len(dataset.conflicts)
            try:
                bundle_hash = hashlib.sha256((current_artifacts / "chain" / "v2" / "bundle.json").read_bytes()).hexdigest()
            except OSError as exc:
                raise ValueError("没有可核验的产业链证据包，无法确认有限覆盖范围") from exc

        next_revision = state.revision + 1
        relative = f"artifact_revisions/{next_revision}-{uuid.uuid4().hex}"
        target = run_dir / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        temp = target.parent / (".staging-" + uuid.uuid4().hex)
        history = dict(pointer.get("history") or {})
        history[str(state.revision)] = str(pointer.get("current") or "artifacts")
        history[str(next_revision)] = relative
        announcement_only = all(row.get("type") == "accept_announcement_scope" for row in selected)
        start_stage = "report_fusion" if announcement_only else "data_interpret"
        affected = ["report_fusion"] if announcement_only else ["data_interpret", "chart_generate", "chapter_write", "report_fusion"]
        fresh = state.model_copy(deep=True)
        fresh.revision = next_revision
        fresh.current_stage = start_stage
        fresh.status = "running"
        fresh.updated_at = datetime.now().isoformat()
        if start_stage not in fresh.stage_results:
            fresh.stage_results[start_stage] = StageResult(stage=start_stage)
        fresh.stage_results[start_stage].status = "running"
        fresh.stage_results[start_stage].revision = next_revision
        fresh.stage_results[start_stage].error = None
        engine._invalidate_following_stages(fresh, start_stage)
        if "data_fetch" in fresh.stage_results:
            fetch_data = fresh.stage_results["data_fetch"].data
            fetch_data["total_records"] = dataset.total_record_count
            fetch_data["replenishment_status"] = "completed"
        input_file = run_dir / "input_data.json"
        input_data = json.loads(input_file.read_text(encoding="utf-8")) if input_file.exists() else {}
        review_stages = input_data.get("review_stages")
        if review_stages is None:
            review_stages = ["data_fetch", "data_interpret", "chart_generate", "chapter_write", "report_fusion"]
        try:
            shutil.copytree(current_artifacts, temp)
            (temp / "remediation_issue_baseline.json").write_text(json.dumps({
                "from_revision": state.revision,
                "items": [item.model_dump(mode="json") for item in snapshot.items if item.status != "resolved"],
            }, ensure_ascii=False, indent=2), encoding="utf-8")
            (temp / "dataset.json").write_text(dataset.model_dump_json(indent=2), encoding="utf-8")
            if announcement_ids:
                (temp / "announcement_scope_decision.json").write_text(json.dumps({
                    "run_id": run_id, "from_revision": state.revision, "revision": next_revision,
                    "accepted_ids": sorted(set(announcement_ids)),
                    "dataset_sha256": hashlib.sha256((temp / "dataset.json").read_bytes()).hexdigest(),
                    "actor": "本地未认证用户", "created_at": datetime.now().isoformat(),
                }, ensure_ascii=False, indent=2), encoding="utf-8")
            if scope_actions:
                (temp / "scope_decision.json").write_text(json.dumps({
                    "run_id": run_id, "from_revision": state.revision, "revision": next_revision,
                    "classification_only": True, "issue_fingerprint": scope_actions[0]["expected_fingerprint"],
                    "bundle_sha256": bundle_hash,
                    "actor": "本地未认证用户", "created_at": datetime.now().isoformat(),
                }, ensure_ascii=False, indent=2), encoding="utf-8")
            if revised:
                (temp / "remediation_revisions.json").write_text(json.dumps(list(previous.values()), ensure_ascii=False, indent=2), encoding="utf-8")
            if chain_bundle is not None:
                chain_dir = temp / "chain" / "v2"
                (chain_dir / "bundle.json").write_text(chain_bundle.model_dump_json(indent=2), encoding="utf-8")
                (chain_dir / "quality.json").write_text(chain_bundle.quality.model_dump_json(indent=2), encoding="utf-8")
                (chain_dir / "manifest.json").write_text(chain_bundle.manifest.model_dump_json(indent=2), encoding="utf-8")
                documents = chain_dir / "documents"
                documents.mkdir(parents=True, exist_ok=True)
                for document_id, quote in chain_documents.items():
                    (documents / f"{document_id}.raw").write_text(quote, encoding="utf-8")
            # 修复同样推进了版本：仍在等待审核的阶段必须换发新决策包，
            # 否则其 approve 会被判为「决策版本已变化」。
            from backend.app.engine.review_decisions import refresh_waiting_review_packages
            refresh_waiting_review_packages(fresh)
            (temp / "workflow_state.json").write_text(fresh.model_dump_json(indent=2), encoding="utf-8")
            (temp / "remediation_commit.json").write_text(json.dumps({
                "idempotency_key": idempotency_key, "request_digest": request_digest, "action_ids": action_ids,
                "from_revision": state.revision, "to_revision": next_revision, "added_record_ids": added,
                "affected_stages": affected, "result_state": fresh.model_dump(mode="json"),
                "actor": "本地未认证用户", "created_at": datetime.now().isoformat(),
            }, ensure_ascii=False, indent=2), encoding="utf-8")
            temp.replace(target)
            _atomic_write(pointer_path, json.dumps({"current": relative, "history": history}, ensure_ascii=False).encode())
        finally:
            if temp.exists():
                shutil.rmtree(temp)
        task = asyncio.create_task(engine._execute_stage(run_id, start_stage, review_stages))
        engine._running_tasks[run_id] = task
        return RemediationApplyResult(state=fresh, affected_stages=affected)
