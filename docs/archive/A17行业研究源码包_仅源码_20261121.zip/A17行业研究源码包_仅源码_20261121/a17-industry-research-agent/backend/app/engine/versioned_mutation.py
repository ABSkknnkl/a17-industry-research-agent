"""Copy-on-write boundary for edits to a versioned workflow."""
from __future__ import annotations

import json
import shutil
import uuid
from dataclasses import dataclass
from pathlib import Path

from agents_core.artifact_paths import resolve_artifact_dir
from backend.app.engine.remediation_sources import _atomic_write
from backend.app.schemas.workflow import WorkflowState


def rebase_artifact_references(value, old_path: str, new_path: str):
    """Change local artifact pointers, never arbitrary evidence or prose."""
    if isinstance(value, dict):
        result = {}
        for key, item in value.items():
            if key in {"uri", "svg_uri", "artifact_dir"} and isinstance(item, str) and (
                item == old_path or item.startswith(old_path + "/")
            ):
                result[key] = new_path + item[len(old_path):]
            else:
                result[key] = rebase_artifact_references(item, old_path, new_path)
        return result
    if isinstance(value, list):
        return [rebase_artifact_references(item, old_path, new_path) for item in value]
    return value


@dataclass
class VersionFork:
    pointer_path: Path
    old_pointer: bytes
    new_dir: Path
    snapshot_path: Path
    old_snapshot: bytes | None

    def rollback(self) -> None:
        _atomic_write(self.pointer_path, self.old_pointer)
        if self.old_snapshot is None:
            self.snapshot_path.unlink(missing_ok=True)
        else:
            _atomic_write(self.snapshot_path, self.old_snapshot)
        shutil.rmtree(self.new_dir, ignore_errors=True)


def begin_versioned_mutation(run_dir: Path, state: WorkflowState, stage: str) -> tuple[WorkflowState, VersionFork | None]:
    """Publish a fail-closed new working tree while keeping the old tree immutable.

    On a crash, the new tree remains marked running with stale exports and the
    normal startup recovery marks it interrupted. Readers never see the old
    version's files being changed.
    """
    pointer_path = run_dir / "artifact_pointer.json"
    if not pointer_path.exists():
        return state, None
    old_pointer = pointer_path.read_bytes()
    pointer = json.loads(old_pointer)
    current = resolve_artifact_dir(run_dir)
    history = dict(pointer.get("history") or {})
    old_relative = pointer["current"]
    if str(state.revision) in history and history[str(state.revision)] != old_relative:
        raise ValueError("当前任务版本与产物指针不一致，不能安全编辑")
    next_revision = state.revision + 1
    relative = f"artifact_revisions/{next_revision}-{uuid.uuid4().hex}"
    target = run_dir / relative
    staging = target.parent / (".staging-" + uuid.uuid4().hex)
    target.parent.mkdir(parents=True, exist_ok=True)
    snapshot = run_dir / "revisions" / f"{state.revision}.json"
    old_snapshot = snapshot.read_bytes() if snapshot.exists() else None
    fork = VersionFork(pointer_path, old_pointer, target, snapshot, old_snapshot)
    try:
        shutil.copytree(current, staging)
        old_path, new_path = str(current.resolve()), str(target.resolve())
        for path in staging.rglob("*.json"):
            if path.name == "remediation_commit.json":
                path.unlink()
                continue
            if path.name in {"dataset.json", "interpretation_report.json", "remediation_revisions.json"}:
                continue
            content = path.read_text(encoding="utf-8")
            if old_path in content:
                data = rebase_artifact_references(json.loads(content), old_path, new_path)
                path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        data = rebase_artifact_references(state.model_dump(mode="json"), old_path, new_path)
        rebased = WorkflowState.model_validate(data)
        provisional = rebased.model_copy(deep=True)
        provisional.revision = next_revision
        provisional.current_stage = stage
        provisional.status = "running"
        if stage in provisional.stage_results:
            provisional.stage_results[stage].status = "running"
            provisional.stage_results[stage].revision = next_revision
        fusion = provisional.stage_results.get("report_fusion")
        if fusion:
            fusion.data["exports_stale"] = True
        (staging / "workflow_state.json").write_text(provisional.model_dump_json(indent=2), encoding="utf-8")
        _atomic_write(snapshot, state.model_dump_json(indent=2).encode())
        staging.replace(target)
        history[str(state.revision)] = old_relative
        history[str(next_revision)] = relative
        _atomic_write(pointer_path, json.dumps({**pointer, "current": relative, "history": history}, ensure_ascii=False).encode())
        return rebased, fork
    except Exception:
        if staging.exists():
            shutil.rmtree(staging, ignore_errors=True)
        if target.exists():
            shutil.rmtree(target, ignore_errors=True)
        if old_snapshot is None:
            snapshot.unlink(missing_ok=True)
        else:
            _atomic_write(snapshot, old_snapshot)
        raise
