"""Revise the paragraphs flagged in a published chapter draft."""
from __future__ import annotations

import asyncio
import json
import re
from pathlib import Path
from typing import Any

import httpx

from agents_core.artifact_paths import resolve_artifact_dir
from agents_core.context_budget import ContextBudgetExceeded, serialize_context
from agents_core.financial_semantics import retain_supported_claims
from chapter_writer.agent import ChapterWriterAgent, _issue_kind, _remediation_claims_supported
from chapter_writer.models import ChapterDraft, ChapterWritingRequest, InterpretationReport
from chapter_writer.outline import DEFAULT_OUTLINE
from chapter_writer.retriever import DynamicEvidenceRetriever

_GAP = re.compile(r"^段落资料缺口：(CH-\d{2})\s+(.+)$", re.S)
_PARAGRAPH = re.compile(r"^(P[\w.-]+)\s+(.+)$", re.S)
_REPAIR_PROMPT = (
    "仅修订给出的一个研报段落。只保留所附证据能直接核验且与原段主题相关的陈述。"
    "核对主体、年份、口径和单位，去掉重复、推测和无证据的因果判断。"
    "返回 JSON 对象，字段 text 和 evidence_ids。证据不足时返回空 text 与空 evidence_ids。"
)


def _gap_parts(issue: str) -> tuple[str, list[str]] | None:
    match = _GAP.match(issue)
    return (match[1], match[2].split("；")) if match else None


def _repair_audit(row: dict[str, Any]) -> bool:
    return (
        row.get("code") in {"chapter_claim_repair", "chapter_paragraph_revision"}
        and row.get("disposition") == "isolated"
        and not row.get("revision_status")
    )


async def _revise_chapter(raw, outline, problems, evidence, retriever, agent, slots):
    chapter = ChapterDraft.model_validate(raw)
    sections = {section["section_id"]: section for section in raw["sections"]}
    saved = {p["paragraph_id"]: (section, p) for section in sections.values() for p in section["paragraphs"]}
    audit = raw.setdefault("content_audit", [])
    isolated = {row["location"]: row for row in audit if _repair_audit(row) and row.get("location")}
    for pid, row in isolated.items():
        problems.setdefault(pid, [str(row.get("claim") or "原段落未通过核验")])
    chapter_evidence = retriever.retrieve(outline.chapter_id, outline).get("evidence", {})
    repaired, removed = {}, {}
    changed_sections = set()
    for pid, issues in problems.items():
        previous = isolated.get(pid, {})
        section, original = saved.get(pid, (sections.get(previous.get("section_id")), {}))
        # Old drafts may carry a gap in quality.issues without retaining the original text.
        if section is None and re.fullmatch(r"P-\d{2}-\d{2}-\d{2}", pid):
            section = sections.get(f"SEC-{pid[2:7]}")
        text = str(original.get("text") or previous.get("original") or "")
        original_ids = original.get("evidence_ids") or previous.get("evidence_ids") or []
        available = {rid: evidence[rid] for rid in dict.fromkeys([*original_ids, *chapter_evidence])
                     if rid in evidence}
        refs = [rid for rid in original_ids if rid in available]
        only_duplicate = all("重复" in issue and "数值" not in issue and "因果" not in issue for issue in issues)
        reason = "与其他段落重复" if only_duplicate else "缺少可核验的证据，无法保留原段落"
        replacement = None

        def verify(candidate, ids):
            if not isinstance(candidate, str) or not candidate.strip() or not isinstance(ids, list):
                return None
            if not ids or any(not isinstance(rid, str) or rid not in available for rid in ids):
                return None
            outcome = agent._apply_remediation_revisions(
                chapter, outline, [{"target_id": pid, "text": candidate.strip(), "evidence_refs": ids}],
                available, retriever.report.financial_ratios,
            )
            if outcome and outcome[0]["status"] == "accepted":
                return next(p for part in chapter.sections for p in part.paragraphs if p.paragraph_id == pid)
            return None

        if section is not None and text and not only_duplicate:
            trimmed = retain_supported_claims(text, lambda clause: _remediation_claims_supported(clause, refs, available))
            replacement = verify(trimmed, refs)
            if replacement is None and available and agent.llm.is_available:
                evidence_ids = list(available)[:32]
                payload = {"paragraph_id": pid, "text": text, "issues": issues,
                           "evidence": {rid: available[rid] for rid in evidence_ids}}
                try:
                    prompt, _, _ = serialize_context(payload, system=_REPAIR_PROMPT)
                    async with slots:
                        proposed = await agent.llm.generate_json(_REPAIR_PROMPT, prompt)
                    if isinstance(proposed, dict):
                        replacement = verify(proposed.get("text"), proposed.get("evidence_ids"))
                    if replacement is None:
                        reason = "修订后仍未通过证据核验"
                except (ContextBudgetExceeded, httpx.HTTPError, TimeoutError, ValueError, RuntimeError, KeyError, IndexError):
                    reason = "修订未返回可核验的内容"

        if section is not None:
            paragraphs = section["paragraphs"]
            position = next((i for i, p in enumerate(paragraphs) if p["paragraph_id"] == pid), None)
            if position is not None:
                paragraphs.pop(position)
                changed_sections.add(section["section_id"])
            if replacement is not None:
                if position is None:
                    position = next((i for i, p in enumerate(paragraphs)
                                     if p["paragraph_id"].startswith(pid.rsplit("-", 1)[0] + "-")
                                     and p["paragraph_id"] > pid), len(paragraphs))
                paragraphs.insert(position, {**original, **replacement.model_dump(mode="json")})
                changed_sections.add(section["section_id"])
            else:
                # The validation copy participates in duplicate checks for later targets.
                part = next(s for s in chapter.sections if s.section_id == section["section_id"])
                part.paragraphs = [p for p in part.paragraphs if p.paragraph_id != pid]

        row = previous or {"code": "chapter_paragraph_revision", "location": pid,
                           "section_id": section["section_id"] if section else None,
                           "original": text, "evidence_ids": original_ids}
        if not previous:
            audit.append(row)
        if replacement is not None:
            raw["evidence_ids"] = list(dict.fromkeys([*raw.get("evidence_ids", []), *replacement.evidence_ids]))
            row.update(disposition="repaired", revision_status="repaired", reason="已通过证据核验",
                       replacement_evidence_ids=replacement.evidence_ids)
            repaired[pid] = replacement.evidence_ids
        else:
            if not only_duplicate:
                details = [re.search(r"因质量问题被整段移除（([^）]+)）", issue) for issue in issues]
                kinds = list(dict.fromkeys(
                    detail[1] if detail else _issue_kind(issue) for issue, detail in zip(issues, details)
                ))
                kinds = [kind for kind in kinds if kind and kind != "因质量问题被整段移除"]
                if kinds:
                    reason = f"{'、'.join(kinds)}，{reason}"
            row.update(disposition="isolated", revision_status="removed", reason=reason)
            removed[pid] = reason
    return chapter.chapter_id, repaired, removed, changed_sections


async def prepare_chapter_revision(state, run_dir: Path, agent: ChapterWriterAgent):
    artifact_dir = resolve_artifact_dir(run_dir)
    path = artifact_dir / "chapter_result.json"
    package = json.loads(path.read_text(encoding="utf-8"))
    report = InterpretationReport.model_validate_json((artifact_dir / "interpretation_report.json").read_text(encoding="utf-8"))
    retriever = DynamicEvidenceRetriever(ChapterWritingRequest(report=report))
    evidence = {rid: row.model_dump(mode="json") for rid, row in report.evidence_index.items()
                if "review_excluded" not in row.issues}
    quality = package["quality"]
    issues = quality.get("issues", [])
    problems: dict[str, dict[str, list[str]]] = {}
    for issue in issues:
        if gap := _gap_parts(issue):
            for part in gap[1]:
                if paragraph := _PARAGRAPH.match(part.strip()):
                    problems.setdefault(gap[0], {}).setdefault(paragraph[1], []).append(paragraph[2])

    outlines = {outline.chapter_id: outline for outline in DEFAULT_OUTLINE}
    slots = asyncio.Semaphore(4)
    results = await asyncio.gather(*(
        _revise_chapter(chapter, outlines[cid], problems.get(cid, {}), evidence, retriever, agent, slots)
        for chapter in package["chapters"] if (cid := chapter["chapter_id"]) in outlines
        and (cid in problems or any(_repair_audit(row) for row in chapter.get("content_audit", [])))
    ))
    repaired = {pid: ids for _, accepted, _, _ in results for pid, ids in accepted.items()}
    removed = {pid: reason for _, _, drops, _ in results for pid, reason in drops.items()}
    changed_sections = {section for _, _, _, changed in results for section in changed}
    if not repaired and not removed:
        raise ValueError("当前版本没有可修订的问题段落")

    touched = set(repaired) | set(removed)

    def remaining_issue(issue: str) -> str:
        gap = _gap_parts(issue)
        if gap is None:
            return issue
        parts = [part for part in gap[1] if not (match := _PARAGRAPH.match(part.strip())) or match[1] not in touched]
        return f"段落资料缺口：{gap[0]} {'；'.join(parts)}" if parts else ""

    gaps = [f"段落资料缺口：{cid} {pid} 因质量问题被整段移除（{reason}）"
            for cid, _, drops, _ in results for pid, reason in drops.items()]
    quality["issues"] = list(dict.fromkeys([*(item for issue in issues if (item := remaining_issue(issue))), *gaps]))
    quality["passed"] = not quality["issues"] and not quality.get("fallback_chapter_ids")
    package["status"] = "completed" if quality["passed"] else "partial"
    sections = {section["section_id"]: section["paragraphs"] for chapter in package["chapters"] for section in chapter["sections"]}
    paragraphs = [p for rows in sections.values() for p in rows if str(p.get("text", "")).strip()]
    quality["evidence_coverage"] = sum(bool(p.get("evidence_ids")) for p in paragraphs) / max(len(paragraphs), 1)

    disclosures = []
    for answer in package.get("question_answers", []):
        ids = answer.get("paragraph_ids") or []
        if not touched.intersection(ids):
            continue
        answer_ids = [pid for pid in ids if pid not in removed]
        answer["paragraph_ids"] = answer_ids
        prior_refs = set(answer.get("evidence_record_ids") or [])
        for pid in repaired.keys() & set(ids):
            prior_refs.update(repaired[pid])
        answer["evidence_record_ids"] = sorted(prior_refs.intersection(
            rid for p in sections.get(answer.get("section_id"), []) if p["paragraph_id"] in answer_ids
            for rid in p.get("evidence_ids", [])
        ))
        if not answer_ids and answer.get("text"):
            answer["revision_evidence_gap"] = "原结论缺少可核验的证据"
            disclosures.append(f"研究问题「{answer['text']}」的原结论缺少可核验的证据，相关段落已移除。")

    package["warnings"] = list(dict.fromkeys([
        *(item for warning in package.get("warnings", []) if (item := remaining_issue(warning))), *gaps, *disclosures,
    ]))
    data = state.stage_results["chapter_write"].model_copy(deep=True).data
    for chapter in data.get("chapters") or []:
        for section in chapter.get("sections", []):
            if section.get("section_id") in changed_sections:
                section["paragraphs"] = sections[section["section_id"]]
    if not data.get("chapters"):
        data["chapters"] = package["chapters"]
    summary = {"repaired_count": len(repaired), "removed_count": len(removed),
               "removed": [{"paragraph_id": pid, "reason": reason} for pid, reason in removed.items()]}
    data.update(agent_status=package["status"], paragraph_revision=summary,
                quality={**(data.get("quality") or {}), **quality, "warnings": package["warnings"]})
    message = f"修订完成，修复 {len(repaired)} 段，移除 {len(removed)} 段"
    return {path: json.dumps(package, ensure_ascii=False, indent=2)}, data, message
