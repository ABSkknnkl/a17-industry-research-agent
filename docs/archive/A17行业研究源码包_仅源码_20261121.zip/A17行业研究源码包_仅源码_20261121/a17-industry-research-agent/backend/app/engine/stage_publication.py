"""Isolated stage workspaces and CAS-gated atomic artifact publication."""
from __future__ import annotations

import hashlib
import json
import shutil
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from agents_core.artifact_paths import (
    ArtifactWorkspace,
    reset_artifact_workspace,
    resolve_artifact_dir,
    set_artifact_workspace,
)
from backend.app.core.storage import storage
from backend.app.engine.remediation_sources import _atomic_write
from backend.app.engine.versioned_mutation import rebase_artifact_references
from backend.app.schemas.workflow import WorkflowState


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _file_manifest(root: Path) -> dict[str, str]:
    manifest: dict[str, str] = {}
    if not root.exists():
        return manifest
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(root).as_posix()
        if relative in {"workflow_state.json", "stage_input.json", "stage_execution.json", "events.jsonl"}:
            continue
        manifest[relative] = _sha256(path)
    return manifest


class StagePublication:
    """Own one stage's private tree; only publish after the engine's CAS succeeds."""

    def __init__(self, run_id: str, stage: str, state: WorkflowState, store: Any = None) -> None:
        self.run_id = run_id
        self.stage = stage
        self.attempt_id = uuid.uuid4().hex
        self.store = store if store is not None else storage
        self.input_revision = state.revision
        self.run_dir = self.store.get_run_dir(run_id)
        self.pointer_path = self.run_dir / "artifact_pointer.json"
        self.source_dir = resolve_artifact_dir(self.run_dir)
        self.source_relative = self.source_dir.relative_to(self.run_dir).as_posix()
        self._token: Any = None
        self._published = False
        self._moved_target: Path | None = None

        if not self.pointer_path.exists():
            pointer = {
                "current": self.source_relative,
                "history": {str(self.input_revision): self.source_relative},
                "stage_history": [],
            }
            _atomic_write(
                self.pointer_path,
                json.dumps(pointer, ensure_ascii=False, indent=2).encode("utf-8"),
            )
        self.expected_pointer = self.pointer_path.read_bytes()

        # The pointer-selected state is authoritative as soon as a pointer exists.
        # Seed both visible and private trees with the same running state.
        state_bytes = state.model_dump_json(indent=2).encode("utf-8")
        _atomic_write(self.source_dir / "workflow_state.json", state_bytes)

        self.workspace = ArtifactWorkspace(
            run_dir=self.run_dir,
            path=self.run_dir / ".stage_workspaces" / f"{stage}-{self.attempt_id}",
        )
        self.workspace.path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(self.source_dir, self.workspace.path)
        _atomic_write(self.workspace.path / "workflow_state.json", state_bytes)

        input_file = self.run_dir / "input_data.json"
        snapshot_file = self.run_dir / "execution_snapshot.json"
        self.input_snapshot = {
            "run_id": run_id,
            "stage": stage,
            "attempt_id": self.attempt_id,
            "input_revision": self.input_revision,
            "source_artifacts": self.source_relative,
            "source_pointer_sha256": hashlib.sha256(self.expected_pointer).hexdigest(),
            "input_data_sha256": _sha256(input_file) if input_file.is_file() else None,
            "execution_snapshot_sha256": _sha256(snapshot_file) if snapshot_file.is_file() else None,
            "artifact_sha256": _file_manifest(self.source_dir),
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        _atomic_write(
            self.workspace.path / "stage_input.json",
            json.dumps(self.input_snapshot, ensure_ascii=False, indent=2).encode("utf-8"),
        )

    @property
    def published(self) -> bool:
        return self._published

    def activate(self) -> None:
        if self._token is None and not self._published:
            self._token = set_artifact_workspace(self.workspace)

    def suspend(self) -> None:
        """Temporarily expose committed artifacts to the bounded supplement coordinator."""
        if self._token is not None:
            reset_artifact_workspace(self._token)
            self._token = None

    def abandon_paths(self, value: Any) -> Any:
        """Never leak a discarded private path into failed state or logs."""
        return rebase_artifact_references(
            value, str(self.workspace.path.resolve()), str(self.source_dir.resolve()),
        )

    def _rebase_workspace(self, target: Path) -> None:
        old_path = str(self.workspace.path.resolve())
        new_path = str(target.resolve())
        for path in self.workspace.path.rglob("*.json"):
            content = path.read_text(encoding="utf-8")
            if old_path not in content:
                continue
            data = rebase_artifact_references(json.loads(content), old_path, new_path)
            _atomic_write(
                path,
                json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8"),
            )

    def publish(self, state: WorkflowState) -> WorkflowState:
        """Move the completed tree and atomically switch its pointer."""
        if self._published:
            return state
        if state.revision != self.input_revision:
            raise ValueError("阶段输入 revision 已变化，禁止发布旧执行结果")
        if self.pointer_path.read_bytes() != self.expected_pointer:
            raise ValueError("阶段执行期间产物指针已变化，禁止发布旧输入结果")
        if _file_manifest(self.source_dir) != self.input_snapshot["artifact_sha256"]:
            raise ValueError("阶段执行期间输入产物哈希已变化，禁止发布旧输入结果")

        target_relative = f"artifact_revisions/{state.revision}-{uuid.uuid4().hex}"
        target = self.run_dir / target_relative
        target.parent.mkdir(parents=True, exist_ok=True)
        self._rebase_workspace(target)
        rebased_data = rebase_artifact_references(
            state.model_dump(mode="json"),
            str(self.workspace.path.resolve()),
            str(target.resolve()),
        )
        rebased_state = WorkflowState.model_validate(rebased_data)
        # `artifact_sha256` 是读者会拿来校验交付产物的字段，必须对应该阶段
        # 发布后的输出，而不是输入快照。输入哈希单独保留，CAS 语义不变。
        output_manifest = _file_manifest(self.workspace.path)
        execution_record = {
            **self.input_snapshot,
            "input_artifact_sha256": self.input_snapshot["artifact_sha256"],
            "artifact_sha256": output_manifest,
            "output_artifacts": target_relative,
            "output_revision": state.revision,
            "published_at": datetime.now(timezone.utc).isoformat(),
            "status": "published",
        }
        _atomic_write(
            self.workspace.path / "stage_execution.json",
            json.dumps(execution_record, ensure_ascii=False, indent=2).encode("utf-8"),
        )

        # save_state follows the active workspace, so the complete final state is
        # already inside the tree before readers can see the new pointer.
        self.store.save_state(rebased_state)
        self.workspace.path.replace(target)
        self._moved_target = target
        try:
            pointer = json.loads(self.expected_pointer)
            history = dict(pointer.get("history") or {})
            history[str(state.revision)] = target_relative
            stage_history = list(pointer.get("stage_history") or [])
            stage_history.append({
                "stage": self.stage,
                "revision": state.revision,
                "input": self.source_relative,
                "output": target_relative,
                "published_at": execution_record["published_at"],
            })
            _atomic_write(
                self.pointer_path,
                json.dumps({
                    **pointer,
                    "current": target_relative,
                    "history": history,
                    "stage_history": stage_history,
                }, ensure_ascii=False, indent=2).encode("utf-8"),
            )
        except Exception:
            shutil.rmtree(target, ignore_errors=True)
            self._moved_target = None
            raise
        self.workspace.path = target
        self._published = True
        return rebased_state

    def close(self) -> None:
        if self._token is not None:
            reset_artifact_workspace(self._token)
            self._token = None
        if not self._published:
            shutil.rmtree(self.workspace.path, ignore_errors=True)
            if self._moved_target is not None:
                shutil.rmtree(self._moved_target, ignore_errors=True)
                self._moved_target = None
