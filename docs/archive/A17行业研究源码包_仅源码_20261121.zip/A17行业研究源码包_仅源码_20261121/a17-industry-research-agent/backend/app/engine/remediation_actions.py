from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import uuid
from contextlib import asynccontextmanager
from datetime import date
from pathlib import Path
from typing import Any, Awaitable, Callable

from backend.app.engine.remediation_issues import build_remediation_snapshot
from backend.app.engine.remediation_sources import _atomic_write
from backend.app.schemas.remediation import ActionRequest, CandidateAction
from backend.app.schemas.workflow import WorkflowState

logger = logging.getLogger(__name__)


class RemediationConflict(ValueError):
    pass


def load_actions(run_dir: Path) -> list[dict[str, Any]]:
    path = run_dir / "remediation" / "actions.json"
    if not path.exists():
        return []
    try:
        rows = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise ValueError("补齐记录损坏，请检查后恢复") from exc
    if not isinstance(rows, list):
        raise ValueError("补齐记录格式错误")
    return rows


def save_actions(run_dir: Path, rows: list[dict[str, Any]]) -> None:
    _atomic_write(run_dir / "remediation" / "actions.json", json.dumps(rows, ensure_ascii=False, indent=2).encode())


def recover_interrupted_actions(run_dir: Path, active_ids: set[str]) -> None:
    """Mark abandoned local jobs as failed without touching another live worker."""
    import os

    rows = load_actions(run_dir)
    changed = False
    for row in rows:
        if row.get("status") != "pending" or row.get("action_id") in active_ids:
            continue
        owner = row.get("worker_pid")
        if isinstance(owner, int) and owner > 0 and owner != os.getpid():
            try:
                os.kill(owner, 0)
                continue
            except PermissionError:
                continue
            except ProcessLookupError:
                pass
        row["status"] = "failed"
        row["error"] = "处理被中断，请重新提交。"
        row["result_summary"] = row["error"]
        changed = True
    if changed:
        save_actions(run_dir, rows)


def validate_request(state: WorkflowState, run_dir: Path, issue_id: str, request: ActionRequest) -> None:
    if state.revision != request.expected_revision:
        raise RemediationConflict("任务版本已变化，请刷新后重新操作")
    if state.current_stage != "report_fusion" or state.status != "waiting_review":
        raise RemediationConflict("请在报告融合待审核时处理质检问题")
    snapshot = build_remediation_snapshot(state, run_dir)
    item = next((item for item in snapshot.items if item.issue_id == issue_id), None)
    if item is None or item.fingerprint != request.expected_fingerprint:
        raise RemediationConflict("问题或数据已变化，请刷新后重新核对")
    if request.type not in item.actions:
        raise ValueError("该问题不支持此操作")


def _request_digest(issue_id: str, request: ActionRequest) -> str:
    value = {"issue_id": issue_id, **request.model_dump(mode="json")}
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def save_candidate(state: WorkflowState, run_dir: Path, issue_id: str, request: ActionRequest,
                   *, status: str, summary: str = "", result: dict[str, Any] | None = None,
                   actor: str = "本地未认证用户") -> CandidateAction:
    validate_request(state, run_dir, issue_id, request)
    rows = load_actions(run_dir)
    digest = _request_digest(issue_id, request)
    old = next((row for row in rows if row.get("idempotency_key") == request.idempotency_key), None)
    if old:
        if old.get("request_digest") != digest:
            raise RemediationConflict("该请求标识已用于不同操作")
        return CandidateAction.model_validate(old)
    action = CandidateAction(action_id="action-" + uuid.uuid4().hex, issue_id=issue_id, type=request.type,
                             status=status, expected_fingerprint=request.expected_fingerprint,
                             result_summary=summary)
    row = action.model_dump(mode="json")
    row.update({"request": request.model_dump(mode="json"), "request_digest": digest,
                "idempotency_key": request.idempotency_key, "actor": actor})
    if status == "pending":
        import os
        row["worker_pid"] = os.getpid()
    if result:
        row.update(result)
    rows.append(row)
    save_actions(run_dir, rows)
    return CandidateAction.model_validate(row)


def create_search_action(state: WorkflowState, run_dir: Path, issue_id: str, request: ActionRequest) -> CandidateAction:
    payload = request.payload
    if request.type != "supplement_search":
        raise ValueError("动作类型不匹配")
    query = str(payload.get("query_hint") or "").strip()
    entities = payload.get("entities") or []
    if not query or len(query) > 1000 or not isinstance(entities, list) or len(entities) > 50:
        raise ValueError("请填写有效的补采查询和实体")
    if payload.get("domain") not in {"financials", "industry_chain", "macro", "competitors"}:
        raise ValueError("不支持该补采领域")
    return save_candidate(state, run_dir, issue_id, request, status="pending", summary="正在定向补采")


@asynccontextmanager
async def _unlocked():
    yield


def _filter_search_records(run_dir: Path, state: WorkflowState, issue_id: str,
                           records: list[dict[str, Any]], as_of: date) -> list[dict[str, Any]]:
    from agents_core.artifact_paths import resolve_artifact_dir
    from agents_core.financial_semantics import metric_family

    path = resolve_artifact_dir(run_dir) / "dataset.json"
    dataset = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    existing = {str(r.get("record_id")) for section in ("industry", "companies", "financials", "macro", "industry_chain", "reports", "news")
                for r in dataset.get(section, []) or [] if isinstance(r, dict) and r.get("record_id")}
    item = next((i for i in build_remediation_snapshot(state, run_dir).items if i.issue_id == issue_id), None)
    conflict = item.context.get("conflict", {}) if item and item.category == "source_conflict" else {}
    candidates = item.context.get("records", []) if conflict else []
    entities = {str(x) for row in candidates for x in (row.get("entity_name"), row.get("entity_code")) if x}
    if conflict.get("entity"):
        entities.add(str(conflict["entity"]))
    expected_metric = metric_family(str(conflict.get("metric") or ""))
    expected_period = str(conflict.get("period") or "")[:10]
    filtered = []
    for record in records:
        rid = str(record.get("record_id") or "")
        if not rid or rid in existing:
            continue
        if any(str(record.get(key) or "")[:10] > as_of.isoformat() for key in ("period_end", "published_at") if record.get(key)):
            continue
        if conflict:
            if record.get("domain") != "financials":
                continue
            if entities and not entities.intersection({str(record.get("entity_name") or ""), str(record.get("entity_code") or "")}):
                continue
            if expected_metric and metric_family(str(record.get("metric") or "")) != expected_metric:
                continue
            if expected_period and str(record.get("period_end") or "")[:10] != expected_period:
                continue
        existing.add(rid)
        filtered.append(record)
    return filtered


async def execute_search_action(run_id: str, run_dir: Path, action_id: str,
                                fetch: Callable[..., Awaitable[list[Any]]],
                                get_state: Callable[[], WorkflowState | None],
                                lock: asyncio.Lock | None = None) -> CandidateAction:
    rows = load_actions(run_dir)
    row = next((r for r in rows if r.get("action_id") == action_id), None)
    if not row:
        raise ValueError("补采操作不存在")
    request = ActionRequest.model_validate(row["request"])
    try:
        state = get_state()
        if state is None:
            raise RemediationConflict("任务不存在")
        fusion = state.stage_results.get("report_fusion")
        as_of = date.fromisoformat(str(fusion.data.get("research_as_of"))) if fusion and fusion.data.get("research_as_of") else None
        if not as_of:
            raise ValueError("缺少研究截止日期，无法执行补采")
        demand = {"domain": request.payload["domain"], "entities": request.payload.get("entities") or [],
                  "query_hint": str(request.payload["query_hint"]).strip(), "reason": "质检问题定向补采",
                  "_remediation_strict": True}
        results = await fetch(run_id, "data_fetch", demand, as_of)
        records = [r.model_dump(mode="json") if hasattr(r, "model_dump") else r for r in results or []]
        records = [r for r in records if isinstance(r, dict) and r.get("record_id")][:200]
        error = None
    except Exception as exc:
        logger.warning("Remediation search failed: %s", type(exc).__name__)
        records, error = [], "补采未完成，请检查数据服务后重试。"

    async with lock if lock is not None else _unlocked():
        rows = load_actions(run_dir)
        row = next((r for r in rows if r.get("action_id") == action_id), None)
        if row is None:
            raise ValueError("补采操作不存在")
        state = get_state()
        try:
            if state is None:
                raise RemediationConflict("任务不存在")
            validate_request(state, run_dir, row["issue_id"], request)
            if error is None and as_of is not None:
                records = _filter_search_records(run_dir, state, row["issue_id"], records, as_of)
        except (ValueError, RemediationConflict):
            records, error = [], "任务版本或问题已变化，本次补采结果未应用。"
        row["status"] = "failed" if error else ("ready" if records else "no_new_data")
        row["error"] = error
        row["result_summary"] = error or (f"找到 {len(records)} 条候选数据，待核验并应用。" if records else "本次没有新增候选数据。")
        row["candidate_record_ids"] = [str(r["record_id"]) for r in records]
        row["candidate_records"] = records
        save_actions(run_dir, rows)
    return CandidateAction.model_validate(row)


async def execute_chain_action(run_id: str, run_dir: Path, action_id: str,
                               get_state: Callable[[], WorkflowState | None],
                               lock: asyncio.Lock | None = None, *, verifier=None) -> CandidateAction:
    from agents_core.artifact_paths import resolve_artifact_dir
    from backend.app.engine.remediation_evidence import prepare_chain_binding, verify_chain_candidate

    rows = load_actions(run_dir)
    row = next((item for item in rows if item.get("action_id") == action_id), None)
    if not row:
        raise ValueError("工序核验操作不存在")
    request = ActionRequest.model_validate(row["request"])
    candidate = row.get("prepared") or {}
    try:
        bundle = json.loads((resolve_artifact_dir(run_dir) / "chain" / "v2" / "bundle.json").read_text(encoding="utf-8"))
        result = await verify_chain_candidate(candidate, bundle["scope"], verifier=verifier)
        error = None
    except Exception as exc:
        logger.warning("Remediation chain verification failed: %s", type(exc).__name__)
        result, error = {}, "独立关系核验未完成，请检查模型服务后重试。"
    async with lock if lock is not None else _unlocked():
        rows = load_actions(run_dir)
        row = next((item for item in rows if item.get("action_id") == action_id), None)
        if row is None:
            raise ValueError("工序核验操作不存在")
        state = get_state()
        try:
            if state is None:
                raise RemediationConflict("任务不存在")
            validate_request(state, run_dir, row["issue_id"], request)
            item = next(i for i in build_remediation_snapshot(state, run_dir).items if i.issue_id == row["issue_id"])
            payload = request.payload
            checked = prepare_chain_binding(run_dir, item, str(payload.get("source_id") or ""), payload.get("page"),
                str(payload.get("excerpt") or ""), str(payload.get("subject_id") or ""),
                str(payload.get("object_id") or ""), date.fromisoformat(candidate["as_of"]))
            if checked != candidate:
                raise RemediationConflict("原文或工序已变化")
        except (ValueError, RemediationConflict, StopIteration, KeyError):
            result, error = {}, "任务版本、原文或工序已变化，本次核验结果未应用。"
        accepted = result.get("accepted") is True and not error
        row["status"] = "failed" if error else ("ready" if accepted else "needs_review")
        row["error"] = error
        row["verdict"] = result.get("verdict") or {}
        row["result_summary"] = error or ("工序原文已通过独立核验，应用后还需重新质检。" if accepted
                                            else "原文尚不足以证明所选工序的先后关系，请更换或补充资料。")
        save_actions(run_dir, rows)
    return CandidateAction.model_validate(row)
