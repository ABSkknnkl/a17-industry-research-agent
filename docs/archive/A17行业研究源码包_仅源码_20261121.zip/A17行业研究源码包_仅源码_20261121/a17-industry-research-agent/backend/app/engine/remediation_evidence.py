from __future__ import annotations

import hashlib
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

from backend.app.engine.remediation_sources import load_source, publication_date_verified, verify_excerpt
from backend.app.schemas.remediation import RemediationItem


def prepare_document_record(run_dir: Path, source_id: str, page: int, excerpt: str, as_of: date) -> dict[str, Any]:
    if isinstance(page, bool) or not isinstance(page, int) or not verify_excerpt(run_dir, source_id, page, excerpt):
        raise ValueError("原文摘录与指定 PDF 页不匹配")
    source = load_source(run_dir, source_id)
    date_verified = publication_date_verified(run_dir, source, page, as_of)
    record_id = "R-" + hashlib.sha256(f"{source_id}|{page}|{excerpt}".encode()).hexdigest()[:20]
    return {"record_id": record_id, "domain": "reports", "metric": "人工补充资料摘录", "value": excerpt,
            "published_at": source.published_at if date_verified else None,
            "source": {"task_id": "remediation", "skill_id": "user-document", "skill_version": "1",
                       "query": source.title, "trace_id": source_id, "retrieved_at": datetime.now(timezone.utc).isoformat(),
                       "status": "human_review"},
            "raw_fields": {"source_id": source_id, "source_url": source.source_url, "source_locator": f"PDF 第{page}页",
                           "document_sha256": source.sha256, "literal_excerpt": excerpt, "title": source.title,
                           "publisher_verified": source.publisher_verified,
                           "official_origin_verified": source.official_origin_verified,
                           "declared_published_at": source.published_at, "publication_date_verified": date_verified},
            "issues": [] if date_verified else ["user_supplied_source_unverified", "unverified_publication_date", "missing_published_at"]}


def prepare_chain_binding(run_dir: Path, item: RemediationItem, source_id: str, page: int, excerpt: str,
                          subject_id: str, object_id: str, as_of: date) -> dict[str, Any]:
    if item.category != "chain_relation" or not subject_id or subject_id == object_id:
        raise ValueError("请选择两个不同的产业链工序")
    activities = {str(a.get("entity_id")): a for a in item.context.get("activities", []) if isinstance(a, dict)
                  and a.get("entity_type") == "activity"}
    subject, target = activities.get(subject_id), activities.get(object_id)
    if not subject or not target:
        raise ValueError("关系两端必须是当前产业链中的工序")
    if isinstance(page, bool) or not isinstance(page, int) or not verify_excerpt(run_dir, source_id, page, excerpt):
        raise ValueError("原文摘录与指定 PDF 页不匹配")
    source = load_source(run_dir, source_id)
    date_verified = publication_date_verified(run_dir, source, page, as_of)
    text = "".join(excerpt.split()).casefold()
    names = [str(x.get("canonical_name") or "") for x in (subject, target)]
    if any(not name or "".join(name.split()).casefold() not in text for name in names):
        raise ValueError("摘录必须明确包含两个工序的名称")
    return {"subject_id": subject_id, "object_id": object_id, "subject": names[0], "object": names[1],
            "predicate": "precedes", "status": "unresolved", "as_of": as_of.isoformat(),
            "source": {"source_id": source_id, "title": source.title, "source_url": source.source_url,
                       "source_locator": f"PDF 第{page}页", "document_sha256": source.sha256,
                       "published_at": source.published_at if date_verified else None,
                       "declared_published_at": source.published_at, "publication_date_verified": date_verified,
                       "publisher_verified": source.publisher_verified,
                       "official_origin_verified": source.official_origin_verified, "literal_excerpt": excerpt}}


def evaluate_chain_verdict(candidate: dict[str, Any], verdict: dict[str, Any]) -> bool:
    from chain_research.service import current_fact_issue

    quote = (candidate.get("source") or {}).get("literal_excerpt") or ""
    return bool((candidate.get("source") or {}).get("publication_date_verified") is True
                and verdict.get("supported") is True and verdict.get("in_scope") is True
                and str(verdict.get("reason") or "").strip()
                and not current_fact_issue(quote, candidate["as_of"]))


async def verify_chain_candidate(candidate: dict[str, Any], scope: dict[str, Any], *, verifier=None) -> dict[str, Any]:
    """Use the existing chain verifier prompt on the actual quote and explicit endpoints."""
    quote = candidate["source"]["literal_excerpt"]
    payload = {"scope": scope, "document_url": candidate["source"].get("source_url"),
               "document_title": candidate["source"]["title"], "checks": [{"id": "candidate", "claim": {
                   "subject": candidate["subject"], "predicate": "precedes", "object": candidate["object"], "quote": quote},
                   "context": quote}]}
    if verifier is None:
        import json
        import httpx
        from agents_core.call_ledger import thinking_supported
        from chain_research.project import PROMPTS
        from chain_research.service import json_object
        from chart_generator.config import Settings

        settings = Settings.from_env()
        if not settings.llm_api_key:
            raise RuntimeError("未配置工序关系核验模型")
        system = (PROMPTS["verify"] + "每项必须输出 in_scope 布尔值。必须确认原文直接证明两个活动的先后方向；"
                  "仅提及活动、分类或企业参与不构成工序关系。证据不足时 supported 必须为 false。")
        body = {"model": settings.llm_model, "temperature": 0.1, "max_tokens": 2048,
                "messages": [{"role": "system", "content": system},
                             {"role": "user", "content": json.dumps(payload, ensure_ascii=False)}]}
        if thinking_supported(settings.llm_model):
            body["thinking"] = {"type": "disabled"}
        async with httpx.AsyncClient(timeout=120, trust_env=False) as client:
            response = await client.post(settings.llm_base_url.rstrip("/") + "/chat/completions",
                                         headers={"Authorization": "Bearer " + settings.llm_api_key}, json=body)
            response.raise_for_status()
            result = json_object(response.json()["choices"][0]["message"]["content"])
    else:
        result = await verifier(payload)
    checks = result.get("checks", []) if isinstance(result, dict) else []
    verdict = next((item for item in checks if isinstance(item, dict) and item.get("id") == "candidate"), {})
    safe = {"supported": verdict.get("supported") is True, "in_scope": verdict.get("in_scope") is True,
            "reason": str(verdict.get("reason") or "")[:500]}
    return {"accepted": evaluate_chain_verdict(candidate, safe), "verdict": safe}


def integrate_verified_chain_binding(bundle: Any, candidate: dict[str, Any], verdict: dict[str, Any]) -> tuple[Any, str]:
    from chain_research.models import ChainKnowledgeBundle, stable_id

    if not evaluate_chain_verdict(candidate, verdict) or candidate.get("predicate") != "precedes":
        raise ValueError("原文未通过独立工序关系核验")
    if candidate.get("as_of") != bundle.scope.as_of:
        raise ValueError("产业链研究时点已变化")
    subject = bundle.entity_by_id(candidate["subject_id"])
    target = bundle.entity_by_id(candidate["object_id"])
    if (not subject or not target or subject.entity_type != "activity" or target.entity_type != "activity"
            or subject.entity_id == target.entity_id or subject.canonical_name != candidate["subject"]
            or target.canonical_name != candidate["object"]
            or not {subject.entity_id, target.entity_id}.issubset(set(bundle.structure.activity_ids))):
        raise ValueError("工序端点已变化或不属于当前产业链结构")
    source = candidate["source"]
    quote = source["literal_excerpt"]
    document_id = stable_id("doc", source["source_id"], source["source_locator"], quote)
    evidence_id = stable_id("evidence", document_id, quote)
    assertion_id = stable_id("assertion", subject.entity_id, "precedes", target.entity_id, evidence_id)
    if any(item.assertion_id == assertion_id for item in bundle.assertions):
        raise ValueError("该工序关系及来源已存在")
    updated = bundle.model_dump(mode="json")
    updated["evidence"].append({"evidence_id": evidence_id, "document_id": document_id,
        "url": source.get("source_url"), "title": source["title"], "document_kind": "other",
        "published_at": source.get("published_at"), "content_hash": hashlib.sha256(quote.encode()).hexdigest()[:32],
        "source_family": f"user_pdf:{source['document_sha256']}", "source_tier": "unverified",
        "locator": source["source_locator"], "quote": quote})
    updated["assertions"].append({"assertion_id": assertion_id, "subject_id": subject.entity_id,
        "predicate": "precedes", "object_id": target.entity_id, "status": "supported", "evidence_ids": [evidence_id],
        "qualifiers": {"extra": {"source_pdf_sha256": source["document_sha256"], "source_id": source["source_id"]}},
        "verification": {"method": "model_assisted", "verifier_version": "remediation_independent_v1",
                         "rationale": str(verdict["reason"]), "supporting_evidence_ids": [evidence_id]}})
    updated["structure"]["structure_assertion_ids"].append(assertion_id)
    updated["revision"] += 1
    updated["manifest"]["revision"] = updated["revision"]
    updated["manifest"]["notes"].append("Supplemented process relation independently verified; chain completeness remains uncertified.")
    supported = [item for item in updated["assertions"] if item["status"] == "supported"]
    coverage = updated["quality"]["coverage_values"]
    coverage["supported_assertions"] = len(supported)
    coverage["activities_with_supported_facts"] = len({entity_id for item in supported
        for entity_id in (item["subject_id"], item["object_id"]) if entity_id in updated["structure"]["activity_ids"]})
    coverage["presentation_ready"] = False
    updated["quality"]["release_status"] = "partial"
    updated["quality"]["evidence_trace_rate"] = 1.0 if supported else None
    if "completeness_not_certified" not in updated["quality"]["reason_codes"]:
        updated["quality"]["reason_codes"].append("completeness_not_certified")
    return ChainKnowledgeBundle.model_validate(updated), document_id


def prepare_text_revision(target_kind: str, target_id: str, text: str,
                          evidence_refs: list[str], reason: str) -> dict[str, Any]:
    if target_kind not in {"paragraph", "summary", "methodology"} or not target_id.strip():
        raise ValueError("请选择要修订的内容")
    if not text.strip() or not reason.strip():
        raise ValueError("请填写修订内容和理由")
    if target_kind in {"paragraph", "summary"} and not evidence_refs:
        raise ValueError("正文修订需要关联可核验证据")
    return {"target_kind": target_kind, "target_id": target_id, "text": text.strip(),
            "evidence_refs": evidence_refs, "reason": reason.strip(), "status": "pending_recheck"}


def prepare_limitation(target_id: str, template: str, reason: str) -> dict[str, Any]:
    import re
    from agents_core.remediation_boundaries import LIMITATIONS

    if not re.fullmatch(r"P-\d{2}-\d{2}-\d{2}", target_id) or template not in LIMITATIONS:
        raise ValueError("请选择有效段落和研究边界")
    revision = prepare_text_revision("methodology", target_id, LIMITATIONS[template], [], reason)
    revision["template"] = template
    return revision
