"""五阶段产物的统一、可兼容契约校验。"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from pydantic import BaseModel, ValidationError

from chart_generator.models import ChartGenerationResult
from chapter_writer.models import ChapterWritingResult
from data_fetcher.models import StructuredResearchDataset
from data_interpreter.models import InterpretationReport
from report_fusion.models import ReportViewModel


class StageContractError(ValueError):
    """阶段 JSON 产物存在结构或跨字段契约错误。"""


@dataclass(frozen=True)
class StageContract:
    artifact_name: str
    parser: Callable[[dict[str, Any]], BaseModel]
    version: int = 1


STAGE_CONTRACTS: dict[str, StageContract] = {
    "data_fetch": StageContract("dataset.json", StructuredResearchDataset.model_validate),
    "data_interpret": StageContract("interpretation_report.json", InterpretationReport.model_validate),
    "chart_generate": StageContract("chart_result.json", ChartGenerationResult.model_validate),
    "chapter_write": StageContract("chapter_result.json", ChapterWritingResult.model_validate),
    "report_fusion": StageContract("report_view.json", ReportViewModel.model_validate),
}

STAGE_PREREQUISITES: dict[str, tuple[str, ...]] = {
    "data_fetch": (),
    "data_interpret": ("data_fetch",),
    "chart_generate": ("data_interpret",),
    "chapter_write": ("data_interpret", "chart_generate"),
    "report_fusion": ("data_interpret", "chart_generate", "chapter_write"),
}


def _contract_error(contract: StageContract, exc: ValidationError) -> StageContractError:
    # 不回显 Pydantic 的 input 值，避免输入/远端错误在异常中泄漏。
    issues = []
    for item in exc.errors()[:12]:
        location = ".".join(str(part) for part in item.get("loc", ())) or "root"
        issues.append(f"{location}: {item.get('msg', '格式错误')}")
    return StageContractError(f"{contract.artifact_name} 契约校验失败：" + "；".join(issues))


def _validate_chart_cross_fields(parsed: ChartGenerationResult) -> None:
    for chart in parsed.charts:
        # A3 的产业链证据图由确定性 SVG 模板渲染，保留 `inline_svg` 而不是
        # ECharts option；generated_image 则以 image_uri 为实际渲染体。两者
        # 都是 ready 图表的合法载体，不能只按 option 是否为空判定缺图。
        has_fallback_render = (
            (chart.render_mode == "svg" and bool(chart.inline_svg))
            or (chart.render_mode == "generated_image" and bool(chart.image_uri))
        )
        if chart.status == "ready" and not chart.option and not has_fallback_render:
            raise StageContractError(f"chart_result.json 中 ready 图表 {chart.chart_id} 缺少 option")
        if not chart.data_fingerprint.strip():
            raise StageContractError(f"chart_result.json 中图表 {chart.chart_id} 缺少 data_fingerprint")


def _evidence_ids(value: Any) -> set[str]:
    found: set[str] = set()
    if isinstance(value, dict):
        for key, item in value.items():
            if key in {"evidence_ids", "point_evidence_ids"} and isinstance(item, list):
                found.update(str(entry).strip() for entry in item if str(entry).strip())
            else:
                found.update(_evidence_ids(item))
    elif isinstance(value, list):
        for item in value:
            found.update(_evidence_ids(item))
    return found


def _validate_report_evidence(parsed: ReportViewModel) -> None:
    catalog_ids = [item.record_id for item in parsed.evidence_catalog]
    if len(catalog_ids) != len(set(catalog_ids)):
        raise StageContractError("report_view.json 的 evidence_catalog 存在重复 record_id")
    # 文本原文只能支持“部分核验”时，A5 会把断言及证据 ID 显式标注；
    # 这类已披露限制不是静默的未登记引用。未进入该标注清单的引用仍失败。
    annotated_ids: set[str] = set()
    for warning in parsed.verification_warnings:
        if warning.get("disposition") != "annotated":
            continue
        for field in ("evidence_ids", "verification_evidence_ids"):
            values = warning.get(field) or []
            if isinstance(values, list):
                annotated_ids.update(str(value) for value in values if isinstance(value, str) and value)
    missing = sorted(_evidence_ids(parsed.model_dump(mode="json")) - set(catalog_ids) - annotated_ids)
    if missing:
        raise StageContractError(
            "report_view.json 存在未登记证据引用：" + "、".join(missing[:8])
        )


def validate_stage_artifact(stage: str, path: str | Path) -> BaseModel:
    """解析阶段主产物；缺新增可选字段的旧 JSON 可按原模型默认值读取。"""
    contract = STAGE_CONTRACTS.get(stage)
    if contract is None:
        raise StageContractError(f"未知阶段契约: {stage}")
    artifact_path = Path(path)
    try:
        payload = json.loads(artifact_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise StageContractError(f"无法读取 {contract.artifact_name}: {type(exc).__name__}") from exc
    if not isinstance(payload, dict):
        raise StageContractError(f"{contract.artifact_name} 顶层必须是 JSON 对象")
    try:
        artifact_version = int(payload.pop("schema_version", 0))
    except (TypeError, ValueError) as exc:
        raise StageContractError(f"{contract.artifact_name} 的契约版本无效") from exc
    if artifact_version > contract.version or artifact_version < 0:
        raise StageContractError(
            f"{contract.artifact_name} 契约版本 {artifact_version} 不受支持"
        )
    try:
        parsed = contract.parser(payload)
    except ValidationError as exc:
        raise _contract_error(contract, exc) from exc
    if stage == "chart_generate":
        _validate_chart_cross_fields(parsed)  # type: ignore[arg-type]
    elif stage == "chapter_write":
        # 真实 JSON 往返一次，防止 warnings 等运行时字段只在内存对象里存在。
        try:
            parsed = contract.parser(parsed.model_dump(mode="json"))
        except ValidationError as exc:
            raise _contract_error(contract, exc) from exc
    elif stage == "report_fusion":
        _validate_report_evidence(parsed)  # type: ignore[arg-type]
    return parsed


def validate_stage_prerequisites(stage: str, artifact_dir: str | Path) -> list[str]:
    """返回上游主产物的缺失或契约错误；供恢复调度统一使用。"""
    if stage not in STAGE_PREREQUISITES:
        raise StageContractError(f"未知阶段契约: {stage}")
    root = Path(artifact_dir)
    errors: list[str] = []
    for upstream in STAGE_PREREQUISITES[stage]:
        contract = STAGE_CONTRACTS[upstream]
        path = root / contract.artifact_name
        if not path.is_file():
            errors.append(f"缺少 {contract.artifact_name}")
            continue
        try:
            validate_stage_artifact(upstream, path)
        except StageContractError as exc:
            errors.append(str(exc))
    return errors
