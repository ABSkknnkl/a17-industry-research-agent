from __future__ import annotations
from agents_core.artifact_paths import resolve_artifact_dir

import hashlib
import json
import re
from pathlib import Path
from typing import Any

from backend.app.schemas.remediation import CandidateAction, RemediationItem, RemediationSnapshot
from backend.app.schemas.workflow import WorkflowState


def _read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return default


def _digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, default=str).encode()).hexdigest()


def _item(category: str, key: str, revision: int, title: str, detail: str,
          refs: list[str], actions: list[str], context: dict[str, Any]) -> RemediationItem:
    return RemediationItem(
        issue_id=f"{category}-{_digest(key)[:20]}",
        fingerprint=_digest({"revision": revision, "category": category, "key": key, "context": context, "detail": detail}),
        category=category, title=title, detail=detail, refs=refs, actions=actions, context=context,
    )


def build_remediation_snapshot(state: WorkflowState, run_dir: Path) -> RemediationSnapshot:
    """Derive actionable issues without mutating historical quality or its release gate."""
    art = resolve_artifact_dir(run_dir)
    dataset = _read_json(art / "dataset.json", {})
    if not isinstance(dataset, dict):
        dataset = {}
    records = {}
    for section in ("industry", "companies", "financials", "macro", "industry_chain", "reports", "news"):
        for record in dataset.get(section, []) or []:
            if isinstance(record, dict) and record.get("record_id"):
                records[str(record["record_id"])] = record

    verified_decisions = {}
    analysis = state.stage_results.get("data_interpret")
    if (analysis and analysis.revision == state.revision and analysis.status in ("approved", "completed")
            and (dataset.get("quality_summary") or {}).get("remediation_decisions")):
        try:
            from agents_core.conflict_resolution import project_dataset
            from data_fetcher.models import StructuredResearchDataset

            _, _, decisions = project_dataset(StructuredResearchDataset.model_validate(dataset))
            report = _read_json(art / "interpretation_report.json", {})
            audited = (report.get("data_quality_appendix") or {}).get("conflict_items") or [] if isinstance(report, dict) else []
            for decision in decisions:
                if any(isinstance(row, dict)
                       and set(row.get("evidence_record_ids") or []) == set(decision["conflict"].get("record_ids") or [])
                       and f"人工核对后采用 {decision['selected_record_id']}" in str(row.get("arbitration_rule") or "")
                       for row in audited):
                    verified_decisions[decision["conflict_key"]] = decision
        except (ValueError, TypeError, KeyError):
            pass

    items: list[RemediationItem] = []
    for conflict in dataset.get("conflicts", []) or []:
        if not isinstance(conflict, dict) or not conflict.get("conflict_key"):
            continue
        key = str(conflict["conflict_key"])
        refs = [str(v) for v in conflict.get("record_ids", [])]
        ctx = {"conflict": conflict, "records": [records[r] for r in refs if r in records]}
        label = " / ".join(str(conflict.get(k) or "未知") for k in ("entity", "metric", "period"))
        item = _item("source_conflict", key, state.revision, f"核对来源冲突：{label}",
                     "核对候选值及其原文、期间和口径，补充依据后再提交裁决。", refs,
                     ["attach_source", "enter_financial_record", "resolve_conflict", "supplement_search"], ctx)
        if key in verified_decisions:
            item.status = "resolved"
            item.actions = []
            item.detail = "已重新分析并记录核对依据；其他质量问题仍需分别检查。"
            item.context["resolution"] = verified_decisions[key]
        items.append(item)

    saved_chapters = _read_json(art / "chapter_result.json", {})
    sections = [section for chapter in (saved_chapters.get("chapters", []) if isinstance(saved_chapters, dict) else [])
                if isinstance(chapter, dict) for section in chapter.get("sections", []) if isinstance(section, dict)
                and re.fullmatch(r"SEC-\d{2}-\d{2}", str(section.get("section_id") or ""))]
    boundary_section = next((section for section in sections if section.get("section_id") == "SEC-07-03"), sections[-1] if sections else {})
    section_id = str(boundary_section.get("section_id") or "")
    boundary_target = f"P-{section_id[4:]}-99" if section_id else ""
    matrix = (dataset.get("quality_summary") or {}).get("requirement_evidence_matrix") or []
    original_input = _read_json(run_dir / "input_data.json", {})
    for entry in matrix:
        if not isinstance(entry, dict):
            continue
        requirement, coverage = entry.get("requirement") or {}, entry.get("coverage") or {}
        if not isinstance(requirement, dict) or not isinstance(coverage, dict) or coverage.get("passed") is not False:
            continue
        key = str(requirement.get("requirement_id") or "")
        if key:
            from backend.app.engine.scoped_delivery import eligible_automatic_announcement
            available_actions = ["supplement_search", "enter_financial_record", "limit_claim"]
            if eligible_automatic_announcement(dataset, original_input, key):
                available_actions.append("accept_announcement_scope")
            items.append(_item("coverage", key, state.revision, str(requirement.get("label") or "补充数据覆盖"),
                               "该数据需求尚未满足，请补采或录入有原文依据的数据。", [key],
                               available_actions,
                               {"requirement": requirement, "coverage": coverage, "boundary_target": boundary_target,
                                "boundary_section": boundary_section.get("title")}))

    chapter = state.stage_results.get("chapter_write")
    chapter_issues = ((chapter.data.get("quality") or {}).get("issues") or []) if chapter else []
    audit_by_paragraph = {}
    for saved_chapter in saved_chapters.get("chapters", []) if isinstance(saved_chapters, dict) else []:
        for audit in saved_chapter.get("content_audit", []) if isinstance(saved_chapter, dict) else []:
            if isinstance(audit, dict) and audit.get("location") and audit.get("original"):
                audit_by_paragraph[str(audit["location"])] = audit
    report = _read_json(art / "interpretation_report.json", {})
    evidence_index = report.get("evidence_index", {}) if isinstance(report, dict) else {}
    seen_paragraphs = set()
    for issue in chapter_issues:
        if not isinstance(issue, str):
            continue
        chapter_match = re.search(r"CH-\d{2}", issue)
        pattern = (r"(P-\d{2}-\d{2}-\d{2})\s*(?:因质量问题被整段移除（([^）]*)）"
                   r"|人工修订未通过复验：([^；;]*))")
        for match in re.finditer(pattern, issue):
            paragraph = match.group(1)
            reason = match.group(2) or match.group(3)
            chapter_id = chapter_match.group(0) if chapter_match else f"CH-{paragraph[2:4]}"
            key = f"{chapter_id}:{paragraph}"
            if key in seen_paragraphs:
                continue
            seen_paragraphs.add(key)
            audit = audit_by_paragraph.get(paragraph, {})
            suggested = [evidence_index[eid] for eid in (audit.get("evidence_ids") or [])
                         if eid in evidence_index and isinstance(evidence_index[eid], dict)]
            items.append(_item("chapter_gap", key, state.revision, f"补充段落：{chapter_id} / {paragraph}",
                               f"该段落需要修订：{reason}。原文不可用时请根据可核验依据重新撰写。",
                               [chapter_id, paragraph], ["attach_source", "revise_paragraph", "limit_claim", "supplement_search", "enter_financial_record"],
                               {"original_text": audit.get("original"), "evidence_candidates": suggested, "reason": reason}))

    fusion = state.stage_results.get("report_fusion")
    quality_issues = ((fusion.data.get("quality") or {}).get("issues") or []) if fusion else []
    for issue in quality_issues:
        if not isinstance(issue, str):
            continue
        rd_conflict = "称研发原始记录不可引用" in issue
        chain_conflict = "企业产业链归属缺少对应来源" in issue
        if not rd_conflict and not chain_conflict:
            continue
        match = re.search(r"P-\d{2}-\d{2}-\d{2}", issue)
        if not match:
            continue
        paragraph_id = match.group(0)
        chapter_id = f"CH-{paragraph_id[2:4]}"
        key = f"{chapter_id}:{paragraph_id}"
        if key in seen_paragraphs:
            continue
        original = next((para.get("text")
                         for chapter in saved_chapters.get("chapters", []) if isinstance(chapter, dict)
                         for section in chapter.get("sections", []) if isinstance(section, dict)
                         for para in section.get("paragraphs", []) if isinstance(para, dict)
                         and para.get("paragraph_id") == paragraph_id), None) if isinstance(saved_chapters, dict) else None
        evidence_ids = dict.fromkeys(
            rid for cell in (dataset.get("quality_summary") or {}).get("requested_financial_coverage", [])
            if rd_conflict and isinstance(cell, dict) and cell.get("hard") and cell.get("passed")
            for rid in cell.get("evidence_record_ids") or []
        )
        suggested = [evidence_index[rid] for rid in evidence_ids
                     if rid in evidence_index and isinstance(evidence_index[rid], dict)
                     and evidence_index[rid].get("domain") == "financials"
                     and evidence_index[rid].get("metric") == "rd_investment"]
        seen_paragraphs.add(key)
        items.append(_item("chapter_gap", key, state.revision, f"核对段落：{chapter_id} / {paragraph_id}",
                           issue, [chapter_id, paragraph_id], ["attach_source", "revise_paragraph", "limit_claim"],
                           {"original_text": original, "evidence_candidates": suggested,
                            "reason": "正文与可引用的研发记录不一致" if rd_conflict else "企业环节归属缺少证据"}))
    if any(isinstance(v, str) and ("工序关系" in v or "产业链关系未完整核验" in v)
           for v in quality_issues):
        bundle = _read_json(art / "chain" / "v2" / "bundle.json", {})
        entities = bundle.get("entities", []) if isinstance(bundle, dict) else []
        active_ids = set((bundle.get("structure") or {}).get("activity_ids", [])) if isinstance(bundle, dict) else set()
        activities = [e for e in entities if isinstance(e, dict) and e.get("entity_type") == "activity" and e.get("entity_id") in active_ids]
        scope_failed = next((v for v in quality_issues if isinstance(v, str)
                             and "有限覆盖复验未通过" in v and "收窄范围将移除过多正文" in v), None)
        actions = ["attach_source", "supplement_search"]
        detail = "请选择两个具体工序，并补充能证明先后关系的原文。企业归属不能代替工序证据。"
        if scope_failed:
            reason = scope_failed.split("有限覆盖复验未通过：", 1)[-1]
            detail = (f"有限覆盖复验未通过：{reason}。请先补充可核验证据或修订受影响章节；"
                      "重复确认同一范围无法解决问题。")
        else:
            actions.append("accept_chain_scope")
        items.append(_item("chain_relation", "missing-process-relations", state.revision, "补充产业链工序关系",
                           detail, [], actions, {"activities": activities}))

    for index, issue in enumerate(quality_issues):
        if not isinstance(issue, str) or not issue.strip():
            continue
        items.append(_item("other", f"{index}:{issue}", state.revision, "原始质检提示", issue, [], [], {}))

    baseline = _read_json(art / "remediation_issue_baseline.json", {})
    if isinstance(baseline, dict) and baseline.get("from_revision") != state.revision:
        existing_ids = {item.issue_id for item in items}
        for old in baseline.get("items", []):
            try:
                previous = RemediationItem.model_validate(old)
            except (ValueError, TypeError):
                continue
            if previous.issue_id in existing_ids or previous.status == "resolved":
                continue
            previous.fingerprint = _digest({"revision": state.revision, "previous": previous.fingerprint})
            previous.status = "rechecking" if state.status == "running" else "needs_review"
            previous.detail = "本版尚未确认该问题的复验结果。" + previous.detail
            if previous.category == "chapter_gap" and chapter and chapter.revision == state.revision and chapter.status in ("completed", "approved"):
                target = next((ref for ref in previous.refs if ref.startswith("P-")), "")
                audited = [a for saved in saved_chapters.get("chapters", []) if isinstance(saved, dict)
                           for a in saved.get("content_audit", []) if isinstance(a, dict)] if isinstance(saved_chapters, dict) else []
                if any(a.get("code") == "user_paragraph_revision" and a.get("location") == target
                       and a.get("disposition") == "accepted" for a in audited):
                    previous.status = "resolved"
                    previous.actions = []
                    previous.detail = "本版修订已通过章节复验，其他质量问题仍需分别检查。"
            items.append(previous)

    saved = _read_json(run_dir / "remediation" / "actions.json", [])
    candidates = []
    for row in saved if isinstance(saved, list) else []:
        try:
            candidates.append(CandidateAction.model_validate(row))
        except (ValueError, TypeError):
            continue

    # 段落缺口若已由研究边界声明披露（remediation_revisions 中该章存在
    # methodology 条目——每章至多一条、覆盖该章全部已披露缺口），视为已处置。
    # 融合层硬阻塞类（企业归属缺来源/研发记录不可引用）不适用——边界声明无法
    # 清除其阻塞，必须保留待办等待人工补来源。
    methodology_targets = {str(row.get("target_id") or "")
                           for row in _read_json(art / "remediation_revisions.json", [])
                           if isinstance(row, dict) and row.get("target_kind") == "methodology"}
    methodology_chapters = {target[2:4] for target in methodology_targets
                            if re.fullmatch(r"P-\d{2}-\d{2}-\d{2}", target)}
    for item in items:
        if item.category != "chapter_gap" or item.status == "resolved" or not methodology_chapters:
            continue
        detail_text = str(item.detail or "")
        if "缺少对应来源" in detail_text or "研发原始记录不可引用" in detail_text:
            continue
        paragraph = next((ref for ref in item.refs if ref.startswith("P-")), "")
        if paragraph and paragraph[2:4] in methodology_chapters:
            item.status = "resolved"
            item.actions = []
            item.detail = "该段落缺口已由研究边界声明披露；如需实质修复请补充可核验证据。"

    for item in items:
        if item.status != "resolved" and any(a.issue_id == item.issue_id and a.expected_fingerprint == item.fingerprint and a.status == "ready" for a in candidates):
            item.status = "submitted"
    return RemediationSnapshot(run_id=state.run_id, revision=state.revision, items=items, candidate_actions=candidates)
