"""Canonical, verifiable review decisions for every workflow stage."""

from __future__ import annotations

import hashlib
import json
from typing import Any

from backend.app.schemas.workflow import ReviewDecision, ReviewRequest, StageResult, WorkflowState


class DecisionValidationError(ValueError):
    """Raised when a review does not match its immutable decision package."""


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def _sha256(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def _risk(
    code: str,
    title: str,
    *,
    severity: str = "medium",
    description: str = "",
    blocking: bool = False,
    evidence_ids: list[str] | None = None,
    source_paths: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "code": code,
        "title": title,
        "description": description or title,
        "severity": severity if severity in {"low", "medium", "high"} else "medium",
        "blocking": bool(blocking),
        "evidence_record_ids": sorted({str(item) for item in (evidence_ids or []) if str(item)}),
        "source_paths": sorted({str(item) for item in (source_paths or []) if str(item)}),
    }


def _warning_code(prefix: str, text: str) -> str:
    return f"{prefix}_{hashlib.sha256(text.encode('utf-8')).hexdigest()[:12]}"


def _deduplicate(risks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_code: dict[str, dict[str, Any]] = {}
    for risk in risks:
        code = risk["code"]
        if code not in by_code:
            by_code[code] = risk
            continue
        current = by_code[code]
        current["blocking"] = current["blocking"] or risk["blocking"]
        if risk["severity"] == "high" or current["severity"] == "high":
            current["severity"] = "high"
        current["evidence_record_ids"] = sorted(set(current["evidence_record_ids"] + risk["evidence_record_ids"]))
        current["source_paths"] = sorted(set(current["source_paths"] + risk["source_paths"]))
    return [by_code[code] for code in sorted(by_code)]


def _native_failure(result: StageResult) -> list[dict[str, Any]]:
    stage = result.stage
    native = str(result.data.get("agent_status") or result.status)
    if stage == "data_fetch" and result.status != "failed":
        # A1 的 blocked/partial 可能只是数值域缺口；事件或受支持产业链断言
        # 是否足以继续由下面的定性证据风险与统一门禁决定。
        return []
    if native not in {"failed", "blocked"} and result.status != "failed":
        return []
    codes = {
        "data_fetch": "data_fetch_execution_failed",
        "data_interpret": "analysis_execution_failed",
        "chart_generate": "chart_execution_failed",
        "chapter_write": "chapter_execution_failed",
        "report_fusion": "fusion_execution_failed",
    }
    return [
        _risk(
            codes[stage],
            "阶段原生执行失败",
            severity="high",
            description=result.error or f"{stage} 原生状态为 {native}",
            blocking=True,
        )
    ]


def _explicit_risks(data: dict[str, Any]) -> list[dict[str, Any]]:
    risks = []
    for index, raw in enumerate(data.get("risks") or []):
        if not isinstance(raw, dict):
            continue
        title = str(raw.get("title") or raw.get("description") or raw.get("message") or "审核风险")
        code = str(raw.get("code") or raw.get("risk_code") or _warning_code("risk", f"{index}:{title}"))
        risks.append(
            _risk(
                code,
                title,
                severity=str(raw.get("severity") or "medium"),
                description=str(raw.get("description") or raw.get("message") or title),
                blocking=raw.get("blocking") is True or raw.get("hard_blocked") is True,
                evidence_ids=list(raw.get("evidence_record_ids") or raw.get("evidence_ids") or []),
                source_paths=list(raw.get("source_paths") or []),
            )
        )
    return risks


def _collect_risks(result: StageResult) -> list[dict[str, Any]]:
    data = result.data or {}
    failed = _native_failure(result)
    if failed:
        return failed

    stage = result.stage
    risks = _explicit_risks(data)
    native = str(data.get("agent_status") or "")
    quality = data.get("quality") if isinstance(data.get("quality"), dict) else {}
    warnings = [str(item) for item in data.get("warnings") or [] if str(item).strip()]

    if stage == "data_fetch":
        domains = data.get("domains") if isinstance(data.get("domains"), dict) else {}
        quantitative = sum(
            int(domains.get(key) or 0)
            for key in ("industry", "companies", "financials", "macro", "industry_chain", "reports", "news")
        )
        events = int(domains.get("events") or 0)
        total = int(data.get("total_records") or 0) or quantitative + events
        chain = data.get("chain_research") if isinstance(data.get("chain_research"), dict) else {}
        coverage_values = chain.get("coverage_values") if isinstance(chain.get("coverage_values"), dict) else {}
        chain_supported = int(coverage_values.get("supported_assertions") or 0)
        if total <= 0 and chain_supported <= 0:
            risks.append(_risk("data_fetch_no_records", "没有取得有效研究记录", severity="high", blocking=True))
        elif quantitative <= 0 and (events > 0 or chain_supported > 0):
            risks.append(_risk("data_fetch_qualitative_only", "仅有定性事件或产业链证据", description="量化域记录为零，后续内容不得宣称量化覆盖完整。"))
        else:
            for domain in ("industry", "companies", "financials", "macro", "industry_chain", "reports", "news"):
                if int(domains.get(domain) or 0) <= 0:
                    risks.append(_risk(f"domain_{domain}_missing", f"数据域缺口：{domain}", severity="low"))
        for requirement in data.get("metric_requirements") or []:
            if isinstance(requirement, dict) and requirement.get("passed") is False:
                requirement_id = str(requirement.get("requirement_id") or "unknown")
                risks.append(_risk(f"requirement_{requirement_id}", str(requirement.get("label") or "指标需求未覆盖")))
        if data.get("collaboration_requests"):
            risks.append(_risk("intent_clarification_required", "研究意图仍需澄清", severity="high"))

    elif stage == "data_interpret":
        domains = data.get("domains") if isinstance(data.get("domains"), dict) else {}
        chain = data.get("chain_research") if isinstance(data.get("chain_research"), dict) else {}
        has_qualitative = int(domains.get("events") or 0) > 0 or bool(chain.get("supported_assertions"))
        numeric_missing = data.get("analysis_numeric_missing") is True or quality.get("record_count") == 0
        if numeric_missing:
            risks.append(
                _risk(
                    "analysis_numeric_missing",
                    "量化记录缺失",
                    description="仅可保留有证据的定性分析，不得宣称量化覆盖完整。",
                    blocking=not has_qualitative,
                    severity="medium" if has_qualitative else "high",
                )
            )
        for row in data.get("dimension_coverage") or []:
            if not isinstance(row, dict) or row.get("status") == "covered":
                continue
            dimension = str(row.get("dimension") or "unknown")
            coverage_status = str(row.get("status") or "missing")
            risks.append(
                _risk(
                    f"dimension_{dimension}_{coverage_status}",
                    f"分析维度{coverage_status}：{dimension}",
                    description=str(row.get("reason") or "维度证据不足"),
                    evidence_ids=list(row.get("record_ids") or []),
                )
            )

    elif stage == "chart_generate":
        if quality.get("passed") is False:
            risks.append(
                _risk(
                    "chart_quality_not_passed",
                    "图表质量或用户要求数量未完全满足",
                    description="；".join(str(item) for item in quality.get("issues") or []) or "图表结果需要人工确认",
                )
            )
        delivery = data.get("chain_delivery") if isinstance(data.get("chain_delivery"), dict) else {}
        if delivery.get("requested") and delivery.get("status") == "failed":
            risks.append(_risk("chain_delivery_failed", "要求的产业链图未形成可交付结果", severity="high", description=str(delivery.get("reason") or ""), blocking=True))
        elif delivery.get("requested") and delivery.get("status") != "complete":
            risks.append(_risk("chain_delivery_partial", "产业链图仅部分覆盖", severity="high", description=str(delivery.get("reason") or "")))
        if data.get("data_demands"):
            risks.append(_risk("chart_data_demands_unresolved", "图表数据需求尚未完全解决"))

    elif stage == "chapter_write":
        if native == "partial" or quality.get("passed") is False or quality.get("fallback_count"):
            risks.append(
                _risk(
                    "chapter_quality_degraded",
                    "章节内容存在降级或质量缺口",
                    description="；".join(str(item) for item in quality.get("issues") or []) or "已审稿仍需人工确认",
                )
            )

    elif stage == "report_fusion":
        release_mode = str(data.get("release_mode") or "formal")
        substantive_policy = data.get("delivery_policy") == "substantive_errors_only_v1"
        if data.get("hard_blocked") or data.get("delivery_blocked"):
            risks.append(_risk("fusion_consistency_failed", "报告一致性或交付硬校验失败", severity="high", blocking=True))
        if native == "partial" or quality.get("passed") is False:
            if substantive_policy:
                if not data.get("hard_blocked") and not data.get("delivery_blocked"):
                    risks.append(_risk("fusion_quality_notes", "非实质性质量说明已记录，可正式交付", severity="low"))
            elif release_mode == "draft_with_warnings" and not data.get("hard_blocked") and not data.get("delivery_blocked"):
                risks.append(_risk("fusion_draft_quality_limits", "仅以受限草稿交付", severity="high", description="不得将当前内容表述为完整、通过或正式研报。"))
            else:
                risks.append(_risk("fusion_formal_quality_failed", "正式研报质量门禁未通过", severity="high", blocking=True))

    # Unstructured warnings remain visible under stable content-derived codes.
    structured_warning_fragments = ("量化记录缺失", "用户要求", "实际生成", "没有合格图表")
    for warning in warnings:
        if any(fragment in warning for fragment in structured_warning_fragments):
            continue
        risks.append(_risk(_warning_code("warning", warning), warning, severity="low"))

    return _deduplicate(risks)


def build_decision_package(result: StageResult, run_id: str, revision: int) -> dict[str, Any]:
    risks = _collect_risks(result)
    blocking = sorted(risk["code"] for risk in risks if risk["blocking"])
    acknowledgement = sorted(risk["code"] for risk in risks if not risk["blocking"])
    recommended = "blocked" if blocking else ("accept_with_risks" if acknowledgement else "approve")
    snapshot = {
        "run_id": run_id,
        "stage": result.stage,
        "revision": revision,
        "risks": risks,
        "blocking_risk_codes": blocking,
        "acknowledgement_required_codes": acknowledgement,
        "recommended_action": recommended,
    }
    digest = _sha256(snapshot)
    return {
        "decision_id": f"dec_{_sha256({'run_id': run_id, 'snapshot': digest})[:24]}",
        "run_id": run_id,
        "stage": result.stage,
        "revision": revision,
        "risk_snapshot_sha256": digest,
        "risks": risks,
        "risk_notices": risks,
        "blocking_risk_codes": blocking,
        "acknowledgement_required_codes": acknowledgement,
        "recommended_action": recommended,
    }


def attach_decision_package(result: StageResult, run_id: str, revision: int) -> dict[str, Any]:
    package = build_decision_package(result, run_id, revision)
    result.data = {**(result.data or {}), "decision_package": package}
    return package


def refresh_waiting_review_packages(state: WorkflowState) -> list[str]:
    """Rebuild decision packages of stages that are awaiting review.

    Any mutation that advances the run revision while a stage stays in
    ``waiting_review`` (direct edit, replenishment, single-chapter rewrite,
    remediation, revision restore) invalidates the package produced by the
    previous revision: :func:`_validate_package_identity` compares the
    package revision against the *current* run revision, so a stale package
    can never be approved again and every retry ends in a 409
    "决策版本已变化" loop even after the client refreshes its state.

    Rebuilding recomputes the risk snapshot from the (already edited) stage
    data, so the optimistic-lock guard still rejects genuinely old tabs that
    kept the previous decision id / snapshot hash. Returns the stages refreshed.
    """
    refreshed: list[str] = []
    for stage, result in state.stage_results.items():
        if result.status != "waiting_review":
            continue
        package = (result.data or {}).get("decision_package")
        if isinstance(package, dict) and package.get("revision") == state.revision:
            continue
        attach_decision_package(result, state.run_id, state.revision)
        refreshed.append(stage)
    return refreshed


def _validate_package_identity(
    result: StageResult,
    req: ReviewRequest,
    run_id: str,
    revision: int,
) -> dict[str, Any]:
    package = (result.data or {}).get("decision_package")
    if not isinstance(package, dict):
        raise DecisionValidationError("阶段缺少可校验的决策包，请重新执行该阶段")
    if package.get("run_id") != run_id or package.get("stage") != req.stage:
        raise DecisionValidationError("决策包的任务或阶段不匹配")
    if package.get("revision") != revision or req.expected_revision != revision:
        raise DecisionValidationError("决策版本已变化，请刷新后重新审核")
    if not req.decision_id or not req.risk_snapshot_sha256:
        raise DecisionValidationError("审核请求必须携带决策 ID 与风险快照哈希")
    if req.decision_id != package.get("decision_id"):
        raise DecisionValidationError("决策 ID 不匹配")
    if req.risk_snapshot_sha256 != package.get("risk_snapshot_sha256"):
        raise DecisionValidationError("风险快照哈希不匹配，风险内容可能已变化")
    return package


def validate_review_request(
    result: StageResult,
    req: ReviewRequest,
    run_id: str,
    revision: int,
    *,
    actor: str = "user",
) -> ReviewDecision:
    package = _validate_package_identity(result, req, run_id, revision)
    recommended = str(package.get("recommended_action") or "approve")
    action = recommended if req.action == "accept_recommendation" else req.action
    blocking = list(package.get("blocking_risk_codes") or [])
    acknowledgement = sorted(package.get("acknowledgement_required_codes") or [])
    if action == "blocked" or blocking:
        raise DecisionValidationError("存在硬阻塞风险，接受风险也不能批准")
    if action not in {"approve", "accept_with_risks"}:
        raise DecisionValidationError(f"推荐动作 {action} 不是可批准的审核动作")
    if action == "approve" and acknowledgement:
        raise DecisionValidationError("存在需要显式接受风险的项目，请使用接受风险动作")

    accepted: list[str] = []
    if action == "accept_with_risks":
        accepted = sorted(req.accepted_risk_codes or [])
        if accepted != acknowledgement:
            raise DecisionValidationError("风险代码集合必须与本版本需要确认的风险完全一致")
    elif req.accepted_risk_codes:
        raise DecisionValidationError("无风险审核不得附加风险代码")

    return ReviewDecision(
        run_id=run_id,
        stage=req.stage,
        revision=revision,
        action=action,
        actor=actor,
        decision_id=str(package["decision_id"]),
        risk_snapshot_sha256=str(package["risk_snapshot_sha256"]),
        accepted_risk_codes=accepted,
        comment=req.comment,
    )


def system_review_decision(result: StageResult, run_id: str, revision: int) -> ReviewDecision:
    package = (result.data or {}).get("decision_package")
    if not isinstance(package, dict):
        raise DecisionValidationError("自动审核缺少决策包")
    action = str(package.get("recommended_action") or "approve")
    if action not in {"approve", "accept_with_risks"}:
        raise DecisionValidationError("硬阻塞阶段不能自动通过")
    req = ReviewRequest(
        run_id=run_id,
        stage=result.stage,
        action=action,
        expected_revision=revision,
        decision_id=str(package["decision_id"]),
        risk_snapshot_sha256=str(package["risk_snapshot_sha256"]),
        accepted_risk_codes=list(package.get("acknowledgement_required_codes") or []) if action == "accept_with_risks" else [],
        comment="系统按当前决策包推荐动作自动处理",
    )
    return validate_review_request(result, req, run_id, revision, actor="system")


def append_review_decision(state: WorkflowState, decision: ReviewDecision) -> ReviewDecision:
    for existing in state.review_decisions:
        if (
            existing.run_id == decision.run_id
            and existing.stage == decision.stage
            and existing.revision == decision.revision
            and existing.actor == decision.actor
            and existing.action == decision.action
            and existing.decision_id == decision.decision_id
            and existing.risk_snapshot_sha256 == decision.risk_snapshot_sha256
        ):
            return existing
    state.review_decisions.append(decision)
    return decision
