from __future__ import annotations

import hashlib
import json
import os
import re
import tempfile
from dataclasses import dataclass
from datetime import date
from pathlib import Path

import httpx
import pymupdf
from pydantic import BaseModel

from backend.app.schemas.remediation import SourceCandidate


MAX_BYTES = 25_000_000
MAX_PAGES = 500
_SOURCE_ID = re.compile(r"^source-[0-9a-f]{32}$")


@dataclass
class SourceInput:
    title: str
    declared_publisher: str = ""
    published_at: date | None = None
    as_of: date | None = None
    url: str | None = None
    content: bytes | None = None


class SourcePage(BaseModel):
    page: int
    text: str


def _atomic_write(path: Path, content: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix=".source-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(content)
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def _path(run_dir: Path, source_id: str, suffix: str) -> Path:
    if not _SOURCE_ID.fullmatch(source_id):
        raise ValueError("无效的材料标识")
    return run_dir / "remediation" / "sources" / f"{source_id}.{suffix}"


async def _fetch_official_pdf(url: str, published_at: date, as_of: date) -> bytes:
    from data_fetcher.official_filing import _eligible_url, _valid_last_modified

    if not _eligible_url(url, published_at, as_of):
        raise ValueError("公告链接或发布日期不符合现有来源校验")
    async with httpx.AsyncClient(timeout=30, follow_redirects=False) as client:
        async with client.stream("GET", url) as response:
            response.raise_for_status()
            if not _valid_last_modified(response.headers.get("last-modified", ""), published_at, as_of):
                raise ValueError("公告修改日期缺失或与发布日期不一致")
            content = bytearray()
            async for chunk in response.aiter_bytes():
                content.extend(chunk)
                if len(content) > MAX_BYTES:
                    raise ValueError("PDF 超过 25 MB")
    return bytes(content)


async def store_source(run_dir: Path, request: SourceInput) -> SourceCandidate:
    title = request.title.strip()
    if not title:
        raise ValueError("请填写资料标题")
    content = request.content
    kind = "upload_pdf" if content is not None else "reference_only"
    official_verified = False
    if content is not None and request.url:
        from data_fetcher.official_filing import _eligible_url
        if not 0 < len(content) <= MAX_BYTES or not content.startswith(b"%PDF-"):
            raise ValueError("PDF 无效或超过 25 MB")
        if not request.published_at or not request.as_of or not _eligible_url(request.url, request.published_at, request.as_of):
            raise ValueError("公告链接或发布日期不符合来源校验，可只上传文件保留为待核资料")
        try:
            published = await _fetch_official_pdf(request.url, request.published_at, request.as_of)
        except httpx.HTTPError as exc:
            raise ValueError("获取公告失败，请检查链接和网络后重试") from exc
        if hashlib.sha256(content).digest() != hashlib.sha256(published).digest():
            raise ValueError("上传文件与官方公告内容不一致")
        official_verified = True
    if content is None:
        if not request.url or not request.url.strip():
            raise ValueError("请提供 PDF 或来源链接")
        from data_fetcher.official_filing import _eligible_url
        if request.published_at and request.as_of and _eligible_url(request.url, request.published_at, request.as_of):
            try:
                content = await _fetch_official_pdf(request.url, request.published_at, request.as_of)
            except httpx.HTTPError as exc:
                raise ValueError("获取公告失败，请检查链接和网络后重试，或上传 PDF") from exc
            kind = "official_url"
            official_verified = True

    sha = None
    pages = None
    parse_status = "reference_only"
    if content is not None:
        if not 0 < len(content) <= MAX_BYTES or not content.startswith(b"%PDF-"):
            raise ValueError("PDF 无效或超过 25 MB")
        try:
            with pymupdf.open(stream=content, filetype="pdf") as doc:
                if doc.needs_pass or not 1 <= len(doc) <= MAX_PAGES:
                    raise ValueError("PDF 加密或页数超过 500 页")
                pages = len(doc)
                parse_status = "ready" if any(page.get_text().strip() for page in doc) else "unreadable"
        except ValueError:
            raise
        except Exception as exc:
            raise ValueError("无法读取 PDF") from exc
        sha = hashlib.sha256(content).hexdigest()

    identity = json.dumps([sha, request.url, title, request.declared_publisher, str(request.published_at)], ensure_ascii=False)
    source_id = "source-" + hashlib.sha256(identity.encode()).hexdigest()[:32]
    source = SourceCandidate(
        source_id=source_id, kind=kind, title=title, declared_publisher=request.declared_publisher.strip(),
        official_origin_verified=official_verified,
        source_url=request.url, published_at=request.published_at.isoformat() if request.published_at else None,
        sha256=sha, page_count=pages, parse_status=parse_status,
    )
    if content is not None:
        _atomic_write(_path(run_dir, source_id, "pdf"), content)
    _atomic_write(_path(run_dir, source_id, "json"), source.model_dump_json(indent=2).encode())
    return source


def load_source(run_dir: Path, source_id: str) -> SourceCandidate:
    try:
        return SourceCandidate.model_validate_json(_path(run_dir, source_id, "json").read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError("材料不存在") from exc


def list_sources(run_dir: Path) -> list[SourceCandidate]:
    directory = run_dir / "remediation" / "sources"
    if not directory.exists():
        return []
    sources = []
    for path in sorted(directory.glob("source-*.json")):
        try:
            sources.append(load_source(run_dir, path.stem))
        except (ValueError, OSError):
            continue
    return sources


def read_source_page(run_dir: Path, source_id: str, page: int) -> SourcePage:
    source = load_source(run_dir, source_id)
    if source.parse_status != "ready" or isinstance(page, bool) or not 1 <= page <= (source.page_count or 0):
        raise ValueError("材料不可提取文本或页码无效")
    content = _path(run_dir, source_id, "pdf").read_bytes()
    if hashlib.sha256(content).hexdigest() != source.sha256:
        raise ValueError("材料内容已改变，请重新上传")
    with pymupdf.open(stream=content, filetype="pdf") as doc:
        return SourcePage(page=page, text=doc[page - 1].get_text())


def verify_excerpt(run_dir: Path, source_id: str, page: int, excerpt: str) -> bool:
    normalized = re.sub(r"\s+", "", excerpt or "")
    if not 12 <= len(normalized) <= 1200:
        return False
    try:
        return normalized in re.sub(r"\s+", "", read_source_page(run_dir, source_id, page).text)
    except (ValueError, OSError):
        return False


def publication_date_verified(run_dir: Path, source: SourceCandidate, page: int, as_of: date) -> bool:
    """Reject explicit later publication dates; uploads retain an unverified date."""
    if not source.published_at or date.fromisoformat(source.published_at) > as_of:
        raise ValueError("材料日期缺失或晚于研究截止日期")
    if source.official_origin_verified:
        return True
    pages = sorted(set(range(1, min(source.page_count or 0, 3) + 1)) | {page})
    pattern = re.compile(r"(?:published(?:\s+(?:on|at))?|publication\s+date|发布日期|披露日期|发布于)\s*[:：]?\s*"
                         r"(20\d{2})\s*(?:[-/.]|年)\s*(\d{1,2})\s*(?:[-/.]|月)\s*(\d{1,2})", re.I)
    for page_number in pages:
        for match in pattern.finditer(read_source_page(run_dir, source.source_id, page_number).text):
            try:
                stated = date(*map(int, match.groups()))
            except ValueError:
                continue
            if stated > as_of or stated != date.fromisoformat(source.published_at):
                raise ValueError("材料中明确的发布日期与声明日期或研究截止日期不一致")
    return False
