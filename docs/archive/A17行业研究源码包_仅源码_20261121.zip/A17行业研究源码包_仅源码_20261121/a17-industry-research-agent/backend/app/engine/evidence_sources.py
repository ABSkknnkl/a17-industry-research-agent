from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

SOURCE_FILE = "evidence_sources.json"
_PAGE_RE = re.compile(r"第\s*([0-9]+)\s*页")
_PDF_PAGE_RE = re.compile(r"PDF\s*第\s*([0-9]+)\s*页", re.IGNORECASE)
_PDF_URL_RE = re.compile(r"\.pdf(?:$|[?#])", re.IGNORECASE)


def load_evidence_sources(run_dir: Path) -> dict[str, dict[str, Any]]:
    """Load the per-run evidence provenance overlay.

    This is an additive index: it never replaces a source already embedded in
    the run. A missing or broken file simply means the run keeps its original
    (possibly empty) provenance fields.
    """
    path = Path(run_dir) / SOURCE_FILE
    if not path.is_file():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    sources = payload.get("sources") if isinstance(payload, dict) else payload
    if not isinstance(sources, dict):
        return {}
    return {
        str(record_id): value
        for record_id, value in sources.items()
        if isinstance(value, dict)
    }


def source_url_for(record: dict[str, Any]) -> str:
    url = str(record.get("source_url") or record.get("url") or "").strip()
    if not url:
        return ""
    locator = str(record.get("source_locator") or "")
    page_match = _PDF_PAGE_RE.search(locator) or _PAGE_RE.search(locator)
    page = page_match.group(1) if page_match else ""
    if page and "#" not in url and _PDF_URL_RE.search(url):
        return f"{url}#page={page}"
    return url


def merge_evidence_sources(state: Any, run_dir: Path) -> Any:
    """Attach provenance fields to the API's evidence index in-place.

    The overlay is kept on disk instead of rewriting historical artifacts, so
    old runs can be made traceable without re-running the five-agent pipeline.
    """
    sources = load_evidence_sources(run_dir)
    if not sources:
        return state
    stage = getattr(state, "stage_results", {}).get("data_interpret")
    stage_data = getattr(stage, "data", None) if stage is not None else None
    if not isinstance(stage_data, dict):
        return state
    index = stage_data.get("evidence_index")
    if not isinstance(index, dict):
        return state

    for record_id, ref in index.items():
        if not isinstance(ref, dict):
            continue
        source = sources.get(str(record_id))
        if not source:
            continue
        url = source_url_for(source)
        if url and not ref.get("source_url"):
            ref["source_url"] = url
        for key in ("source_locator", "published_at", "document_sha256"):
            value = source.get(key)
            if value and not ref.get(key):
                ref[key] = value
        if source.get("title") and not ref.get("source_title"):
            ref["source_title"] = source["title"]
        if source.get("publisher") and not ref.get("source_publisher"):
            ref["source_publisher"] = source["publisher"]
    return state
