"""A3 数据补采的集中协调层。

职责边界：
- A3 只产出结构化 ``data_demands``，不直接改数据集、不决定是否重跑 A2。
- 本协调器校验需求、按未满足矩阵项限量选择、执行一次有界补采，并在锁内
  以输入哈希 + revision 双重守卫提交；返回 ``none``/``committed``/``discarded``。
- 工作流引擎保留锁、下游失效与审计提交等基础设施，并根据返回值决定是否
  重跑 A2。这样补采策略不再散落在状态机执行流程里。
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import shutil
from datetime import date, datetime
from pathlib import Path
from typing import Any, Literal, Protocol

from agents_core.artifact_paths import resolve_artifact_dir

from backend.app.core.storage import storage
from backend.app.schemas.workflow import StageResult, WorkflowState

logger = logging.getLogger(__name__)

SupplementStatus = Literal["none", "committed", "discarded"]
_DEFAULT_DOMAINS = frozenset(
    {"industry", "companies", "financials", "macro", "industry_chain", "reports", "news", "events"}
)


class SupplementHost(Protocol):
    """协调器所需的状态机基础设施端口（不暴露业务流程）。"""

    def _run_lock(self, run_id: str) -> asyncio.Lock: ...

    async def _fetch_supplement_with_audit(self, run_id: str, stage: str, demand: dict[str, Any], as_of: date) -> list[Any]: ...

    def _invalidate_following_stages(self, state: WorkflowState, stage: Any) -> None: ...

    def _commit_state_with_history(self, run_dir: Path, state: WorkflowState, **kwargs: Any) -> None: ...


class SupplementCoordinator:
    """无状态策略对象；每次调用传入当前宿主，避免跨运行持有锁或状态。"""

    def __init__(self, host: SupplementHost) -> None:
        self._host = host

    @staticmethod
    def _string_list(value: Any) -> list[str]:
        if not isinstance(value, (list, tuple, set)):
            return []
        result: list[str] = []
        for item in value:
            text = str(item or "").strip()
            if text and text not in result:
                result.append(text)
        return result

    @classmethod
    def normalize_demand(cls, raw: Any) -> dict[str, Any] | None:
        """只接受可执行的结构化需求；非法需求不触达外部数据源。"""
        if not isinstance(raw, dict):
            return None
        domain = str(raw.get("domain") or "").strip()
        if domain not in _DEFAULT_DOMAINS:
            return None
        entities = cls._string_list(raw.get("entities"))
        metrics = cls._string_list(raw.get("metrics"))
        periods = cls._string_list(raw.get("period_ends"))
        skills = cls._string_list(raw.get("acceptable_skill_ids"))
        query_hint = str(raw.get("query_hint") or "").strip()
        if not (entities or metrics or query_hint):
            return None
        return {
            **raw,
            "domain": domain,
            "entities": entities,
            "metrics": metrics,
            "period_ends": periods,
            "acceptable_skill_ids": skills,
            "query_hint": query_hint,
        }

    @classmethod
    def select_chart_supplement_demands(
        cls,
        demands: list[dict],
        matrix: list[dict],
        requested_coverage: list[dict] | None = None,
    ) -> list[dict]:
        """选择最多两个不同的未满足需求，供一次有界补采使用。

        ``matrix`` 是 A1/A2 的结构化矩阵；``requested_coverage`` 是 A2 在附录里
        对用户显式要求的覆盖记录（扁平结构，可能没有对应的矩阵行）。旧实现只看
        矩阵，A2 追加的 ``event_catalysts`` 等硬需求永远进不了补采。
        """
        from agents_core.financial_semantics import metric_family

        valid_demands = [d for d in (cls.normalize_demand(item) for item in (demands or [])) if d]
        rows: list[dict[str, Any]] = []
        seen_rids: set[str] = set()
        for row in matrix or []:
            if isinstance(row, dict):
                rows.append(row)
                rid = str((row.get("requirement") or {}).get("requirement_id") or "")
                if rid:
                    seen_rids.add(rid)
        for row in requested_coverage or []:
            if not isinstance(row, dict):
                continue
            rid = str(row.get("requirement_id") or "")
            if not rid or rid in seen_rids:
                continue
            seen_rids.add(rid)
            rows.append({
                "requirement": {
                    key: row.get(key)
                    for key in (
                        "requirement_id", "label", "domain", "hard", "entity_names",
                        "metric_families", "period_ends", "acceptable_skill_ids",
                    )
                },
                "coverage": row,
            })

        selected: list[tuple[int, str, dict[str, Any]]] = []
        for row in rows:
            if not isinstance(row, dict):
                continue
            requirement, coverage = row.get("requirement") or {}, row.get("coverage") or {}
            if not isinstance(requirement, dict) or not isinstance(coverage, dict):
                continue
            if coverage.get("passed") is not False or coverage.get("out_of_scope"):
                continue
            if requirement.get("hard") is False:
                continue
            rid = str(requirement.get("requirement_id") or "")
            if not rid:
                continue
            entities = cls._string_list(requirement.get("entity_names"))
            metrics = cls._string_list(requirement.get("metric_families"))
            domain = str(requirement.get("domain") or "")
            sources = cls._string_list(requirement.get("acceptable_skill_ids"))
            if not domain and rid == "event_catalysts":
                # 兼容历史 A2 附录：早期事件行只有 requirement_id/label，
                # 缺 domain/skills，补采必须按事件源而不是默认财务源执行。
                domain = "news"
                sources = ["announcement-search", "hithink-event-query"]
            match = next(
                (
                    demand
                    for demand in valid_demands
                    if str(demand.get("domain") or "") == domain
                    and (not entities or not demand["entities"] or set(entities) & set(demand["entities"]))
                    and (
                        not metrics
                        or not demand["metrics"]
                        or {metric_family(str(m)) for m in metrics}
                        & {metric_family(str(m)) for m in demand["metrics"]}
                    )
                ),
                None,
            )
            periods = cls._string_list(requirement.get("period_ends"))
            if not sources:
                sources = cls._string_list(requirement.get("acceptable_skill_ids"))
            base = dict(match) if match else {
                "domain": domain,
                "entities": entities,
                "metrics": metrics or [str(requirement.get("label") or rid)],
                "query_hint": str(requirement.get("label") or rid),
                "reason": coverage.get("missing") or ["需求未覆盖"],
            }
            priority = 0 if rid.startswith(("annual_", "focused_")) else 1 if requirement.get("hard", True) else 2
            selected.append(
                (
                    priority,
                    rid,
                    {
                        **base,
                        "requirement_id": rid,
                        "entities": entities or base["entities"],
                        "metrics": metrics or base["metrics"],
                        "period_ends": periods,
                        "acceptable_skill_ids": sources,
                        "query_hint": " ".join([
                            *entities, *periods, *metrics,
                            *([] if domain in {"news", "events"} else sources),
                            str(base.get("query_hint") or ""),
                        ]).strip(),
                    },
                )
            )


        result: list[dict[str, Any]] = []
        seen: set[tuple[Any, ...]] = set()
        for _, _, demand in sorted(selected, key=lambda item: (item[0], item[1])):
            fingerprint = (
                str(demand.get("domain", "")).casefold(),
                tuple(sorted(str(x).strip().casefold() for x in demand["entities"])),
                tuple(sorted(metric_family(str(x)) for x in demand["metrics"])),
                tuple(sorted(demand["period_ends"])),
                tuple(sorted(demand["acceptable_skill_ids"])),
            )
            if fingerprint in seen:
                continue
            seen.add(fingerprint)
            result.append(demand)
            if len(result) == 2:
                break
        return result

    async def run_chart_supplement(
        self,
        run_id: str,
        input_revision: int,
        result: StageResult,
        as_of: date,
    ) -> SupplementStatus:
        """在锁外补采、锁内双重守卫提交；任何守卫失败都保留旧版本。"""
        from backend.app.agents.adapters import SupplementalRecordCollision, merge_supplemental_records
        from data_fetcher.models import StructuredResearchDataset

        demands = result.data.get("data_demands") or []
        artifact_dir = resolve_artifact_dir(storage.get_run_dir(run_id))
        path = artifact_dir / "dataset.json"
        if not isinstance(demands, list) or not path.exists():
            return "none"
        original_bytes = path.read_bytes()
        original_hash = hashlib.sha256(original_bytes).hexdigest()
        input_path = storage.get_run_dir(run_id) / "input_data.json"
        original_input = input_path.read_bytes() if input_path.exists() else None
        dataset = StructuredResearchDataset.model_validate_json(original_bytes)
        matrix = dataset.quality_summary.get("requirement_evidence_matrix") or []
        requested = list(dataset.quality_summary.get("requested_requirement_coverage") or [])
        # A2 会在 interpretation_report.json 里追加用户显式要求的覆盖行
        # （例如 event_catalysts），但这份附录不一定回写到 dataset.json。
        # 只读 dataset 会漏掉这些迟到硬需求，补采回路继续空转。
        report_path = artifact_dir / "interpretation_report.json"
        if report_path.exists():
            try:
                report_payload = json.loads(report_path.read_text(encoding="utf-8"))
                report_rows = (report_payload.get("data_quality_appendix") or {}).get(
                    "requested_requirement_coverage"
                ) or []
                existing_ids = {str(row.get("requirement_id") or "") for row in requested}
                for row in report_rows:
                    if not isinstance(row, dict):
                        continue
                    rid = str(row.get("requirement_id") or "")
                    if rid and rid not in existing_ids:
                        requested.append(row)
                        existing_ids.add(rid)
            except (OSError, json.JSONDecodeError) as exc:
                logger.warning("[%s] 读取 A2 覆盖附录失败（继续用 dataset 快照）：%s", run_id, exc)
        dataset.quality_summary["requested_requirement_coverage"] = requested
        selected = self.select_chart_supplement_demands(demands, matrix, requested)
        if not selected:
            return "none"
        for demand in selected:
            if str(demand.get("domain") or "") in {"news", "events"}:
                subject = str(dataset.subject or "").strip()
                if subject:
                    demand["entities"] = demand.get("entities") or [subject]
                    demand["query_hint"] = (
                        f"{subject} 重大合同 订单 中标 业绩预告 股权激励 事件催化 公告"
                    )

        async with self._host._run_lock(run_id):
            fresh = storage.load_state(run_id)
            if (
                not fresh
                or fresh.status != "running"
                or fresh.current_stage != "chart_generate"
                or fresh.revision != input_revision
            ):
                return "discarded"
            fetch_stage = fresh.stage_results.get("data_fetch")
            if fetch_stage is None or (fetch_stage.data.get("automatic_replenishment") or {}).get("round", 0):
                return "none"
            attempts = [
                {
                    "requirement_id": demand["requirement_id"],
                    "fingerprint": hashlib.sha256(
                        json.dumps(
                            {
                                k: demand.get(k)
                                for k in ("domain", "entities", "metrics", "period_ends", "acceptable_skill_ids")
                            },
                            ensure_ascii=False,
                            sort_keys=True,
                        ).encode()
                    ).hexdigest(),
                    "status": "started",
                }
                for demand in selected
            ]
            fetch_stage.data["automatic_replenishment"] = {"round": 1, "attempts": attempts}
            storage.save_state(fresh)

        fetched: list[Any] = []
        for demand, attempt in zip(selected, attempts):
            try:
                records = await self._host._fetch_supplement_with_audit(
                    run_id, "chart_generate", demand, as_of
                )
                fetched.extend(records)
                attempt["status"] = "returned" if records else "empty"
            except asyncio.CancelledError:
                raise
            except Exception:
                attempt["status"] = "failed"

        def coverage_map(source: StructuredResearchDataset) -> dict[str, set[str]]:
            result: dict[str, set[str]] = {}
            for row in source.quality_summary.get("requirement_evidence_matrix") or []:
                rid = str((row.get("requirement") or {}).get("requirement_id") or "")
                if rid:
                    result[rid] = set((row.get("coverage") or {}).get("evidence_record_ids") or [])
            for row in source.quality_summary.get("requested_requirement_coverage") or []:
                rid = str(row.get("requirement_id") or "")
                if rid and rid not in result:
                    result[rid] = set(row.get("evidence_record_ids") or [])
            return result

        before = coverage_map(dataset)
        candidate = dataset.model_copy(deep=True)
        try:
            added = merge_supplemental_records(candidate, {}, fetched, as_of) if fetched else []
        except SupplementalRecordCollision:
            added = []
            for attempt in attempts:
                if attempt["status"] == "returned":
                    attempt["status"] = "rejected_collision"

        target_ids = {d["requirement_id"] for d in selected}
        gained: set[str] = set()
        for rid, evidence_ids in coverage_map(candidate).items():
            if rid in target_ids:
                gained.update(evidence_ids - before.get(rid, set()))
        gained.intersection_update(added)
        replacements = {
            item.get("original_record", {}).get("record_id"): item.get("replacement_record_id")
            for item in candidate.quality_summary.get("restatement_adjustments", [])
        }
        eligible = [
            record for record in fetched if record.record_id in gained or replacements.get(record.record_id) in gained
        ]
        if eligible:
            candidate = dataset.model_copy(deep=True)
            merge_supplemental_records(candidate, {}, eligible, as_of)
            candidate.quality_summary["requested_requirement_coverage"] = [
                row
                for row in candidate.quality_summary.get("requested_requirement_coverage", [])
                if row.get("requirement_id") != "supplement_analysis_stale"
            ]

        async with self._host._run_lock(run_id):
            fresh = storage.load_state(run_id)
            if (
                not fresh
                or fresh.status != "running"
                or fresh.current_stage != "chart_generate"
                or fresh.revision != input_revision
                or not path.exists()
                or hashlib.sha256(path.read_bytes()).hexdigest() != original_hash
                or (input_path.read_bytes() if input_path.exists() else None) != original_input
            ):
                return "discarded"
            fetch_stage = fresh.stage_results["data_fetch"]
            fetch_stage.data["automatic_replenishment"] = {
                "round": 1,
                "attempts": attempts,
                "status": "committed" if eligible else "no_qualified_evidence",
                "event_record_count": len(candidate.events),
                "requested_requirement_coverage": candidate.quality_summary.get(
                    "requested_requirement_coverage", []
                ),
            }
            if not eligible:
                storage.save_state(fresh)
                return "none"
            previous = fresh.model_copy(deep=True)
            run_dir = storage.get_run_dir(run_id)
            from backend.app.engine.versioned_mutation import begin_versioned_mutation

            old_art_dir = resolve_artifact_dir(run_dir)
            fresh, version_fork = begin_versioned_mutation(run_dir, fresh, "data_interpret")
            if version_fork:
                path = resolve_artifact_dir(run_dir) / path.relative_to(old_art_dir)
                fetch_stage = fresh.stage_results["data_fetch"]
            archive = run_dir / "revisions" / "artifacts" / f"r{input_revision}"
            archive_created = False
            touched: dict[Path, bytes | None] = {}

            def backup(item: Path) -> None:
                if item not in touched:
                    touched[item] = item.read_bytes() if item.exists() else None

            try:
                if not version_fork and not archive.exists():
                    archive.parent.mkdir(parents=True, exist_ok=True)
                    archive_created = True
                    shutil.copytree(resolve_artifact_dir(run_dir), archive)
                backup(path)
                path.write_text(candidate.model_dump_json(indent=2), encoding="utf-8")
                fresh.revision += 1
                fetch_stage.revision = fresh.revision
                fetch_stage.data["record_count"] = candidate.total_record_count
                fetch_stage.data["requirement_evidence_matrix"] = candidate.quality_summary.get(
                    "requirement_evidence_matrix", []
                )
                self._host._invalidate_following_stages(fresh, "data_fetch")
                fresh.current_stage = "data_interpret"
                fresh.status = "running"
                fresh.stage_results["data_interpret"].status = "running"
                fresh.updated_at = datetime.now().isoformat()
                self._host._commit_state_with_history(
                    run_dir,
                    fresh,
                    action="auto_replenish",
                    stage="data_fetch",
                    from_revision=input_revision,
                    to_revision=fresh.revision,
                    comment="图表需求触发定向补采",
                    changed_fields=["dataset"],
                    snapshot_state=previous,
                    backup=backup,
                )
            except Exception:
                for item, content in touched.items():
                    if content is None:
                        item.unlink(missing_ok=True)
                    else:
                        item.write_bytes(content)
                if archive_created:
                    shutil.rmtree(archive, ignore_errors=True)
                if version_fork:
                    version_fork.rollback()
                raise
            return "committed"
