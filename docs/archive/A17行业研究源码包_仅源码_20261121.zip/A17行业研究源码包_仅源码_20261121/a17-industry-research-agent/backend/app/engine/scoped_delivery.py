"""Build narrowly scoped report components without inventing chain relations."""
from __future__ import annotations

from copy import deepcopy
from datetime import date
import hashlib
import json
import re
from html import escape
from pathlib import Path
from typing import Any


def recheck_industry_annual_coverage(dataset: dict[str, Any], evidence_ids: set[str]) -> dict[str, Any]:
    """Revalidate historical industry cells using only trusted, citable full-year data."""
    from data_fetcher.agent import DataFetcherAgent
    from data_fetcher.models import ResearchRecord, ResearchRequirement, StructuredResearchDataset

    quality = deepcopy(dataset.get("quality_summary") or {})
    needs_recheck = [row for row in quality.get("requirement_evidence_matrix", [])
                     if row["requirement"].get("domain") == "industry"
                     and row["requirement"].get("requirement_id", "").startswith("annual_")
                     and row["coverage"].get("passed") is False
                     and not row["coverage"].get("out_of_scope")]
    if not needs_recheck:
        return quality
    excluded = {rid for conflict in dataset.get("conflicts", []) for rid in conflict.get("record_ids", [])}
    eligible_ids = evidence_ids - excluded
    records = []
    for row in dataset.get("industry", []):
        if row.get("record_id") not in eligible_ids:
            continue
        record = ResearchRecord.model_validate(row)
        end = record.period_end
        if (end and end.month == 12 and end.day == 31 and record.period_start == date(end.year, 1, 1)
                and record.period_type in {"annual", "ytd_month"} and record.unit
                and not set(record.issues) & {"period_conflict", "review_excluded", "unit_unknown"}):
            records.append(record.model_copy(update={"period_type": "annual"}))
    trusted = StructuredResearchDataset(subject=dataset["subject"], research_as_of=dataset["research_as_of"],
                                        industry=records)
    for row in needs_recheck:
        requirement = ResearchRequirement.model_validate(row["requirement"])
        coverage = DataFetcherAgent._evaluate_requirement(trusted, requirement)
        if coverage.passed:
            row["coverage"] = coverage.model_dump(mode="json")
    return quality


def reconcile_industry_annual_warnings(warnings: list[str], verified: set[str], complete_families: set[str]) -> list[str]:
    missing_prefix = "硬性数据需求未覆盖："
    reconciled = []
    for warning in warnings:
        if warning.startswith(missing_prefix):
            labels = [label.strip() for label in warning[len(missing_prefix):].split("、")]
            remaining = [label for label in labels if label not in verified]
            if remaining:
                reconciled.append(missing_prefix + "、".join(remaining))
        elif ("口径映射不一致" in warning and "年度序列需求已由原始记录满足" in warning
              and any(f"全年{family}" in warning for family in complete_families)):
            continue
        else:
            reconciled.append(warning)
    return reconciled


def eligible_automatic_announcement(dataset: Any, raw_input: Any, requirement_id: str) -> bool:
    """Identify historical machine-added checks only when original inputs are available."""
    from agents_core.research_scope import explicitly_requests_filing

    if not isinstance(dataset, dict) or not isinstance(raw_input, dict) or not isinstance(raw_input.get("input_data"), dict):
        return False
    if explicitly_requests_filing(json.dumps(raw_input["input_data"], ensure_ascii=False)):
        return False
    rows = (dataset.get("quality_summary") or {}).get("requirement_evidence_matrix") or []
    if not isinstance(rows, list):
        return False
    annual_entities = {str(name) for row in rows if isinstance(row, dict)
        for requirement in [row.get("requirement") or {}] if isinstance(requirement, dict)
        and requirement.get("domain") == "financials" and requirement.get("period_ends")
        for name in requirement.get("entity_names") or [] if name}
    matches_entity = any(requirement_id == "announcement_search_" + hashlib.sha256(name.encode()).hexdigest()[:16]
                         for name in annual_entities)
    return bool(matches_entity and any(
        isinstance(row, dict) and isinstance(row.get("requirement"), dict) and isinstance(row.get("coverage"), dict)
        and row["requirement"].get("requirement_id") == requirement_id
        and row["requirement"].get("domain") == "news"
        and row["requirement"].get("acceptable_skill_ids") == ["announcement-search"]
        and row["coverage"].get("passed") is False and not row["coverage"].get("out_of_scope")
        for row in rows))


def restore_trusted_coverage(appendix: dict[str, Any], quality_summary: dict[str, Any] | None) -> dict[str, Any]:
    """Restore immutable collection requirements after editable analysis has been loaded."""
    result = deepcopy(appendix)
    trusted_rows = (quality_summary or {}).get("requirement_evidence_matrix") or []
    trusted: dict[str, dict[str, Any]] = {}
    for row in trusted_rows:
        if not isinstance(row, dict):
            continue
        requirement, coverage = row.get("requirement"), row.get("coverage")
        if not isinstance(requirement, dict) or not isinstance(coverage, dict):
            continue
        rid = str(requirement.get("requirement_id") or "")
        if rid and coverage.get("requirement_id") == rid:
            trusted[rid] = deepcopy(row)

    matrix = []
    seen: set[str] = set()
    for row in result.get("requirement_evidence_matrix") or []:
        if not isinstance(row, dict) or not isinstance(row.get("requirement"), dict):
            continue
        rid = str(row["requirement"].get("requirement_id") or "")
        if rid in trusted:
            matrix.append(deepcopy(trusted[rid]))
            seen.add(rid)
        else:
            row["requirement"]["origin"] = "unknown"
            matrix.append(row)
    matrix.extend(deepcopy(row) for rid, row in trusted.items() if rid not in seen)
    result["requirement_evidence_matrix"] = matrix

    def restore_rows(key: str, expected: set[str]) -> None:
        original = result.get(key) or []
        rows = [row for row in original if isinstance(row, dict) and str(row.get("requirement_id") or "") not in trusted]
        rows.extend(deepcopy(trusted[rid]["coverage"]) for rid in trusted if rid in expected)
        result[key] = rows

    if trusted:
        restore_rows("requested_requirement_coverage", set(trusted))
        restore_rows("requested_financial_coverage", {rid for rid in trusted if rid.startswith("annual_")})
    return result


def valid_scope_decision(decision: Any, run_id: str, revision: int, bundle_bytes: bytes) -> bool:
    """The scope choice applies only to the newly generated revision of this run."""
    if not isinstance(decision, dict) or isinstance(revision, bool):
        return False
    current, previous = decision.get("revision"), decision.get("from_revision")
    return bool(
        decision.get("run_id") == run_id and decision.get("classification_only") is True
        and isinstance(current, int) and not isinstance(current, bool) and current == revision
        and isinstance(previous, int) and not isinstance(previous, bool) and previous + 1 == current
        and str(decision.get("issue_fingerprint") or "").strip()
        and isinstance(bundle_bytes, bytes)
        and decision.get("bundle_sha256") == hashlib.sha256(bundle_bytes).hexdigest()
    )


def scoped_chain_eligible(data: dict[str, Any]) -> bool:
    """Recognize a revalidated limited-scope result without claiming the chain is complete."""
    chain = data.get("chain_delivery") or {}
    quality = data.get("quality") or {}
    return bool(isinstance(chain, dict) and isinstance(quality, dict)
        and data.get("delivery_status") == "ready_scoped" and data.get("agent_status") == "completed"
        and not data.get("hard_blocked") and not data.get("delivery_blocked")
        and quality.get("passed") is True and chain.get("requested") is True
        and chain.get("status") == "partial" and chain.get("scope_applied") is True
        and type(chain.get("verified_relations")) is int and chain.get("verified_relations") == 0
        and isinstance(chain.get("scoped_chart_id"), str) and chain["scoped_chart_id"].strip())


def valid_announcement_scope(decision: Any, run_id: str, revision: int, dataset_bytes: bytes) -> bool:
    if not isinstance(decision, dict) or isinstance(revision, bool):
        return False
    current, previous, ids = decision.get("revision"), decision.get("from_revision"), decision.get("accepted_ids")
    return bool(decision.get("run_id") == run_id and isinstance(current, int) and not isinstance(current, bool)
        and current == revision and isinstance(previous, int) and not isinstance(previous, bool) and previous + 1 == current
        and isinstance(ids, list) and ids and all(isinstance(item, str) and item.startswith("announcement_search_") for item in ids)
        and isinstance(dataset_bytes, bytes) and decision.get("dataset_sha256") == hashlib.sha256(dataset_bytes).hexdigest())


def merge_announcement_choices(decision: Any, run_id: str, revision: int,
                               dataset_bytes: bytes, new_ids: list[str]) -> list[str]:
    existing = decision["accepted_ids"] if valid_announcement_scope(decision, run_id, revision, dataset_bytes) else []
    return sorted(set(existing) | set(new_ids))


def carry_announcement_scope(artifact_dir: Path, run_id: str, previous_revision: int, revision: int) -> bool:
    from backend.app.engine.remediation_sources import _atomic_write

    path = artifact_dir / "announcement_scope_decision.json"
    try:
        decision = json.loads(path.read_text(encoding="utf-8"))
        dataset = (artifact_dir / "dataset.json").read_bytes()
    except (OSError, ValueError):
        return False
    if revision != previous_revision + 1 or not valid_announcement_scope(decision, run_id, previous_revision, dataset):
        return False
    decision.setdefault("confirmed_revision", previous_revision)
    decision["from_revision"] = previous_revision
    decision["revision"] = revision
    _atomic_write(path, json.dumps(decision, ensure_ascii=False, indent=2).encode())
    return True


def carry_scope_decision(artifact_dir: Path, run_id: str, previous_revision: int, revision: int) -> bool:
    """Carry a valid decision across an approval that did not modify content."""
    from backend.app.engine.remediation_sources import _atomic_write

    path = artifact_dir / "scope_decision.json"
    try:
        decision = json.loads(path.read_text(encoding="utf-8"))
        bundle = (artifact_dir / "chain" / "v2" / "bundle.json").read_bytes()
    except (OSError, ValueError):
        return False
    if revision != previous_revision + 1 or not valid_scope_decision(decision, run_id, previous_revision, bundle):
        return False
    decision.setdefault("confirmed_revision", previous_revision)
    decision["from_revision"] = previous_revision
    decision["revision"] = revision
    _atomic_write(path, json.dumps(decision, ensure_ascii=False, indent=2).encode())
    return True


def scope_report_narrative(report: Any, chapters: Any, allowed_chain_evidence: set[str]) -> tuple[Any, Any, int]:
    """Remove chain claims outside the independently checked classification view."""
    from report_fusion.models import ParagraphDraft

    report = report.model_copy(deep=True)
    chapters = chapters.model_copy(deep=True)
    index = report.evidence_index
    chain_terms = re.compile(r"产业链|供应链|价值链|上游|中游|下游|工序|环节|代表企业|供货关系")

    def unsafe(text: Any, refs: Any = ()) -> bool:
        if chain_terms.search(str(text or "")):
            return True
        return any(ref in index and index[ref].domain == "industry_chain" and ref not in allowed_chain_evidence
                   for ref in refs or [])

    original, removed = 0, 0
    affected_chapters: set[str] = set()
    for chapter in chapters.chapters:
        if chapter.chapter_id == "CH-03" and ("产业链" in chapter.title or "供应链" in chapter.title):
            chapter.summary = "本章仅展示有证据支持的环节分类；工序关系尚未核验。"
            chapter.evidence_ids = []
            for section in chapter.sections:
                section.title = "已核验环节分类与研究限制"
                section.purpose = "说明本次分类的适用范围"
                section.key_points = []
                section.paragraphs = [ParagraphDraft(paragraph_id=f"{section.section_id}-scope",
                    text="本节仅保留有证据支持的环节分类，工序关系及其他归属尚未完整核验。")]
                section.metric_cards = []
                section.comparison_table = None
                section.callouts = []
                section.uncertainties = []
            continue
        if unsafe(chapter.summary, chapter.evidence_ids):
            chapter.summary = "本章根据可核验的资料展开分析。"
        chapter.evidence_ids = [eid for eid in chapter.evidence_ids if not unsafe('', [eid])]
        for section in chapter.sections:
            section.key_points = [text for text in section.key_points if not unsafe(text)]
            kept = []
            for paragraph in section.paragraphs:
                original += 1
                if unsafe(paragraph.text, paragraph.evidence_ids):
                    removed += 1
                    affected_chapters.add(chapter.chapter_id)
                else:
                    kept.append(paragraph)
            section.paragraphs = kept
            section.metric_cards = [card for card in section.metric_cards if not unsafe(card.label, card.evidence_ids)]
            section.callouts = [callout for callout in section.callouts if not unsafe(callout.title + callout.text, callout.evidence_ids)]
            if section.comparison_table and unsafe(section.comparison_table.model_dump_json(), section.comparison_table.evidence_ids):
                section.comparison_table = None
            section.uncertainties = [text for text in section.uncertainties if not unsafe(text)]
    if original and removed / original > 0.2:
        chapters_text = "、".join(sorted(affected_chapters))
        raise ValueError(f"收窄范围将移除过多正文（{removed}/{original} 段，涉及 {chapters_text}），"
                         "请先补充证据或修订受影响章节")
    report.industry_chain_segments = []
    report.insights = [item for item in report.insights if not unsafe(json.dumps(item, ensure_ascii=False),
        item.get("evidence_record_ids") or item.get("evidence_ids") or [])]
    report.key_metrics = [item for item in report.key_metrics if not unsafe(json.dumps(item, ensure_ascii=False),
        item.get("evidence_record_ids") or item.get("evidence_ids") or [])]
    if unsafe(report.executive_summary):
        report.executive_summary = "本报告仅保留可核验资料，并披露研究范围限制。"
    return report, chapters, removed


def render_scoped_bundle(bundle: Any, report_evidence_ids: set[str]) -> tuple[str, list[str]]:
    """Rebuild from supported bundle assertions, never from an editable chart graph."""
    from chain_research.evidence_bridge import project_supported_evidence
    from chain_research.graph_spec import bundle_to_chain_spec

    supported = {row["record_id"] for row in project_supported_evidence(bundle)} & report_evidence_ids
    graph = bundle_to_chain_spec(bundle).model_dump(mode="json")
    return render_scoped_classification(graph, supported)


def prepare_scoped_report(report: Any, chapters: Any, charts: Any, bundle_bytes: bytes,
                          decision: Any, run_id: str, revision: int) -> tuple[Any, Any, Any, str]:
    """Prepare a scope-limited view from a version-bound evidence bundle."""
    from chain_research.evidence_bridge import project_supported_evidence
    from chain_research.models import ChainKnowledgeBundle

    if not valid_scope_decision(decision, run_id, revision, bundle_bytes):
        raise ValueError("产业链范围确认已过期或证据包已变化")
    chain = charts.quality.get("chain_delivery") or {}
    if (chain.get("requested") is not True or chain.get("status") != "partial"
            or type(chain.get("verified_relations")) is not int or chain.get("verified_relations") != 0):
        raise ValueError("当前产业链状态不适用该交付范围")
    bundle = ChainKnowledgeBundle.model_validate_json(bundle_bytes)
    if bundle.scope.as_of != str(report.as_of):
        raise ValueError("产业链证据与报告研究时点不一致")
    trusted_ids: set[str] = set()
    for row in project_supported_evidence(bundle):
        ref = report.evidence_index.get(row["record_id"])
        if ref is not None and all(getattr(ref, key, None) == row.get(key)
                                   for key in ("record_id", "domain", "entity", "metric", "value")):
            trusted_ids.add(row["record_id"])
    svg, refs = render_scoped_bundle(bundle, trusted_ids)
    safe_report, safe_chapters, removed = scope_report_narrative(report, chapters, trusted_ids)
    safe_charts = charts.model_copy(deep=True)
    chain_charts = [chart for chart in safe_charts.charts if chart.chart_type == "industry_chain"]
    if not chain_charts:
        raise ValueError("缺少可替换的产业链图表，请先重新生成")
    selected = chain_charts[0]
    omitted = {chart.chart_id for chart in chain_charts[1:]}
    safe_charts.charts = [chart for chart in safe_charts.charts if chart.chart_id not in omitted]
    for chapter in safe_chapters.chapters:
        chapter.chart_ids = [cid for cid in chapter.chart_ids if cid not in omitted]
        for section in chapter.sections:
            section.chart_ids = [cid for cid in section.chart_ids if cid not in omitted]
    selected.title = "已核验环节分类"
    selected.insight_goal = "仅展示有证据支持的环节分类"
    selected.evidence_ids = refs
    selected.option = {}
    selected.data_contract = {"scoped_classification": True}
    selected.footnotes = ["仅展示有证据支持的分类；工序关系尚未核验。"]
    selected.subtitle = "有限覆盖：工序关系尚未核验"
    selected.source_line = "来源见报告证据索引"
    selected.render_mode = "svg"
    selected.image_uri = None
    selected.chain_graph = None
    selected.supplement_image_uri = None
    selected.supplement_html_uri = None
    selected.supplement_note = None
    safe_charts.quality["chain_delivery"] = {**chain, "scope_applied": True,
        "scoped_chart_id": selected.chart_id, "scoped_removed_paragraphs": removed}
    return safe_report, safe_chapters, safe_charts, svg


def render_scoped_classification(graph: dict[str, Any], allowed_evidence_ids: set[str]) -> tuple[str, list[str]]:
    """Render supported activity names only; never copy the original graph's edges or companies."""
    entries: list[tuple[str, list[str]]] = []
    seen: set[str] = set()
    for node in graph.get("nodes", []):
        if not isinstance(node, dict) or node.get("source_tier") != "evidence":
            continue
        name = str(node.get("name") or "").strip()
        refs = node.get("evidence_record_ids") or []
        if (not name or name in seen or not isinstance(refs, list) or not refs
                or any(not isinstance(ref, str) or ref not in allowed_evidence_ids for ref in refs)):
            continue
        seen.add(name)
        entries.append((name, refs))
    if not entries:
        raise ValueError("没有可展示的已核验环节分类")

    height = 118 + 42 * len(entries)
    lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 {height}" role="img" aria-label="已核验环节分类">',
        f'<rect width="960" height="{height}" fill="#fff"/>',
        '<text x="32" y="40" fill="#203a5e" font-size="24" font-weight="700">已核验环节分类</text>',
        '<text x="32" y="72" fill="#6b665c" font-size="15">仅展示有证据支持的分类；工序关系尚未核验。</text>',
    ]
    for index, (name, _) in enumerate(entries):
        y = 110 + index * 42
        lines.append(f'<text x="40" y="{y}" fill="#292923" font-size="17">{escape(name)}</text>')
        lines.append(f'<line x1="32" y1="{y + 12}" x2="928" y2="{y + 12}" stroke="#e4dfd4"/>')
    lines.append('</svg>')
    evidence_ids = list(dict.fromkeys(ref for _, refs in entries for ref in refs))
    return ''.join(lines), evidence_ids
