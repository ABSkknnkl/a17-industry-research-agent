from __future__ import annotations
import json
import re
import shutil
from pathlib import Path
from backend.app.core.config import settings
from backend.app.schemas.workflow import (
    WorkflowState,
    RunSummary,
    RunListResponse,
    RevisionSummary,
    RevisionListResponse,
)


class StorageManager:
    # run_id 只允许字母/数字/点/下划线/连字符；文件名同理但更严（不得含路径分隔符）。
    _RUN_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
    _FILE_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")

    def __init__(self, base_dir: Path | None = None) -> None:
        self.base_dir = base_dir or settings.DATA_DIR
        self.base_dir.mkdir(parents=True, exist_ok=True)

    def _safe_run_dir(self, run_id: str) -> Path:
        """校验 run_id 并返回 base_dir 内的目标目录（未创建）。

        为什么需要：`base_dir / run_id` 在 run_id 含 `..` 或为绝对路径时会逃逸到工作区外，
        导致越界创建目录、甚至 `delete_run` 越界删除（缺陷 D-01）。这里做白名单 + 归属双重校验。

        Args:
            run_id: 运行标识，形如 `run-20260923094843-353`。

        Returns:
            base_dir 下的目标目录（Path，尚未创建）。

        Raises:
            ValueError: run_id 为空、含非法字符、为 `.`/`..`，或解析后不在 base_dir 之内。
        """
        if not isinstance(run_id, str) or run_id in {".", ".."} or not self._RUN_ID_RE.match(run_id):
            raise ValueError(f"非法 run_id: {run_id!r}")
        base = self.base_dir.resolve()
        target = (base / run_id).resolve()
        if target == base or not target.is_relative_to(base):
            raise ValueError(f"run_id 越界（不得指向 base_dir 之外）: {run_id!r}")
        return target

    @classmethod
    def _safe_file_name(cls, file_name: str) -> str:
        """校验写入用文件名（防 `../` 逃逸与子目录穿越）。

        Raises:
            ValueError: 文件名为空、含路径分隔符或非法字符。
        """
        if not isinstance(file_name, str) or not cls._FILE_NAME_RE.match(file_name):
            raise ValueError(f"非法文件名: {file_name!r}")
        return file_name

    def get_run_dir(self, run_id: str) -> Path:
        run_dir = self._safe_run_dir(run_id)
        run_dir.mkdir(parents=True, exist_ok=True)
        (run_dir / "revisions").mkdir(exist_ok=True)
        (run_dir / "artifacts").mkdir(exist_ok=True)
        return run_dir

    def resolve_artifact_dir(self, run_id: str, revision: int | None = None) -> Path:
        from agents_core.artifact_paths import resolve_artifact_dir

        return resolve_artifact_dir(self.get_run_dir(run_id), revision)

    def save_state(self, state: WorkflowState) -> None:
        run_dir = self.get_run_dir(state.run_id)
        pointer_exists = (run_dir / "artifact_pointer.json").exists()
        state_file = self.resolve_artifact_dir(state.run_id) / "workflow_state.json" if pointer_exists else run_dir / "state.json"
        tmp_state_file = state_file.parent / f"state.{state.revision}.tmp"
        data = state.model_dump(mode="json")

        # 原子落盘 state.json（写入同目录临时文件后通过系统调用原子替换，防止并发损坏）
        with open(tmp_state_file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        tmp_state_file.replace(state_file)

        # Legacy tools still read the root mirror; the pointer-selected state is authoritative.
        if pointer_exists:
            mirror = run_dir / f"state.{state.revision}.mirror.tmp"
            with open(mirror, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2, default=str)
            mirror.replace(run_dir / "state.json")

        # 同时归档当前 revision（同样执行原子替换）
        rev_file = run_dir / "revisions" / f"{state.revision}.json"
        tmp_rev_file = run_dir / "revisions" / f"{state.revision}.tmp"
        with open(tmp_rev_file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        tmp_rev_file.replace(rev_file)

    def load_state(self, run_id: str) -> WorkflowState | None:
        run_dir = self.get_run_dir(run_id)
        if (run_dir / "artifact_pointer.json").exists():
            artifact_dir = self.resolve_artifact_dir(run_id)
            state_file = artifact_dir / "workflow_state.json"
        else:
            artifact_dir = run_dir / "artifacts"
            state_file = run_dir / "state.json"
        if not state_file.exists():
            return None
        with open(state_file, "r", encoding="utf-8") as f:
            state = WorkflowState.model_validate(json.load(f))

        analysis = state.stage_results.get("data_interpret")
        if (
            analysis is not None
            and analysis.status in {"waiting_review", "approved", "completed"}
            and "comps_matrix" not in analysis.data
        ):
            # 旧任务只把标的池写入了解读产物，按状态所选的同一快照读取。
            try:
                report = json.loads((artifact_dir / "interpretation_report.json").read_text(encoding="utf-8"))
            except (OSError, ValueError):
                return state
            matrix = report.get("comps_matrix") if isinstance(report, dict) else None
            if isinstance(matrix, dict):
                analysis.data["comps_matrix"] = matrix
        return state

    def load_revision(self, run_id: str, revision: int) -> WorkflowState | None:
        rev_file = self.get_run_dir(run_id) / "revisions" / f"{revision}.json"
        if not rev_file.exists():
            return None
        with open(rev_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        return WorkflowState.model_validate(data)

    def list_revisions(self, run_id: str) -> RevisionListResponse:
        state = self.load_state(run_id)
        if not state:
            return RevisionListResponse(run_id=run_id, current_revision=1, revisions=[])

        rev_dir = self.get_run_dir(run_id) / "revisions"
        revisions: list[RevisionSummary] = []
        for file in sorted(rev_dir.glob("*.json"), key=lambda p: int(p.stem)):
            try:
                with open(file, "r", encoding="utf-8") as f:
                    d = json.load(f)
                revisions.append(
                    RevisionSummary(
                        revision=d.get("revision", int(file.stem)),
                        status=d.get("status", "pending"),
                        current_stage=d.get("current_stage", "data_fetch"),
                        updated_at=d.get("updated_at", ""),
                    )
                )
            except Exception:
                continue

        return RevisionListResponse(
            run_id=run_id,
            current_revision=state.revision,
            revisions=revisions,
        )

    @staticmethod
    def _resolve_title(state: dict) -> str:
        """列表标题：阶段产物里的主题优先，缺省退回任务 ID。

        为什么不能只看 input_data：WorkflowState（schemas/workflow.py）没有该字段，
        state.json 里根本不存在，历史实现导致列表全部显示「研报任务: run-xxx」。
        """
        stage_results = state.get("stage_results") or {}
        fusion = (stage_results.get("report_fusion") or {}).get("data") or {}
        if isinstance(fusion, dict):
            value = fusion.get("title")
            if isinstance(value, str) and value.strip():
                return value.strip()
        fetch = (stage_results.get("data_fetch") or {}).get("data") or {}
        if isinstance(fetch, dict):
            for key in ("industry_topic", "topic"):
                value = fetch.get(key)
                if isinstance(value, str) and value.strip():
                    return f"《{value.strip()}》行业研究报告"
        req_input = state.get("input_data") or {}
        if isinstance(req_input, dict) and req_input.get("industry_topic"):
            return f"《{req_input['industry_topic']}》行业研究报告"
        return f"研报任务: {state.get('run_id', '')}"

    def list_runs(self, offset: int = 0, limit: int = 20) -> RunListResponse:
        runs: list[RunSummary] = []
        for run_dir in self.base_dir.iterdir():
            if not run_dir.is_dir():
                continue
            state_file = run_dir / "state.json"
            if not state_file.exists() and not (run_dir / "artifact_pointer.json").exists():
                continue
            try:
                if (run_dir / "artifact_pointer.json").exists():
                    state_file = self.resolve_artifact_dir(run_dir.name) / "workflow_state.json"
                with open(state_file, "r", encoding="utf-8") as f:
                    d = json.load(f)
                # 统计产物数量与最终报告是否可用
                art_count = 0
                for sr in d.get("stage_results", {}).values():
                    art_count += len(sr.get("artifacts", []))

                fusion_res = d.get("stage_results", {}).get("report_fusion")
                report_available = bool(
                    fusion_res
                    and fusion_res.get("status") in ["approved", "completed"]
                )
                # 受限草稿：只要 report_fusion 落过报告类产物（pdf/html/md）即可从列表进入
                # 下载页；是否放行由下载页门控判定（前端 reportGate 是唯一权威）。
                fusion_artifacts = (fusion_res or {}).get("artifacts") or []
                draft_available = any(
                    str((a or {}).get("kind", "")).startswith("report_")
                    for a in fusion_artifacts
                    if isinstance(a, dict)
                )

                # 提取标题：WorkflowState 不落 input_data，所以标题只能从阶段产物里取。
                # 优先级：融合阶段标题（《X》深度行业研究报告）→ 采集阶段主题 → 旧版 input_data。
                title = self._resolve_title(d)

                runs.append(
                    RunSummary(
                        run_id=d.get("run_id", run_dir.name),
                        project_id=d.get("project_id", "default"),
                        title=title,
                        current_stage=d.get("current_stage", "data_fetch"),
                        status=d.get("status", "pending"),
                        revision=d.get("revision", 1),
                        created_at=d.get("created_at", ""),
                        updated_at=d.get("updated_at", ""),
                        artifact_count=art_count,
                        report_available=report_available,
                        draft_available=draft_available,
                    )
                )
            except Exception:
                continue

        # 按创建时间降序排序
        runs.sort(key=lambda r: r.created_at, reverse=True)
        total = len(runs)
        paged_items = runs[offset : offset + limit]
        return RunListResponse(total=total, offset=offset, limit=limit, items=paged_items)

    def save_artifact_file(self, run_id: str, filename: str, content: bytes | str) -> Path:
        run_dir = self.get_run_dir(run_id)
        target = self.resolve_artifact_dir(run_id) / self._safe_file_name(filename)
        if isinstance(content, str):
            target.write_text(content, encoding="utf-8")
        else:
            target.write_bytes(content)
        return target

    def get_artifact_path(self, run_id: str, artifact_id: str) -> Path | None:
        run_dir = self.get_run_dir(run_id)
        art_dir = self.resolve_artifact_dir(run_id)
        if not art_dir.exists():
            return None
        # 1. 常见固定产物 ID 快速精确匹配
        id_map = {
            "report_markdown": "report.md",
            "report_html": "report.html",
            "report_pdf": "report.pdf",
            "dataset_json": "dataset.json",
            "interpretation_report_json": "interpretation_report.json",
            "chart_result_json": "chart_result.json",
            "chapter_result_json": "chapter_result.json",
            "artifact_manifest": "manifest.json",
            "report_view_json": "report_view.json",
            "consistency_report_json": "consistency_report.json",
        }
        mapped_name = id_map.get(artifact_id)
        if mapped_name and (art_dir / mapped_name).is_file():
            return art_dir / mapped_name

        # 2. 检查 artifacts 目录下是否有同名文件或匹配 ID
        for p in art_dir.iterdir():
            if p.name == "workflow_state.json":
                continue
            if p.is_file() and (p.name == artifact_id or p.stem == artifact_id or artifact_id in p.name):
                return p
        # 2. 检查 charts 子目录
        charts_dir = art_dir / "charts"
        if charts_dir.exists():
            clean_id = artifact_id[:-4] if artifact_id.endswith("_svg") else artifact_id
            for p in charts_dir.iterdir():
                if p.is_file() and (p.name == artifact_id or p.stem == artifact_id or p.stem == clean_id or clean_id in p.name):
                    return p
        # 3. 检查 images 子目录（2026-10-17）：产业链「HTML 排版版」截图与 AI 生图位图
        # 落在 artifacts/images/ 下，之前只认 charts/，导致这些位图在产物接口里 404，
        # 前端拿不到图只能显示"未内联"。
        images_dir = art_dir / "images"
        if images_dir.exists():
            for p in images_dir.iterdir():
                if p.is_file() and (p.name == artifact_id or p.stem == artifact_id):
                    return p
        return None

    def delete_run(self, run_id: str) -> bool:
        # 复用同一套校验：越界 run_id 直接抛错，绝不对 base_dir 之外执行 rmtree（缺陷 D-01）
        run_dir = self._safe_run_dir(run_id)
        deleted = False
        if run_dir.exists():
            shutil.rmtree(run_dir, ignore_errors=True)
            deleted = True

        # 同步清理 output/runs 下对应 run_id 或关联产物目录
        output_runs_dir = settings.PROJECT_ROOT / "output" / "runs"
        if output_runs_dir.exists():
            # 1. 精确匹配 output/runs/<run_id>
            exact_output = output_runs_dir / run_id
            if exact_output.exists():
                shutil.rmtree(exact_output, ignore_errors=True)
                deleted = True
            # 2. 匹配可能包含 run_id 的残留文件夹
            try:
                for p in output_runs_dir.iterdir():
                    if p.is_dir() and run_id in p.name:
                        shutil.rmtree(p, ignore_errors=True)
                        deleted = True
            except Exception:
                pass

        return deleted

    def clear_all_runs(self) -> int:
        """彻底清空所有历史研报任务与本地全量产物数据"""
        count = 0
        # 1. 清空 data/runs/ 下所有运行目录（保留 .gitkeep）
        if self.base_dir.exists():
            for p in list(self.base_dir.iterdir()):
                if p.is_dir():
                    shutil.rmtree(p, ignore_errors=True)
                    count += 1

        # 2. 清空 output/runs/ 下所有残留中间产物（保留 .gitkeep）
        output_runs_dir = settings.PROJECT_ROOT / "output" / "runs"
        if output_runs_dir.exists():
            for p in list(output_runs_dir.iterdir()):
                if p.is_dir():
                    shutil.rmtree(p, ignore_errors=True)
                elif p.is_file() and p.name != ".gitkeep":
                    p.unlink(missing_ok=True)

        return count


storage = StorageManager()
