from __future__ import annotations
from agents_core.artifact_paths import resolve_artifact_dir
import asyncio
import csv
import io
import json
import logging
import os
import re
import mimetypes
import zipfile
from hashlib import file_digest
from pathlib import Path
from typing import Any, Literal
from fastapi import APIRouter, File, Form, HTTPException, Query, Response, UploadFile, status
from fastapi.responses import FileResponse, StreamingResponse

logger = logging.getLogger("api_routes")

from backend.app.core.event_hub import event_hub
from backend.app.core.storage import storage
from backend.app.engine.evidence_sources import load_evidence_sources, merge_evidence_sources, source_url_for
from backend.app.engine.state_machine import ReviewConflictError, RevisionConflictError, engine
from backend.app.schemas.remediation import ActionRequest, ApplyRemediationRequest
from backend.app.schemas.workflow import (
    AgentTraceEvent,
    ArtifactRef,
    RevisionListResponse,
    ReviewRequest,
    RunCreateRequest,
    RunListResponse,
    StageName,
    WorkflowState,
)

router = APIRouter(prefix="/api/v1")
_remediation_tasks: dict[str, asyncio.Task] = {}


@router.get("/runs/{run_id}/remediation")
async def get_remediation_endpoint(run_id: str):
    from backend.app.engine.remediation_actions import recover_interrupted_actions
    from backend.app.engine.remediation_issues import build_remediation_snapshot

    async with engine._run_lock(run_id):
        state = storage.load_state(run_id)
        if state is None:
            raise HTTPException(status_code=404, detail="任务不存在")
        run_dir = storage.get_run_dir(run_id)
        recover_interrupted_actions(run_dir, {key for key, task in _remediation_tasks.items() if not task.done()})
        return build_remediation_snapshot(state, run_dir)


@router.post("/runs/{run_id}/remediation/sources")
async def add_remediation_source_endpoint(
    run_id: str,
    title: str = Form(...),
    declared_publisher: str = Form(""),
    published_at: str | None = Form(None),
    url: str | None = Form(None),
    file: UploadFile | None = File(None),
):
    from datetime import date
    from backend.app.engine.remediation_sources import MAX_BYTES, SourceInput, store_source

    state = storage.load_state(run_id)
    if state is None:
        raise HTTPException(status_code=404, detail="任务不存在")
    try:
        fusion = state.stage_results.get("report_fusion")
        as_of_text = fusion.data.get("research_as_of") if fusion else None
        content = await file.read(MAX_BYTES + 1) if file else None
        return await store_source(storage.get_run_dir(run_id), SourceInput(
            title=title, declared_publisher=declared_publisher,
            published_at=date.fromisoformat(published_at) if published_at else None,
            as_of=date.fromisoformat(as_of_text) if as_of_text else None, url=url, content=content,
        ))
    except (ValueError, OSError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/runs/{run_id}/remediation/sources")
async def list_remediation_sources_endpoint(run_id: str):
    from backend.app.engine.remediation_sources import list_sources

    if storage.load_state(run_id) is None:
        raise HTTPException(status_code=404, detail="任务不存在")
    return list_sources(storage.get_run_dir(run_id))


@router.get("/runs/{run_id}/remediation/sources/{source_id}/pages/{page}")
async def get_remediation_source_page_endpoint(run_id: str, source_id: str, page: int):
    from backend.app.engine.remediation_sources import read_source_page

    if storage.load_state(run_id) is None:
        raise HTTPException(status_code=404, detail="任务不存在")
    try:
        return read_source_page(storage.get_run_dir(run_id), source_id, page)
    except (ValueError, OSError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/runs/{run_id}/remediation/items/{issue_id}/actions")
async def submit_remediation_action_endpoint(run_id: str, issue_id: str, request: ActionRequest):
    from backend.app.engine.remediation_actions import (
        RemediationConflict, create_search_action, execute_chain_action, execute_search_action, load_actions,
        save_candidate, validate_request,
    )

    try:
        async with engine._run_lock(run_id):
            state = storage.load_state(run_id)
            if state is None:
                raise HTTPException(status_code=404, detail="任务不存在")
            run_dir = storage.get_run_dir(run_id)
            already_exists = any(row.get("idempotency_key") == request.idempotency_key for row in load_actions(run_dir))
            if request.type == "supplement_search":
                action = create_search_action(state, run_dir, issue_id, request)
            elif request.type == "attach_source":
                from datetime import date
                from backend.app.engine.remediation_evidence import prepare_chain_binding, prepare_document_record
                from backend.app.engine.remediation_issues import build_remediation_snapshot

                validate_request(state, run_dir, issue_id, request)
                item = next(i for i in build_remediation_snapshot(state, run_dir).items if i.issue_id == issue_id)
                fusion = state.stage_results.get("report_fusion")
                as_of_text = fusion.data.get("research_as_of") if fusion else None
                if not as_of_text:
                    raise ValueError("缺少研究截止日期")
                payload = request.payload
                if item.category == "chain_relation":
                    prepared = prepare_chain_binding(run_dir, item, str(payload.get("source_id") or ""), payload.get("page"),
                        str(payload.get("excerpt") or ""), str(payload.get("subject_id") or ""),
                        str(payload.get("object_id") or ""), date.fromisoformat(as_of_text))
                    verified = prepared["source"]["publication_date_verified"]
                    action = save_candidate(state, run_dir, issue_id, request, status="pending" if verified else "needs_review",
                        summary="正在独立核验工序关系。" if verified else "发布日期尚未核实，请提供可核验的公告链接。",
                        result={"prepared": prepared})
                else:
                    record = prepare_document_record(run_dir, str(payload.get("source_id") or ""), payload.get("page"),
                                                     str(payload.get("excerpt") or ""), date.fromisoformat(as_of_text))
                    verified = record["raw_fields"]["publication_date_verified"]
                    action = save_candidate(state, run_dir, issue_id, request, status="ready" if verified else "needs_review",
                        summary="摘录已定位，应用后可用于正文复核。" if verified else "摘录已定位，但发布日期尚未核实；请提供可核验的公告链接。",
                        result={"candidate_record_ids": [record["record_id"]], "candidate_records": [record]})
            elif request.type in ("resolve_conflict", "enter_financial_record"):
                from datetime import date
                from backend.app.engine.remediation_conflicts import conflict_item_after_merge, prepare_conflict_decision, prepare_financial_record
                from backend.app.engine.remediation_issues import build_remediation_snapshot

                validate_request(state, run_dir, issue_id, request)
                item = next(i for i in build_remediation_snapshot(state, run_dir).items if i.issue_id == issue_id)
                fusion = state.stage_results.get("report_fusion")
                as_of_text = fusion.data.get("research_as_of") if fusion else None
                if not as_of_text:
                    raise ValueError("缺少研究截止日期")
                as_of = date.fromisoformat(as_of_text)
                payload = request.payload
                if request.type == "resolve_conflict":
                    selected_id = str(payload.get("selected_record_id") or "")
                    if selected_id not in {row.get("record_id") for row in item.context.get("records", [])}:
                        from backend.app.agents.adapters import merge_supplemental_records
                        from data_fetcher.models import ResearchRecord, StructuredResearchDataset

                        candidate = next((row for row in load_actions(run_dir)
                            if row.get("type") == "enter_financial_record" and row.get("status") == "ready"
                            and row.get("issue_id") == issue_id and row.get("expected_fingerprint") == item.fingerprint
                            and row.get("request", {}).get("expected_revision") == state.revision
                            and selected_id in row.get("candidate_record_ids", [])), None)
                        if candidate is None:
                            raise ValueError("新记录候选不存在或已过期")
                        record = prepare_financial_record(run_dir, candidate["request"]["payload"], as_of)["record"]
                        if record["record_id"] != selected_id:
                            raise ValueError("新记录内容已变化")
                        dataset = StructuredResearchDataset.model_validate_json((storage.resolve_artifact_dir(run_id) / "dataset.json").read_text(encoding="utf-8"))
                        if selected_id not in merge_supplemental_records(dataset, {}, [ResearchRecord.model_validate(record)], as_of):
                            raise ValueError("新记录未构成有效的补充数据")
                        item = conflict_item_after_merge(item, dataset)
                    prepared = prepare_conflict_decision(
                        run_dir, item, str(payload.get("selected_record_id") or ""), payload.get("source_id"),
                        payload.get("page"), str(payload.get("excerpt") or ""), str(payload.get("reason") or ""), as_of,
                    )
                else:
                    if not str(payload.get("reason") or "").strip():
                        raise ValueError("请填写人工核对理由")
                    prepared = prepare_financial_record(run_dir, payload, as_of)
                official = prepared["source"]["publication_date_verified"]
                summary = "原文已定位，待应用后重新质检。" if official else "原文已定位，但发布日期尚未核实；请提供可核验的公告链接。"
                record_ids = [prepared["record"]["record_id"]] if "record" in prepared else []
                action = save_candidate(state, run_dir, issue_id, request, status="ready" if official else "needs_review",
                    summary=summary, result={"prepared": prepared, "candidate_record_ids": record_ids,
                                             "candidate_records": [prepared["record"]] if record_ids else []})
            elif request.type == "accept_announcement_scope":
                from backend.app.engine.remediation_issues import build_remediation_snapshot

                validate_request(state, run_dir, issue_id, request)
                item = next(i for i in build_remediation_snapshot(state, run_dir).items if i.issue_id == issue_id)
                if item.category != "coverage" or request.payload.get("accept_limitation") is not True:
                    raise ValueError("请明确确认公告检索缺口将作为报告限制披露")
                action = save_candidate(state, run_dir, issue_id, request, status="ready",
                    summary="已选择披露公告检索限制；应用后仍需重新核验用户指定的财务数据。")
            elif request.type == "accept_chain_scope":
                from backend.app.engine.remediation_issues import build_remediation_snapshot

                validate_request(state, run_dir, issue_id, request)
                item = next(i for i in build_remediation_snapshot(state, run_dir).items if i.issue_id == issue_id)
                if item.category != "chain_relation" or request.payload.get("classification_only") is not True:
                    raise ValueError("请明确确认仅交付已核验分类并披露工序关系缺口")
                action = save_candidate(state, run_dir, issue_id, request, status="ready",
                    summary="已选择仅展示已核验环节分类；应用后重新质检，工序关系仍标记未核验。")
            elif request.type == "revise_paragraph":
                from backend.app.engine.remediation_evidence import prepare_text_revision
                from backend.app.engine.remediation_issues import build_remediation_snapshot

                validate_request(state, run_dir, issue_id, request)
                item = next(i for i in build_remediation_snapshot(state, run_dir).items if i.issue_id == issue_id)
                payload = request.payload
                target = str(payload.get("target_id") or "")
                refs = payload.get("evidence_refs")
                if item.category != "chapter_gap" or target not in item.refs:
                    raise ValueError("修订目标与所选段落缺口不一致")
                if not isinstance(refs, list) or not all(isinstance(ref, str) for ref in refs) or len(refs) > 50:
                    raise ValueError("证据引用格式无效")
                report_path = storage.resolve_artifact_dir(run_id) / "interpretation_report.json"
                report = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else {}
                available = set((report.get("evidence_index") or {}).keys())
                for candidate in load_actions(run_dir):
                    if (candidate.get("status") == "ready" and candidate.get("type") in ("attach_source", "enter_financial_record")
                            and candidate.get("request", {}).get("expected_revision") == state.revision):
                        available.update(candidate.get("candidate_record_ids") or [])
                if set(refs) - available:
                    raise ValueError("所选证据未出现在当前报告证据目录中")
                prepared = prepare_text_revision("paragraph", target, str(payload.get("text") or ""), refs,
                                                 str(payload.get("reason") or ""))
                action = save_candidate(state, run_dir, issue_id, request, status="ready",
                    summary="段落修订已保存，应用后将重新核验证据和内容。", result={"prepared": prepared})
            elif request.type == "limit_claim":
                from backend.app.engine.remediation_evidence import prepare_limitation
                from backend.app.engine.remediation_issues import build_remediation_snapshot

                validate_request(state, run_dir, issue_id, request)
                item = next(i for i in build_remediation_snapshot(state, run_dir).items if i.issue_id == issue_id)
                payload = request.payload
                target = str(payload.get("target_id") or "")
                if item.category == "chapter_gap" and target not in item.refs:
                    raise ValueError("研究边界目标与所选段落缺口不一致")
                if item.category == "coverage":
                    if target != item.context.get("boundary_target"):
                        raise ValueError("所选研究边界位置已变化")
                    path = storage.resolve_artifact_dir(run_id) / "chapter_result.json"
                    chapters = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
                    section_id = f"SEC-{target[2:4]}-{target[5:7]}"
                    if not any(section.get("section_id") == section_id for chapter in chapters.get("chapters", [])
                               for section in chapter.get("sections", [])):
                        raise ValueError("所选研究边界位置不存在")
                prepared = prepare_limitation(target, str(payload.get("template") or ""), str(payload.get("reason") or ""))
                action = save_candidate(state, run_dir, issue_id, request, status="ready",
                    summary="研究边界已保存；应用后写入正文和研究边界，资料缺口仍需复核。", result={"prepared": prepared})
            else:
                raise ValueError("该处理方式尚未接入")
            if action.status == "pending" and not already_exists:
                if request.type == "attach_source":
                    task = asyncio.create_task(execute_chain_action(
                        run_id, run_dir, action.action_id, lambda: storage.load_state(run_id), engine._run_lock(run_id)))
                else:
                    task = asyncio.create_task(execute_search_action(
                        run_id, run_dir, action.action_id, engine._fetch_supplement_with_audit,
                        lambda: storage.load_state(run_id), engine._run_lock(run_id),
                    ))
                _remediation_tasks[action.action_id] = task
                task.add_done_callback(lambda _task: _remediation_tasks.pop(action.action_id, None))
            return action
    except RemediationConflict as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/runs/{run_id}/remediation/apply")
async def apply_remediation_endpoint(run_id: str, request: ApplyRemediationRequest):
    from backend.app.engine.remediation_actions import RemediationConflict
    from backend.app.engine.remediation_apply import apply_remediation

    if storage.load_state(run_id) is None:
        raise HTTPException(status_code=404, detail="任务不存在")
    try:
        return await apply_remediation(run_id, request.expected_revision, request.action_ids,
                                       request.idempotency_key, store=storage, engine=engine)
    except RemediationConflict as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except (ValueError, OSError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


async def _auto_remediation_runner(run_id: str) -> None:
    from backend.app.engine.auto_remediation import run_auto_remediation

    try:
        log = await run_auto_remediation(run_id, store=storage, engine=engine)
        logger.info("auto remediation finished run=%s final=%s", run_id, log.get("final_status"))
    except Exception as exc:  # noqa: BLE001 - background runner must never crash the API
        logger.exception("auto remediation failed run=%s", run_id)
        from backend.app.engine.auto_remediation import _read_log, _write_log

        run_dir = storage.get_run_dir(run_id)
        log = _read_log(run_dir)
        log["fatal_error"] = f"{type(exc).__name__}: {exc}"
        _write_log(run_dir, log)


@router.post("/runs/{run_id}/remediation/auto")
async def start_auto_remediation_endpoint(run_id: str):
    """让智能体自动处置补救工作台的待办问题（后台多轮执行，直至可交付或仅剩需人工项）。"""
    state = storage.load_state(run_id)
    if state is None:
        raise HTTPException(status_code=404, detail="任务不存在")
    if state.status == "running":
        raise HTTPException(status_code=409, detail="任务正在执行，请等待当前阶段完成")
    if state.status != "waiting_review" or state.current_stage != "report_fusion":
        raise HTTPException(status_code=409, detail="请在报告融合待审核状态启动自动处理")
    key = f"auto:{run_id}"
    existing = _remediation_tasks.get(key)
    if existing is not None and not existing.done():
        return {"started": True, "already_running": True, "run_id": run_id}
    task = asyncio.create_task(_auto_remediation_runner(run_id))
    _remediation_tasks[key] = task
    task.add_done_callback(lambda _task: _remediation_tasks.pop(key, None))
    return {"started": True, "already_running": False, "run_id": run_id}


@router.get("/runs/{run_id}/remediation/auto")
async def get_auto_remediation_endpoint(run_id: str):
    if storage.load_state(run_id) is None:
        raise HTTPException(status_code=404, detail="任务不存在")
    from backend.app.engine.auto_remediation import _read_log

    task = _remediation_tasks.get(f"auto:{run_id}")
    log = _read_log(storage.get_run_dir(run_id)) or {}
    return {
        "running": bool(task is not None and not task.done()),
        "final_status": log.get("final_status"),
        "rounds": log.get("rounds", [])[log.get("round_start", 0):],
        "remaining_manual": log.get("remaining_manual", []),
        "fatal_error": log.get("fatal_error"),
    }


@router.post("/runs", response_model=WorkflowState, status_code=status.HTTP_201_CREATED)
async def create_run_endpoint(req: RunCreateRequest) -> WorkflowState:
    """创建并启动研报任务（首阶段异步推进，返回初始状态）"""
    try:
        return await engine.create_run(req)
    except ReviewConflictError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))


@router.get("/runs", response_model=RunListResponse)
async def list_runs_endpoint(
    offset: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
) -> RunListResponse:
    """分页获取历史任务列表"""
    return storage.list_runs(offset=offset, limit=limit)


@router.get("/runs/{run_id}", response_model=WorkflowState)
async def get_run_endpoint(run_id: str) -> WorkflowState:
    """获取指定任务的最新完整状态"""
    state = storage.load_state(run_id)
    if not state:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"未找到研报任务: {run_id}",
        )
    merge_evidence_sources(state, storage.get_run_dir(run_id))
    return state


@router.get("/runs/{run_id}/evidence/{record_id}/source")
async def get_evidence_source_endpoint(run_id: str, record_id: str) -> dict[str, Any]:
    """Return the verified original-document locator for one evidence record."""
    state = storage.load_state(run_id)
    if not state:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"未找到研报任务: {run_id}",
        )
    source = load_evidence_sources(storage.get_run_dir(run_id)).get(record_id)
    if not source:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"该证据尚未建立原文索引: {record_id}",
        )
    return {
        "record_id": record_id,
        "source_url": source_url_for(source),
        "source_locator": source.get("source_locator"),
        "published_at": source.get("published_at"),
        "document_sha256": source.get("document_sha256"),
        "title": source.get("title"),
        "publisher": source.get("publisher"),
        "basis": source.get("basis"),
        "verified": bool(source.get("verified", False)),
    }


@router.get("/runs/{run_id}/revisions", response_model=RevisionListResponse)
async def list_revisions_endpoint(run_id: str) -> RevisionListResponse:
    """获取指定任务的所有历史修订版本快照索引"""
    return storage.list_revisions(run_id)


@router.get("/runs/{run_id}/revisions/{revision}", response_model=WorkflowState)
async def get_revision_endpoint(run_id: str, revision: int) -> WorkflowState:
    """获取指定任务的某个历史版本快照详情"""
    state = storage.load_revision(run_id, revision)
    if not state:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"未找到版本快照: run_id={run_id}, revision={revision}",
        )
    return state


@router.post("/runs/{run_id}/revisions/{revision}/restore", response_model=WorkflowState)
async def restore_revision_endpoint(run_id: str, revision: int) -> WorkflowState:
    """从指定的历史版本快照回滚并恢复为新版本"""
    try:
        return await engine.restore_revision(run_id, revision)
    except ValueError as e:
        err_msg = str(e)
        if "未找到" in err_msg or "不存在" in err_msg:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=err_msg)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=err_msg)
    except Exception as e:
        logger.exception(f"版本回滚恢复失败: run_id={run_id}, revision={revision} - {e}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/runs/{run_id}/feedback-history")
async def get_feedback_history_endpoint(run_id: str):
    """获取指定任务的人机协同反馈与优化历史记录"""
    history_file = storage.get_run_dir(run_id) / "feedback_history.json"
    if not history_file.exists():
        return []
    try:
        return json.loads(history_file.read_text(encoding="utf-8"))
    except Exception:
        return []


@router.post("/runs/{run_id}/reviews", response_model=WorkflowState)
async def submit_review_endpoint(run_id: str, req: ReviewRequest) -> WorkflowState:
    """提交人工协同审核意见（批准通过、修改重跑、原条件重跑或风险放行）"""
    if req.run_id != run_id:
        req.run_id = run_id
    try:
        return await engine.handle_review(req)
    except (ReviewConflictError, RevisionConflictError) as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.post("/runs/{run_id}/cancel", response_model=WorkflowState)
async def cancel_run_endpoint(run_id: str) -> WorkflowState:
    """中途强行中断并取消运行中或等待审核的任务"""
    try:
        return await engine.cancel_run(run_id)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        logger.exception(f"取消任务失败: {run_id} - {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e)
        )


@router.post("/runs/{run_id}/resume", response_model=WorkflowState)
async def resume_run_endpoint(
    run_id: str,
    from_stage: StageName | None = Query(default=None, description="指定断点恢复的起始阶段（可选，默认自动检测未完成阶段）"),
) -> WorkflowState:
    """断点恢复执行：从中断/失败阶段或指定阶段一键继续推进流水线"""
    try:
        return await engine.resume_run(run_id, from_stage=from_stage)
    except ReviewConflictError as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    except Exception as e:
        logger.exception(f"恢复任务失败: {run_id} - {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e)
        )


@router.get("/runs/{run_id}/events", response_model=list[AgentTraceEvent])
async def get_run_events_endpoint(
    run_id: str, limit: int = Query(default=150, ge=1, le=500)
) -> list[AgentTraceEvent]:
    """获取指定任务的智能体微观执行动线与工具调用事件列表（在做什么、用了什么工具）"""
    return event_hub.get_events(run_id, limit=limit)


@router.get("/runs/{run_id}/events/summary")
async def get_call_summary_endpoint(run_id: str):
    """Summarize distinct logical calls and actual requests from the full event history."""
    return event_hub.get_call_summary(run_id)


@router.get("/runs/{run_id}/events/stream")
async def stream_run_events_endpoint(run_id: str):
    """基于 SSE (Server-Sent Events) 实时流式下发智能体执行动线与工具调用事件"""
    async def sse_generator():
        try:
            async for event in event_hub.subscribe(run_id):
                payload = json.dumps(event.model_dump(mode="json"), ensure_ascii=False)
                yield f"data: {payload}\n\n"
        except asyncio.CancelledError:
            pass

    return StreamingResponse(
        sse_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.delete("/runs")
async def clear_all_runs_endpoint():
    """彻底清空所有历史研报任务与本地全量产物数据"""
    deleted_count, cancelled_count = await engine.clear_all_runs()
    return {
        "status": "ok",
        "message": f"已成功彻底清空所有历史任务与后端产物数据（清理 {deleted_count} 个任务）",
        "deleted_count": deleted_count,
        "cancelled_tasks": cancelled_count,
    }


@router.delete("/runs/{run_id}")
async def delete_run_endpoint(run_id: str):
    """删除指定历史任务及其所有本地产物数据"""
    run_dir = storage.base_dir / run_id
    output_run_dir = settings.PROJECT_ROOT / "output" / "runs" / run_id
    if not run_dir.exists() and not output_run_dir.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"任务不存在: {run_id}",
        )
    await engine.delete_run(run_id)
    return {"status": "ok", "message": f"任务 {run_id} 已成功删除"}


_REPORT_FILES = {
    "report_markdown": "report.md",
    "report_html": "report.html",
    "report_pdf": "report.pdf",
}
_REPORT_FILE_IDS = {filename: key for key, filename in _REPORT_FILES.items()}


def _matches_legacy_draft(artifacts_dir: Path, ref: ArtifactRef, report_id: str | None) -> bool:
    """Recover old r1 references only when the current draft's manifest matches its bytes."""
    if ref.revision != 1 or not report_id:
        return False
    try:
        root = artifacts_dir.resolve()
        path = (root / _REPORT_FILES[ref.artifact_id]).resolve()
        manifest_path = (root / "manifest.json").resolve()
        if (not path.is_relative_to(root) or not manifest_path.is_relative_to(root) or not path.is_file()
                or path != Path(ref.uri).resolve()):
            return False
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if not isinstance(manifest, dict) or manifest.get("report_id") != report_id:
            return False
        entries = manifest.get("artifacts")
        if not isinstance(entries, list):
            return False
        with path.open("rb") as stream:
            size = os.fstat(stream.fileno()).st_size
            if size <= 0:
                return False
            digest = file_digest(stream, "sha256").hexdigest()
        return any(
            isinstance(entry, dict)
            and entry.get("uri") == str(path)
            and entry.get("kind") == ref.artifact_id.removeprefix("report_")
            and entry.get("size_bytes") == size
            and entry.get("sha256") == digest
            for entry in entries
        )
    except (OSError, ValueError, RuntimeError):
        return False


@router.get("/runs/{run_id}/report-cover")
async def report_cover_endpoint(run_id: str, revision: int | None = None):
    """Return the first PDF page as a small PNG cover for the delivery card."""
    pdf_response = await download_artifact_endpoint(run_id, "report_pdf", "formal", revision)
    if not isinstance(pdf_response, FileResponse):
        raise HTTPException(status_code=404, detail="报告封面不可用")
    pdf_path = Path(pdf_response.path)
    cover_path = pdf_path.parent / ".report_cover.png"
    if cover_path.is_file() and cover_path.stat().st_mtime >= pdf_path.stat().st_mtime:
        return FileResponse(
            path=str(cover_path),
            media_type="image/png",
            headers={"Cache-Control": "private, max-age=60"},
        )
    try:
        import pymupdf

        with pymupdf.open(str(pdf_path)) as document:
            if document.page_count < 1:
                raise HTTPException(status_code=404, detail="报告 PDF 没有可预览页面")
            page = document.load_page(0)
            pixmap = page.get_pixmap(matrix=pymupdf.Matrix(1.25, 1.25), alpha=False)
            pixmap.save(str(cover_path))
    except HTTPException:
        raise
    except Exception as exc:
        logger.warning("生成报告封面失败 run_id=%s error=%s", run_id, exc)
        raise HTTPException(status_code=500, detail="报告封面生成失败") from exc
    return FileResponse(
        path=str(cover_path),
        media_type="image/png",
        headers={"Cache-Control": "private, max-age=60"},
    )


@router.get("/runs/{run_id}/artifacts/{artifact_id}")
async def download_artifact_endpoint(run_id: str, artifact_id: str, mode: Literal["formal", "draft", "preview"] = "formal",
                                     revision: int | None = None):
    """下载研报产物文件流（Markdown / HTML / PDF / 结构化 JSON 数据）"""
    run_dir = storage.get_run_dir(run_id)
    try:
        artifacts_dir = resolve_artifact_dir(run_dir, revision)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail="该历史版本没有独立产物快照") from exc
    current_state = storage.load_state(run_id)
    state = (storage.load_revision(run_id, revision) if revision is not None else current_state)
    if revision is not None and (not state or state.revision != revision):
        raise HTTPException(status_code=404, detail="历史版本状态不存在")

    # 0. S-02：报告类产物必须先通过「当前版本资格」检查，
    #    不能只判断文件存在——编辑后旧 PDF 仍留在磁盘上供历史查阅，
    #    但不得再从固定 ID / 原文件名入口当作当前版本返回。
    report_artifact_id = _REPORT_FILE_IDS.get(artifact_id, artifact_id)
    is_report_artifact = report_artifact_id in _REPORT_FILES
    if mode == "preview" and (artifact_id != "report_html" or revision is not None):
        raise HTTPException(status_code=409, detail="终审预览仅支持当前版本的 HTML 报告")
    draft_download = False
    structured_reports = {"report_view_json", "report_view.json", "artifact_manifest", "manifest.json",
                          "consistency_report_json", "consistency_report.json"}
    if artifact_id in structured_reports:
        for report_id in _REPORT_FILES:
            try:
                await download_artifact_endpoint(run_id, report_id, mode, revision)
                draft_download = mode == "draft"
                break
            except HTTPException as exc:
                if exc.status_code not in (404, 409):
                    raise
        else:
            raise HTTPException(status_code=409, detail="当前报告尚未完成复验，不能导出报告视图或清单")
    if is_report_artifact:
        fusion = state.stage_results.get("report_fusion") if state else None
        fusion_data = fusion.data if (fusion and isinstance(fusion.data, dict)) else {}

        # R1：下载资格按「构建代次 vs 当前版本」判定，替代旧的永久
        # downstream_stale 布尔（重建后永不被消费 → 永久 409）。
        #
        # - 新 run：融合完成时登记 built_at_revision；此后任何编辑都会使
        #   state.revision 前进 → 代次不一致 → 409；重建/重导出后重新登记 → 恢复。
        # - 历史 run（无 built_at_revision）：退化为旧口径——融合获批且无
        #   未消费的 stale 标记即可下载，保持既有报告可访问。
        built_at = fusion_data.get("built_at_revision")
        status_ok = bool(fusion and fusion.status in ("approved", "completed"))
        if built_at is not None:
            try:
                generation_ok = int(built_at) == state.revision
            except (TypeError, ValueError):
                generation_ok = False
            eligible = status_ok and generation_ok and not fusion_data.get("delivery_blocked")
        else:
            stale_any = any(
                (sr.data or {}).get("downstream_stale")
                for sr in (state.stage_results.values() if state else [])
                if isinstance(sr.data, dict)
            )
            eligible = status_ok and not stale_any and not fusion_data.get("delivery_blocked")

        draft_download = mode == "draft"
        quality = fusion_data.get("quality") or {}
        substantive_policy = fusion_data.get("delivery_policy") == "substantive_errors_only_v1"
        content_ok = not fusion_data.get("hard_blocked")
        formal_ok = (fusion_data.get("agent_status") not in {"failed", "blocked"}
                     and (substantive_policy or (fusion_data.get("agent_status") != "partial"
                          and quality.get("passed") is not False)))
        chain = fusion_data.get("chain_delivery") or {}
        from backend.app.engine.scoped_delivery import scoped_chain_eligible
        if not substantive_policy and chain.get("requested") and (chain.get("status") != "complete"
                or not isinstance(chain.get("verified_relations"), int)
                or isinstance(chain.get("verified_relations"), bool)
                or chain["verified_relations"] < 1) and not scoped_chain_eligible(fusion_data):
            formal_ok = False
        eligible = eligible and not fusion_data.get("exports_stale") and content_ok and (draft_download or formal_ok)
        # A locally re-rendered editable view is safe to preview before approval.
        # Its manifest revision must match the current review; PDF remains gated.
        preview_kind = {
            "report_markdown": "report_markdown", "report.md": "report_markdown",
            "report_html": "report_html", "report.html": "report_html",
        }.get(artifact_id)
        edited_preview = bool(
            preview_kind and fusion and state
            and fusion.status == "waiting_review"
            and fusion_data.get("quality_notice")
            and not fusion_data.get("exports_stale")
            and not fusion_data.get("delivery_blocked")
            and any(a.kind == preview_kind and a.revision == state.revision for a in fusion.artifacts)
        )
        explicit_draft = bool(
            mode == "draft" and fusion and state and generation_ok
            and fusion_data.get("draft_available") and fusion_data.get("draft_sanitized")
            and not fusion_data.get("exports_stale") and not fusion_data.get("delivery_blocked")
            and any(
                a.artifact_id == report_artifact_id
                and (
                    a.revision == state.revision
                    or (state.status == "waiting_review" and fusion.status == "waiting_review"
                        and fusion.revision == state.revision
                        and _matches_legacy_draft(artifacts_dir, a, fusion_data.get("report_id")))
                )
                for a in fusion.artifacts
            )
        ) if built_at is not None else False
        eligible = eligible or explicit_draft or (edited_preview and mode == "draft")
        if mode == "preview":
            eligible = bool(
                state and state.status == "waiting_review" and state.current_stage == "report_fusion"
                and fusion and fusion.status == "waiting_review" and fusion.revision == state.revision
                and built_at is not None and generation_ok and content_ok and formal_ok
                and (substantive_policy or quality.get("passed") is True) and not fusion_data.get("delivery_blocked")
                and not fusion_data.get("exports_stale") and not fusion_data.get("quality_notice")
                and any(a.artifact_id == "report_html" and a.kind == "report_html"
                        and a.revision == state.revision for a in fusion.artifacts)
            )
        if not eligible:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="当前报告产物已失效（内容已编辑待重建，或融合未获批），请重建后再下载",
            )

    # 1. 常见固定 ID 映射
    id_map = {
        **_REPORT_FILES,
        "dataset_json": "dataset.json",
        "interpretation_report_json": "interpretation_report.json",
        "chart_result_json": "chart_result.json",
        "chapter_result_json": "chapter_result.json",
        "artifact_manifest": "manifest.json",
        "report_view_json": "report_view.json",
        "consistency_report_json": "consistency_report.json",
    }
    file_name = id_map.get(artifact_id, artifact_id)
    target_path = artifacts_dir / file_name

    # 2. 尝试精确或模糊查找
    if not target_path.exists() and revision is None:
        found = storage.get_artifact_path(run_id, artifact_id)
        if found and found.exists():
            target_path = found

    if not target_path.exists() or not target_path.is_file():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"产物文件不存在: run_id={run_id}, artifact_id={artifact_id}",
        )

    if not target_path.resolve().is_relative_to(artifacts_dir.resolve()):
        raise HTTPException(status_code=400, detail="产物文件不得位于任务目录之外")
    canonical_report = _REPORT_FILE_IDS.get(target_path.resolve().name)
    if canonical_report and not is_report_artifact:
        return await download_artifact_endpoint(run_id, canonical_report, mode, revision)
    if target_path.suffix.lower() in {".md", ".html", ".pdf"}:
        fusion = state.stage_results.get("report_fusion") if state else None
        if fusion and fusion.data.get("exports_stale"):
            raise HTTPException(status_code=409, detail="报告已修改，当前导出版本需要重新生成")

    mime_type, _ = mimetypes.guess_type(str(target_path))
    if not mime_type:
        if target_path.suffix == ".md":
            mime_type = "text/markdown"
        elif target_path.suffix == ".html":
            mime_type = "text/html"
        elif target_path.suffix == ".pdf":
            mime_type = "application/pdf"
        elif target_path.suffix == ".json":
            mime_type = "application/json"
        elif target_path.suffix == ".svg":
            mime_type = "image/svg+xml"
        else:
            mime_type = "application/octet-stream"

    if mode == "preview":
        return FileResponse(
            path=str(target_path), media_type=mime_type, filename=target_path.name,
            content_disposition_type="inline",
            headers={"X-Report-Mode": "preview", "Content-Security-Policy": "sandbox", "Cache-Control": "no-store"},
        )
    return FileResponse(
        path=str(target_path),
        media_type=mime_type,
        filename=("draft-" + target_path.name) if draft_download else target_path.name,
        headers={"X-Report-Mode": "draft" if draft_download else "formal", "X-Report-Release-Mode": "draft_with_warnings" if draft_download else "formal"},
    )


# ── 紧凑交付包（2026-11-16）：一次拿到正式交付所需的全部文件 ────────────────

# evidence.csv 列 = report_view.json evidence_catalog（EvidenceSource）全字段不裁剪：
# 紧凑包定位「可审计交付」——引用编号核对、证据主键交叉定位、口径五件套、
# 溯源四件套（链接/文内定位/披露日/哈希）、取数层回链，没有纯装饰列。
_EVIDENCE_CSV_COLUMNS = (
    "number", "record_id", "label", "domain", "metric", "entity", "value",
    "unit", "period", "period_type", "source_url", "source_locator",
    "published_at", "document_sha256", "input_source_numbers",
)
_COMPACT_ZIP_MEMBERS = ("report_markdown", "report_html", "report_pdf")


def _csv_cell(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _build_evidence_csv(catalog: list[dict[str, Any]]) -> bytes:
    """把 evidence_catalog 序列化为 UTF-8 BOM 的 CSV（Excel 双击直接打开不乱码）。"""
    buf = io.StringIO(newline="")
    writer = csv.writer(buf)
    writer.writerow(_EVIDENCE_CSV_COLUMNS)
    for entry in catalog:
        if not isinstance(entry, dict):
            continue
        row = []
        for col in _EVIDENCE_CSV_COLUMNS:
            value = entry.get(col)
            if col == "input_source_numbers" and isinstance(value, list):
                value = ";".join(str(item) for item in value)
            row.append(_csv_cell(value))
        writer.writerow(row)
    return b"\xef\xbb\xbf" + buf.getvalue().encode("utf-8")


@router.get("/runs/{run_id}/exports/compact")
async def download_compact_export_endpoint(run_id: str, revision: int | None = None):
    """打包当前（或指定历史版本的）正式交付：报告三格式 + manifest + report_view + evidence.csv。

    资格门沿用 artifact 端点的同一套校验——对快照里实际存在的那份报告文件按
    formal 模式自调用（与 :593-603 结构化报告过门同一模式），409/404 原样冒泡；
    门禁改动自动同步，不在打包层另立一套。draft 不在此列：打包属正式交付语义，
    受限草稿场景前端按钮直接禁用（走逐份 draft 下载）。
    """
    run_dir = storage.get_run_dir(run_id)
    try:
        artifacts_dir = resolve_artifact_dir(run_dir, revision)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail="该历史版本没有独立产物快照") from exc
    state = (storage.load_revision(run_id, revision) if revision is not None
             else storage.load_state(run_id))
    if revision is not None and (not state or state.revision != revision):
        raise HTTPException(status_code=404, detail="历史版本状态不存在")

    available = [aid for aid in _COMPACT_ZIP_MEMBERS
                 if (artifacts_dir / _REPORT_FILES[aid]).is_file()]
    if not available:
        raise HTTPException(
            status_code=404,
            detail=f"报告产物尚未生成: run_id={run_id}" + (f" revision={revision}" if revision is not None else ""),
        )

    # 资格门：三个报告文件的 formal 判定一致，过一次即可。
    await download_artifact_endpoint(run_id, available[0], "formal", revision)

    members: list[tuple[str, bytes]] = []
    for aid in available:
        path = artifacts_dir / _REPORT_FILES[aid]
        members.append((_REPORT_FILES[aid], path.read_bytes()))
    # report_view.json（883KB 级，占包体近三成）不进包：用户/前端都不读它，
    # 审计消费形态是 evidence.csv；manifest.json 仍在包内可对账。
    for name in ("manifest.json",):
        path = artifacts_dir / name
        if path.is_file():
            members.append((name, path.read_bytes()))
    catalog: list[dict[str, Any]] = []
    view_path = artifacts_dir / "report_view.json"
    if view_path.is_file():
        try:
            raw_catalog = json.loads(view_path.read_text(encoding="utf-8")).get("evidence_catalog")
            if isinstance(raw_catalog, list):
                catalog = raw_catalog
        except (OSError, json.JSONDecodeError, AttributeError):
            catalog = []
    members.append(("evidence.csv", _build_evidence_csv(catalog)))

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for name, data in members:
            zf.writestr(name, data)
    revision_label = f"-r{revision}" if revision is not None else ""
    return Response(
        content=buf.getvalue(),
        media_type="application/zip",
        headers={
            "Content-Disposition": f'attachment; filename="report-compact-{run_id}{revision_label}.zip"',
            "X-Report-Mode": "formal",
        },
    )


# ── 问财 SkillHub 技能生态库端点 ──────────────────────────────────────────
from backend.app.core.skills_hub import skills_hub
from backend.app.schemas.workflow import SkillCatalogResponse, SkillItem


@router.get("/skills", response_model=SkillCatalogResponse)
async def list_skills_catalog(refresh: bool = False) -> SkillCatalogResponse:
    """获取同花顺问财与五智能体协同技能全景目录"""
    return skills_hub.get_catalog(force_reload=refresh)


@router.get("/skills/{stage_id}/{skill_id}", response_model=SkillItem)
async def get_skill_detail_endpoint(stage_id: str, skill_id: str) -> SkillItem:
    """获取指定智能体阶段下单个技能的完整文档与参数定义"""
    item = skills_hub.get_skill_detail(stage_id=stage_id, skill_id=skill_id)
    if not item:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"未找到指定的智能体技能: {stage_id}/{skill_id}",
        )
    return item


# ── 系统与模型 Key 设置端点 ──────────────────────────────────────────
from pydantic import BaseModel
import httpx
import time
from backend.app.core.config import settings


class SettingsConfigRequest(BaseModel):
    llm_api_key: str | None = None
    llm_base_url: str | None = None
    llm_model: str | None = None
    iwencai_api_key: str | None = None


class TestLlmRequest(BaseModel):
    llm_api_key: str | None = None
    llm_base_url: str | None = None
    llm_model: str | None = None


class TestIwencaiRequest(BaseModel):
    iwencai_api_key: str | None = None


@router.get("/settings/config")
async def get_settings_config():
    """获取当前大模型与问财 Key 配置"""
    return {
        "llm_api_key": settings.LLM_API_KEY,
        "llm_base_url": settings.LLM_BASE_URL,
        "llm_model": settings.LLM_MODEL,
        "iwencai_api_key": settings.IWENCAI_API_KEY,
        "has_custom_settings": settings.user_settings_file.exists(),
    }


@router.post("/settings/config")
async def update_settings_config(req: SettingsConfigRequest):
    """更新并持久化配置，热更新环境变量"""
    update_data = {}
    if req.llm_api_key is not None:
        update_data["LLM_API_KEY"] = req.llm_api_key.strip()
    if req.llm_base_url is not None:
        update_data["LLM_BASE_URL"] = req.llm_base_url.strip().rstrip("/")
    if req.llm_model is not None:
        update_data["LLM_MODEL"] = req.llm_model.strip()
    if req.iwencai_api_key is not None:
        update_data["IWENCAI_API_KEY"] = req.iwencai_api_key.strip()

    settings.save_user_settings(update_data)
    logger.info("用户成功更新系统模型与接口配置")
    return {
        "status": "ok",
        "message": "配置保存成功并已实时生效",
        "data": {
            "llm_api_key": settings.LLM_API_KEY,
            "llm_base_url": settings.LLM_BASE_URL,
            "llm_model": settings.LLM_MODEL,
            "iwencai_api_key": settings.IWENCAI_API_KEY,
            "has_custom_settings": settings.user_settings_file.exists(),
        },
    }


@router.post("/settings/reset")
async def reset_settings_config():
    """恢复系统预置默认配置"""
    if settings.user_settings_file.exists():
        try:
            settings.user_settings_file.unlink()
        except Exception:
            pass

    settings.LLM_API_KEY = os.getenv("DEFAULT_LLM_API_KEY", "")
    settings.LLM_BASE_URL = "https://ark.cn-beijing.volces.com/api/plan/v3"
    settings.LLM_MODEL = "deepseek-v4-flash"
    settings.IWENCAI_API_KEY = os.getenv("DEFAULT_IWENCAI_API_KEY", "")
    settings.apply_to_env()
    return {
        "status": "ok",
        "message": "已恢复系统预置默认配置",
        "data": {
            "llm_api_key": settings.LLM_API_KEY,
            "llm_base_url": settings.LLM_BASE_URL,
            "llm_model": settings.LLM_MODEL,
            "iwencai_api_key": settings.IWENCAI_API_KEY,
            "has_custom_settings": False,
        },
    }


@router.post("/settings/test-llm")
async def test_llm_connectivity(req: TestLlmRequest):
    """测试大模型基座接口连通性"""
    api_key = (req.llm_api_key or settings.LLM_API_KEY).strip()
    base_url = (req.llm_base_url or settings.LLM_BASE_URL).strip().rstrip("/")
    model = (req.llm_model or settings.LLM_MODEL).strip()

    if not api_key:
        return {"success": False, "message": "API Key 不能为空"}
    if not base_url:
        return {"success": False, "message": "Base URL 不能为空"}

    endpoint = f"{base_url}/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": "ping"}],
        "max_tokens": 5,
    }

    start_t = time.time()
    try:
        async with httpx.AsyncClient(timeout=12.0) as client:
            resp = await client.post(endpoint, headers=headers, json=payload)
            elapsed_ms = int((time.time() - start_t) * 1000)
            if resp.status_code == 200:
                return {
                    "success": True,
                    "message": f"连接成功！模型响应正常（耗时 {elapsed_ms}ms）",
                    "latency_ms": elapsed_ms,
                    "model": model,
                }
            else:
                return {
                    "success": False,
                    "message": f"接口返回异常 (HTTP {resp.status_code}): {resp.text[:200]}",
                    "latency_ms": elapsed_ms,
                }
    except Exception as e:
        elapsed_ms = int((time.time() - start_t) * 1000)
        return {
            "success": False,
            "message": f"连通测试失败: {str(e)}",
            "latency_ms": elapsed_ms,
        }


@router.post("/settings/test-iwencai")
async def test_iwencai_connectivity(req: TestIwencaiRequest):
    """测试问财金融数据接口连通性（支持单 Key 或多 Key 逗号分隔配置）"""
    raw_api_key = (req.iwencai_api_key or settings.IWENCAI_API_KEY).strip()
    if not raw_api_key:
        return {"success": False, "message": "问财 API Key 不能为空"}

    # 支持逗号、分号、换行分隔的多 Key 配置，提取所有有效 Key
    keys = [k.strip() for k in re.split(r"[,;\n]+", raw_api_key) if k.strip()]
    if not keys:
        return {"success": False, "message": "问财 API Key 不能为空"}

    api_key = keys[0]
    start_t = time.time()
    try:
        url = "https://openapi.iwencai.com/v1/query2data"
        import secrets
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "X-Claw-Call-Type": "normal",
            "X-Claw-Skill-Id": "hithink-astock-selector",
            "X-Claw-Skill-Version": "1.0.0",
            "X-Claw-Plugin-Id": "none",
            "X-Claw-Plugin-Version": "none",
            "X-Claw-Trace-Id": secrets.token_hex(32),
        }
        payload = {
            "query": "平安银行",
            "page": "1",
            "limit": "1",
        }
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.post(url, headers=headers, json=payload)
            elapsed_ms = int((time.time() - start_t) * 1000)
            key_count_hint = f"（已识别 {len(keys)} 个 Key，首个 Key 耗时 {elapsed_ms}ms）" if len(keys) > 1 else f"（耗时 {elapsed_ms}ms）"
            if resp.status_code == 200:
                return {
                    "success": True,
                    "message": f"问财官方 SkillHub 接口验证通过！{key_count_hint}",
                    "latency_ms": elapsed_ms,
                }
            elif resp.status_code in (401, 403):
                return {
                    "success": False,
                    "message": f"问财 Token 鉴权失败 (HTTP {resp.status_code})，请检查 Key 是否有效",
                    "latency_ms": elapsed_ms,
                }
            else:
                return {
                    "success": True,
                    "message": f"问财接口鉴权通过（响应码 {resp.status_code}，{key_count_hint}）",
                    "latency_ms": elapsed_ms,
                }
    except Exception as e:
        elapsed_ms = int((time.time() - start_t) * 1000)
        return {
            "success": False,
            "message": f"网络连通异常: {str(e)}",
            "latency_ms": elapsed_ms,
        }

