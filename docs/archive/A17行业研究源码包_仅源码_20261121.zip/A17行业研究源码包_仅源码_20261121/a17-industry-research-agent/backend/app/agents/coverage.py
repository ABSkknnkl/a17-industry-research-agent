"""A2 维度覆盖：只按实际证据与需求验收结果计算，不做乐观默认。"""

from __future__ import annotations

from typing import Any


_DIMENSION_SPECS = (
    ("industry", "行业概览", ("industry",), ("reports", "news")),
    ("finance", "财务分析", ("financials",), ()),
    ("competition", "竞争格局", ("companies",), ()),
    ("industry_chain", "产业链结构", ("industry_chain",), ()),
    ("macro_policy", "宏观与政策", ("macro",), ("events", "news", "reports")),
    ("risk", "风险评估", (), ()),
)

_REQUIREMENT_WORDS = (
    ("finance", ("financial", "finance", "revenue", "profit", "margin", "roe", "debt", "cash", "rd_", "财务", "营收", "利润", "毛利", "研发", "偿债", "现金流")),
    ("competition", ("competition", "competitor", "peer", "market_share", "compan", "竞争", "份额", "可比", "龙头")),
    ("industry_chain", ("industry_chain", "chain", "产业链", "供应链", "上游", "下游")),
    ("macro_policy", ("macro", "policy", "event", "news", "宏观", "政策", "事件", "新闻", "公告")),
    ("risk", ("risk", "sensitivity", "风险", "敏感性", "压力测试")),
    ("industry", ("industry_overview", "market_size", "行业概览", "市场规模", "行业规模")),
)


def _get(value: Any, name: str, default: Any = None) -> Any:
    if isinstance(value, dict):
        return value.get(name, default)
    return getattr(value, name, default)


def _list(value: Any) -> list[Any]:
    return list(value) if isinstance(value, (list, tuple)) else []


def _records(dataset: Any, domain: str) -> list[Any]:
    return _list(_get(dataset, domain, []))


def _native_status(report: Any) -> str:
    status = _get(report, "status", "completed")
    return status if status in {"completed", "partial", "failed"} else "completed"


def _flatten_requirement(row: dict[str, Any]) -> dict[str, Any]:
    requirement = row.get("requirement") or {}
    coverage = row.get("coverage") or {}
    return {**row, **requirement, **coverage}


def _requirement_dimensions(row: dict[str, Any], source: str) -> set[str]:
    if source == "requested_financial_coverage":
        return {"finance"}
    explicit = " ".join(
        str(row.get(key) or "") for key in ("dimension", "domain", "requirement_domain")
    ).lower()
    text = " ".join(
        [explicit, str(row.get("requirement_id") or ""), str(row.get("label") or "")]
        + [str(item) for item in _list(row.get("metric_families"))]
    ).lower()
    if explicit in {name for name, *_ in _DIMENSION_SPECS}:
        return {explicit}
    if explicit in {"financials", "finance"}:
        return {"finance"}
    dimensions = {
        dimension
        for dimension, words in _REQUIREMENT_WORDS
        if any(word in text for word in words)
    }
    return dimensions


def _requirement_rows(report: Any) -> list[tuple[str, dict[str, Any]]]:
    appendix = _get(report, "data_quality_appendix", {}) or {}
    if not isinstance(appendix, dict):
        return []
    rows: list[tuple[str, dict[str, Any]]] = []
    for source in (
        "requested_requirement_coverage",
        "requested_financial_coverage",
        "requirement_evidence_matrix",
    ):
        for raw in _list(appendix.get(source)):
            if isinstance(raw, dict):
                rows.append((source, _flatten_requirement(raw)))
    return rows


def _failed_requirements(report: Any, dimension: str) -> list[dict[str, Any]]:
    failed = []
    for source, row in _requirement_rows(report):
        if dimension not in _requirement_dimensions(row, source):
            continue
        passed = row.get("passed")
        status = str(row.get("status") or row.get("coverage_status") or "").lower()
        if passed is False or status in {"missing", "partial", "failed", "uncovered", "not_covered"}:
            failed.append(row)
    return failed


def _requirement_reason(failed: list[dict[str, Any]]) -> str:
    fragments = []
    for row in failed[:3]:
        detail = row.get("missing") or row.get("reason") or row.get("label") or row.get("requirement_id")
        if isinstance(detail, list):
            detail = "、".join(str(item) for item in detail[:3])
        if detail:
            fragments.append(str(detail))
    return "；".join(fragments) or "适用的需求覆盖验收未通过"


def _risk_assessment(report: Any) -> tuple[int, str | None]:
    anomalies = _list(_get(report, "anomalies", []))
    validations = _list(_get(report, "cross_validations", []))
    count = len(anomalies) + len(validations)
    appendix = _get(report, "data_quality_appendix", {}) or {}
    analysis_facts = _get(report, "analysis_facts", {}) or {}
    explicit = None
    if isinstance(appendix, dict):
        explicit = appendix.get("risk_assessment")
    if explicit is None and isinstance(analysis_facts, dict):
        explicit = analysis_facts.get("risk_assessment")
    explicit_status = str(_get(explicit, "status", "") or "") or None
    if isinstance(explicit, dict) and explicit_status:
        count = max(count, 1)
    return count, explicit_status


def build_dimension_coverage(
    dataset: Any,
    report: Any,
    chain_context: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Build reviewable coverage without treating structure completion as success.

    ``covered`` requires direct dimension evidence, no failed applicable requirement,
    and a completed native report. Supporting-only evidence is always ``partial``.
    Risk coverage additionally requires an actual anomaly/cross-validation result or
    an explicit risk-assessment record; an empty anomaly list alone proves nothing.
    """

    native_status = _native_status(report)
    chain_facts = _list((chain_context or {}).get("facts"))
    chain_release = str((chain_context or {}).get("quality", {}).get("release_status") or "")
    rows: list[dict[str, Any]] = []

    for dimension, label, primary_domains, supporting_domains in _DIMENSION_SPECS:
        if dimension == "risk":
            primary_count, risk_status = _risk_assessment(report)
            supporting_count = 0
            record_ids: list[str] = []
        else:
            primary_records = [
                record for domain in primary_domains for record in _records(dataset, domain)
            ]
            supporting_records = [
                record for domain in supporting_domains for record in _records(dataset, domain)
            ]
            primary_count = len(primary_records)
            supporting_count = len(supporting_records)
            record_ids = [
                str(_get(record, "record_id"))
                for record in [*primary_records, *supporting_records]
                if _get(record, "record_id")
            ][:50]
            if dimension == "industry_chain" and chain_facts:
                primary_count += len(chain_facts)
            if dimension == "competition" and not primary_count:
                comps = _get(report, "comps_matrix")
                primary_count = len(_list(_get(comps, "entries", [])))

        failed_requirements = _failed_requirements(report, dimension)
        evidence_count = primary_count + supporting_count
        requirement_status = "failed" if failed_requirements else ("not_applicable" if not _requirement_rows(report) else "passed")
        status = "missing"
        reason = "缺少该维度的可用证据"

        if native_status == "failed":
            reason = "数据解读原生状态为 failed，不能据此宣称覆盖"
        elif dimension == "risk" and not evidence_count:
            reason = "未提供可验证的风险评估结果；无异常不等于已完成风险评估"
        elif primary_count:
            if failed_requirements:
                status = "partial"
                reason = f"已有证据，但需求覆盖未完整：{_requirement_reason(failed_requirements)}"
            elif native_status == "partial":
                status = "partial"
                reason = "存在该维度证据，但数据解读原生状态为 partial"
            elif dimension == "industry_chain" and chain_facts and chain_release and chain_release != "verified":
                status = "partial"
                reason = f"产业链证据发布状态为 {chain_release or 'unknown'}，完整性尚未认证"
            elif dimension == "risk" and risk_status == "partial":
                status = "partial"
                reason = "风险评估已执行，但结论仍存在部分缺口"
            else:
                status = "covered"
                reason = f"由 {primary_count} 项实际证据及适用需求覆盖结果支持"
        elif supporting_count:
            status = "partial"
            reason = "仅有定性或间接证据，不能宣称该维度完整覆盖"
            if failed_requirements:
                reason += f"；{_requirement_reason(failed_requirements)}"
        elif failed_requirements:
            reason = f"缺少证据且需求未覆盖：{_requirement_reason(failed_requirements)}"

        rows.append(
            {
                "dimension": dimension,
                "label": label,
                "status": status,
                "reason": reason,
                "evidence_count": evidence_count,
                "record_ids": record_ids,
                "requirement_status": requirement_status,
            }
        )
    return rows
