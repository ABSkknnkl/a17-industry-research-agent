from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field
from backend.app.schemas.workflow import StageName, WorkflowState


class RemediationItem(BaseModel):
    issue_id: str
    fingerprint: str
    category: Literal["source_conflict", "chain_relation", "chapter_gap", "coverage", "other"]
    severity: Literal["blocking", "warning", "unknown"] = "unknown"
    status: Literal["open", "submitted", "rechecking", "resolved", "needs_review"] = "open"
    title: str
    detail: str
    refs: list[str] = Field(default_factory=list)
    actions: list[str] = Field(default_factory=list)
    context: dict[str, Any] = Field(default_factory=dict)


class CandidateAction(BaseModel):
    action_id: str
    issue_id: str
    type: str
    status: Literal["pending", "ready", "needs_review", "failed", "no_new_data"]
    expected_fingerprint: str
    candidate_record_ids: list[str] = Field(default_factory=list)
    candidate_records: list[dict[str, Any]] = Field(default_factory=list)
    result_summary: str = ""
    error: str | None = None


class RemediationSnapshot(BaseModel):
    run_id: str
    revision: int
    items: list[RemediationItem] = Field(default_factory=list)
    candidate_actions: list[CandidateAction] = Field(default_factory=list)


class SourceCandidate(BaseModel):
    source_id: str
    kind: Literal["upload_pdf", "official_url", "reference_only"]
    title: str
    declared_publisher: str = ""
    publisher_verified: bool = False
    official_origin_verified: bool = False
    source_url: str | None = None
    published_at: str | None = None
    sha256: str | None = None
    page_count: int | None = None
    parse_status: Literal["ready", "unreadable", "reference_only"]


class ActionRequest(BaseModel):
    expected_revision: int
    expected_fingerprint: str
    idempotency_key: str = Field(min_length=1, max_length=128)
    type: Literal["supplement_search", "attach_source", "enter_financial_record", "resolve_conflict", "revise_paragraph", "limit_claim", "accept_chain_scope", "accept_announcement_scope"]
    payload: dict[str, Any] = Field(default_factory=dict)


class ApplyRemediationRequest(BaseModel):
    expected_revision: int
    idempotency_key: str = Field(min_length=1, max_length=128)
    action_ids: list[str] = Field(min_length=1)


class RemediationApplyResult(BaseModel):
    state: WorkflowState
    affected_stages: list[StageName]
