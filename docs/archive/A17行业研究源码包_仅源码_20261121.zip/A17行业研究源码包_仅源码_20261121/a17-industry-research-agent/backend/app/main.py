from __future__ import annotations
import logging
import os
from contextlib import asynccontextmanager
from datetime import datetime
from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

import backend.app.core.setup_env  # 自动注册五智能体路径
from backend.app.api.routes import router as api_router
from backend.app.core.config import settings
from backend.app.schemas.workflow import StageResult

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("fastapi_app")


import asyncio

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("行业研究五智能体协同服务启动中...")
    logger.info(f"  模型基座: {settings.LLM_MODEL} @ {settings.LLM_BASE_URL}")
    logger.info(f"  问财SkillHub配置完成，数据存储路径: {settings.DATA_DIR}")

    # 根治服务重启或异常退出导致的任务假死与孤立运行状态。
    # 列表接口是分页契约，启动恢复必须遍历所有页，不能只看最近 200 条。
    try:
        from backend.app.core.storage import StorageManager
        from backend.app.engine.state_machine import engine
        storage = StorageManager()
        auto_resume = os.getenv('AUTO_RESUME_INTERRUPTED_RUNS', '').strip().lower() in {'1', 'true', 'yes', 'on'}
        page_size = 200
        offset = 0
        seen_run_ids: set[str] = set()
        while True:
            runs_resp = storage.list_runs(offset=offset, limit=page_size)
            items = list(runs_resp.items)
            for r in items:
                if r.status != "running" or r.run_id in seen_run_ids:
                    continue
                seen_run_ids.add(r.run_id)
                try:
                    if auto_resume:
                        logger.warning(f"检测到中断任务 {r.run_id}，按显式配置自动续跑。")
                        asyncio.create_task(engine.resume_run(r.run_id))
                    else:
                        state = storage.load_state(r.run_id)
                        if state is None or state.status != "running":
                            continue
                        stage = state.current_stage or "data_fetch"
                        result = state.stage_results.get(stage)
                        if result is None:
                            result = StageResult(stage=stage, revision=state.revision)
                            state.stage_results[stage] = result
                        state.status = "failed"
                        result.status = "failed"
                        result.error = "服务重启前任务已中断，可从当前阶段重试。"
                        state.updated_at = datetime.now().isoformat()
                        storage.save_state(state)
                        logger.warning(f"检测到中断任务 {r.run_id} (阶段: {stage})；未自动续跑，请手动恢复。")
                except Exception as exc:
                    logger.warning(
                        "任务 %s 自愈处理失败（%s），继续检查其他任务",
                        r.run_id, type(exc).__name__,
                    )
            offset += len(items)
            total = getattr(runs_resp, "total", None)
            if not items or len(items) < page_size or (total is not None and offset >= total):
                break
    except Exception as e:
        logger.warning(f"自愈检测异常 (非致命): {e}")

    yield
    logger.info("行业研究五智能体协同服务已安全停止")


app = FastAPI(
    title="同花顺问财SkillHub五智能体行业研报系统",
    description="面向证券投资研究领域的多智能体流水线协同与全程人机协同研报生成后端",
    version="1.0.0",
    lifespan=lifespan,
)

# 允许跨域
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 挂载业务端点
app.include_router(api_router)


@app.get("/health")
@app.get("/health/ready")
async def health_check():
    return {
        "status": "ok",
        "service": "industry-research-multi-agent-backend",
        "llm_model": settings.LLM_MODEL,
        "agents_ready": True,
    }


@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.exception(f"全局未捕获异常: {request.url} - {exc}")
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": f"服务器内部错误: {str(exc)}"},
    )
