#!/usr/bin/env bash
# ==============================================================================
# 行业研究五智能体系统 — 一键启动 / 停止脚本
#
# 用法：
#   ./start.sh                 启动后端 + 前端，打开浏览器，Ctrl+C 停止
#   ./start.sh --no-open       启动但不要自动打开浏览器
#   ./start.sh --stop          停止本项目启动的服务（含异常残留）
#   ./start.sh --help          查看帮助
# ==============================================================================

set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${ROOT_DIR}"

RUN_DIR="${ROOT_DIR}/.run"
LOG_DIR="${RUN_DIR}/logs"
BACKEND_PID_FILE="${RUN_DIR}/backend.pid"
FRONTEND_PID_FILE="${RUN_DIR}/frontend.pid"
BACKEND_LOG="${LOG_DIR}/backend.log"
FRONTEND_LOG="${LOG_DIR}/frontend.log"

BACKEND_PORT_DEFAULT=8000
FRONTEND_PORT="${FRONTEND_PORT:-5173}"
OPEN_BROWSER=1
ACTION="start"

usage() {
  sed -n '2,10p' "${BASH_SOURCE[0]}" | sed 's/^# //; s/^#//'
}

for arg in "$@"; do
  case "${arg}" in
    --stop) ACTION="stop" ;;
    --no-open) OPEN_BROWSER=0 ;;
    --help|-h) usage; exit 0 ;;
    *) echo "未知参数：${arg}"; usage; exit 2 ;;
  esac
done

mkdir -p "${LOG_DIR}"

# ------------------------------------------------------------------------------
# 基础环境
# ------------------------------------------------------------------------------
if [ "${ACTION}" = "start" ]; then
  if [ ! -f "${ROOT_DIR}/.env" ]; then
    if [ -f "${ROOT_DIR}/.env.example" ]; then
      cp "${ROOT_DIR}/.env.example" "${ROOT_DIR}/.env"
      echo "[初始化] 已从 .env.example 创建 .env。"
      echo "         首次使用请在 .env 中填写 LLM_API_KEY 和 IWENCAI_API_KEY；"
      echo "         本次仍会继续启动前端界面。"
    else
      echo "[错误] 未找到 .env，也没有 .env.example 可初始化。"
      exit 1
    fi
  fi
fi

# 端口优先取环境变量，其次 .env，最后用默认值；--stop 不需要加载 Python 依赖。
BACKEND_PORT="${PORT:-}"
if [ -z "${BACKEND_PORT}" ] && [ -f "${ROOT_DIR}/.env" ]; then
  BACKEND_PORT="$(grep -E '^[[:space:]]*PORT[[:space:]]*=' "${ROOT_DIR}/.env" | tail -1 | cut -d= -f2 | tr -d '[:space:]"' || true)"
fi
BACKEND_PORT="${BACKEND_PORT:-${BACKEND_PORT_DEFAULT}}"
case "${BACKEND_PORT}" in
  ''|*[!0-9]*) BACKEND_PORT="${BACKEND_PORT_DEFAULT}" ;;
esac

if [ "${ACTION}" = "start" ]; then
  PYTHON_BIN=""
  VENV_PY="${ROOT_DIR}/.venv/bin/python"
  if [ ! -x "${VENV_PY}" ]; then
    PYTHON_BOOTSTRAP=""
    for cmd in python3.11 python3 python; do
      if command -v "${cmd}" >/dev/null 2>&1; then
        PYTHON_BOOTSTRAP="${cmd}"
        break
      fi
    done
    if [ -z "${PYTHON_BOOTSTRAP}" ]; then
      echo "[错误] 未找到 Python 3。请先安装 Python 3.11+ 后重试。"
      exit 1
    fi
    echo "[初始化] 创建 Python 虚拟环境 .venv（使用 ${PYTHON_BOOTSTRAP}）..."
    "${PYTHON_BOOTSTRAP}" -m venv "${ROOT_DIR}/.venv"
  fi

  if ! "${VENV_PY}" -c 'import fastapi, pydantic, uvicorn' >/dev/null 2>&1; then
    echo "[依赖] 正在安装后端依赖（首次启动可能需要几分钟）..."
    "${VENV_PY}" -m pip install --upgrade pip
    "${VENV_PY}" -m pip install -r "${ROOT_DIR}/requirements.txt"
  fi
  PYTHON_BIN="${VENV_PY}"

  # 报告 PDF 由 Playwright 排版；优先用自带 Chromium，缺失时回退系统 Chrome。
  if [ "${SKIP_PLAYWRIGHT_INSTALL:-0}" != "1" ] && [ -x "${ROOT_DIR}/.venv/bin/playwright" ]; then
    "${ROOT_DIR}/.venv/bin/playwright" install chromium >/dev/null 2>&1 || \
      echo "[提示] Playwright Chromium 未就绪；PDF 导出将尝试使用系统 Chrome。"
  fi

  cd "${ROOT_DIR}"
  export PYTHONPATH="${ROOT_DIR}${PYTHONPATH:+:${PYTHONPATH}}"
  for agent_dir in "${ROOT_DIR}"/agents_core/*; do
    [ -d "${agent_dir}" ] && export PYTHONPATH="${agent_dir}:${PYTHONPATH}"
  done
  export PYTHONUNBUFFERED=1
fi

# ------------------------------------------------------------------------------
# 停止 / 清理
# ------------------------------------------------------------------------------
command_matches_project() {
  local pid="$1" cmd cwd
  cmd="$(ps -p "${pid}" -o command= 2>/dev/null || true)"
  case "${cmd}" in
    *"${ROOT_DIR}/backend/run_server.py"*|*"${ROOT_DIR}/frontend/node_modules/.bin/vite"*|*"${ROOT_DIR}/frontend/node_modules/vite/bin/vite.js"*) return 0 ;;
  esac
  # 兼容相对路径启动的进程：用进程 cwd 判断是否属于本项目。
  cwd="$(lsof -a -p "${pid}" -d cwd -Fn 2>/dev/null | sed -n 's/^n//p' | head -1 || true)"
  [ -n "${cwd}" ] || return 1
  case "${cmd}" in
    *"backend/run_server.py"*)
      [ "${cwd}" = "${ROOT_DIR}" ] && return 0
      ;;
    *"frontend/node_modules/.bin/vite"*|*"frontend/node_modules/vite/bin/vite.js"*)
      [ "${cwd}" = "${ROOT_DIR}/frontend" ] && return 0
      ;;
  esac
  return 1
}

terminate_pid() {
  local pid="$1"
  if ! kill -0 "${pid}" 2>/dev/null; then
    return 0
  fi
  pkill -TERM -P "${pid}" 2>/dev/null || true
  kill -TERM "${pid}" 2>/dev/null || true
  for _ in $(seq 1 20); do
    kill -0 "${pid}" 2>/dev/null || return 0
    sleep 0.25
  done
  pkill -KILL -P "${pid}" 2>/dev/null || true
  kill -KILL "${pid}" 2>/dev/null || true
}

stop_from_pid_file() {
  local name="$1" pid_file="$2"
  if [ ! -f "${pid_file}" ]; then
    return 0
  fi
  local pid
  pid="$(tr -d '[:space:]' < "${pid_file}")"
  if [ -n "${pid}" ] && command_matches_project "${pid}"; then
    echo "  --> 停止 ${name} (pid=${pid})"
    terminate_pid "${pid}"
  else
    echo "  --> 忽略 ${name} 的失效 pid 文件（${pid:-空}）"
  fi
  rm -f "${pid_file}"
}

stop_port_leftover() {
  local port="$1"
  local pids
  pids="$(lsof -nP -iTCP:"${port}" -sTCP:LISTEN -t 2>/dev/null || true)"
  [ -z "${pids}" ] && return 0
  for pid in ${pids}; do
    if command_matches_project "${pid}"; then
      echo "  --> 停止端口 ${port} 上的残留进程 (pid=${pid})"
      terminate_pid "${pid}"
    else
      echo "  --> 端口 ${port} 被其他程序占用，未自动处理："
      ps -p "${pid}" -o pid=,command= 2>/dev/null || true
      return 1
    fi
  done
}

stop_services() {
  echo "[停止] 正在停止前后端服务..."
  stop_from_pid_file "后端" "${BACKEND_PID_FILE}"
  stop_from_pid_file "前端" "${FRONTEND_PID_FILE}"
  # PID 文件可能被手动删除或上次强退；再按端口做一次项目进程兜底检查。
  stop_port_leftover "${BACKEND_PORT}" || true
  stop_port_leftover "${FRONTEND_PORT}" || true
  echo "[完成] 已停止本项目服务。"
}

if [ "${ACTION}" = "stop" ]; then
  stop_services
  exit 0
fi

# ------------------------------------------------------------------------------
# 启动前检查
# ------------------------------------------------------------------------------
port_owner() {
  lsof -nP -iTCP:"$1" -sTCP:LISTEN 2>/dev/null || true
}

for port in "${BACKEND_PORT}" "${FRONTEND_PORT}"; do
  owner="$(port_owner "${port}")"
  if [ -n "${owner}" ]; then
    echo "[错误] 端口 ${port} 已被占用："
    echo "${owner}"
    echo "       如果这是上次异常的残留进程，请执行：./start.sh --stop"
    exit 1
  fi
done

if ! command -v curl >/dev/null 2>&1; then
  echo "[错误] 未找到 curl，无法执行健康检查。请先安装 curl。"
  exit 1
fi
if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "[错误] 未找到 node/npm。请安装 Node.js 22+ 后重试。"
  exit 1
fi

if [ ! -x "${ROOT_DIR}/frontend/node_modules/.bin/vite" ]; then
  echo "[依赖] 前端依赖未就绪，正在执行 npm install ..."
  (cd "${ROOT_DIR}/frontend" && npm install)
fi

if grep -qE '^LLM_API_KEY=your_' "${ROOT_DIR}/.env" 2>/dev/null; then
  echo "[提示] .env 仍是模板占位：请填写 LLM_API_KEY 后新建的真实行业任务才能调用模型。"
elif ! grep -qE '^LLM_API_KEY=.+' "${ROOT_DIR}/.env" 2>/dev/null; then
  echo "[提示] .env 中 LLM_API_KEY 为空，后端可启动但真实研报任务会失败。"
fi
if grep -qE '^IWENCAI_API_KEY=your_' "${ROOT_DIR}/.env" 2>/dev/null; then
  echo "[提示] .env 仍是模板占位：请填写 IWENCAI_API_KEY 后数据获取阶段才能工作。"
elif ! grep -qE '^IWENCAI_API_KEY=.+' "${ROOT_DIR}/.env" 2>/dev/null; then
  echo "[提示] .env 中 IWENCAI_API_KEY 为空，数据获取阶段会失败。"
fi

# ------------------------------------------------------------------------------
# 启动服务
# ------------------------------------------------------------------------------
wait_for_url() {
  local url="$1" name="$2" pid="$3" tries="$4"
  local i
  for i in $(seq 1 "${tries}"); do
    if curl -fsS --max-time 2 "${url}" >/dev/null 2>&1; then
      return 0
    fi
    if ! kill -0 "${pid}" 2>/dev/null; then
      return 1
    fi
    sleep 1
  done
  return 1
}

cleanup() {
  local exit_code=$?
  trap - INT TERM EXIT
  echo ""
  echo "[停止] 正在关闭前后端服务..."
  for pid_file in "${FRONTEND_PID_FILE}" "${BACKEND_PID_FILE}"; do
    [ -f "${pid_file}" ] || continue
    pid="$(tr -d '[:space:]' < "${pid_file}")"
    [ -n "${pid}" ] && terminate_pid "${pid}"
    rm -f "${pid_file}"
  done
  echo "[完成] 服务已停止。"
  exit "${exit_code}"
}

FRONTEND_PID=""
BACKEND_PID=""
trap cleanup INT TERM EXIT

echo "================================================================================"
echo "[启动] 行业研究五智能体协同研报生成系统"
echo "  工程路径: ${ROOT_DIR}"
echo "  Python:   $("${PYTHON_BIN}" --version 2>&1) (${PYTHON_BIN})"
echo "  后端日志: ${BACKEND_LOG}"
echo "  前端日志: ${FRONTEND_LOG}"
echo "================================================================================"

echo "  --> 启动 FastAPI 后端 (端口 ${BACKEND_PORT})"
(
  cd "${ROOT_DIR}"
  exec "${PYTHON_BIN}" "${ROOT_DIR}/backend/run_server.py"
) >"${BACKEND_LOG}" 2>&1 &
BACKEND_PID=$!
echo "${BACKEND_PID}" >"${BACKEND_PID_FILE}"

echo -n "  --> 等待后端健康检查"
if ! wait_for_url "http://127.0.0.1:${BACKEND_PORT}/health" "后端" "${BACKEND_PID}" 60; then
  echo " [失败]"
  tail -n 30 "${BACKEND_LOG}" 2>/dev/null || true
  exit 1
fi
echo " [OK]"

echo "  --> 启动 Vue3 + Vite 前端 (端口 ${FRONTEND_PORT})"
(
  cd "${ROOT_DIR}/frontend"
  export VITE_PROXY_TARGET="http://127.0.0.1:${BACKEND_PORT}"
  exec "${ROOT_DIR}/frontend/node_modules/.bin/vite" --host 0.0.0.0 --port "${FRONTEND_PORT}" --strictPort
) >"${FRONTEND_LOG}" 2>&1 &
FRONTEND_PID=$!
echo "${FRONTEND_PID}" >"${FRONTEND_PID_FILE}"

echo -n "  --> 等待前端就绪"
if ! wait_for_url "http://127.0.0.1:${FRONTEND_PORT}/" "前端" "${FRONTEND_PID}" 60; then
  echo " [失败]"
  tail -n 30 "${FRONTEND_LOG}" 2>/dev/null || true
  exit 1
fi
echo " [OK]"

FRONTEND_URL="http://localhost:${FRONTEND_PORT}"
BACKEND_URL="http://localhost:${BACKEND_PORT}"
if [ "${OPEN_BROWSER}" -eq 1 ]; then
  if command -v open >/dev/null 2>&1; then
    open "${FRONTEND_URL}" >/dev/null 2>&1 || true
  elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "${FRONTEND_URL}" >/dev/null 2>&1 || true
  fi
fi

echo ""
echo "================================================================================"
echo "[成功] 系统已启动"
echo "  - 前端工作台: ${FRONTEND_URL}"
echo "  - 后端接口:   ${BACKEND_URL}/api/v1"
echo "  - 接口文档:   ${BACKEND_URL}/docs"
echo "  - 停止服务:   ./start.sh --stop   （或在此终端按 Ctrl+C）"
echo "================================================================================"

wait "${FRONTEND_PID}"
