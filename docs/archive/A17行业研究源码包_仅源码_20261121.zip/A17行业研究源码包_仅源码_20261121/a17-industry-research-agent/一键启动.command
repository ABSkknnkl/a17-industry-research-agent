#!/usr/bin/env bash
# 双击入口：自动创建虚拟环境、安装依赖、启动前后端并打开页面。
set -Eeuo pipefail
cd "$(dirname "$0")" || exit 1
exec ./start.sh "$@"
