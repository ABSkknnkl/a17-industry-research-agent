# 退役技能归档（skills_retired_20261110）

B17（2026-11-10 上午）曾将 11 个零调用官方技能退役至此。
B20（同日下午）按用户「使用新版 skill，拉下来检查，剔除没用的」重新分诊：

- **重新启用**（移回 `../skills/`，商店新版自包含包 + 新写 PLAYBOOK）：
  hithink-management-query（股东股本——全管线唯一股权结构取数）、
  hithink-insresearch-query（机构研究与评级）、
  hithink-basicinfo-query（公司档案）
- **永久剔除**（已从项目删除；如需恢复，用 `iwencai-skillhub-cli --dir <临时目录> install <技能名>` 从官方商店重新安装即可）：
  hithink-hkstock-selector、hithink-usstock-selector、hithink-etf-selector、
  hithink-futures-query、hithink-futures-selector、hithink-zhishu-query、
  hithink-sector-selector、hithink-event-query（题材无关或能力被在用技能覆盖）
- B19 收编的 `skills_official_extra/`（cb-selector、fund×4、模拟炒股）同批判定无用并删除。
- 第三方方法论候选 10 个（可比公司/DCF/三表/业绩归因/监管知识库等）拉下检查后全部拒收
  （Excel/PPT 工件、组合归因、回测规则或与现有 20 个分析技能重复），明细见改动清单 B20。

本目录现仅存此说明文件。
