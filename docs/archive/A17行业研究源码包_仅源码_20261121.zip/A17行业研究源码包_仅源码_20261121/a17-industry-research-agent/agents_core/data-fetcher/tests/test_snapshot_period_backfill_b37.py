"""B37（2026-11-11）行情快照期间补齐 + 列 timestamp 期间兜底 + 报告期截止日列 回归测试。

背景（run-20261111101134 实测）：975 条数值记录中 584 条缺 period_end，
其中 305 条是行情/估值/概念相关度**快照**（latest_price/最新涨跌幅/pe_dynamic/相关系数），
其语义就是「查询执行时点的市场快照」，却被计成「缺日期」，把质量报告的
带日期数值占比压到 40%，触发「超过一半数值记录缺少日期」限制。

三处修复：
1. 快照类指标缺失期间 → period_end = as_of（查询日），provenance = market_snapshot_at_query；
2. columns[].timestamp 元数据兜底（列名无日期戳但列定义带 timestamp）；
3. PERIOD_KEYS 增加「报告期截止日」（问财带期间词查询返回的列）。
"""

from __future__ import annotations

from datetime import date, datetime, timezone

from data_fetcher.fusion import DataFusion
from data_fetcher.models import Domain, SkillResult

AS_OF = date(2026, 11, 11)


def _result(skill_id: str, records: list[dict], domain: Domain,
            columns: list[dict] | None = None) -> SkillResult:
    payload = None
    if columns is not None:
        payload = {"query": "测试", "columns": columns, "datas": records}
    return SkillResult(
        task_id="T1",
        skill_name=skill_id,
        skill_id=skill_id,
        skill_version="1.0.0",
        domain=domain,
        query="测试查询",
        trace_id="tr-b37",
        retrieved_at=datetime(2026, 11, 11, tzinfo=timezone.utc),
        success=True,
        records=records,
        raw_payload=payload,
    )


def _records_by_metric(ds, metric: str, domain: Domain):
    return [r for r in ds.records_for(domain) if r.metric == metric]


class TestSnapshotPeriodBackfill:
    """快照类指标：缺失期间 → 查询日 as_of。"""

    def test_latest_price_gets_as_of(self):
        ds = DataFusion().fuse([
            _result("hithink-astock-selector", [
                {"股票代码": "001696.SZ", "股票简称": "宗申动力", "最新价": "13.26", "最新涨跌幅": -0.52},
            ], Domain.COMPANIES),
        ], AS_OF)
        price = _records_by_metric(ds, "latest_price", Domain.COMPANIES)
        assert len(price) == 1
        assert price[0].period_end == AS_OF
        assert price[0].period_provenance == "market_snapshot_at_query"

    def test_dynamic_pe_gets_as_of(self):
        """估值点值（pe_dynamic 等 canonical metric）同属快照。"""
        ds = DataFusion().fuse([
            _result("hithink-astock-selector", [
                {"股票代码": "600941.SH", "股票简称": "中国移动", "最新动态市盈率": 15.49},
            ], Domain.COMPANIES),
        ], AS_OF)
        pe = _records_by_metric(ds, "pe_dynamic", Domain.COMPANIES)
        assert len(pe) == 1
        assert pe[0].period_end == AS_OF
        assert pe[0].period_provenance == "market_snapshot_at_query"

    def test_correlation_coefficient_gets_as_of(self):
        """概念相关度快照（相关系数）同属查询时点快照。"""
        ds = DataFusion().fuse([
            _result("hithink-astock-selector", [
                {"股票代码": "600728.SH", "股票简称": "佳都科技", "相关产品名称": "低空经济", "相关系数": 51.77},
            ], Domain.INDUSTRY_CHAIN),
        ], AS_OF)
        corr = _records_by_metric(ds, "相关系数", Domain.INDUSTRY_CHAIN)
        assert len(corr) == 1
        assert corr[0].period_end == AS_OF
        assert corr[0].period_provenance == "market_snapshot_at_query"

    def test_latest_price_in_business_row_uses_as_of_not_report_period(self):
        """主营构成行混入「最新价」时，快照必须锚定查询日，不得继承报告期。

        问财「宁德时代 主营构成 收入占比 2023年」返回的一行同时含
        报告期截止日=20231231 与 最新价=241.01；后者是 2026-11-18 查询时点的
        行情快照。若把 2023 报告期赋给最新价，图表会把它当成 2023 年价格，
        并在 2024/2026 重复展开成虚假的多年水平趋势。
        """
        ds = DataFusion().fuse([
            _result("hithink-business-query", [
                {"股票代码": "300750.SZ", "股票简称": "宁德时代",
                 "最新价": "241.01", "最新涨跌幅": 1.052411,
                 "收入占比": 98.07, "项目名称": "电气机械及器材制造业",
                 "报告期截止日": "20231231"},
            ], Domain.INDUSTRY_CHAIN),
        ], AS_OF)
        price = _records_by_metric(ds, "latest_price", Domain.INDUSTRY_CHAIN)
        assert len(price) == 1
        assert price[0].period_end == AS_OF
        assert price[0].period_provenance == "market_snapshot_at_query"
        revenue = _records_by_metric(ds, "业务收入", Domain.INDUSTRY_CHAIN)
        assert not revenue  # 该测试行没给业务收入，避免误生成
        share = _records_by_metric(ds, "收入占比", Domain.INDUSTRY_CHAIN)
        assert len(share) == 1
        assert share[0].period_end == date(2023, 12, 31)
        assert share[0].period_provenance == "row"

    def test_field_period_date_stamp_wins_over_as_of(self):
        """列名带日期戳（总市值[20261111]）时 field_period 优先于 as_of 回退。"""
        ds = DataFusion().fuse([
            _result("hithink-astock-selector", [
                {"股票代码": "001696.SZ", "股票简称": "宗申动力", "总市值[20261111]": 210.5},
            ], Domain.COMPANIES),
        ], AS_OF)
        cap = _records_by_metric(ds, "market_cap", Domain.COMPANIES)
        assert len(cap) == 1
        assert cap[0].period_end == date(2026, 11, 11)
        assert cap[0].period_provenance == "field"

    def test_business_segment_without_period_stays_missing(self):
        """主营构成（业务收入等）非快照：上游无报告期时保持缺失、不造数。"""
        ds = DataFusion().fuse([
            _result("hithink-business-query", [
                {"股票代码": "000099.SZ", "股票简称": "中信海直", "分类标准": "产品",
                 "项目名称": "航空运输业", "业务收入": 1240627803.03, "业务成本": 824378174.74,
                 "业务利润": 416249628.29, "收入占比": 96.22},
            ], Domain.INDUSTRY_CHAIN),
        ], AS_OF)
        rev = _records_by_metric(ds, "业务收入", Domain.INDUSTRY_CHAIN)
        assert len(rev) == 1
        assert rev[0].period_end is None
        assert rev[0].period_provenance == "unknown"


class TestColumnTimestampAndReportPeriod:
    """columns[].timestamp 兜底与「报告期截止日」列。"""

    def test_column_timestamp_fills_period(self):
        """列名无日期戳但列定义带 timestamp → 期间兜底（provenance=column_ts）。"""
        ds = DataFusion().fuse([
            _result("hithink-finance-query", [
                {"股票代码": "000099.SZ", "股票简称": "中信海直", "营业收入": 2215984977.85},
            ], Domain.FINANCIALS,
                columns=[{"key": "营业收入", "unit": "元", "timestamp": "20251231"}]),
        ], AS_OF)
        rev = _records_by_metric(ds, "revenue", Domain.FINANCIALS) or \
              _records_by_metric(ds, "营业收入", Domain.FINANCIALS)
        assert len(rev) == 1
        assert rev[0].period_end == date(2025, 12, 31)
        assert rev[0].period_provenance == "column_ts"

    def test_report_period_deadline_column_consumed(self):
        """问财带期间词查询返回「报告期截止日」列 → 正常解析为期间。"""
        ds = DataFusion().fuse([
            _result("hithink-business-query", [
                {"股票代码": "000099.SZ", "股票简称": "中信海直", "分类标准": "行业",
                 "项目名称": "通用航空运输业", "业务收入": 2215984977.85,
                 "报告期截止日": "20251231"},
            ], Domain.INDUSTRY_CHAIN),
        ], AS_OF)
        rev = _records_by_metric(ds, "业务收入", Domain.INDUSTRY_CHAIN)
        assert len(rev) == 1
        assert rev[0].period_end == date(2025, 12, 31)
        assert rev[0].period_provenance == "row"


def test_growth_family_aliases_b38():
    """B38：增速族近义词归一到 revenue_yoy/net_profit_yoy（SEMI-Q2 缺口实测）。"""
    from data_fetcher.fusion import metric_family
    for term in ("营业收入增速", "收入同比增长率", "营收增速", "收入增速",
                 "revenue growth", "revenue growth rate", "营收同比增长率"):
        assert metric_family(term) == "revenue_yoy", term
    for term in ("净利润同比增长率", "净利润增速", "归母净利润增速", "net profit growth"):
        assert metric_family(term) == "net_profit_yoy", term
    # 误吃防线（B33 教训）：复合词与水平值不得被增速别名吞掉
    assert metric_family("净利率同比增长率") == "净利率同比增长率"
    assert metric_family("研发费用同比增长率") == "研发费用同比增长率"
    assert metric_family("营业收入") == "revenue"
    assert metric_family("净利润") == "net_profit"
