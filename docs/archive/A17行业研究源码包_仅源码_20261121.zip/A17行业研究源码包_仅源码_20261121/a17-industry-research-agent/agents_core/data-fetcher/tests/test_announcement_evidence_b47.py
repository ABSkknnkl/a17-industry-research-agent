"""B47-2 红测：公告检索证据按「实体 + 年份 + 确为年报」认，不按 task_id 认。

实测（run-20261111153609，SEMI-N1）：34 条公告事件里，模型规划的 T24–T27
已经取到了四家公司 2024/2025 年报原文（如「北方华创：2025年年度报告」，
2026-04-18），但 `_announcement_search_coverage` 只认 `source.task_id ==
task.task_id`（即代码兜底任务的 `ann_<hash>`），于是判「2025年度公告检索未
返回可用线索」——同一份证据换个任务 ID 检索到就不算数。

修法两件事：
1. 解绑 task_id：任何 announcement-search 事件，只要实体身份匹配、公告日期
   不晚于 as_of，就可计入；
2. 加实质条件：证据必须是「年报」类公告（标题/正文含 年度报告/年报）。
   这比原来更严格——原来不管事件是不是年报都算，现在只有年报才算。
"""

from __future__ import annotations

from datetime import date, datetime, timezone

from data_fetcher.agent import DataFetcherAgent
from data_fetcher.models import (
    Domain,
    EventRecord,
    ResearchObjective,
    ResearchRequirement,
    SkillTask,
    SourceRef,
    StructuredResearchDataset,
)

AS_OF = date(2026, 11, 11)
ENTITY = "北方华创"
ENTITY_CODE = "002371.SZ"


def _source(task_id: str, query: str = "北方华创 年度报告 2023年 2024年 2025年") -> SourceRef:
    return SourceRef(
        task_id=task_id, skill_id="announcement-search", skill_version="1.0.0",
        query=query, trace_id="t", retrieved_at=datetime(2026, 11, 11, tzinfo=timezone.utc),
        status="success", record_count=1,
    )


def _event(record_id: str, title: str, announced: date, task_id: str = "T24") -> EventRecord:
    return EventRecord(
        record_id=record_id, entity_name=ENTITY, entity_code=ENTITY_CODE,
        title=title, event_type="公告", announce_date=announced, body="",
        source=_source(task_id),
    )


def _company() -> object:
    from data_fetcher.models import ResearchRecord
    return ResearchRecord(
        record_id="C-1", domain=Domain.COMPANIES, entity_name=ENTITY,
        entity_code=ENTITY_CODE, metric="entity_identity", value="已上市",
        source=_source("T1", query="北方华创 上市"),
    )


def _annual_requirements() -> list[ResearchRequirement]:
    return [
        ResearchRequirement(
            requirement_id=f"annual_{year}", label=f"{ENTITY} {year}年全年 revenue",
            domain=Domain.FINANCIALS, entity_names=[ENTITY], period_ends=[date(year, 12, 31)],
            metric_families=["revenue"],
        )
        for year in (2023, 2024, 2025)
    ]


def _task(query: str = "北方华创 2023年 2024年 2025年 2026年 年度报告 财务报表更正 会计政策变更 追溯调整 比较数据") -> SkillTask:
    return SkillTask(
        task_id="ann_7ee8a205eba1d0c6", skill_name="announcement-search",
        arguments={"query": query},
        requirement_ids=[f"annual_{year}" for year in (2023, 2024, 2025)],
    )


def _objective(requirements: list[ResearchRequirement]) -> ResearchObjective:
    return ResearchObjective(industry="半导体设备", requirements=requirements, as_of=AS_OF)


def _dataset(events: list[EventRecord]) -> StructuredResearchDataset:
    return StructuredResearchDataset(subject="半导体设备", research_as_of=AS_OF,
                                     companies=[_company()], events=events)


def test_evidence_from_another_announcement_task_counts() -> None:
    """核心回归：T24 取到的年报事件，必须能计入 ann_* 任务的覆盖率。"""
    events = [
        _event("E-1", "北方华创：2024年年度报告摘要", date(2025, 4, 26)),
        _event("E-2", "北方华创：2025年年度报告", date(2026, 4, 18)),
    ]
    cov = DataFetcherAgent._announcement_search_coverage(
        _task(), _objective(_annual_requirements()), _dataset(events),
    )
    assert cov.passed is True
    assert cov.evidence_count == 2
    assert cov.missing == []


def test_non_annual_report_announcement_does_not_count() -> None:
    """实质条件：重大合同公告不是年报，不能拿来充「年度公告检索」证据。"""
    events = [
        _event("E-1", "北方华创：2024年年度报告", date(2025, 4, 26)),
        _event("E-2", "北方华创：关于签订2025年重大销售合同的公告", date(2025, 9, 1)),
    ]
    cov = DataFetcherAgent._announcement_search_coverage(
        _task(), _objective(_annual_requirements()), _dataset(events),
    )
    assert cov.evidence_count == 1
    # 2025 年度没有年报线索 → 仍须如实报缺口
    assert cov.passed is False
    assert any("2025" in item for item in cov.missing)


def test_missing_year_still_reported_honestly() -> None:
    """只有 2024 年报时，2025 年度缺口必须如实申报（不得因解绑 task_id 而放松）。"""
    events = [_event("E-1", "北方华创：2024年年度报告", date(2025, 4, 26))]
    cov = DataFetcherAgent._announcement_search_coverage(
        _task(), _objective(_annual_requirements()), _dataset(events),
    )
    assert cov.passed is False
    assert cov.evidence_count == 1
    assert any("2025" in item for item in cov.missing)


def test_other_company_announcement_not_counted() -> None:
    """身份护栏：别家公司的年报不能算本公司证据。"""
    other = EventRecord(
        record_id="E-x", entity_name="中微公司", entity_code="688012.SH",
        title="中微公司：2025年年度报告", event_type="公告", announce_date=date(2026, 3, 31),
        source=_source("T25"),
    )
    cov = DataFetcherAgent._announcement_search_coverage(
        _task(), _objective(_annual_requirements()), _dataset([other]),
    )
    assert cov.evidence_count == 0
    assert cov.passed is False


def test_future_announcement_excluded() -> None:
    """公告日期晚于 as_of 的记录不得计入（既有护栏，防未来信息泄漏）。"""
    events = [
        _event("E-1", "北方华创：2024年年度报告", date(2025, 4, 26)),
        _event("E-2", "北方华创：2025年年度报告", date(2026, 12, 31)),
    ]
    cov = DataFetcherAgent._announcement_search_coverage(
        _task(), _objective(_annual_requirements()), _dataset(events),
    )
    assert cov.evidence_count == 1
    assert cov.passed is False
