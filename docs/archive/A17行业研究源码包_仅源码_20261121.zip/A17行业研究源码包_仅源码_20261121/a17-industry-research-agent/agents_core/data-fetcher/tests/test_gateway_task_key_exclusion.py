"""任务级 key 排除（2026-11-10，B16.2）。

用户决策的两层口径：
- 配额由服务端**每日刷新**，项目侧不做跨任务 / 跨天记忆（B16.1 的日级熔断已回退）；
- 但**单个任务内**，key 一旦返回「您今天的次数已用完，建议升级权益…」，
  本任务后续所有尝试（网络重试 / 鉴权重试 / 自愈级联）不再使用该 key。

即：excluded_keys 由任务持有、随任务丢弃；新任务从头尝试所有 key。
"""

import asyncio

import httpx
import pytest

from data_fetcher.config import Settings
from data_fetcher.models import Domain, SkillSpec, SkillTask
from data_fetcher.skillhub import IwencaiAuthenticationError, IwencaiGateway, SkillHub

EXHAUSTED_BODY = "您今天的次数已用完，建议您[升级权益](https://search.10jqka.com.cn/activepage)获取更多额度。"


def _spec() -> SkillSpec:
    return SkillSpec(
        name="test", skill_id="test", version="1", domain=Domain.INDUSTRY,
        endpoint="/test", required_arguments=["query"], response_list_keys=["datas"],
        source_path="", description="test",
    )


def _two_key_gateway(handler) -> IwencaiGateway:
    gateway = IwencaiGateway(Settings(iwencai_api_key="k1,k2"))
    gateway._client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    return gateway


@pytest.fixture
def no_cooldown(monkeypatch):
    """401 打击会开 5s 全局冷却窗口；单测里跳过真实等待。"""
    monkeypatch.setattr("data_fetcher.skillhub.auth_cooldown_remaining", lambda: 0.0)


def test_daily_exhausted_key_skipped_within_single_call(no_cooldown):
    seen = []

    def handler(req):
        seen.append(req.headers["Authorization"])
        if req.headers["Authorization"] == "Bearer k1":
            return httpx.Response(401, text=EXHAUSTED_BODY)
        return httpx.Response(200, json={"code": 0, "datas": [{"ok": 1}]})

    gateway = _two_key_gateway(handler)
    excluded: set[str] = set()
    payload = asyncio.run(
        gateway.call(_spec(), {"query": "行业"}, call_type="normal", trace_id="t", excluded_keys=excluded)
    )
    assert payload["code"] == 0
    assert seen == ["Bearer k1", "Bearer k2"]  # k1 尽 → 立即换 k2，不退避、不重试 k1
    assert excluded == {"k1"}


def test_exclusion_persists_within_task_but_not_across_tasks(no_cooldown):
    seen = []

    def handler(req):
        seen.append(req.headers["Authorization"])
        return httpx.Response(401, text=EXHAUSTED_BODY)

    gateway = _two_key_gateway(handler)
    task_excluded: set[str] = set()
    with pytest.raises(IwencaiAuthenticationError):
        asyncio.run(
            gateway.call(_spec(), {"query": "行业"}, call_type="normal", trace_id="t1", excluded_keys=task_excluded)
        )
    assert seen == ["Bearer k1", "Bearer k2"]
    with pytest.raises(IwencaiAuthenticationError):
        asyncio.run(
            gateway.call(_spec(), {"query": "行业"}, call_type="retry", trace_id="t2", excluded_keys=task_excluded)
        )
    assert seen == ["Bearer k1", "Bearer k2"]  # 同任务再次调用：零 HTTP，全部 key 已被排除
    fresh: set[str] = set()
    with pytest.raises(IwencaiAuthenticationError):
        asyncio.run(
            gateway.call(_spec(), {"query": "行业"}, call_type="normal", trace_id="t3", excluded_keys=fresh)
        )
    assert seen == ["Bearer k1", "Bearer k2", "Bearer k1", "Bearer k2"]  # 新任务从头尝试


def test_alive_key_serves_while_exhausted_key_never_retried_in_task(no_cooldown):
    seen = []

    def handler(req):
        seen.append(req.headers["Authorization"])
        if req.headers["Authorization"] == "Bearer k1":
            return httpx.Response(401, text=EXHAUSTED_BODY)
        return httpx.Response(200, json={"code": 0, "datas": [{"ok": 1}]})

    gateway = _two_key_gateway(handler)
    excluded: set[str] = set()
    first = asyncio.run(
        gateway.call(_spec(), {"query": "行业"}, call_type="normal", trace_id="t1", excluded_keys=excluded)
    )
    second = asyncio.run(
        gateway.call(_spec(), {"query": "行业"}, call_type="retry", trace_id="t2", excluded_keys=excluded)
    )
    assert first["code"] == 0 and second["code"] == 0
    assert seen == ["Bearer k1", "Bearer k2", "Bearer k2"]  # 同任务第二次调用只打活 key
    assert excluded == {"k1"}


def test_shell_quota_exhaustion_also_excludes_key_within_call(no_cooldown):
    seen = []

    def handler(req):
        seen.append(req.headers["Authorization"])
        if req.headers["Authorization"] == "Bearer k1":
            return httpx.Response(200, json={"code": 403, "message": "额度不足，请升级权益"})
        return httpx.Response(200, json={"code": 0, "datas": [{"ok": 1}]})

    gateway = _two_key_gateway(handler)
    excluded: set[str] = set()
    payload = asyncio.run(
        gateway.call(_spec(), {"query": "行业"}, call_type="normal", trace_id="t", excluded_keys=excluded)
    )
    assert payload["code"] == 0
    assert seen == ["Bearer k1", "Bearer k2"]
    assert excluded == {"k1"}


def test_task_scoped_exclusion_flows_through_hub_retries(monkeypatch):
    """_execute_task 的鉴权重试与自愈级联必须共享同一排除集。"""

    async def instant_sleep(_delay):
        return

    monkeypatch.setattr(asyncio, "sleep", instant_sleep)

    class ExhaustedOnceGateway:
        def __init__(self):
            self.seen_sets = []
            self.call_types = []

        async def call(self, spec, arguments, *, call_type, trace_id, excluded_keys=None):
            self.seen_sets.append(excluded_keys)
            self.call_types.append(call_type)
            if len(self.seen_sets) == 1:
                excluded_keys.add("k1")  # 模拟真实网关：日配额尽 → 记入任务排除集
                raise IwencaiAuthenticationError(
                    "Iwencai daily quota exhausted (key 1/2); excluded for this task"
                )
            return {"datas": [{"ok": 1}]}

    gateway = ExhaustedOnceGateway()
    hub = SkillHub(gateway=gateway, retry_backoff_seconds=0)
    results = asyncio.run(hub.execute_plan([
        SkillTask(task_id="a", skill_name="industry_data", arguments={"query": "行业"})
    ]))
    assert results[0].success is True
    assert gateway.call_types == ["normal", "retry"]
    assert len(gateway.seen_sets) == 2
    assert gateway.seen_sets[0] is gateway.seen_sets[1]  # 同一任务共享同一排除集
    assert "k1" in gateway.seen_sets[1]  # 首次尝试的排除结果延续到鉴权重试
