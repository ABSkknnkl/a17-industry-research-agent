"""B46（2026-11-11）新闻/研报记录的实体归属 + 需求按 label 收窄主体。

背景（run-20261111154718）：问财 news 行没有公司字段，逐键拆分后 entity_name=None；
三条「亿航/纵横/宗申 适航取证」需求又都是 entity_names=[]，于是三个需求共享同一新闻池——
**亿航的新闻可以去满足纵横的需求**，这是会写进报告的实质错误（不是缺数据）。

两处修复：
1. 融合末段做实体归属：标题/正文只命中**唯一**已知组织名才归属；命中多个 → 保持 None（歧义不猜）；
2. 需求 label 里点名了已知公司（如「亿航智能2024—2025年…」）时，评估器按该主体收窄。
"""

from __future__ import annotations

from datetime import date, datetime, timezone

from data_fetcher.agent import DataFetcherAgent
from data_fetcher.fusion import DataFusion
from data_fetcher.models import (
    Domain,
    ResearchRecord,
    ResearchRequirement,
    SkillResult,
    SourceRef,
    StructuredResearchDataset,
)

AS_OF = date(2026, 11, 11)


def _result(skill_id: str, domain: Domain, records: list[dict]) -> SkillResult:
    return SkillResult(
        task_id="T",
        skill_name=skill_id,
        skill_id=skill_id,
        skill_version="1.0.0",
        domain=domain,
        query="测试",
        trace_id="tr-b46",
        retrieved_at=datetime(2026, 11, 11, tzinfo=timezone.utc),
        success=True,
        records=records,
    )


def _identity(name: str, code: str | None = "000000.SZ") -> dict:
    row = {"股票简称": name, "股票代码": code} if code else {"名称": name}
    return row


def _fuse_news(title: str) -> StructuredResearchDataset:
    return DataFusion().fuse([
        _result("hithink-basicinfo-query", Domain.COMPANIES, [
            _identity("亿航智能", None),
            _identity("纵横股份"),
            _identity("宗申动力"),
        ]),
        _result("news-search", Domain.NEWS, [{"title": title, "publish_date": "2025-06-01"}]),
    ], AS_OF)


def _news_record(entity: str | None, rid: str = "R-n1") -> ResearchRecord:
    return ResearchRecord(
        record_id=rid,
        domain=Domain.NEWS,
        entity_name=entity,
        metric="title",
        value="适航取证进展",
        period_end=date(2025, 6, 1),
        published_at=date(2025, 6, 1),
        source=SourceRef(
            task_id="t", skill_id="news-search", skill_version="1.0.0",
            query="适航", trace_id="tr", retrieved_at="2026-11-11T00:00:00+00:00",
        ),
    )


def _requirement(label: str) -> ResearchRequirement:
    return ResearchRequirement(
        requirement_id="airworthiness",
        label=label,
        domain=Domain.NEWS,
        requires_period_end=True,
    )


class TestNewsEntityAttribution:
    def test_unique_company_mention_is_attributed(self):
        ds = _fuse_news("亿航智能获颁TC型号合格证，低空经济再进一步")
        rec = [r for r in ds.news if r.metric == "title"][0]
        assert rec.entity_name == "亿航智能"

    def test_ambiguous_mention_is_not_attributed(self):
        ds = _fuse_news("亿航智能与纵横股份签署战略合作，共拓低空物流")
        rec = [r for r in ds.news if r.metric == "title"][0]
        assert rec.entity_name is None, "命中多个主体时不猜，保持未归属"

    def test_no_mention_stays_unattributed(self):
        ds = _fuse_news("低空经济行业日报｜政策与基建进展汇总")
        rec = [r for r in ds.news if r.metric == "title"][0]
        assert rec.entity_name is None


class TestRequirementEntityScope:
    @staticmethod
    def _dataset(entity: str | None) -> StructuredResearchDataset:
        return StructuredResearchDataset(
            research_as_of=AS_OF,
            companies=[
                ResearchRecord(
                    record_id="R-id1", domain=Domain.COMPANIES, entity_name="亿航智能",
                    entity_code=None, metric="entity_identity", value="亿航智能",
                    source=SourceRef(task_id="t0", skill_id="basic", skill_version="1",
                                     query="q", trace_id="tr0", retrieved_at="2026-11-11T00:00:00+00:00"),
                    issues=["missing_entity_code"],
                ),
                ResearchRecord(
                    record_id="R-id2", domain=Domain.COMPANIES, entity_name="纵横股份",
                    entity_code="688070.SH", metric="entity_identity", value="纵横股份",
                    source=SourceRef(task_id="t0", skill_id="basic", skill_version="1",
                                     query="q", trace_id="tr0", retrieved_at="2026-11-11T00:00:00+00:00"),
                ),
            ],
            news=[_news_record(entity)],
        )

    def test_label_names_company_and_other_company_evidence_rejected(self):
        cov = DataFetcherAgent._evaluate_requirement(
            self._dataset("纵横股份"), _requirement("亿航智能2024—2025年适航取证进展事件记录")
        )
        assert cov.passed is False
        reasons = {r for v in cov.rejected_evidence.values() for r in v}
        assert "entity_mismatch" in reasons

    def test_label_names_company_and_matching_evidence_passes(self):
        cov = DataFetcherAgent._evaluate_requirement(
            self._dataset("亿航智能"), _requirement("亿航智能2024—2025年适航取证进展事件记录")
        )
        assert cov.passed is True

    def test_label_without_company_keeps_whole_pool(self):
        cov = DataFetcherAgent._evaluate_requirement(
            self._dataset("纵横股份"), _requirement("低空航空器适航取证进展事件记录")
        )
        assert cov.passed is True
