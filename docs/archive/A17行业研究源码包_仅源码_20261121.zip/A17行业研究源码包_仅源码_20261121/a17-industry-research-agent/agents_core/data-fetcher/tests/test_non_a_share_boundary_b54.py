"""B54（2026-11-11 用户拍板）：非 A 股主体的公告/年报需求按数据源边界处理。

背景：低空 run（`run-20261111204734`）的两道硬门都指向亿航智能（美股）：
1. `公告检索：亿航智能 2024/2025/2026 年度报告…` —— 问财公告频道是 A 股法定披露口径；
2. `指定年度指标缺口：亿航智能 2024年全年 revenue` —— 数据源只有 ytd_month/美元口径记录。

用户口径：把这道门禁也放宽。实现方式沿用 B45 的 `out_of_scope`：
不伪造成通过（passed 仍 False），但标为数据源覆盖边界，报告按 warnings 申报、不阻断交付。
"""
from __future__ import annotations

from datetime import date, datetime, timezone

from data_fetcher.agent import DataFetcherAgent
from data_fetcher.models import (
    Domain,
    ResearchObjective,
    ResearchRecord,
    ResearchRequirement,
    SkillTask,
    SourceRef,
    StructuredResearchDataset,
)

AS_OF = date(2026, 11, 11)


def _source(task_id="T1", query="基本信息") -> SourceRef:
    return SourceRef(task_id=task_id, skill_id="hithink-basicinfo-query", skill_version="1.0.0",
                     query=query, trace_id="t", retrieved_at=datetime(2026, 11, 11, tzinfo=timezone.utc))


def _identity(name: str, code: str | None) -> ResearchRecord:
    return ResearchRecord(record_id=f"C-{name}", domain=Domain.COMPANIES, entity_name=name,
                          entity_code=code, metric="entity_identity", value=name,
                          period_end=AS_OF, source=_source(),
                          issues=[] if code else ["missing_entity_code"])


def _task(query: str) -> SkillTask:
    return SkillTask(task_id="ann_9f00ba12", skill_name="announcement-search",
                     arguments={"query": query}, requirement_ids=["annual_ehang_2024"])


def _requirement(name: str, year: int = 2024, rid: str = "annual_ehang_2024") -> ResearchRequirement:
    return ResearchRequirement(requirement_id=rid,
                               label=f"{name} {year}年全年 revenue", domain=Domain.FINANCIALS,
                               entity_names=[name], period_ends=[date(year, 12, 31)],
                               metric_families=["revenue"], requires_period_end=True)


def _dataset(companies, events=(), financials=()) -> StructuredResearchDataset:
    return StructuredResearchDataset(subject="低空经济", research_as_of=AS_OF,
                                     companies=list(companies), events=list(events),
                                     financials=list(financials))


def _objective(requirements) -> ResearchObjective:
    return ResearchObjective(industry="低空经济", requirements=list(requirements), as_of=AS_OF)


def test_us_listed_entity_announcement_gap_is_boundary_not_blocker():
    ds = _dataset([_identity("亿航智能", None), _identity("纵横股份", "688070.SH")])
    cov = DataFetcherAgent._announcement_search_coverage(
        _task("亿航智能 2024年 2025年 2026年 年度报告 财务报表更正"),
        _objective([_requirement("亿航智能")]), ds,
    )
    assert cov.passed is False, "不覆盖仍是事实"
    assert cov.out_of_scope is True
    assert "A 股" in cov.scope_note


def test_a_share_entity_without_announcements_stays_blocking():
    ds = _dataset([_identity("北方华创", "002371.SZ")])
    cov = DataFetcherAgent._announcement_search_coverage(
        _task("北方华创 2024年 2025年 年度报告"), _objective([_requirement("北方华创", rid="annual_beifang_2024")]), ds,
    )
    assert cov.passed is False
    assert cov.out_of_scope is False


def test_annual_revenue_only_ytd_month_record_is_boundary():
    """亿航只有 ytd_month/美元口径的 revenue：无合格记录 + 无 A 股代码 → 边界。"""
    ds = _dataset([_identity("亿航智能", None)])
    rejected = {"R-ehang-ytd": ["period_type_mismatch", "currency_mismatch"]}
    out_of_scope, note = DataFetcherAgent._out_of_scope(_requirement("亿航智能"), ds, rejected)
    assert out_of_scope is True
    assert "非年度" in note


def test_no_rejected_evidence_keeps_gap():
    """查不到任何返回记录 ≠ 结构性不覆盖——仍按缺口处理（B45 原有边界不放宽）。"""
    ds = _dataset([_identity("亿航智能", None)])
    out_of_scope, _ = DataFetcherAgent._out_of_scope(_requirement("亿航智能"), ds, {})
    assert out_of_scope is False


def test_a_share_entity_with_bad_period_keeps_gap():
    ds = _dataset([_identity("纵横股份", "688070.SH")])
    rejected = {"R-zong-ytd": ["period_type_mismatch"]}
    out_of_scope, _ = DataFetcherAgent._out_of_scope(_requirement("纵横股份", rid="annual_zong_2024"), ds, rejected)
    assert out_of_scope is False
