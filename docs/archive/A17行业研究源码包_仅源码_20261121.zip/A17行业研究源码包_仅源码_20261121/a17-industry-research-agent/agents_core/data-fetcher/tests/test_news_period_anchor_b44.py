"""B44（2026-11-11）新闻/研报记录的期间锚点 + 需求年份约束。

背景（run-20261111154718 实测）：低空题的「三家公司 2024—2025 年适航取证进展事件记录」
三个硬需求各被拒 784 条，理由 100% 是 ``missing_period``。核查发现这些新闻记录全都有
``published_at=2026-11-08``，只是通用逐键拆分通道从不把发布时间回填成 ``period_end``
（财务/宏观有专属通道，新闻没有）→ 任何「需要期间」的新闻需求在结构上不可能满足。

但直接把发布时间当期间会制造新的不诚实：需求的 ``period_ends`` 是空的，
2026 年的行业日报会去满足「2024—2025 年」的需求。所以两件事必须一起做：

1. 新闻/研报记录：``period_end`` 缺失时取 ``published_at``，provenance 单列
   ``published_at``（与 B37 的 ``market_snapshot_at_query`` 同思路）；
2. 需求 label 里写明年的（如「2024—2025年」），年份不符的记录拒绝，理由如实写
   ``period_out_of_scope``，而不是误导性的 ``missing_period``。
"""

from __future__ import annotations

from datetime import date, datetime, timezone

from data_fetcher.agent import DataFetcherAgent
from data_fetcher.fusion import DataFusion
from data_fetcher.models import (
    Domain,
    ResearchRecord,
    ResearchRequirement,
    SkillResult,
    SourceRef,
    StructuredResearchDataset,
)

AS_OF = date(2026, 11, 11)


def _news_result(records: list[dict]) -> SkillResult:
    return SkillResult(
        task_id="T1",
        skill_name="news-search",
        skill_id="news-search",
        skill_version="1.0.0",
        domain=Domain.NEWS,
        query="低空经济 适航",
        trace_id="tr-b44",
        retrieved_at=datetime(2026, 11, 8, tzinfo=timezone.utc),
        success=True,
        records=records,
    )


def _report_result(records: list[dict]) -> SkillResult:
    return SkillResult(
        task_id="T2",
        skill_name="report-search",
        skill_id="report-search",
        skill_version="1.0.0",
        domain=Domain.REPORTS,
        query="低空经济 研报",
        trace_id="tr-b44b",
        retrieved_at=datetime(2026, 11, 8, tzinfo=timezone.utc),
        success=True,
        records=records,
    )


def _news_record(period: date | None, *, record_id: str = "R-news1") -> ResearchRecord:
    return ResearchRecord(
        record_id=record_id,
        domain=Domain.NEWS,
        metric="title",
        value="亿航获颁型号合格证",
        period_end=period,
        published_at=period,
        source=SourceRef(
            task_id="t1",
            skill_id="news-search",
            skill_version="1.0.0",
            query="亿航 适航",
            trace_id="tr-1",
            retrieved_at="2026-11-08T00:00:00+00:00",
        ),
    )


class TestNewsPeriodAnchor:
    """第 1 部分：新闻/研报记录必须带期间锚点。"""

    def test_news_row_gets_period_from_publish_date(self):
        ds = DataFusion().fuse([
            _news_result([
                {"title": "低空经济行业日报｜2026 年 11 月 8 日", "publish_date": "2026-11-08"},
            ]),
        ], AS_OF)

        titles = [r for r in ds.news if r.metric == "title"]
        assert titles, "应产出 title 记录"
        rec = titles[0]
        assert rec.period_end == date(2026, 11, 8)
        assert rec.period_provenance == "published_at"
        assert "missing_period_end" not in rec.issues

    def test_news_row_without_publish_date_stays_undated(self):
        ds = DataFusion().fuse([
            _news_result([{"title": "无日期新闻"}],),
        ], AS_OF)

        rec = [r for r in ds.news if r.metric == "title"][0]
        assert rec.period_end is None
        assert rec.period_provenance != "published_at"

    def test_report_row_gets_period_from_publish_date(self):
        ds = DataFusion().fuse([
            _report_result([{"title": "低空经济深度报告", "publish_date": "2026-11-06"}]),
        ], AS_OF)

        rec = [r for r in ds.reports if r.metric == "title"][0]
        assert rec.period_end == date(2026, 11, 6)
        assert rec.period_provenance == "published_at"


class TestRequirementLabelYears:
    """第 2 部分：需求 label 的年份必须生效。"""

    @staticmethod
    def _dataset(period: date | None) -> StructuredResearchDataset:
        return StructuredResearchDataset(research_as_of=AS_OF, news=[_news_record(period)])

    @staticmethod
    def _requirement(label: str = "亿航智能2024—2025年适航取证进展事件记录") -> ResearchRequirement:
        return ResearchRequirement(
            requirement_id="evtol_airworthiness_2024_2025",
            label=label,
            domain=Domain.NEWS,
            requires_period_end=True,
        )

    def test_record_outside_label_years_is_rejected_with_true_reason(self):
        result = DataFetcherAgent._evaluate_requirement(
            self._dataset(date(2026, 11, 8)), self._requirement()
        )
        assert result.passed is False
        reasons = {r for v in result.rejected_evidence.values() for r in v}
        assert "period_out_of_scope" in reasons
        assert "missing_period" not in reasons

    def test_record_inside_label_years_passes(self):
        result = DataFetcherAgent._evaluate_requirement(
            self._dataset(date(2025, 6, 1)), self._requirement()
        )
        assert result.passed is True
        assert not result.rejected_evidence

    def test_label_without_years_accepts_any_period(self):
        result = DataFetcherAgent._evaluate_requirement(
            self._dataset(date(2026, 11, 8)), self._requirement(label="适航取证进展事件记录")
        )
        assert result.passed is True
