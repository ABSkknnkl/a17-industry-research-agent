"""A1 来源地址保真：文本记录拆成 title/summary 指标后仍保留原文 URL。"""

from __future__ import annotations

from datetime import date, datetime, timezone

from data_fetcher.fusion import DataFusion
from data_fetcher.models import Domain, SkillResult

AS_OF = date(2026, 11, 21)


def _result(domain: Domain, skill: str, records: list[dict]) -> SkillResult:
    return SkillResult(
        task_id="T1",
        skill_name=skill,
        skill_id=skill,
        skill_version="1.0.0",
        domain=domain,
        query="测试",
        trace_id="tr-provenance",
        retrieved_at=datetime(2026, 11, 21, tzinfo=timezone.utc),
        success=True,
        records=records,
    )


def test_report_url_survives_title_and_summary_split():
    dataset = DataFusion().fuse([
        _result(Domain.REPORTS, "report-search", [{
            "title": "新能源汽车行业深度报告",
            "summary": "摘要正文",
            "url": "https://example.com/report/1",
            "publish_time": "2026-11-20",
        }]),
    ], AS_OF)

    rows = [r for r in dataset.reports if r.metric in ("title", "summary")]
    assert rows
    for row in rows:
        assert row.raw_fields["source_url"] == "https://example.com/report/1"
        assert row.raw_fields["source_locator"] == "研究报告原文页"


def test_news_url_survives_generic_record_split():
    dataset = DataFusion().fuse([
        _result(Domain.NEWS, "news-search", [{
            "title": "行业日报",
            "url": "https://example.com/news/1",
            "publish_time": "2026-11-20",
        }]),
    ], AS_OF)

    row = next(r for r in dataset.news if r.metric == "title")
    assert row.raw_fields["source_url"] == "https://example.com/news/1"
    assert row.raw_fields["source_locator"] == "新闻原文页"


def test_event_url_attached_to_event_record():
    dataset = DataFusion().fuse([
        _result(Domain.NEWS, "announcement-search", [{
            "公告标题": "重大合同公告",
            "公告日期": "2026-11-20",
            "url": "https://static.cninfo.com.cn/finalpage/2026-11-20/1.PDF",
        }]),
    ], AS_OF)

    assert dataset.events
    event = dataset.events[0]
    assert event.raw_fields["source_url"].endswith("1.PDF")
    assert event.raw_fields["source_locator"] == "公告 PDF 全文"
