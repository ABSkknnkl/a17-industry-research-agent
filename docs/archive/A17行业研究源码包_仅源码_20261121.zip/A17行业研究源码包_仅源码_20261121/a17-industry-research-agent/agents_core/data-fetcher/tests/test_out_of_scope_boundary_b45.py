"""B45（2026-11-11）数据源结构性不覆盖 → out_of_scope 边界，而非硬缺口。

背景（run-20261111154718）：亿航智能是美股公司，问财 A 股底座的财务查询只能返回
**别家公司**的记录（rejected 全为 entity_mismatch），而它在数据源里连证券代码都没有
（identity 记录 entity_code=None / missing_entity_code）。这条需求因此永久 hard 阻塞，
报告只能停在受限草稿。

判据（窄口径，避免把「查失败」误判成「不覆盖」）：
1. 需求是 FINANCIALS 且指名实体；
2. 该实体在身份记录中没有证券代码（missing_entity_code）；
3. 被拒证据非空，且**全部**含 entity_mismatch（数据源确实响应了，只是给的是别家）。

满足时：coverage.out_of_scope=True 且 passed=False（不覆盖仍是事实），
报告融合层不再把它当硬阻塞，而是在 warnings 里作为边界申报。
"""

from __future__ import annotations

from datetime import date, datetime, timezone

from data_fetcher.agent import DataFetcherAgent
from data_fetcher.models import (
    Domain,
    ResearchRecord,
    ResearchRequirement,
    SourceRef,
    StructuredResearchDataset,
)


def _identity(name: str, code: str | None) -> ResearchRecord:
    return ResearchRecord(
        record_id=f"R-id-{name}",
        domain=Domain.COMPANIES,
        entity_name=name,
        entity_code=code,
        metric="entity_identity",
        value=name,
        period_end=date(2026, 11, 11),
        source=SourceRef(
            task_id="t0",
            skill_id="hithink-basicinfo-query",
            skill_version="1.0.0",
            query="基本信息",
            trace_id="tr-0",
            retrieved_at="2026-11-11T00:00:00+00:00",
        ),
        issues=[] if code else ["missing_entity_code"],
    )


def _fin(name: str, value: float = 100.0) -> ResearchRecord:
    return ResearchRecord(
        record_id=f"R-fin-{name}-{value}",
        domain=Domain.FINANCIALS,
        entity_name=name,
        entity_code=None,
        metric="revenue",
        value=value,
        unit="亿元",
        period_end=date(2024, 12, 31),
        period_type="annual",
        source=SourceRef(
            task_id="t1",
            skill_id="hithink-finance-query",
            skill_version="1.0.0",
            query="2024年 营业收入",
            trace_id="tr-1",
            retrieved_at="2026-11-11T00:00:00+00:00",
        ),
    )


def _requirement(entity: str) -> ResearchRequirement:
    return ResearchRequirement(
        requirement_id="annual_ehang_2024",
        label=f"{entity} 2024年全年 revenue",
        domain=Domain.FINANCIALS,
        entity_names=[entity],
        period_ends=[date(2024, 12, 31)],
        metric_families=["revenue"],
        requires_period_end=True,
    )


class TestOutOfScopeDetection:
    def test_entity_without_code_and_only_mismatched_evidence_is_out_of_scope(self):
        ds = StructuredResearchDataset(
            research_as_of=date(2026, 11, 11),
            companies=[_identity("亿航智能", None), _identity("纵横股份", "688070.SH")],
            financials=[_fin("纵横股份")],  # 数据源只回了别家的记录
        )
        cov = DataFetcherAgent._evaluate_requirement(ds, _requirement("亿航智能"))

        assert cov.passed is False, "不覆盖仍是事实，不得伪造成通过"
        assert cov.out_of_scope is True
        assert "数据源" in cov.scope_note

    def test_entity_with_code_is_not_out_of_scope(self):
        ds = StructuredResearchDataset(
            research_as_of=date(2026, 11, 11),
            companies=[_identity("纵横股份", "688070.SH")],
            financials=[_fin("纵横股份")],
        )
        cov = DataFetcherAgent._evaluate_requirement(ds, _requirement("纵横股份"))

        assert cov.out_of_scope is False
        assert cov.passed is True  # 有代码 + 记录实体相符 → 正常通过

    def test_entity_covered_by_records_is_passed_not_out_of_scope(self):
        ds = StructuredResearchDataset(
            research_as_of=date(2026, 11, 11),
            companies=[_identity("亿航智能", None)],
            financials=[_fin("亿航智能")],
        )
        cov = DataFetcherAgent._evaluate_requirement(ds, _requirement("亿航智能"))

        assert cov.passed is True
        assert cov.out_of_scope is False

    def test_non_financial_requirement_never_marked_out_of_scope(self):
        ds = StructuredResearchDataset(
            research_as_of=date(2026, 11, 11),
            companies=[_identity("亿航智能", None)],
            financials=[_fin("纵横股份")],
        )
        req = _requirement("亿航智能")
        req.domain = Domain.NEWS
        cov = DataFetcherAgent._evaluate_requirement(ds, req)

        assert cov.out_of_scope is False
