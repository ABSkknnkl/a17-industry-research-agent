"""Public API for the data-fetcher agent foundation."""

import sys
from pathlib import Path

# `industry_reference` 等兄弟包用 "from industry_reference..." 这种绝对导入，
# 要求 `agents_core` 在 sys.path 上。以 `data_fetcher.xxx` 包方式导入时，调用方
# 不一定注入该路径——测试里表现为"只有特定执行顺序才报 ModuleNotFoundError"。
# 这里显式补齐，让包自身可用，而不是依赖启动脚本预先设置。
_AGENTS_CORE = str(Path(__file__).resolve().parents[2])
if _AGENTS_CORE not in sys.path:
    sys.path.append(_AGENTS_CORE)

from data_fetcher.agent import DataFetcherAgent
from data_fetcher.fusion import infer_default_unit
from data_fetcher.models import (
    EventRecord,
    ResearchRequest,
    ResearchRunResult,
    StructuredResearchDataset,
)

__all__ = [
    "DataFetcherAgent",
    "EventRecord",
    "ResearchRequest",
    "ResearchRunResult",
    "StructuredResearchDataset",
    "infer_default_unit",
]

