"""The sole execution plane: validated DAG scheduling over Iwencai SkillHub."""

from __future__ import annotations

import asyncio
from contextvars import ContextVar
from collections.abc import Awaitable, Callable
from datetime import datetime, timezone
import json                     # ⚠️ 必须保留：record_query_telemetry 用它写遥测账本
from hashlib import sha256      # query 指纹（账本不落明文 query，安全不变量）
from pathlib import Path
import re
import secrets
from time import monotonic
from typing import Any, Protocol

import httpx

from data_fetcher.config import Settings
from data_fetcher.models import Domain, SkillResult, SkillSpec, SkillTask

_request_observer: ContextVar[Any] = ContextVar('iwencai_request_observer', default=None)


def _is_daily_exhausted_text(text: str) -> bool:
    """识别 key 日配额尽的响应文案（2026-11-10 探针实测 401 body）。

    「您今天的次数已用完，建议升级权益…」。命中仅在**当前任务内**跳过该 key；
    配额由服务端每日刷新，项目侧不做任何跨任务 / 跨天的记忆。
    """
    return "已用完" in text or ("次数" in text and "升级权益" in text)


class SkillHubError(RuntimeError):
    pass


class SkillValidationError(SkillHubError):
    pass


class IwencaiAuthenticationError(SkillHubError):
    pass


def _safe_error_label(exc: BaseException) -> str:
    label = type(exc).__name__
    if isinstance(exc, IwencaiAuthenticationError):
        match = re.search(r"\bHTTP (401|403|429)\b", str(exc))
        if match:
            label += f" HTTP {match.group(1)}"
    elif isinstance(exc, httpx.HTTPStatusError):
        label += f" HTTP {exc.response.status_code}"
    return label


# ── 全局鉴权熔断窗口（B23-T4）──────────────────────────────────────────────
# SEMI-Q4 实测：announcement-search 一批 8 个任务并发，撞上配额窗口后
# 24 次 HTTP 401（占该技能请求 22%）。旧逻辑虽然退避 0.6s×n 并换 key，但
# **并发请求各自撞墙**——一个请求被拒后其余请求并不知道，仍在同一秒内打。
# 这里加一个进程级「打击时刻」：任一请求遇 401/403/429 就记下时刻，后续
# 所有请求在窗口内先排队等待，整批一起退，而不是轮流送死。
# 用无锁时间戳（并发同时 sleep 同一剩余时长正是想要的行为，无需互斥）。
_AUTH_COOLDOWN_SECONDS = 5.0
_AUTH_STRIKE_AT = 0.0


def note_auth_strike() -> None:
    """记录一次鉴权/配额打击，开启（或顺延）全局冷却窗口。"""
    global _AUTH_STRIKE_AT
    _AUTH_STRIKE_AT = monotonic()


def auth_cooldown_remaining() -> float:
    """当前全局冷却窗口的剩余秒数（<=0 表示窗口已过）。"""
    return _AUTH_STRIKE_AT + _AUTH_COOLDOWN_SECONDS - monotonic()


async def await_auth_window() -> None:
    """发请求前等待全局冷却窗口结束。

    注意：这里是「等待」，不是「跳过」——配额恢复需要真实时间。
    """
    remaining = auth_cooldown_remaining()
    if remaining > 0:
        await asyncio.sleep(remaining)


DEFAULT_SKILLS_DIR = Path(__file__).resolve().parents[1] / "skills"

REMOTE_SKILL_DOMAINS: dict[str, Domain] = {
    "announcement-search": Domain.NEWS,
    "hithink-astock-selector": Domain.COMPANIES,
    # B20（2026-11-10）：按「检查后启用有用的」重新启用 3 个（B17 曾退役）
    "hithink-basicinfo-query": Domain.COMPANIES,
    "hithink-management-query": Domain.COMPANIES,
    "hithink-insresearch-query": Domain.REPORTS,
    "hithink-business-query": Domain.INDUSTRY_CHAIN,
    "hithink-finance-query": Domain.FINANCIALS,
    "hithink-industry-query": Domain.INDUSTRY,
    "hithink-macro-query": Domain.MACRO,
    "hithink-market-query": Domain.COMPANIES,
    # 2026-11-15 分支合并：补齐技能中心界面宣称的 25 个问财技能。
    # 域映射沿用分支原值；其中 etf-selector / futures-selector 归到 COMPANIES
    # 并不贴切（ETF 份额、期货合约不是公司），但改域会影响 entity_identity 与
    # 估值样本，先按原样接入、观察后再定。
    "hithink-etf-selector": Domain.COMPANIES,
    "hithink-event-query": Domain.NEWS,
    "hithink-futures-query": Domain.INDUSTRY_CHAIN,
    "hithink-futures-selector": Domain.COMPANIES,
    "hithink-hkstock-selector": Domain.COMPANIES,
    "hithink-sector-selector": Domain.INDUSTRY,
    "hithink-usstock-selector": Domain.COMPANIES,
    "hithink-zhishu-query": Domain.INDUSTRY,
    "news-search": Domain.NEWS,
    "report-search": Domain.REPORTS,
}

CORE_SKILL_ALIASES = {
    "industry_data": "hithink-industry-query",
    "financial_data": "hithink-finance-query",
    "macro_data": "hithink-macro-query",
    "industry_chain": "hithink-business-query",
    "report_search": "report-search",
    "news_search": "news-search",
    "company_basic_info": "hithink-basicinfo-query",
}

PLANNING_SKILL_SOURCES = {
    "industry-research-requirements": "技能商店/行业概览",
    "financial-data-quality": "技能商店/财务报表深度解读/financial-statement",
    "research-event-calendar": "技能商店/催化剂日历",
}


def discover_skill_documents(skills_dir: Path = DEFAULT_SKILLS_DIR) -> list[dict[str, Any]]:
    """Read project Skill frontmatter without executing instructions in the documents."""
    documents: list[dict[str, Any]] = []
    if not skills_dir.exists():
        return documents
    for skill_file in sorted(skills_dir.glob("*/SKILL.md")):
        text = skill_file.read_text(encoding="utf-8")
        header = text.split("---", 2)[1] if text.startswith("---") and text.count("---") >= 2 else ""
        fields: dict[str, str] = {}
        for line in header.splitlines():
            if ":" not in line:
                continue
            key, value = line.split(":", 1)
            fields[key.strip()] = value.strip().strip("'\"")
        name = fields.get("name") or skill_file.parent.name
        documents.append({
            "name": name,
            "description": fields.get("description", ""),
            "path": str(skill_file),
            "executable": name in REMOTE_SKILL_DOMAINS,
            "role": (
                "execution" if name in REMOTE_SKILL_DOMAINS
                else "planning" if name in PLANNING_SKILL_SOURCES
                else "reference"
            ),
            "source_material": PLANNING_SKILL_SOURCES.get(name),
        })
    return documents


PLAYBOOK_FILENAME = "PLAYBOOK.json"


def load_skill_playbook(document_path: str | None) -> dict[str, Any]:
    """读取技能目录下的使用手册；缺失或损坏时返回空字典（不阻断技能加载）。"""
    if not document_path:
        return {}
    path = Path(document_path).parent / PLAYBOOK_FILENAME
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def discover_executable_skills(skills_dir: Path = DEFAULT_SKILLS_DIR) -> tuple[SkillSpec, ...]:
    specs: list[SkillSpec] = []
    for document in discover_skill_documents(skills_dir):
        name = document["name"]
        if name not in REMOTE_SKILL_DOMAINS:
            continue
        endpoint = (
            "/v1/comprehensive/search"
            if name in {"announcement-search", "news-search", "report-search"}
            else "/v1/query2data"
        )
        specs.append(SkillSpec(
            name=name,
            skill_id=name,
            version="1.0.0",
            domain=REMOTE_SKILL_DOMAINS[name],
            endpoint=endpoint,
            description=document["description"],
            source_path=document["path"],
            playbook=load_skill_playbook(document["path"]),
        ))
    return tuple(specs)


class Gateway(Protocol):
    async def call(
        self,
        spec: SkillSpec,
        arguments: dict[str, Any],
        *,
        call_type: str,
        trace_id: str,
        excluded_keys: set[str] | None = None,
    ) -> Any: ...


def _extract_records(payload: Any, keys: tuple[str, ...]) -> list[dict[str, Any]]:
    if not isinstance(payload, dict):
        return []
    for key in keys:
        candidate = payload.get(key)
        if isinstance(candidate, list):
            return [item for item in candidate if isinstance(item, dict)]
        if isinstance(candidate, dict):
            for nested_key in ("items", "list", "records", "datas", "result", "results", "data"):
                nested = candidate.get(nested_key)
                if isinstance(nested, list):
                    return [item for item in nested if isinstance(item, dict)]
    return []


def classify_raw_response(payload: Any) -> str:
    """原始网关响应形态分类（2026-11-10 空召回治理）。

    - rows:       问财结构化响应且 datas 有行
    - text:       文本技能（news/report/announcement）的 data 有内容
    - gateway_null: 网关 200 但响应体是 null（词槽无法解析）
    - empty:      有响应壳但确实 0 行
    - other:      无法解析的非对象载荷

    旧审计把「data 有内容的文本技能响应」也算空召回（SEMI-Q3 实测 54% 空
    召回率里 228/237 是这种误计），治理第一步就是把口径掰正。
    """
    if payload is None:
        return "gateway_null"
    if not isinstance(payload, dict):
        return "other"
    datas = payload.get("datas")
    if isinstance(datas, list) and datas:
        return "rows"
    data = payload.get("data")
    if isinstance(data, list) and data:
        return "text"
    if isinstance(datas, list) or isinstance(data, list):
        return "empty"
    # 有响应壳（query/columns/QTime 等）但没有任何行键
    return "empty" if ("query" in payload or "columns" in payload or "QTime" in payload) else "other"


def record_query_telemetry(
    task_id: str,
    skill_name: str,
    domain: str,
    original_query: str,
    relaxed_query: str | None,
    success: bool,
    row_count: int,
    stage: str,
    error: str | None = None,
    telemetry_file: Path | None = None,
) -> None:
    """Record query performance and zero-result anomalies for continuous benchmark expansion."""
    try:
        if telemetry_file is None:
            telemetry_dir = Path(__file__).resolve().parents[3] / "scratch"
            telemetry_dir.mkdir(parents=True, exist_ok=True)
            telemetry_file = telemetry_dir / "iwencai_query_telemetry.jsonl"
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "task_id": task_id,
            "skill_name": skill_name,
            "domain": domain,
            "stage": stage,
            "success": success,
            "row_count": row_count,
            "error_present": bool(error),
            # 2026-11-10 问财技能体检：账本不落原始 query/error（安全不变量，
            # 防凭证/用户内容泄漏——见 test_telemetry_omits_queries…）。空召回
            # 分析需要「同 query 关联」：用指纹（sha256 截断）替代明文。
            "query_fingerprint": sha256(
                f"{original_query or ''}|{relaxed_query or ''}".encode("utf-8", "ignore")
            ).hexdigest()[:16],
            "relaxed_changed": bool(relaxed_query and relaxed_query != original_query),
        }
        with open(telemetry_file, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception:
        pass


def relax_level1_predicates(query: str) -> str:
    """Level 1: Strip restrictive numerical inequalities, ranking bounds, and superfluous natural language."""
    # 1. 剔除括号内修饰说明内容，如（eVTOL 无人机通航基础设施）
    relaxed = re.sub(r"[（\(][^）\)]*[）\)]", "", query)
    # 2. 剔除标点符号并替换为空格
    relaxed = re.sub(r"[，。！？；、,;!?]+", " ", relaxed)
    # 3. 剔除自然语言引导废话（保留核心材料/核心技术等专业名词）
    relaxed = re.sub(
        r"(?:请|帮我|详细|全面|深入|最新(?=数据|信息|情况|行业)|核心(?=企业|龙头|标的|公司)|代表性|龙头|主营业务与|高度相关|企业按|按A股|取前\d+~\d+家|取前\d+家|前\d+~\d+家|排名前\d+家)",
        "",
        relaxed,
    )
    # 4. 剥离严苛的数值阈值过滤条件（长单位优先，如亿元优先于亿），避免过度约束导致零召回
    relaxed = re.sub(
        r"(?:最新)?(?:总市值|a股流通市值|流通市值|市值|动态市盈率|静态市盈率|市盈率|市净率|市销率|最新涨跌幅|涨跌幅|成交额|换手率|收盘价|最新价)\s*(?:大于|小于|高于|低于|>=|<=|>|<|=)\s*[0-9\.]+\s*(?:亿元|万元|万|亿|%|倍)?",
        "",
        relaxed,
    )
    # 4b. 剥离排序短语（2026-11-10 空召回治理：docstring 本就承诺剥离 ranking
    # bounds，但旧正则漏了排序后缀，T03 类细分选股 query 三级自愈全部 no-op
    # ——L1/L2/L3 都返回原句导致候选被跳过）。排序只影响返回顺序不影响命中
    # 集合，剥离语义保守。
    relaxed = re.sub(
        r"按(?:最新)?(?:总市值|a股流通市值|流通市值|市值|涨跌幅|最新涨跌幅|市盈率|"
        r"动态市盈率|静态市盈率|成交额|换手率|收盘价|最新价)(?:降序|升序|倒序|顺序)",
        "",
        relaxed,
    )
    # 5. 合并多余空白
    relaxed = re.sub(r"[ \t]+", " ", relaxed).strip()
    return relaxed or query


_METRIC_AND_ATTRIBUTE_KEYWORDS = (
    "市盈率", "市净率", "市销率", "pe", "pb", "ps", "pe_ttm", "pe_lyr",
    "涨跌幅", "板块排名", "行业排名", "区间涨跌幅", "排名",
    "营业收入", "营业总收入", "营收", "主营业务收入", "净利润", "归母净利润", "扣非净利润",
    "毛利率", "销售毛利率", "综合毛利率", "净利率", "销售净利率", "净资产收益率", "roe", "roa", "roic",
    "总资产", "总负债", "资产负债率", "资产总计", "负债合计",
    "现金流", "经营现金流", "经营活动产生的现金流量净额", "研发费用", "研发投入",
    "总市值", "流通市值", "a股流通市值", "最新价", "收盘价", "换手率", "成交额", "成交量", "振幅",
    "分红", "股息率", "每股收益", "每股净资产", "eps", "bps",
    "流动比率", "速动比率", "主营业务", "主营构成", "分产品收入占比", "分产品",
    "工业增加值", "国内生产总值", "gdp", "cpi", "ppi",
    "当月同比", "当季同比", "同比增长", "环比增长", "月度", "季度", "半年度", "年度",
    "近1年", "近2年", "近3年", "近4年", "近5年", "近3个月", "近6个月",
)

_TAIL_MODIFIERS = {
    "A股", "a股", "按总市值降序", "按市值降序", "按涨跌幅降序", "按动态市盈率升序", "按市盈率升序"
}


def _is_metric_or_attribute_token(token: str) -> bool:
    """Detect whether a token is a financial metric, ranking attribute, or temporal constraint."""
    t = re.sub(r"[\(\[（].*?[\)\]）]", "", token).strip().lower()
    if not t:
        return True
    if any(k == t for k in _METRIC_AND_ATTRIBUTE_KEYWORDS):
        return True
    if any(
        t.startswith(k) or t.endswith(k)
        for k in (
            "市盈率", "市净率", "市销率", "涨跌幅", "排名", "营业收入",
            "净利润", "毛利率", "净利率", "增加值", "同比", "环比",
        )
    ):
        return True
    return False


def _clean_subject_term(term: str) -> str:
    """Normalize subject terms by stripping generic domain suffixes like '行业' or '概念'."""
    cleaned = re.sub(r"(?:行业|板块|概念|赛道|产业|制造业|指数)$", "", term).strip()
    return cleaned if len(cleaned) >= 2 else term


def relax_level2_disjunction(query: str) -> str:
    """Level 2: Convert space-separated concepts into '或' disjunction to break iWenCai strict AND trap.

    Crucially isolates business concepts from financial metric names (e.g. 市盈率, 市净率, 涨跌幅)
    so metrics are NEVER joined with '或' clauses, which would cause cross-industry giant pollution.
    """
    cleaned = relax_level1_predicates(query)
    tokens = cleaned.split()
    if len(tokens) <= 1:
        return cleaned

    tail_modifiers: list[str] = []
    subject_tokens: list[str] = []

    for t in tokens:
        if t in _TAIL_MODIFIERS:
            tail_modifiers.append(t)
        elif _is_metric_or_attribute_token(t):
            continue
        else:
            subject_tokens.append(t)

    if not tail_modifiers:
        tail_modifiers = ["A股", "按总市值降序"]

    cleaned_subjects = [
        _clean_subject_term(s)
        for s in subject_tokens
        if _clean_subject_term(s) and _clean_subject_term(s) not in ("或", "or", "OR")
    ]

    # 多概念（例如：动力电池 正负极材料 电解液）转换为或连接
    if len(cleaned_subjects) >= 2:
        disjunction = " 或 ".join(cleaned_subjects)
        return f"{disjunction} {' '.join(tail_modifiers)}"
    elif len(cleaned_subjects) == 1:
        # 单一概念（例如：光模块行业 剥离后缀为 光模块），直接保留核心词，绝不将指标转化为'或'分支
        return f"{cleaned_subjects[0]} {' '.join(tail_modifiers)}"

    return cleaned


def relax_level3_domain_meta_fallback(query: str, domain: Domain) -> str:
    """Level 3: Universal domain meta-template fallback extracting the primary core noun."""
    # 提取核心主题：若包含“关于...的”，提取中间；若有空格切分，取第一个实词；否则按常见长短截断
    m = re.search(r"关于(.+?)的", query)
    if m:
        subject = m.group(1).strip()
    else:
        tokens = [
            t for t in re.split(r"[\s,;]+", query)
            if t and t not in ("A股", "a股", "按总市值降序", "最新", "包含", "查询") and not _is_metric_or_attribute_token(t)
        ]
        if tokens:
            subject = tokens[0][:30]
        else:
            subject = "核心产业"

    subject = _clean_subject_term(subject)

    if domain in (Domain.COMPANIES, Domain.INDUSTRY):
        return f"{subject} A股 按总市值降序"
    elif domain == Domain.REPORTS:
        return f"{subject} 深度研究 行业分析"
    elif domain == Domain.NEWS:
        return f"{subject} 行业动态 市场趋势"
    elif domain == Domain.MACRO:
        return "国内生产总值:当季同比 季度 近3年"
    elif domain == Domain.INDUSTRY_CHAIN:
        return f"{subject} 主营构成 分产品收入占比"
    return f"{subject} A股"


def simplify_query(query: str) -> str:
    """Backward-compatible wrapper for Level 1 relaxation."""
    return relax_level1_predicates(query)


class IwencaiGateway:
    def __init__(self, settings: Settings | None = None) -> None:
        self.settings = settings or Settings.from_env()
        self._client: httpx.AsyncClient | None = None
        self._keys: list[str] = list(self.settings.iwencai_api_keys)
        if not self._keys and self.settings.iwencai_api_key:
            self._keys = [self.settings.iwencai_api_key]

    async def _http(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=self.settings.fetch_timeout_seconds)
        return self._client

    async def aclose(self) -> None:
        if self._client is not None:
            await self._client.aclose()

    async def call(
        self,
        spec: SkillSpec,
        arguments: dict[str, Any],
        *,
        call_type: str,
        trace_id: str,
        excluded_keys: set[str] | None = None,
    ) -> Any:
        if not self._keys:
            raise IwencaiAuthenticationError("IWENCAI_API_KEY is required for SkillHub execution")
        query = str(arguments["query"])
        if spec.endpoint.endswith("/search"):
            channel = (
                "report" if spec.skill_id == "report-search"
                else "announcement" if spec.skill_id == "announcement-search"
                else "news"
            )
            payload: dict[str, Any] = {
                "query": query,
                "channels": [channel],
                "app_id": "AIME_SKILL",
                "size": int(arguments.get("size", 10)),
            }
        else:
            payload = {
                "query": query,
                "page": str(arguments.get("page", 1)),
                "limit": str(arguments.get("limit", 10)),
                "is_cache": "1",
                "expand_index": "true",
            }
        num_keys = len(self._keys)
        last_auth_error: Exception | None = None
        # 2026-11-10 用户决策：问财 key 配额由服务端**每日刷新**，项目侧不做
        # 跨任务 / 跨天的记忆（避免与上游重置时间错位，把已复活的 key 锁死）。
        # 但单个任务内，key 一旦返回「次数已用完」即跳过不再用——excluded_keys
        # 由任务持有、随任务丢弃；其余 401/403/429 仍走下方既有退避轮换。
        excluded = excluded_keys if excluded_keys is not None else set()
        candidates = [i for i in range(num_keys) if self._keys[i] not in excluded]
        if not candidates:
            # 本任务已排除全部 key：不再发起请求，如实上抛。
            raise IwencaiAuthenticationError(
                f"Iwencai daily quota exhausted on all {num_keys} keys (task-scoped exclusion)"
            )

        for round_idx, key_idx in enumerate(candidates):
            active_key = self._keys[key_idx]
            headers = {
                "Authorization": f"Bearer {active_key}",
                "Content-Type": "application/json",
                "X-Claw-Call-Type": call_type,
                "X-Claw-Skill-Id": spec.skill_id,
                "X-Claw-Skill-Version": spec.version,
                "X-Claw-Plugin-Id": "none",
                "X-Claw-Plugin-Version": "none",
                "X-Claw-Trace-Id": trace_id,
            }
            request_started = monotonic()
            response = None
            outcome = 'response'
            # B23-T4：先过全局冷却窗口，避免同批并发一起撞 401。
            await await_auth_window()
            try:
                response = await (await self._http()).post(
                    f"{self.settings.iwencai_base_url}{spec.endpoint}", json=payload, headers=headers
                )
                if response.status_code >= 400:
                    outcome = 'http_error'
                else:
                    try:
                        provider = response.json()
                        if isinstance(provider, dict) and provider.get('code') not in (0, '0', None, 200, '200'):
                            outcome = 'provider_error'
                    except (ValueError, TypeError):
                        outcome = 'invalid_response'
            except BaseException as exc:
                outcome = 'cancelled' if isinstance(exc, asyncio.CancelledError) else 'failed'
                raise
            finally:
                observer = _request_observer.get()
                if observer:
                    try:
                        await observer({'request_id': secrets.token_hex(16), 'trace_id': trace_id,
                            'elapsed_ms': round((monotonic() - request_started) * 1000, 2),
                            'http_status': response.status_code if response is not None else None,
                            'outcome': outcome})
                    except Exception:
                        pass
            if response.status_code in (401, 403, 429):
                # B23-T4：记录打击时刻，开启全局冷却窗口——同批其它请求
                # 在下一个 await_auth_window() 里会一起退，而不是轮流失败。
                note_auth_strike()
                if _is_daily_exhausted_text(response.text if response is not None else ""):
                    # 日配额尽：本任务内不再使用该 key，直接换下一把。
                    # （不退避——退避是给突发配额窗口恢复用的，对日配额无效。）
                    excluded.add(active_key)
                    last_auth_error = IwencaiAuthenticationError(
                        f"Iwencai daily quota exhausted (key {key_idx + 1}/{num_keys}); excluded for this task"
                    )
                    continue
                last_auth_error = IwencaiAuthenticationError(
                    f"Iwencai authentication/quota failed: HTTP {response.status_code} (key {key_idx + 1}/{num_keys})"
                )
                if round_idx < len(candidates) - 1:
                    # 2026-11-10 问财技能体检：401/403/429 多为突发配额而非 key 失效。
                    # 旧逻辑秒级换 key，把 3 个 key 在突发窗口内全烧掉（LA-Q3/Q4 实测
                    # 每任务 3 连 401、单秒 22 并发）。换 key 前退避，给配额窗口恢复时间。
                    await asyncio.sleep(0.6 * (round_idx + 1))
                    continue
                raise last_auth_error

            response.raise_for_status()
            data = response.json()
            if isinstance(data, dict):
                code = data.get("code")
                msg = str(data.get("message") or data.get("msg") or "").lower()
                if (code not in (0, "0", None, 200, "200") and any(term in msg for term in ("quota", "额度", "token", "auth", "permission", "unauthorized"))) or ("额度不足" in msg):
                    note_auth_strike()
                    if "额度" in msg or "已用完" in msg:
                        # 响应壳明示额度尽：同样任务内跳过该 key。
                        excluded.add(active_key)
                        last_auth_error = IwencaiAuthenticationError(
                            f"Iwencai daily quota exhausted (key {key_idx + 1}/{num_keys}); excluded for this task"
                        )
                        continue
                    last_auth_error = IwencaiAuthenticationError(
                        f"Iwencai quota/auth error response (key {key_idx + 1}/{num_keys})"
                    )
                    if round_idx < len(candidates) - 1:
                        await asyncio.sleep(0.6 * (round_idx + 1))
                        continue
                    raise last_auth_error
            return data

        if last_auth_error:
            raise last_auth_error


class SkillHub:
    def __init__(
        self,
        gateway: Gateway | None = None,
        *,
        concurrency: int | None = None,
        retry_backoff_seconds: float = 0.25,
        skills_dir: Path = DEFAULT_SKILLS_DIR,
    ) -> None:
        settings = Settings.from_env()
        self.gateway = gateway or IwencaiGateway(settings)
        self.skill_documents = discover_skill_documents(skills_dir)
        executable = discover_executable_skills(skills_dir)
        if not executable:
            raise SkillValidationError(f"no executable skills discovered under {skills_dir}")
        self.catalog = {spec.name: spec for spec in executable}
        for alias, target in CORE_SKILL_ALIASES.items():
            target_spec = self.catalog.get(target)
            if target_spec:
                self.catalog[alias] = target_spec.model_copy(update={"name": alias})
        self.concurrency = concurrency or settings.fetch_concurrency_limit
        self.retry_backoff_seconds = retry_backoff_seconds

    def validate_plan(self, tasks: list[SkillTask], completed_task_ids: set[str] | None = None) -> None:
        completed = completed_task_ids or set()
        ids = [task.task_id for task in tasks]
        if len(ids) != len(set(ids)):
            raise SkillValidationError("task_id values must be unique within a plan")
        for task in tasks:
            spec = self.catalog.get(task.skill_name)
            if spec is None:
                raise SkillValidationError(f"unregistered skill: {task.skill_name}")
            missing = [name for name in spec.required_arguments if not task.arguments.get(name)]
            if missing:
                raise SkillValidationError(f"task {task.task_id} missing arguments: {missing}")
            unknown = set(task.depends_on) - set(ids) - completed
            if unknown:
                raise SkillValidationError(f"task {task.task_id} has unknown dependencies: {sorted(unknown)}")
            if task.task_id in task.depends_on:
                raise SkillValidationError(f"task {task.task_id} cannot depend on itself")

        graph = {task.task_id: set(task.depends_on) & set(ids) for task in tasks}
        ready = [task_id for task_id, deps in graph.items() if not deps]
        visited: set[str] = set()
        while ready:
            current = ready.pop()
            if current in visited:
                continue
            visited.add(current)
            for task_id, deps in graph.items():
                if task_id not in visited and deps <= visited:
                    ready.append(task_id)
        if len(visited) != len(graph):
            raise SkillValidationError("task dependencies contain a cycle")

    async def execute_task(self, task: SkillTask) -> SkillResult:
        started = monotonic()
        result = await self._execute_task(task)
        result.elapsed_ms = round((monotonic() - started) * 1000, 2)
        return result

    async def _execute_task(self, task: SkillTask) -> SkillResult:
        spec = self.catalog[task.skill_name]
        trace_id = ""
        attempt_trace_ids: list[str] = []
        query = str(task.arguments["query"]).strip()
        arguments = dict(task.arguments)
        attempts = 0
        last_error: Exception | None = None
        received_empty = False
        # 2026-11-10 空召回治理：区分「网关 200+null 响应体」（词槽无法解析）
        # 与「响应壳 0 行」。同 query 重试救不了前者，留给规划器换姿势。
        last_payload_none = False
        # 2026-11-10 问财技能体检：突发配额（401/403/429）冷却后重试一次；
        # 持续鉴权失败仍向上抛，保留 run 级 iwencai_authentication_failed 熔断。
        auth_retries = 0
        # 2026-11-10：任务级 key 排除集——某 key 在本任务内返回「次数已用完」
        # 后，本任务后续所有尝试（网络重试 / 鉴权重试 / 自愈级联）不再使用它；
        # 任务结束即丢弃，不做跨任务 / 跨天记忆。
        excluded_keys: set[str] = set()

        for network_attempt in range(3):
            attempts += 1
            trace_id = secrets.token_hex(32)
            attempt_trace_ids.append(trace_id)
            try:
                payload = await self.gateway.call(
                    spec, arguments, call_type="normal" if network_attempt == 0 else "retry", trace_id=trace_id,
                    excluded_keys=excluded_keys,
                )
                last_payload_none = payload is None
                records = _extract_records(payload, spec.response_list_keys)
                if records:
                    return SkillResult(
                        task_id=task.task_id, skill_name=task.skill_name, skill_id=spec.skill_id,
                        skill_version=spec.version, domain=spec.domain, query=str(arguments["query"]),
                        trace_id=trace_id, attempt_trace_ids=attempt_trace_ids,
                        success=True, invocation_outcome="records", attempts=attempts, records=records,
                        raw_payload=payload,
                    )
                received_empty = True
                break
            except IwencaiAuthenticationError:
                if auth_retries >= 1 or network_attempt >= 2:
                    raise
                auth_retries += 1
                await asyncio.sleep(3.0)
                continue
            except (httpx.TimeoutException, httpx.NetworkError, httpx.RemoteProtocolError, httpx.HTTPStatusError) as exc:
                last_error = exc
                retryable_status = not isinstance(exc, httpx.HTTPStatusError) or exc.response.status_code in (429, 500, 502, 503, 504)
                if not retryable_status or network_attempt >= 2:
                    break
                await asyncio.sleep(self.retry_backoff_seconds * (2**network_attempt))
            except Exception as exc:
                last_error = exc
                break

        # 若直接返回 0 条记录且未发生网络/鉴权异常，启动全行业通用三级自愈级联
        if last_error is None:
            # 候选自愈语句阶梯
            heal_candidates = [
                ("level1_strip_bounds", relax_level1_predicates(query)),
                ("level2_or_disjunction", relax_level2_disjunction(query)),
                ("level3_domain_meta", relax_level3_domain_meta_fallback(query, spec.domain)),
            ]
            seen_queries = {query}

            for stage_name, relaxed_candidate in heal_candidates:
                if not relaxed_candidate or relaxed_candidate in seen_queries:
                    continue
                seen_queries.add(relaxed_candidate)
                attempts += 1
                arguments["query"] = relaxed_candidate
                trace_id = secrets.token_hex(32)
                attempt_trace_ids.append(trace_id)
                try:
                    payload = await self.gateway.call(
                        spec, arguments, call_type="retry", trace_id=trace_id, excluded_keys=excluded_keys
                    )
                    last_payload_none = payload is None
                    records = _extract_records(payload, spec.response_list_keys)
                    received_empty = received_empty or not records
                    if records:
                        record_query_telemetry(
                            task_id=task.task_id,
                            skill_name=task.skill_name,
                            domain=spec.domain.value,
                            original_query=query,
                            relaxed_query=relaxed_candidate,
                            success=True,
                            row_count=len(records),
                            stage=stage_name,
                        )
                        return SkillResult(
                            task_id=task.task_id,
                            skill_name=task.skill_name,
                            skill_id=spec.skill_id,
                            skill_version=spec.version,
                            domain=spec.domain,
                            query=relaxed_candidate,
                            trace_id=trace_id,
                            attempt_trace_ids=attempt_trace_ids,
                            success=True,
                            invocation_outcome="records",
                            attempts=attempts,
                            records=records,
                            raw_payload=payload,
                        )
                except Exception as exc:
                    last_error = exc

        # 若三级自愈后仍无数据或报错，写入遥测账本
        record_query_telemetry(
            task_id=task.task_id,
            skill_name=task.skill_name,
            domain=spec.domain.value,
            original_query=query,
            relaxed_query=str(arguments.get("query")),
            success=False,
            row_count=0,
            stage="exhausted",
            error=(_safe_error_label(last_error) if last_error else
                   ("gateway_null_body" if last_payload_none else "Skill returned no records after 3-level self-healing")),
        )

        return SkillResult(
            task_id=task.task_id,
            skill_name=task.skill_name,
            skill_id=spec.skill_id,
            skill_version=spec.version,
            domain=spec.domain,
            query=str(arguments["query"]),
            trace_id=trace_id or secrets.token_hex(32),
            attempt_trace_ids=attempt_trace_ids,
            retrieved_at=datetime.now(timezone.utc),
            success=False,
            invocation_outcome="success_empty" if received_empty else "failed",
            attempts=attempts,
            error=(_safe_error_label(last_error) if last_error else
                   ("gateway_null_body" if last_payload_none else "Skill returned no records after 3-level self-healing")),
        )

    async def execute_plan(
        self,
        tasks: list[SkillTask],
        *,
        completed_task_ids: set[str] | None = None,
        on_result: Callable[[SkillResult], Awaitable[None]] | None = None,
        on_request: Callable[[dict[str, Any]], Awaitable[None]] | None = None,
    ) -> list[SkillResult]:
        completed = set(completed_task_ids or set())
        self.validate_plan(tasks, completed)
        pending = {task.task_id: task for task in tasks}
        results: list[SkillResult] = []
        successful = set(completed)
        failed: set[str] = set()
        semaphore = asyncio.Semaphore(self.concurrency)
        task_elapsed: dict[str, float] = {}
        shared_calls: dict[tuple[str, str], asyncio.Future] = {}

        async def run_one(task: SkillTask) -> SkillResult:
            async with semaphore:
                started = monotonic()
                try:
                    key = (task.skill_name, json.dumps(task.arguments, ensure_ascii=False, sort_keys=True, default=str))
                    if key in shared_calls:
                        ok, value = await shared_calls[key]
                        if not ok:
                            raise value
                        return value.model_copy(update={'task_id':task.task_id, 'attempts':0, 'cache_hit':True,
                            'attempt_trace_ids': [], 'trace_id': '',
                            'elapsed_ms':round((monotonic() - started) * 1000, 2)})
                    future = asyncio.get_running_loop().create_future()
                    shared_calls[key] = future
                    sequence = 0
                    request_traces = []
                    async def observe_request(item):
                        nonlocal sequence
                        sequence += 1
                        request_traces.append(item.get('trace_id', ''))
                        if on_request:
                            await on_request({'task_id': task.task_id, 'skill_id': self.catalog[task.skill_name].skill_id,
                                              'attempt': sequence, **item})
                    token = _request_observer.set(observe_request)
                    try:
                        result = await self.execute_task(task)
                        future.set_result((True, result))
                        if not result.success:
                            shared_calls.pop(key, None)
                        return result
                    except BaseException as exc:
                        future.set_result((False, exc))
                        shared_calls.pop(key, None)
                        if isinstance(exc, asyncio.CancelledError) and on_result:
                            spec = self.catalog[task.skill_name]
                            try:
                                await on_result(SkillResult(task_id=task.task_id, skill_name=task.skill_name,
                                    skill_id=spec.skill_id, skill_version=spec.version, domain=spec.domain,
                                    query='', trace_id=request_traces[-1] if request_traces else '',
                                    attempt_trace_ids=list(dict.fromkeys(request_traces)), success=False,
                                    invocation_outcome='failed', attempts=sequence,
                                    elapsed_ms=round((monotonic()-started)*1000, 2), error='cancelled'))
                            except Exception:
                                pass
                        raise
                    finally:
                        _request_observer.reset(token)
                finally:
                    task_elapsed[task.task_id] = round((monotonic() - started) * 1000, 2)

        while pending:
            # 若依赖任务失败，但下游任务自身拥有独立完备的查询语句 (query)，
            # 说明其并不依赖上游输出参数，自愈剥离失败依赖后继续调度执行，避免级联击穿核心数据采集
            for task in list(pending.values()):
                failed_deps = set(task.depends_on) & failed
                if failed_deps:
                    query_val = str(task.arguments.get("query", "")).strip()
                    if query_val:
                        new_deps = [d for d in task.depends_on if d not in failed]
                        pending[task.task_id] = task.model_copy(update={"depends_on": new_deps})

            blocked = [
                task for task in pending.values() if set(task.depends_on) & failed
            ]
            for task in blocked:
                spec = self.catalog[task.skill_name]
                result = SkillResult(
                    task_id=task.task_id, skill_name=task.skill_name, skill_id=spec.skill_id,
                    skill_version=spec.version, domain=spec.domain,
                    query=str(task.arguments.get("query", "")), trace_id=secrets.token_hex(32),
                    success=False, attempts=0, error="dependency failed",
                )
                results.append(result)
                failed.add(task.task_id)
                pending.pop(task.task_id)
                if on_result:
                    await on_result(result)

            ready = [task for task in pending.values() if set(task.depends_on) <= successful]
            if not ready:
                if pending:
                    raise SkillValidationError("no executable tasks remain")
                break
            # ⚠️ 异常隔离（2026-10-17 B12）：旧实现是 ``gather`` 不带 return_exceptions，
            # 任一任务抛 IwencaiAuthenticationError（问财 401）会把**整批**任务一起带走——
            # 实测 12 个任务因 1 次 401 全部丢失，且 on_result 从未回调（事件流 0 条
            # tool_result / 0 条 warn），A1 只报「执行问财技能调度 0 次」，失败完全静默。
            # 这里把异常收敛成 success=False 的 SkillResult，保证「一条失败 ≠ 整批归零」。
            raw = await asyncio.gather(*(run_one(task) for task in ready),
                                       return_exceptions=True)
            batch = []
            for task, item in zip(ready, raw):
                if isinstance(item, asyncio.CancelledError):
                    raise item
                if isinstance(item, BaseException):
                    spec = self.catalog[task.skill_name]
                    item = SkillResult(
                        task_id=task.task_id,
                        skill_name=task.skill_name,
                        skill_id=spec.skill_id,
                        skill_version=spec.version,
                        domain=spec.domain,
                        query=str(task.arguments.get("query", "")),
                        trace_id=secrets.token_hex(32),
                        attempt_trace_ids=[],
                        retrieved_at=datetime.now(timezone.utc),
                        success=False,
                        attempts=1,
                        elapsed_ms=task_elapsed.get(task.task_id),
                        records=[],
                        error=_safe_error_label(item),
                    )
                batch.append(item)
            for result in batch:
                results.append(result)
                pending.pop(result.task_id)
                (successful if result.success else failed).add(result.task_id)
                if on_result:
                    await on_result(result)
        return results
