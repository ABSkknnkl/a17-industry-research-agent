"""行业画像复用：参考库未收录主题时，用 A3 画像给 A1/A2 提供确定性名单。

单一事实源仍在 `agents_core/chart-generator/chart_profiles/*.json`，这里只做只读
加载，避免 data-fetcher 直接依赖 chart_generator 包，也避免把五个行业硬编码进
取数 Agent。画像只提供**候选与主题关键词**，是否准入仍看公司主营文本。
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

_PROFILE_DIR = Path(__file__).resolve().parents[2] / "chart-generator" / "chart_profiles"


def profile_for_industry(industry: str) -> dict[str, Any] | None:
    """按 `_index.json` 顺序匹配画像；命中即返回，未命中返回 None。"""
    index_path = _PROFILE_DIR / "_index.json"
    try:
        order = json.loads(index_path.read_text(encoding="utf-8")).get("order") or []
    except Exception:
        return None
    subject = str(industry or "").casefold()
    if not subject:
        return None
    for key in order:
        path = _PROFILE_DIR / f"{key}.json"
        if not path.exists():
            continue
        try:
            prof = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        kws = [str(k).casefold() for k in (prof.get("kw") or [])]
        if any(k and k in subject for k in kws):
            return prof
    return None


def seed_names(profile: dict[str, Any] | None) -> list[str]:
    """画像中已人工维护的核心标的（品牌龙头 + 上游龙头），保持顺序去重。"""
    if not profile:
        return []
    names: list[str] = []
    seen: set[str] = set()
    for key in ("leading_brand", "leading_upstream"):
        for name in profile.get(key) or []:
            text = str(name).strip()
            if text and text not in seen:
                seen.add(text)
                names.append(text)
    return names


def theme_terms(profile: dict[str, Any] | None) -> list[str]:
    """只用画像关键词作为业务文本匹配词，排除通用环节词。"""
    if not profile:
        return []
    return [str(k).strip() for k in (profile.get("kw") or []) if len(str(k).strip()) >= 2]
