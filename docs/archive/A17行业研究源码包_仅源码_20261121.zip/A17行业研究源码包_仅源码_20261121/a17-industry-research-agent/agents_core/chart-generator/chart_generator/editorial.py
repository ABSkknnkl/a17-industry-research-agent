"""Evidence-preserving chart selection and reader-facing labels."""
from __future__ import annotations

from datetime import date
import re
from typing import Any

from .data_formulation import NormalizedDataTable
from .render import clean_metric_label

_MARKET_METRICS = {'pe', 'pe_ttm', 'pe_dynamic', 'pb', 'ps', 'latest_price',
                   '最新股价', '最新价', 'market_cap', 'circulating_market_cap', '最新涨跌幅'}


def metric_label(value: str) -> str:
    text = str(value).replace('：', ':')
    if '新能源汽车' in text and '销量' in text:
        if '插电' in text or '插混' in text:
            return '插混销量'
        if '纯电' in text:
            return '纯电销量'
        return '新能源汽车销量'
    return clean_metric_label(text)


def period_label(periods: list[str]) -> str:
    if periods and all(p.endswith('-12-31') for p in periods):
        years = sorted({p[:4] for p in periods})
        return (years[0] if len(years) == 1 else f'{years[0]}—{years[-1]}') + '年'
    return '至'.join([periods[0], periods[-1]]) if len(periods) > 1 else (periods[0] if periods else '期间未明确')


def refine_table(table: NormalizedDataTable, chart_type: str, evidence_index: dict[str, Any]) -> tuple[str, str | None]:
    """Choose geometry before points and units are committed to the contract."""
    refs = [evidence_index[rid] for rid in table.raw_evidence_ids if rid in evidence_index]
    periods = sorted({str(r.period) for r in refs if r.period})
    metrics = {r.metric for r in refs}
    temporal = table.axis_type.value == 'time_series'
    if chart_type == 'radar':
        units = set(table.series_units.values())
        if not units or not units.issubset({'分', '评分', '标准分'}):
            return chart_type, '雷达图缺少共同评分尺度与标准化依据，原始金额、股价及比率不混画'
    if temporal and chart_type in {'line', 'area', 'combo'} and len(periods) <= 2 and metrics & _MARKET_METRICS:
        if len(periods) < 2 or (date.fromisoformat(periods[-1])-date.fromisoformat(periods[0])).days <= 7:
            return chart_type, '行情快照不足以构成有解释力的趋势，改查同日指标表'
    if temporal and chart_type == 'combo' and len(periods) < 3 and len(set(table.series_units.values())) > 1:
        return chart_type, '仅有两期异量纲数据，不能支撑双轴趋势解读，改查年度指标表'
    if not temporal and chart_type in {'scatter', 'bubble'} and metrics and metrics.issubset(_MARKET_METRICS):
        if metrics & {'latest_price', '最新股价', '最新价'}:
            return chart_type, '股价与市值快照缺少明确业务比较目的，不生成散点或气泡图'
    if not temporal and (not refs or any(r.period is None for r in refs) or len(periods) != 1):
        return chart_type, '观测期间未对齐，不生成同期比较图；保留原始记录供核对'

    if temporal and periods and all(p.endswith('-12-31') for p in periods):
        first, last = int(periods[0][:4]), int(periods[-1][:4])
        if last-first <= 10:
            complete = [f'{year}-12-31' for year in range(first, last+1)]
            missing = [p for p in complete if p not in table.categories]
            if missing:
                positions = {p: i for i, p in enumerate(table.categories)}
                for field in ('series_data', 'point_evidence_ids', 'point_periods'):
                    empty = '' if field == 'point_evidence_ids' else None
                    setattr(table, field, {name: [items[positions[p]] if p in positions and positions[p] < len(items) else empty for p in complete]
                                          for name, items in getattr(table, field).items()})
                table.categories = complete
                table.quality_notes.append('、'.join(p[:4] for p in missing)+'年缺少数据，留空显示。')

    renames = {name: metric_label(name) for name in table.series_data if name in metrics}
    if renames:
        for field in ('series_data', 'series_units', 'point_evidence_ids', 'point_periods'):
            setattr(table, field, {renames.get(k, k): v for k, v in getattr(table, field).items()})
        table.primary_series_name = renames.get(table.primary_series_name, table.primary_series_name)
        table.secondary_series_name = renames.get(table.secondary_series_name, table.secondary_series_name)
    for name, values in table.series_data.items():
        finite = [abs(v) for v in values if v is not None]
        if table.series_units.get(name) == '辆' and finite and max(finite) >= 10000:
            table.series_data[name] = [round(v/10000, 8) if v is not None else None for v in values]
            table.series_units[name] = '万辆'

    if temporal and chart_type in {'line', 'area'}:
        observed = max((sum(v is not None for v in values) for values in table.series_data.values()), default=0)
        if observed < 3:
            chart_type = 'bar'
    if table.axis_type.value == 'entity_comparison' and chart_type in {'bar', 'comparison_bar', 'horizontal_bar'} and len(table.series_data) == 1:
        chart_type = 'horizontal_bar'
        values = table.series_data[table.primary_series_name]
        order = sorted(range(len(table.categories)), key=lambda i: (values[i] is None, -(values[i] or 0)))
        table.categories = [table.categories[i] for i in order]
        for field in ('series_data', 'point_evidence_ids', 'point_periods'):
            setattr(table, field, {name: [items[i] if i < len(items) else (None if field != 'point_evidence_ids' else '') for i in order]
                                  for name, items in getattr(table, field).items()})
    return chart_type, None


def describe_points(points: list[dict], temporal: bool) -> str:
    entities = {p['entity'] for p in points if p.get('entity')}
    periods = sorted({p['period'] for p in points if p.get('period')})
    metrics = list(dict.fromkeys(metric_label(p['metric']) for p in points))
    count = f'{len(entities)}个主体' if entities else f'{len(points)}个有据数据点'
    if temporal:
        period_kind = '年度' if periods and all(p.endswith('-12-31') for p in periods) else '观测期'
        return f'覆盖{count}、{len(periods)}个{period_kind}，展示{"、".join(metrics[:2])}；缺失值不补齐。'
    return f'对比{count}的{"、".join(metrics[:2])}；口径与观测日期一致。'


def public_notes(notes: list[str]) -> list[str]:
    result = []
    for note in notes:
        if note == '时序周期规范化对齐完成' or note.startswith(('横向对标归一化完成', '成功构建')):
            continue
        if note.startswith('研究基准日：') or '原始证据见图表数据契约' in note:
            continue
        if ('要求但缺失的年份' in note or '请求但缺失的年份' in note):
            years = re.findall(r'\b(?:19|20)\d{2}\b', note)
            if years:
                note = '、'.join(dict.fromkeys(years))+'年缺少数据，留空显示。'
        if note not in result:
            result.append(note)
    return result
