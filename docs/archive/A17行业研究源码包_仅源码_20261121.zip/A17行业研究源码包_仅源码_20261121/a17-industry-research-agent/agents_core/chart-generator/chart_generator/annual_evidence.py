"""Recheck stale annual NEV coverage against the current, traceable evidence index."""
from collections import defaultdict
import math
from agents_core.financial_semantics import metric_family
from .evidence_policy import isolate_anomalous_evidence


def annual_evidence_contract(report):
    annual_ids = defaultdict(set)
    incomplete = set()
    allowed, _ = isolate_anomalous_evidence(list(report.evidence_index), report)
    for row in (getattr(report, 'data_quality_appendix', {}) or {}).get('requirement_evidence_matrix', []):
        requirement, coverage = row.get('requirement', {}), row.get('coverage', {})
        if (not str(requirement.get('requirement_id', '')).startswith('annual_')
                or requirement.get('comparison_baseline') or not requirement.get('hard')):
            continue
        families = requirement.get('metric_families') or []
        ids = set(coverage.get('evidence_record_ids') or [])
        passed = bool(coverage.get('passed'))
        # Only the simple industry-total annual contract can be refreshed here.
        # Source-specific, financial, ratio and other scope gates retain their decisions.
        if (not passed and families == ['nev_sales'] and requirement.get('domain') == 'industry'
                and '新能源' in str(requirement.get('label') or '')
                and not any(requirement.get(key) for key in ('acceptable_skill_ids', 'expected_metric_groups',
                    'requires_entity_code', 'requires_published_at'))):
            ends = {str(end) for end in requirement.get('period_ends') or []}
            entities = set(requirement.get('entity_names') or [])
            current = []
            for rid in allowed:
                ref = report.evidence_index[rid]
                end = str(ref.period or '')
                metric = str(ref.metric or '').lower()
                if (end not in ends or not end.endswith('-12-31')
                        or str(ref.period_start or '') != end[:4]+'-01-01'
                        or ref.period_type not in ('annual', 'ytd_month') or ref.period_provenance != 'row'
                        or ref.domain != 'industry' or metric_family(metric) != 'nev_sales'
                        or ref.scope not in ('consolidated', 'total', 'national', '全国', '中国', '全口径')
                        or not ('新能源' in metric or 'nev' in metric)
                        or any(token in metric for token in ('纯电', '插电', '插混', '增程', '乘用车', '品牌', 'bev', 'phev', '同比', '增长'))
                        or ref.unit not in ('辆', '万辆', '千辆')
                        or not isinstance(ref.value, (int, float)) or isinstance(ref.value, bool) or not math.isfinite(ref.value)
                        or (entities and ref.entity not in entities)
                        or set(ref.issues or []).intersection({'period_conflict', 'review_excluded', 'unit_unknown', 'pending_restatement'})):
                    continue
                current.append(ref)
            ids.update(ref.record_id for ref in current)
            cells = {(str(ref.period), ref.entity) for ref in current}
            passed = bool(ends) and len(current) >= max(1, int(requirement.get('min_records') or 1)) and all(
                (all((end, entity) in cells for entity in entities) if entities
                 else any(period == end for period, _ in cells)) for end in ends)
        for family in families:
            annual_ids[family].update(ids)
            if not passed:
                incomplete.add(family)
    return annual_ids, incomplete
