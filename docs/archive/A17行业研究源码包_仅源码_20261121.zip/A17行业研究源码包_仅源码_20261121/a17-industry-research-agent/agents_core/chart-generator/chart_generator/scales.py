"""Canonical numeric scales shared by ECharts compilation and SVG publication."""
from __future__ import annotations

import math
from typing import Any

def _calc_ticks(low: float, high: float, num_ticks: int = 5) -> list[float]:
    if low == high:
        return [low]
    if low > high:
        low, high = high, low
    span = high - low
    raw_step = span / max(num_ticks - 1, 1)
    magnitude = 10 ** math.floor(math.log10(raw_step)) if raw_step > 0 else 1.0
    fraction = raw_step / magnitude
    if fraction < 1.5:
        step = 1.0 * magnitude
    elif fraction < 3.0:
        step = 2.0 * magnitude
    elif fraction < 7.0:
        step = 5.0 * magnitude
    else:
        step = 10.0 * magnitude
    start = math.floor(low / step) * step
    ticks = []
    curr = start
    while curr <= high + step * 0.001:
        ticks.append(round(curr, 6))
        curr += step
    if ticks and ticks[-1] < high - step * 1e-6:
        ticks.append(round(ticks[-1] + step, 6))
    return ticks if len(ticks) >= 2 else [low, high]


def _nice_num(val: float, round_up: bool = True) -> float:
    if val <= 0:
        return 1.0
    exp = math.floor(math.log10(val))
    f = val / (10 ** exp)
    if round_up:
        if f <= 1.0: nf = 1.0
        elif f <= 2.0: nf = 2.0
        elif f <= 2.5: nf = 2.5
        elif f <= 5.0: nf = 5.0
        else: nf = 10.0
    else:
        if f >= 10.0: nf = 10.0
        elif f >= 5.0: nf = 5.0
        elif f >= 2.5: nf = 2.5
        elif f >= 2.0: nf = 2.0
        else: nf = 1.0
    return nf * (10 ** exp)


def _calc_dual_ticks(
    l_min: float, l_max: float,
    r_min: float, r_max: float,
    num_intervals: int = 5
) -> tuple[list[float], list[float]]:
    """
    Computes synchronized ticks for dual-axis charts so that tick 0 sits at the
    exact same tick index on both left and right axes.
    """
    has_neg = (l_min < 0 or r_min < 0)
    if not has_neg:
        s_l = _nice_num(max(l_max, 1e-6) / num_intervals, round_up=True)
        s_r = _nice_num(max(r_max, 1e-6) / num_intervals, round_up=True)
        l_ticks = [round(i * s_l, 6) for i in range(num_intervals + 1)]
        r_ticks = [round(i * s_r, 6) for i in range(num_intervals + 1)]
        return l_ticks, r_ticks

    # Determine best (n_neg, n_pos) split where n_neg + n_pos == num_intervals
    best_pair = (1, num_intervals - 1)
    best_waste = float("inf")

    for n_neg in range(1, num_intervals):
        n_pos = num_intervals - n_neg
        req_sl = max(max(0.0, -l_min) / n_neg, max(0.0, l_max) / n_pos)
        req_sr = max(max(0.0, -r_min) / n_neg, max(0.0, r_max) / n_pos)
        sl = _nice_num(req_sl, round_up=True)
        sr = _nice_num(req_sr, round_up=True)

        tot_l = num_intervals * sl
        tot_r = num_intervals * sr
        act_l = max(l_max, 0.0) + max(-l_min, 0.0) or 1.0
        act_r = max(r_max, 0.0) + max(-r_min, 0.0) or 1.0
        waste = (tot_l / act_l) + (tot_r / act_r)

        if waste < best_waste:
            best_waste = waste
            best_pair = (n_neg, n_pos)

    n_neg, n_pos = best_pair
    req_sl = max(max(0.0, -l_min) / n_neg, max(0.0, l_max) / n_pos)
    req_sr = max(max(0.0, -r_min) / n_neg, max(0.0, r_max) / n_pos)
    sl = _nice_num(req_sl, round_up=True)
    sr = _nice_num(req_sr, round_up=True)

    l_ticks = [round((-n_neg + i) * sl, 6) for i in range(num_intervals + 1)]
    r_ticks = [round((-n_neg + i) * sr, 6) for i in range(num_intervals + 1)]
    return l_ticks, r_ticks



def _finite(value: Any) -> float | None:
    if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value):
        return float(value)
    return None


def specified_ticks(axis: Any) -> list[float] | None:
    if not isinstance(axis, dict):
        return None
    low, high, step = (_finite(axis.get(key)) for key in ('min','max','interval'))
    if low is None or high is None or step is None or high <= low or step <= 0:
        return None
    count = (high-low)/step
    if not math.isfinite(count) or not 1 <= count <= 1000 or not math.isclose(count, round(count), abs_tol=1e-7):
        return None
    return [float(f'{low+i*step:.12g}') for i in range(round(count)+1)]


def ticks_for_axis(axis: Any, low: float, high: float) -> list[float]:
    fixed = specified_ticks(axis)
    if fixed is not None:
        return fixed
    if low == high:
        high = low + max(abs(low)*.1, 1.0)
    return _calc_ticks(low, high, 5)


def _axis_series(series: list[Any], dimension: str, index: int) -> list[dict[str, Any]]:
    return [
        entry
        for entry in series
        if isinstance(entry, dict)
        and int(entry.get(dimension + 'AxisIndex', 0) or 0) == index
    ]


def _axis_values(series: list[dict[str, Any]], dimension: str) -> list[float]:
    values: list[float] = []
    for entry in series:
        for item in entry.get('data') or []:
            value = item.get('value') if isinstance(item, dict) else item
            if isinstance(value, (list, tuple)):
                position = 0 if dimension == 'x' else 1
                value = value[position] if len(value) > position else None
            numeric = _finite(value)
            if numeric is not None:
                values.append(numeric)
    return values


def _axis_has_zero_baseline(series: list[dict[str, Any]]) -> bool:
    """Bars and filled areas encode magnitude from zero; lines do not."""
    return any(
        str(entry.get('type') or '').lower()
        in {'bar', 'horizontal_bar', 'area', 'boxplot', 'candlestick', 'pictorialbar'}
        for entry in series
    )


def _adaptive_ticks(low: float, high: float, include_zero: bool) -> list[float]:
    """Return a readable tick set that follows the data when zero is not required."""
    if low == high:
        pad = max(abs(low) * 0.1, 1.0)
        low, high = low - pad, high + pad

    if include_zero:
        low, high = min(0.0, low), max(0.0, high)
        return _calc_ticks(low, high, 5)

    span = high - low
    if span <= 0:
        span = max(abs(high), 1.0)
    positive_only = low >= 0
    pad = span * 0.03
    low -= pad
    high += pad
    if positive_only and low < 0:
        low = 0.0

    # Data hugging zero is still best read against a zero baseline.
    if low >= 0 and low < (high - low) * 0.08:
        return _calc_ticks(0.0, high, 5)
    if low < 0 and high <= 0:
        return _calc_ticks(low, high, 5)

    # Prefer nice steps that keep the first tick above zero instead of
    # squeezing the whole series into a zero-based axis.
    raw_step = (high - low) / 4
    candidates = {
        round(base / factor, 12)
        for base in (_nice_num(raw_step, True), _nice_num(raw_step, False))
        for factor in (1.0, 2.0, 5.0, 10.0)
    }
    best: tuple[float, float, int] | None = None
    best_score = float('inf')
    data_span = max(high - low, 1e-9)
    for step in candidates:
        if step <= 0:
            continue
        start = math.floor(low / step) * step
        count = math.ceil((high - start) / step)
        if start > 0 and 3 <= count <= 10:
            score = (start + count * step - low) / data_span + abs(count - 5) * 0.02
            if score < best_score:
                best_score = score
                best = (start, step, count)

    if best is not None:
        start, step, count = best
        return [round(start + i * step, 10) for i in range(count + 1)]

    # Fallback: keep the actual lower bound and spread four even intervals.
    step = (high - low) / 4
    return [round(low + i * step, 10) for i in range(5)]


def apply_axis_scales(option: dict[str, Any]) -> dict[str, Any]:
    """Freeze every numeric axis to a data-aware range shared by ECharts and SVG."""
    series = option.get('series') or []
    series = series if isinstance(series, list) else [series]
    for dimension in ('x', 'y'):
        axes = option.get(dimension + 'Axis') or []
        axes = axes if isinstance(axes, list) else [axes]
        for index, axis in enumerate(axes):
            if (
                not isinstance(axis, dict)
                or axis.get('type') == 'category'
                or axis.get('type') == 'log'
                or (not axis.get('type') and 'data' in axis)
            ):
                continue
            axis_series = _axis_series(series, dimension, index)
            values = _axis_values(axis_series, dimension)
            if not values:
                continue

            # Preserve an explicitly authored, complete tick spec.
            if specified_ticks(axis) is not None:
                continue

            include_zero = _axis_has_zero_baseline(axis_series)
            low, high = min(values), max(values)
            ticks = _adaptive_ticks(low, high, include_zero)
            step = ticks[1] - ticks[0]
            if step <= 0:
                continue
            axis.update(min=ticks[0], max=ticks[-1], interval=step, splitNumber=len(ticks) - 1)
    return option
