"""B41：horizontal_bar / diverging_bar 多系列编译修复（红→绿）。

缺陷（run-20261111154718 低空经济 CHART-01/02）：
``EChartsCompiler._compile_horizontal_bar`` / ``_compile_diverging_bar``
只编译 ``table.primary_series_name`` 单系列；当数据整形产出
「期间为类别、多实体为系列」（如 宗申动力+纵横股份 × 2024+2025）的表时，
option.series 只含第一系列，渲染静默丢失其余实体，data_contract 却保留
全量点 → 一致性审计报「渲染系列与数据点契约不一致」并拒收图表。

修复：多系列时按 ``_compile_bar`` 的既有模式遍历 ``series_data``
编译分组条形（渲染器 render.py 多系列横向分支原生支持）；
单系列路径（离群 markPoint、正负双色）保持原行为不变。
"""
from __future__ import annotations

import pytest

from chart_generator.compiler import EChartsCompiler
from chart_generator.data_formulation import AxisType, NormalizedDataTable
from chart_generator.render import render_svg


def _table(**overrides) -> NormalizedDataTable:
    base: dict = {
        "axis_type": AxisType.TIME_SERIES,
        "x_field_name": "报告期",
        "categories": ["2024-12-31", "2025-12-31"],
        "series_data": {"宗申动力": [103.8, 123.1], "纵横股份": [4.7, 6.2]},
        "series_units": {"宗申动力": "亿元", "纵横股份": "亿元"},
        "primary_series_name": "宗申动力",
    }
    base.update(overrides)
    return NormalizedDataTable(**base)


# --------------------------------------------------------------------------
# horizontal_bar 多系列
# --------------------------------------------------------------------------


def test_horizontal_bar_multi_series_compiles_all_series():
    opt = EChartsCompiler.compile(_table(), "horizontal_bar", "多系列横向条形")
    series = opt["series"]
    assert [s["name"] for s in series] == ["宗申动力", "纵横股份"]
    assert series[0]["data"] == [103.8, 123.1]
    assert series[1]["data"] == [4.7, 6.2]
    # 点数与 data_contract 对齐：类别 × 系列
    assert sum(len(s["data"]) for s in series) == 4
    assert opt["yAxis"]["data"] == ["2024-12-31", "2025-12-31"]


def test_horizontal_bar_multi_series_no_cross_unit_axis():
    """多系列单位不一致时必须拒绝编译（R3 §6.3.3，与 _compile_bar 同约束）。"""
    with pytest.raises(ValueError):
        EChartsCompiler.compile(
            _table(series_units={"宗申动力": "亿元", "纵横股份": "万元"}),
            "horizontal_bar",
            "多系列横向条形",
        )


def test_horizontal_bar_multi_series_none_values_kept():
    opt = EChartsCompiler.compile(
        _table(series_data={"宗申动力": [103.8, None], "纵横股份": [4.7, 6.2]}),
        "horizontal_bar",
        "多系列横向条形",
    )
    assert opt["series"][0]["data"] == [103.8, None]


# --------------------------------------------------------------------------
# diverging_bar 多系列
# --------------------------------------------------------------------------


def test_diverging_bar_multi_series_compiles_all_series():
    opt = EChartsCompiler.compile(
        _table(series_data={"纵横股份": [-0.36, 0.11], "宗申动力": [4.61, 6.66]}),
        "diverging_bar",
        "多系列正负条形",
    )
    series = opt["series"]
    assert [s["name"] for s in series] == ["纵横股份", "宗申动力"]
    assert sum(len(s["data"]) for s in series) == 4
    # 每系列内部保留正负双色 itemStyle
    assert series[0]["data"][0]["itemStyle"]["color"] != series[0]["data"][1]["itemStyle"]["color"]


# --------------------------------------------------------------------------
# 单系列原行为回归
# --------------------------------------------------------------------------


def test_horizontal_bar_single_series_keeps_outlier_markpoint():
    """单系列大离群（max > 5×median 且 ≥100）仍编译 markPoint。"""
    table = _table(
        categories=["A", "B", "C", "D", "E"],
        series_data={"北方华创": [10.0, 12.0, 11.0, 13.0, 900.0]},
        series_units={"北方华创": "亿元"},
        primary_series_name="北方华创",
    )
    opt = EChartsCompiler.compile(table, "horizontal_bar", "单系列横向条形")
    assert len(opt["series"]) == 1
    assert "markPoint" in opt["series"][0]


def test_diverging_bar_single_series_keeps_pos_neg_colors():
    table = _table(
        categories=["2024", "2025"],
        series_data={"净利润增速": [5.0, -3.0]},
        series_units={"净利润增速": "%"},
        primary_series_name="净利润增速",
    )
    opt = EChartsCompiler.compile(table, "diverging_bar", "单系列正负条形")
    assert len(opt["series"]) == 1
    colors = {d["itemStyle"]["color"] for d in opt["series"][0]["data"]}
    assert len(colors) == 2  # 正/负双色


# --------------------------------------------------------------------------
# 端到端：SVG 渲染包含全部系列的数值（缺陷复现场景）
# --------------------------------------------------------------------------


def test_render_svg_multi_series_horizontal_bar_draws_all_points():
    table = _table()
    opt = EChartsCompiler.compile(table, "horizontal_bar", "多系列横向条形")
    svg = render_svg("低空经济营业收入趋势", "horizontal_bar", opt, ["附注"])
    # 4 个数据条数值全部可见（修复前只渲染第一系列的 2 个）
    for val in ("103.8", "123.1", "4.7", "6.2"):
        assert val in svg, f"系列数值 {val} 未出现在渲染 SVG 中"


def test_render_svg_multi_series_diverging_bar_draws_all_points():
    table = _table(series_data={"纵横股份": [-0.36, 0.11], "宗申动力": [4.61, 6.66]})
    opt = EChartsCompiler.compile(table, "diverging_bar", "多系列正负条形")
    svg = render_svg("低空经济归母净利润趋势", "diverging_bar", opt, ["附注"])
    for val in ("-0.36", "0.11", "4.6", "6.7"):
        assert val in svg, f"系列数值 {val} 未出现在渲染 SVG 中"
