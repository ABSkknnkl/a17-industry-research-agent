from chart_generator import ChartGeneratorAgent
from chart_generator.agent import _Candidate
from chart_generator.models import InterpretationReport


def ref(rid, entity, metric, value, unit, period, period_type='annual'):
    return dict(record_id=rid, domain='financials', entity=entity, metric=metric,
                value=value, unit=unit, period=period, period_type=period_type,
                period_provenance='field')


def verify(rows, chart_type='line'):
    report = InterpretationReport.model_validate(dict(report_id='clarity', subject='新能源汽车',
        as_of='2026-11-18', status='completed', evidence_index={r['record_id']: r for r in rows}))
    candidate = _Candidate('旧标题', chart_type, {}, list(report.evidence_index), '', 'CH-02')
    reason = ChartGeneratorAgent()._verify_numeric_candidate(candidate, report)
    return candidate, reason


def test_reject_raw_mixed_unit_radar():
    rows = [ref('r1', '比亚迪', 'revenue', 6e11, '元', '2025-12-31'),
            ref('r2', '比亚迪', 'roe', 24, '%', '2025-12-31'),
            ref('r3', '比亚迪', 'pb', 3, '倍', '2025-12-31')]
    _, reason = verify(rows, 'radar')
    assert reason and '雷达图' in reason


def test_reject_two_day_market_snapshot_trend():
    rows = [ref('r1', '比亚迪', 'pe_dynamic', 24, '倍', '2026-11-17', 'point'),
            ref('r2', '比亚迪', 'pe_dynamic', 24.00001, '倍', '2026-11-18', 'point')]
    _, reason = verify(rows)
    assert reason and '行情' in reason


def test_sparse_annual_series_becomes_bar_without_filling_missing_year():
    rows = [ref('r1', '比亚迪', 'revenue', 6e11, '元', '2023-12-31'),
            ref('r2', '比亚迪', 'revenue', 8e11, '元', '2025-12-31')]
    chart, reason = verify(rows)
    assert reason is None
    assert chart.chart_type == 'bar'
    assert '年度对比' in chart.title and '2023—2025年' in chart.title
    assert '2024-12-31' in chart.data_contract['categories']
    assert not any(p['period'] == '2024-12-31' for p in chart.data_contract['points'])
    assert chart.option['series'][0]['data'][1] is None


def test_count_entities_separately_from_observations():
    rows = [ref(f'{e}-{y}', e, 'revenue', (y-2020)*1e9, '元', f'{y}-12-31')
            for e in ['比亚迪', '宁德时代'] for y in [2023, 2024, 2025]]
    chart, reason = verify(rows)
    assert reason is None
    assert '2个主体' in chart.goal and '3个年度' in chart.goal
    assert '3个样本' not in chart.goal


def test_entity_comparison_uses_sorted_horizontal_bars_with_aligned_evidence():
    rows = [ref('low', '甲公司', 'revenue', 1e9, '元', '2025-12-31'),
            ref('high', '乙公司', 'revenue', 3e9, '元', '2025-12-31')]
    chart, reason = verify(rows, 'bar')
    assert reason is None
    assert chart.chart_type == 'horizontal_bar'
    assert chart.option['yAxis']['data'] == ['乙公司', '甲公司']
    assert chart.option['xAxis']['nameLocation'] == 'middle'
    assert chart.option['grid']['bottom'] >= 44
    assert [p['record_id'] for p in chart.data_contract['points']] == ['high', 'low']
    assert '营业收入' in chart.title and '2个主体' in chart.goal


def test_sales_title_and_display_units_preserve_point_values():
    metric = '新能源汽车:销量:汽车:插电式混合动力:累计值'
    rows = [ref(f'r{y}', '中国', metric, value, '辆', f'{y}-12-31')
            for y,value in [(2023,2804000),(2024,5100000),(2025,5861000)]]
    chart, reason = verify(rows)
    assert reason is None
    assert '插混销量' in chart.title and ':汽车:' not in chart.title
    assert chart.option['yAxis']['name'] == '万辆'
    assert [p['value'] for p in chart.data_contract['points']] == [280.4, 510, 586.1]
    assert {p['unit'] for p in chart.data_contract['points']} == {'万辆'}
    assert chart.point_evidence_ids == ['r2023', 'r2024', 'r2025']


def test_default_linter_does_not_force_advanced_shapes_for_bar_dominant_data():
    from chart_generator.linter import ChartSkillLinter
    charts = [_Candidate(f'比较{i}', 'bar', {'series': [{'data': [10, 20]}]}, ['r'], '', 'CH-02') for i in range(4)]
    codes = {v.code for v in ChartSkillLinter().lint(charts, {'r': {}})}
    assert 'lack_of_chart_diversity' not in codes
    assert 'bar_chart_ratio_exceeded' not in codes


def test_annual_grouped_comparison_is_not_called_trend():
    rows = [ref(f'{m}-{y}', '中国', m, value, '辆', f'{y}-12-31')
            for m in ['新能源汽车:销量:汽车:纯电动:累计值', '新能源汽车:销量:汽车:插电式混合动力:累计值']
            for y,value in [(2023,2804000),(2025,5861000)]]
    chart, reason = verify(rows, 'comparison_bar')
    assert reason is None
    assert '年度对比' in chart.title and '趋势' not in chart.title
    assert any('2024' in note and '缺少' in note for note in chart.footnotes)
    assert not any('构建' in note or '规范化' in note for note in chart.footnotes)


def test_publication_avoids_duplicate_missing_value_disclaimers():
    from chart_generator.render import render_svg
    svg = render_svg('年度销量对比', 'bar', {'xAxis': {'data': ['2023','2024','2025']},
        'yAxis': {'name': '万辆'}, 'series': [{'data': [280.4,None,586.1]}]}, ['2024年缺少数据，留空显示。'])
    assert '2024年缺少数据' in svg
    assert '数据提示：部分时段/指标' not in svg


def test_two_period_mixed_unit_combo_is_replaced_by_source_table():
    rows = [ref(f'{m}-{y}', '宁德时代', m, v, unit, f'{y}-12-31')
            for m,unit,v in [('operating_cash_flow','亿元',900),('gross_margin','%',24)]
            for y in [2023,2024]]
    _, reason = verify(rows, 'combo')
    assert reason and '两期' in reason and '指标表' in reason


def test_publication_combo_labels_both_axis_units():
    from chart_generator.render import render_svg
    svg = render_svg('收入与增长率', 'combo', {'xAxis': {'data': ['2023','2024','2025']},
        'yAxis': [{'name': '亿元'}, {'name': '%'}],
        'series': [{'name': '收入', 'type': 'bar', 'data': [100,120,140]},
                   {'name': '增长率', 'type': 'line', 'yAxisIndex': 1, 'data': [20,20,16.7]}]})
    assert '左轴：亿元' in svg and '右轴：%' in svg


def test_publication_combo_unit_row_does_not_overlap_legend():
    from xml.etree import ElementTree as ET
    from chart_generator.render import render_svg
    svg = render_svg('收入与增长率', 'combo', {'xAxis': {'data': ['2023','2024','2025']},
        'yAxis': [{'name': '亿元'}, {'name': '%'}],
        'series': [{'name': '收入', 'type': 'bar', 'data': [100,120,140]},
                   {'name': '增长率', 'type': 'line', 'yAxisIndex': 1, 'data': [20,20,16.7]}]})
    texts = list(ET.fromstring(svg).iter('{http://www.w3.org/2000/svg}text'))
    units = next(t for t in texts if '左轴：亿元' in (t.text or ''))
    legends = [t for t in texts if t.text in ('收入', '增长率')]
    assert len(legends) == 2
    assert all(float(t.attrib['y']) >= float(units.attrib['y']) + 10 for t in legends)
