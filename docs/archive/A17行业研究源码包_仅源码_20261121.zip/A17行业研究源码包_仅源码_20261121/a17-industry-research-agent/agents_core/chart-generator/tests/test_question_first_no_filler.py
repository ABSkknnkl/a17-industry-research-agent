import asyncio
from types import SimpleNamespace

from chart_generator import ChartGenerationRequest,ChartGeneratorAgent
from chart_generator.config import Settings
from chart_generator.models import InterpretationReport
from chart_generator.question_planner import build_candidate_cards,parse_question_briefs,build_question_plan,apply_plan_to_charts,settle_coverage,validate_selection


def report():
    return InterpretationReport.model_validate({'report_id':'questions','subject':'新能源汽车','as_of':'2026-11-18','status':'completed',
        'evidence_index':{f'R{year}':{'record_id':f'R{year}','domain':'financials','entity':'比亚迪','metric':'revenue','value':year,'unit':'亿元','period':f'{year}-12-31'} for year in [2023,2024,2025]}})


def run(tmp_path,monkeypatch=None):
    if monkeypatch:
        async def failure(*args,**kwargs):raise ValueError('planner failure')
        monkeypatch.setattr('chart_generator.question_planner.build_question_plan',failure)
    briefs=parse_question_briefs(['2025年中国新能源汽车销量最高的三个品牌是哪些？'])
    agent=ChartGeneratorAgent(settings=Settings(output_dir=tmp_path))
    agent.llm=SimpleNamespace(is_available=False)
    return asyncio.run(agent.run(ChartGenerationRequest(report=report(),question_plan_mode='apply',
        question_briefs=[b.model_dump(mode='json') for b in briefs],preferences={'max_charts':15}),save_artifacts=False))


def test_missing_brand_sales_keeps_base_charts_and_reports_gap(tmp_path):
    result=run(tmp_path)
    assert len(result.charts)==1
    assert '营业收入' in result.charts[0].title
    assert result.question_plan.coverage[0].status=='evidence_gap'
    assert result.question_plan.coverage[0].chart_ids==[]


def test_planner_failure_keeps_base_charts_and_reports_gap(tmp_path,monkeypatch):
    result=run(tmp_path,monkeypatch)
    assert len(result.charts)==1
    assert '营业收入' in result.charts[0].title
    assert result.question_plan is not None and result.question_plan.mode=='apply'
    assert result.question_plan.coverage[0].status=='evidence_gap'


def test_industry_sales_cannot_answer_brand_ranking_or_percentage_share():
    briefs=parse_question_briefs(['2025年，纯电和插混分别占中国新能源汽车销量的多少？','2025年中国新能源汽车销量最高的三个品牌是哪些？'])
    chart=SimpleNamespace(chart_id='industry',chart_type='bar',evidence_ids=['R'],data_contract={'points':[
        {'entity':'中国','metric':'新能源汽车:销量:纯电动','value':1062,'unit':'万辆','period':'2025-12-31'},
        {'entity':'中国','metric':'新能源汽车:销量:插电混合动力','value':586,'unit':'万辆','period':'2025-12-31'}]})
    cards=build_candidate_cards([chart],briefs,report())
    assert cards[0].question_ids==[]


def test_unknown_metric_is_not_answered_by_any_chart_of_same_shape():
    brief=parse_question_briefs(['2023—2025年碳排放总量如何变化？'])
    chart=SimpleNamespace(chart_id='revenue',chart_type='line',evidence_ids=['R'],data_contract={'points':[
        {'entity':'比亚迪','metric':'revenue','value':100,'unit':'亿元','period':'2025-12-31'}]})
    assert build_candidate_cards([chart],brief,report())[0].question_ids==[]


def test_total_vehicle_sales_cannot_answer_nev_sales_question():
    briefs=parse_question_briefs(['2023—2025年中国新能源汽车销量如何变化？'])
    chart=SimpleNamespace(chart_id='all-cars',chart_type='line',evidence_ids=['R'],data_contract={'points':[
        {'entity':'中国','metric':'汽车销量:总计:中国','value':3000,'unit':'万辆','period_type':'annual','period':f'{year}-12-31'}
        for year in (2023,2024,2025)]})
    assert build_candidate_cards([chart],briefs,report())[0].question_ids==[]


def test_explicit_nev_sales_remains_eligible():
    briefs=parse_question_briefs(['2023—2025年中国新能源汽车销量如何变化？'])
    chart=SimpleNamespace(chart_id='nev',chart_type='line',evidence_ids=['R'],data_contract={'points':[
        {'entity':'中国','metric':'新能源汽车:销量:总计','value':1000,'unit':'万辆','period_type':'annual','period':f'{year}-12-31'}
        for year in (2023,2024,2025)]})
    assert build_candidate_cards([chart],briefs,report())[0].question_ids==[briefs[0].question_id]


def test_component_sales_alone_do_not_fully_cover_total_nev_sales():
    briefs=parse_question_briefs(['2023—2025年中国新能源汽车销量如何变化？'])
    chart=SimpleNamespace(chart_id='bev',chart_type='line',evidence_ids=['R'],data_contract={'points':[
        {'entity':'中国','metric':'新能源汽车:销量:纯电动','value':1000,'unit':'万辆','period_type':'annual','period':f'{year}-12-31'}
        for year in (2023,2024,2025)]})
    card=build_candidate_cards([chart],briefs,report())[0]
    assert card.question_ids==[briefs[0].question_id]
    assert card.sub_requirements==[]


def test_one_value_is_not_a_chart_for_a_multi_year_trend():
    brief=parse_question_briefs(['2023—2025年中国新能源汽车销量如何变化？'])
    chart=SimpleNamespace(chart_id='single',chart_type='horizontal_bar',evidence_ids=['R'],data_contract={'points':[
        {'entity':'中国','metric':'新能源汽车:销量:纯电动','value':1062,'unit':'万辆','period':'2025-12-31','period_type':'annual'}]})
    assert build_candidate_cards([chart],brief,report())[0].question_ids==[]


def test_llm_cannot_hide_a_data_gap_by_claiming_chart_not_needed():
    brief=parse_question_briefs(['2025年新能源汽车销量最高的三个品牌是哪些？'])
    items,_=validate_selection({'selections':[{'question_id':'Q-1','needs_chart':False,'rationale':'缺少品牌数据'}]},brief,[])
    from chart_generator.models import QuestionChartPlan
    plan=settle_coverage(QuestionChartPlan(mode='apply',questions=items),[],[],brief)
    assert plan.coverage[0].status=='evidence_gap'


def test_explicit_no_chart_stays_not_needed_with_no_data():
    brief=parse_question_briefs(['2025年销量如何变化？不需要图，仅文字说明'])
    items,_=validate_selection({'selections':[{'question_id':'Q-1','needs_chart':False}]},brief,[])
    from chart_generator.models import QuestionChartPlan
    plan=settle_coverage(QuestionChartPlan(mode='apply',questions=items),[],[],brief)
    assert plan.coverage[0].status=='not_needed'


def test_unknown_quantitative_question_keeps_gap_when_model_says_no_chart():
    brief=parse_question_briefs(['2023—2025年碳排放总量如何变化？'])
    items,_=validate_selection({'selections':[{'question_id':'Q-1','needs_chart':False,'rationale':'无碳排放资料'}]},brief,[])
    from chart_generator.models import QuestionChartPlan
    assert settle_coverage(QuestionChartPlan(mode='apply',questions=items),[],[],brief).coverage[0].status=='evidence_gap'


def test_partial_or_ambiguous_powertrain_share_does_not_fully_answer_both_components():
    brief=parse_question_briefs(['2025年，纯电和插混分别占中国新能源汽车销量的多少？'])
    from chart_generator.models import QuestionChartPlan
    for metric in ('新能源汽车:销量:纯电动:占比','新能源汽车销量占比'):
        chart=SimpleNamespace(chart_id='share',chart_type='bar',evidence_ids=['R'],data_contract={'points':[
            {'entity':'中国','metric':metric,'value':60,'unit':'%','period':'2025-12-31','period_type':'annual'}]})
        cards=build_candidate_cards([chart],brief,report())
        plan=asyncio.run(build_question_plan(brief,cards,mode='apply',llm=None))
        selected=apply_plan_to_charts(plan,[chart],max_charts=15,cards=cards)
        assert settle_coverage(plan,selected,cards,brief).coverage[0].status!='published',metric


def test_two_explicit_component_shares_cover_the_question():
    brief=parse_question_briefs(['2025年，纯电和插混分别占中国新能源汽车销量的多少？'])
    chart=SimpleNamespace(chart_id='shares',chart_type='bar',evidence_ids=['R','S'],data_contract={'points':[
        {'entity':'中国','metric':f'新能源汽车:销量:{component}:占新能源汽车总销量比重','value':value,'unit':'%','period':'2025-12-31','period_type':'annual'}
        for component,value in [('纯电动',64.4),('插电式混合动力',35.5)]]})
    cards=build_candidate_cards([chart],brief,report());plan=asyncio.run(build_question_plan(brief,cards,mode='apply',llm=None))
    assert settle_coverage(plan,[chart],cards,brief).coverage[0].status=='published'


def test_question_related_national_series_are_not_dropped_by_generic_macro_quota(tmp_path):
    from chart_generator.models import EvidenceRef
    source=report();source.evidence_index={}
    for metric,unit in [('新能源汽车销量','万辆'),('新能源汽车渗透率','%')]:
        for year in (2023,2024,2025):
            rid=f'{metric}{year}'
            source.evidence_index[rid]=EvidenceRef(record_id=rid,domain='industry',entity='中国',metric=metric,
                value=year-2000,unit=unit,period=f'{year}-12-31',period_type='annual')
    briefs=parse_question_briefs(['2023—2025年中国新能源汽车销量如何变化？','2023—2025年中国新能源汽车渗透率如何变化？'])
    agent=ChartGeneratorAgent(settings=Settings(output_dir=tmp_path));agent.llm=SimpleNamespace(is_available=False)
    result=asyncio.run(agent.run(ChartGenerationRequest(report=source,question_plan_mode='apply',question_briefs=[b.model_dump(mode='json') for b in briefs],
        preferences={'max_charts':6}),save_artifacts=False))
    assert len(result.charts)==2
    assert all(item.status=='published' for item in result.question_plan.coverage)


def test_question_chart_is_added_beyond_base_chart_limit(tmp_path):
    source=report()
    for year in (2023,2024,2025):
        from chart_generator.models import EvidenceRef
        source.evidence_index[f'S{year}']=EvidenceRef(record_id=f'S{year}',domain='industry',entity='中国',
            metric='新能源汽车销量',value=year-1000,unit='万辆',period=f'{year}-12-31')
    brief=parse_question_briefs(['2023—2025年中国新能源汽车销量如何变化？'])
    agent=ChartGeneratorAgent(settings=Settings(output_dir=tmp_path))
    agent.llm=SimpleNamespace(is_available=False)
    base=asyncio.run(agent.run(ChartGenerationRequest(report=source,
        preferences={'max_charts':1}),save_artifacts=False))
    result=asyncio.run(agent.run(ChartGenerationRequest(report=source,question_plan_mode='apply',
        question_briefs=[b.model_dump(mode='json') for b in brief],preferences={'max_charts':1}),save_artifacts=False))
    assert len(base.charts)==1
    assert len(result.charts)==2
    assert {chart.data_fingerprint for chart in base.charts}<={chart.data_fingerprint for chart in result.charts}
    assert sum('新能源' in p['metric'] for chart in result.charts for p in chart.data_contract['points'])==3
    assert any('营业收入' in chart.title for chart in result.charts)


def test_repeated_conformance_keeps_supplement_out_of_base_quota(tmp_path):
    from chart_generator.agent import _Candidate
    from chart_generator.models import EvidenceRef

    source=report()
    metrics=[('revenue','亿元'),('net_profit','亿元'),('gross_margin','%'),('assets','亿元'),('新能源汽车销量','万辆')]
    for metric,unit in metrics:
        for year in (2023,2024,2025):
            rid=f'{metric}{year}'
            source.evidence_index[rid]=EvidenceRef(record_id=rid,domain='industry',entity='中国',
                metric=metric,value=year-2000,unit=unit,period=f'{year}-12-31',period_type='annual')
    candidates=[
        _Candidate(f'{metric}图',chart_type,{},[f'{metric}{year}' for year in (2023,2024,2025)],'对比','CH-02')
        for (metric,_unit),chart_type in zip(metrics,['horizontal_bar','comparison_bar','line','bar','line'])
    ]
    briefs=parse_question_briefs(['2023—2025年中国新能源汽车销量如何变化？'])
    request=ChartGenerationRequest(report=source,question_plan_mode='apply',
        question_briefs=[b.model_dump(mode='json') for b in briefs],preferences={'max_charts':1})
    agent=ChartGeneratorAgent(settings=Settings(output_dir=tmp_path))
    off_request=request.model_copy(update={'question_plan_mode':'off'})
    expected_base=agent._conform_diversity_deterministically(candidates,off_request)
    expected_base=agent._conform_diversity_deterministically(expected_base,off_request)
    first=agent._conform_diversity_deterministically(candidates,request)
    second=agent._conform_diversity_deterministically(first,request)
    second_base=[item for item in second if not getattr(item,'_question_supplement',False)]
    assert {item.fingerprint for item in second_base}=={item.fingerprint for item in expected_base}
    assert any(item.evidence_ids==[f'新能源汽车销量{year}' for year in (2023,2024,2025)]
        for item in second if getattr(item,'_question_supplement',False))

