"""2026-11-20 商业航天实测：同一快照日的行情图堆了 10 张。

股价/涨跌幅/PE/PB/PS/总市值/流通市值/净利润TTM/EPS TTM 同一天出图，产业链和
财务图被挤成配角。出图装配末尾按信息量最多保留 4 张快照图，非快照图原样保留。
"""

from chart_generator.agent import (
    _Candidate,
    _cap_market_snapshot_charts,
    _drop_single_entity_comparisons,
)


def _candidate(title: str, score: int = 100) -> _Candidate:
    return _Candidate(
        title=title,
        chart_type="horizontal_bar",
        option={"series": [{"type": "bar", "data": [1, 2]}]},
        evidence_ids=[title],
        goal="test",
        chapter="C1",
        score=score,
    )


def test_snapshot_charts_capped_at_four_without_touching_other_charts():
    charts = [
        _candidate("产业链结构", 300),
        _candidate("商业航天营业收入对比（2025年）", 200),
        _candidate("商业航天最新股价对比（2026-11-20）", 190),
        _candidate("商业航天最新涨跌幅对比（2026-11-20）", 185),
        _candidate("商业航天市盈率(动态)对比（2026-11-20）", 180),
        _candidate("商业航天市盈率(PE)对比（2026-11-20）", 175),
        _candidate("商业航天总市值对比（2026-11-20）", 170),
        _candidate("商业航天流通市值对比（2026-11-20）", 165),
        _candidate("商业航天市净率(PB)对比（2026-11-20）", 160),
        _candidate("商业航天市销率(PS)对比（2026-11-20）", 155),
        _candidate("商业航天归母净利润ttm对比（2026-11-20）", 150),
        _candidate("商业航天基本每股收益ttm对比（2026-11-20）", 145),
        _candidate("中国GDP：当季同比趋势（2023-12-31至2026-09-30）", 140),
    ]
    out = _cap_market_snapshot_charts(charts)
    snapshots = [c for c in out if "对比（2026-11-20）" in c.title]
    assert len(snapshots) == 4
    # 保留信息量最高的 PE / PB / PS / 总市值；消掉涨跌幅、股价、市值重复项
    kept = {c.title for c in snapshots}
    assert "商业航天最新涨跌幅对比（2026-11-20）" not in kept
    assert "商业航天流通市值对比（2026-11-20）" not in kept
    assert "商业航天市盈率(动态)对比（2026-11-20）" in kept
    # 非快照图一张不少，且相对顺序不变
    others = [c.title for c in out if "对比（2026-11-20）" not in c.title]
    assert others == [c.title for c in charts if "对比（2026-11-20）" not in c.title]


def test_snapshot_cap_is_noop_when_few_charts():
    charts = [
        _candidate("产业链结构"),
        _candidate("商业航天市盈率(PE)对比（2026-11-20）"),
        _candidate("商业航天市净率(PB)对比（2026-11-20）"),
    ]
    assert _cap_market_snapshot_charts(charts) == charts


def test_single_entity_comparison_is_dropped_but_trend_kept():
    single = _Candidate(
        title="中国卫通归母净利润ttm对比（2026-11-20）",
        chart_type="horizontal_bar",
        option={"yAxis": {"data": ["中国卫通"]}, "series": [{"type": "bar", "data": [1]}]},
        evidence_ids=["r1"], goal="test", chapter="C1", score=100,
    )
    pair = _Candidate(
        title="商业航天市盈率(PE)对比（2026-11-20）",
        chart_type="horizontal_bar",
        option={"yAxis": {"data": ["中国卫星", "航天电子"]}, "series": [{"type": "bar", "data": [1, 2]}]},
        evidence_ids=["r2"], goal="test", chapter="C1", score=100,
    )
    trend = _Candidate(
        title="商业航天营业收入趋势（2023—2025年）",
        chart_type="line",
        option={"xAxis": {"data": ["2023", "2024", "2025"]}, "series": [{"type": "line", "data": [1, 2, 3]}]},
        evidence_ids=["r3"], goal="test", chapter="C1", score=100,
    )
    out = _drop_single_entity_comparisons([single, pair, trend])
    assert [c.title for c in out] == [pair.title, trend.title]
