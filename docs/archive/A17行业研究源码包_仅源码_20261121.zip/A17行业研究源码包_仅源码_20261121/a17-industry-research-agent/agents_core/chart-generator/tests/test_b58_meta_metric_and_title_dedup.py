"""B58：检索元数据字段不得画成图表；图标题不得重复实体名。

真实事故（2026-11-12，低空 rev19 / 半导体 rev5 交付前复核）：
- 低空报告正文出现 4 张「低空经济 site_authority 趋势」类曲线，指标是问财检索
  通道的字段（status / site_authority / traceability_type / operation_type），
  值域 0-4，与行业分析无关；
- 两张横截面图标题重复实体名（「宗申动力宗申动力样本对比」「北方华创北方华创样本对比」）。
"""
from __future__ import annotations

from agents_core.financial_semantics import META_ONLY_METRICS, is_meta_only_metric
from chart_generator import ChartGenerationRequest, ChartGeneratorAgent
from chart_generator.agent import _Candidate, _compose_chart_title
from chart_generator.models import ChartPreferences, InterpretationReport


def _report(evidence: dict, subject: str = "低空经济") -> InterpretationReport:
    return InterpretationReport.model_validate({
        "report_id": "B58", "subject": subject, "as_of": "2026-11-12",
        "status": "completed", "evidence_index": evidence,
    })


def _series_evidence(metric: str, values: tuple[float, float], unit: str | None = None) -> dict[str, dict]:
    out = {}
    for idx, (period, value) in enumerate(zip(("2024-12-31", "2025-12-31"), values), 1):
        rid = f"{metric}-{idx}"
        out[rid] = {"record_id": rid, "domain": "industry", "entity": "行业",
                    "metric": metric, "value": value, "unit": unit, "period": period}
    return out


def test_meta_only_metric_predicate_covers_retrieval_fields():
    for name in ("status", "site_authority", "traceability_type", "operation_type",
                 " STATUS ", "Index_Time", "para_index", "trace_info"):
        assert is_meta_only_metric(name), name
    # 真实业务指标与可映射的英文字段不受影响
    for name in ("revenue", "营业收入", "pe_dynamic", "gdp", "市场规模", "指数点位"):
        assert not is_meta_only_metric(name), name
    assert {"status", "site_authority", "operation_type"} <= set(META_ONLY_METRICS)


def test_fallback_never_charts_retrieval_metadata_metrics():
    evidence: dict[str, dict] = {}
    for metric in ("status", "site_authority", "traceability_type", "operation_type"):
        evidence.update(_series_evidence(metric, (0.0, 3.0)))
    evidence.update(_series_evidence("市场规模", (100.0, 130.0), "亿元"))

    agent = ChartGeneratorAgent()
    candidates, suppressed = agent._deterministic_fallback(
        ChartGenerationRequest(report=_report(evidence), preferences=ChartPreferences())
    )

    titles = [c.title for c in candidates]
    for leaked in ("status", "site_authority", "traceability_type", "operation_type"):
        assert all(leaked not in title for title in titles), titles
    assert any("市场规模" in title for title in titles)
    assert "meta_only_metric" in {s.reason_code for s in suppressed}
    # 抑制项要留审计痕迹，便于复盘「为什么少了两张图」
    meta_keys = {s.reason_code for s in suppressed if s.reason_code == "meta_only_metric"}
    assert meta_keys == {"meta_only_metric"}


def test_unknown_snake_case_metric_is_not_turned_into_chart():
    evidence = _series_evidence("some_engine_counter", (1.0, 4.0))
    agent = ChartGeneratorAgent()
    candidates, suppressed = agent._deterministic_fallback(
        ChartGenerationRequest(report=_report(evidence), preferences=ChartPreferences())
    )
    assert candidates == []
    assert "unreadable_metric_label" in {s.reason_code for s in suppressed}


def test_verify_rejects_candidate_whose_evidence_is_all_metadata():
    evidence = _series_evidence("site_authority", (2.0, 3.0))
    report = _report(evidence)
    agent = ChartGeneratorAgent()
    candidate = _Candidate(
        title="低空经济site_authority趋势（2024-12-31至2025-12-31）",
        chart_type="line",
        option={"xAxis": {"type": "category", "data": ["2024-12-31", "2025-12-31"]},
                "series": [{"name": "行业", "type": "line", "data": [2.0, 3.0]}]},
        evidence_ids=list(evidence),
        goal="观察元数据变化",
        chapter="CH-02",
    )
    reason = agent._verify_numeric_candidate(candidate, report)
    assert reason and "元数据" in reason


def test_compose_chart_title_does_not_repeat_subject():
    # 事故原样：系列名就是实体名，旧逻辑拼成「宗申动力宗申动力样本对比」
    assert _compose_chart_title("宗申动力", "宗申动力", "样本对比", "2025-12-31至2026-11-11") == (
        "宗申动力样本对比（2025-12-31至2026-11-11）"
    )
    assert _compose_chart_title("北方华创", "北方华创", "样本对比", "2026-11-11") == (
        "北方华创样本对比（2026-11-11）"
    )
    # 正常情况仍要带主体
    assert _compose_chart_title("低空经济", "营业收入", "趋势", "2024-12-31至2025-12-31") == (
        "低空经济营业收入趋势（2024-12-31至2025-12-31）"
    )
    # 主体为空时不出现前缀空洞
    assert _compose_chart_title("", "归母净利润", "趋势", "2024-12-31至2025-12-31") == (
        "归母净利润趋势（2024-12-31至2025-12-31）"
    )


def test_final_filter_drops_duplicate_titles_keeping_first():
    """同一组证据被两种图型各画一遍时，只保留先到的那张。"""
    from chart_generator.models import ChartPreferences

    evidence = {}
    for metric in ("营业收入增长率", "营业收入", "毛利率", "市盈率(动态)"):
        evidence.update({f"{metric}-{i}": {"record_id": f"{metric}-{i}", "domain": "financials",
                                          "entity": ent, "metric": metric, "value": 10.0 + i,
                                          "unit": "%", "period": f"202{3 + i}-12-31"}
                         for i, ent in enumerate(("北方华创", "中微公司"))})
    report = _report(evidence, subject="半导体设备")

    def cand(title, chart_type, ids):
        return _Candidate(title=title, chart_type=chart_type,
                          option={"xAxis": {"type": "category", "data": ["2023-12-31", "2024-12-31"]},
                                  "series": [{"name": "北方华创", "data": [1.0, 2.0]}]},
                          evidence_ids=ids, goal="", chapter="CH-04")

    ids_a = [k for k in evidence if k.startswith("营业收入增长率")]
    ids_b = [k for k in evidence if k.startswith("营业收入-")]
    ids_c = [k for k in evidence if k.startswith("毛利率")]
    ids_d = [k for k in evidence if k.startswith("市盈率")]
    candidates = [
        cand("半导体设备营业收入增长率趋势（2023-12-31至2024-12-31）", "diverging_bar", ids_a),
        cand("半导体设备营业收入增长率趋势（2023-12-31至2024-12-31）", "line", list(reversed(ids_a))),
        cand("半导体设备营业收入趋势（2023-12-31至2024-12-31）", "line", ids_b),
        cand("半导体设备毛利率趋势（2023-12-31至2024-12-31）", "bar", ids_c),
        cand("半导体设备市盈率(动态)趋势（2023-12-31至2024-12-31）", "bar", ids_d),
    ]
    out = ChartGeneratorAgent()._conform_diversity_deterministically(
        candidates, ChartGenerationRequest(report=report, preferences=ChartPreferences())
    )
    titles = [c.title for c in out]
    assert titles.count("半导体设备营业收入增长率趋势（2023-12-31至2024-12-31）") == 1
    assert len(out) == 4


def test_snapshot_only_entities_excludes_concept_members():
    """只有股价/估值快照的概念成分股，不算「被研究覆盖的公司」。"""
    from chart_generator.agent import _snapshot_only_entities

    evidence = {}
    # 纵横股份：有财报证据 → 覆盖
    evidence["A1"] = {"record_id": "A1", "domain": "financials", "entity": "纵横股份",
                      "metric": "revenue", "value": 3.2, "unit": "亿元", "period": "2025-12-31"}
    for i, metric in enumerate(("latest_price", "market_cap", "pe_dynamic"), 1):
        evidence[f"A{i+1}"] = {"record_id": f"A{i+1}", "domain": "industry_chain", "entity": "纵横股份",
                               "metric": metric, "value": 10.0 + i, "period": "2026-11-11"}
    # 中兴通讯：只有快照 → 未覆盖
    for i, metric in enumerate(("latest_price", "market_cap", "pe_dynamic", "pb"), 1):
        evidence[f"B{i}"] = {"record_id": f"B{i}", "domain": "industry_chain", "entity": "中兴通讯",
                             "metric": metric, "value": 20.0 + i, "period": "2026-11-11"}

    only_snapshot = _snapshot_only_entities(evidence)
    assert "中兴通讯" in only_snapshot
    assert "纵横股份" not in only_snapshot


def test_single_entity_radar_requires_financial_evidence():
    """单主体雷达图不能拿概念成分股当主角（真实事故：中兴通讯样本对比）。"""
    from chart_generator.agent import _radar_scope_violation

    evidence = {}
    for i, metric in enumerate(("latest_price", "market_cap", "pe_dynamic", "pb"), 1):
        evidence[f"B{i}"] = {"record_id": f"B{i}", "domain": "industry_chain", "entity": "中兴通讯",
                             "metric": metric, "value": 20.0 + i, "period": "2026-11-11"}
    evidence["C1"] = {"record_id": "C1", "domain": "financials", "entity": "纵横股份",
                      "metric": "revenue", "value": 3.2, "unit": "亿元", "period": "2025-12-31"}

    assert "财报级证据" in (_radar_scope_violation("radar", {"中兴通讯"}, evidence) or "")
    # 有财报证据的主体、多主体雷达、非雷达图都不拦
    assert _radar_scope_violation("radar", {"纵横股份"}, evidence) is None
    assert _radar_scope_violation("radar", {"纵横股份", "中兴通讯"}, evidence) is None
    assert _radar_scope_violation("bar", {"中兴通讯"}, evidence) is None
