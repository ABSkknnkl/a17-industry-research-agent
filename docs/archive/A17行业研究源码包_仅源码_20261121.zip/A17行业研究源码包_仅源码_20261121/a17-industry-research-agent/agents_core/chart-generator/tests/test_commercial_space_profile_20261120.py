"""2026-11-20 商业航天产业链画像回归。

实测问题（run-20261120160258-b38c717068ad）：主题「商业航天」落到 aircraft 画像，
拓扑出现「机体结构与起落架 / 飞控与导航芯片 / 载人通勤」；且画像串里的
「低空/航空运营场景（巡检、物流、城市治理等）」被按顿号拆成 4 个伪环节。
"""

from __future__ import annotations

from chart_generator.chain_profile import detect_profile
from chart_generator.chain_structure import _split_names, resolve_slots


def test_commercial_space_has_its_own_profile_not_aircraft():
    prof = detect_profile("商业航天")
    assert prof.get("key") == "commercial_space", prof.get("key")
    slots, source = resolve_slots("商业航天")
    labels = [s.label for s in slots]
    assert "画像" in source
    assert "运载火箭制造与总装" in labels
    assert "卫星平台与载荷制造" in labels
    assert "火箭发动机与动力系统" in labels
    assert not any("起落架" in x or "飞控" in x or "eVTOL" in x for x in labels), labels


def test_low_altitude_still_uses_aircraft_profile():
    prof = detect_profile("低空经济")
    assert prof.get("key") == "aircraft", prof.get("key")


def test_parenthesized_scenario_list_is_not_split():
    text = "低空/航空运营场景（巡检、物流、城市治理、载人通勤等）"
    assert _split_names(text, 10) == [text]


def test_semicolon_separator_still_splits_top_level_items():
    text = "空管系统(UTM)、起降场(Vertiport)、通导监；以及仿真训练、运维维修、回收拆解"
    assert _split_names(text, 10) == [
        "空管系统(UTM)", "起降场(Vertiport)", "通导监", "仿真训练", "运维维修", "回收拆解",
    ]
