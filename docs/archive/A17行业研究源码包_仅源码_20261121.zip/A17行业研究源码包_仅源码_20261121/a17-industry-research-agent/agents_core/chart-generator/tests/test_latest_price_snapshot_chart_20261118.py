"""最新价必须按查询时点快照横向对比，不能展开成多年价格趋势。

run-20261118160002 实测：宁德时代/比亚迪的「最新价」来自 2023、2024 主营构成
查询行，既被错误标成报告期，又被图表生成器当成 2023/2024/2026 三个价格点，
画出一条水平线 + 2025 空缺 + 2026 孤立点的假趋势。
"""

from chart_generator.data_formulation import AxisType, DataFormulator
from chart_generator.models import InterpretationReport


def _evidence(rid: str, entity: str, value: float, period: str,
              provenance: str) -> dict:
    return {
        "record_id": rid,
        "domain": "companies",
        "entity": entity,
        "metric": "latest_price",
        "value": value,
        "unit": "元",
        "period": period,
        "period_type": "point",
        "period_provenance": provenance,
    }


def test_latest_price_collapses_to_latest_snapshot_cross_section():
    evidence = [
        _evidence("R-ND-2023", "宁德时代", 241.01, "2023-12-31", "row"),
        _evidence("R-ND-2024", "宁德时代", 241.01, "2024-12-31", "row"),
        _evidence("R-ND-2026", "宁德时代", 241.01, "2026-11-18", "market_snapshot_at_query"),
        _evidence("R-BYD-2023", "比亚迪", 80.15, "2023-12-31", "row"),
        _evidence("R-BYD-2024", "比亚迪", 80.15, "2024-12-31", "row"),
        _evidence("R-BYD-2026", "比亚迪", 80.15, "2026-11-18", "market_snapshot_at_query"),
        _evidence("R-SAN-2025", "三花智控", 32.29, "2025-12-31", "row"),
        _evidence("R-SAN-2026", "三花智控", 32.29, "2026-11-18", "market_snapshot_at_query"),
        _evidence("R-HUI-2025", "汇川技术", 53.45, "2025-12-31", "row"),
        _evidence("R-HUI-2026", "汇川技术", 53.45, "2026-11-18", "market_snapshot_at_query"),
    ]
    report = InterpretationReport.model_validate({
        "report_id": "REP-LATEST-PRICE",
        "subject": "新能源汽车",
        "as_of": "2026-11-18",
        "status": "completed",
        "evidence_index": {e["record_id"]: e for e in evidence},
    })

    table = DataFormulator.formulate(
        list(report.evidence_index), report, target_chart_type="line"
    )

    assert table is not None
    assert table.axis_type == AxisType.ENTITY_COMPARISON
    assert table.categories == ["三花智控", "宁德时代", "比亚迪", "汇川技术"]
    assert len(table.series_data) == 1
    series_name = next(iter(table.series_data))
    assert table.series_data[series_name] == [32.29, 241.01, 80.15, 53.45]
    assert table.point_periods[series_name] == ["2026-11-18"] * 4
    assert table.point_evidence_ids[series_name] == [
        "R-SAN-2026", "R-ND-2026", "R-BYD-2026", "R-HUI-2026"
    ]
    assert all(note for note in table.quality_notes)
