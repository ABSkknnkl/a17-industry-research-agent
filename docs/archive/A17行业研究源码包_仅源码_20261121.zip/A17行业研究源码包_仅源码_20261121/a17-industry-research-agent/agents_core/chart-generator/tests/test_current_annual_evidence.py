from copy import deepcopy
from chart_generator.annual_evidence import annual_evidence_contract
from chart_generator.models import InterpretationReport


def source():
    return {'report_id':'annual','subject':'新能源汽车','as_of':'2026-11-18','status':'completed',
        'evidence_index':{f'R{year}':{'record_id':f'R{year}','domain':'industry','entity':'中国','metric':'新能源汽车:销量:累计值',
            'value':10000000,'unit':'辆','period':f'{year}-12-31','period_start':f'{year}-01-01','period_type':'ytd_month','period_provenance':'row'} for year in (2023,2024,2025)},
        'data_quality_appendix':{'requirement_evidence_matrix':[
            {'requirement':{'requirement_id':f'annual_{year}','label':f'新能源汽车{year}年全年销量','domain':'industry','hard':True,'metric_families':['nev_sales'],'period_ends':[f'{year}-12-31']},
             'coverage':{'passed':False,'evidence_record_ids':[]}} for year in (2023,2024,2025)]}}


def test_current_full_year_nev_evidence_overrides_stale_missing_marker_without_mutating_report():
    report=InterpretationReport.model_validate(source())
    before=deepcopy(report.data_quality_appendix)
    ids,incomplete=annual_evidence_contract(report)
    assert ids['nev_sales']=={'R2023','R2024','R2025'}
    assert incomplete==set()
    assert report.data_quality_appendix==before


def test_missing_year_stays_incomplete():
    raw=source();del raw['evidence_index']['R2024']
    _,incomplete=annual_evidence_contract(InterpretationReport.model_validate(raw))
    assert incomplete=={'nev_sales'}


def test_wrong_scope_uncertain_unit_and_partial_year_do_not_repair_missing_coverage():
    for changes in ({'metric':'汽车销量:总计:中国'},{'metric':'新能源汽车:销量:纯电动:累计值'},
                    {'unit':None},{'period_start':'2024-07-01'},{'issues':['period_conflict']},{'scope':'retail'}):
        raw=source();raw['evidence_index']['R2024'].update(changes)
        _,incomplete=annual_evidence_contract(InterpretationReport.model_validate(raw))
        assert incomplete=={'nev_sales'},changes
