"""chart-generator 测试的路径前置。

为什么需要
----------
pytest 9 在 ``--import-mode=importlib`` 下只把**测试文件自身所在目录**（及 rootdir）
插入 ``sys.path``，``pytest.ini`` 里的 ``pythonpath`` 条目在**单文件运行**时不会生效。
全量运行之所以没暴露问题，是因为 ``agents_core/data-analysis`` 等目录会被其它测试
先收集进 ``sys.path`` —— 属于收集顺序的巧合，不是契约。

chart-generator 的测试需要读取 A2/A4 的模型（如 ``data_interpreter.models``、
``chapter_writer.models``）来验证跨界契约，因此在这里显式补上同级包根目录。
插入是幂等的，且只在缺失时追加，不改变已有优先级。
"""

from __future__ import annotations

import sys
from pathlib import Path

_AGENTS_CORE = Path(__file__).resolve().parents[2]
for _package_root in (
    "data-analysis",
    "chapter-writer",
    "data-fetcher",
    "chain-research",
    "report-fusion",
):
    _path = str(_AGENTS_CORE / _package_root)
    if _path not in sys.path:
        sys.path.append(_path)
