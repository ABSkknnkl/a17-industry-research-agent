from xml.etree import ElementTree as ET

import pytest

from chart_generator.compiler import EChartsCompiler
from chart_generator.data_formulation import NormalizedDataTable
from chart_generator.render import render_svg


def table(combo=False, horizontal=False):
    return NormalizedDataTable(x_field_name='主体' if horizontal else '年度',axis_type='entity_comparison' if horizontal else 'time_series',
        categories=['甲','乙','丙'] if horizontal else ['2023','2024','2025'],
        series_data={'营业收入':[6023.15,None,8039.65], **({'利润增速':[80.7,34,-19]} if combo else {})},
        series_units={'营业收入':'亿元',**({'利润增速':'%'} if combo else {})},
        primary_series_name='营业收入',secondary_series_name='利润增速' if combo else None)


def number(text):
    text=text.replace('%','')
    return float(text[:-1])*10000 if text.endswith('万') else float(text)


def test_dual_axis_ticks_render_exactly_as_compiled():
    option=EChartsCompiler.compile(table(combo=True),'combo','收入与增速')
    nodes=list(ET.fromstring(render_svg('收入与增速','combo',option)).iter('{http://www.w3.org/2000/svg}text'))
    left=[number(n.text) for n in nodes if n.attrib.get('x')=='78' and n.attrib.get('font-size')=='11']
    axis=option['yAxis'][0]
    expected=[axis['min']+i*axis['interval'] for i in range(axis['splitNumber']+1)]
    assert left==pytest.approx(expected)


@pytest.mark.parametrize('kind', ['bar','line','horizontal_bar','combo'])
def test_all_cartesian_axes_publish_explicit_tick_spec(kind):
    option=EChartsCompiler.compile(table(combo=kind=='combo',horizontal=kind=='horizontal_bar'),kind,'数值轴')
    axes=option['yAxis'] if isinstance(option['yAxis'],list) else [option['xAxis'] if kind=='horizontal_bar' else option['yAxis']]
    for axis in axes:
        assert axis['max']>axis['min']
        assert axis['interval']>0
        assert axis['max']-axis['min']==pytest.approx(axis['interval']*axis['splitNumber'])
    svg=ET.fromstring(render_svg('数值轴',kind,option))
    for index,axis in enumerate(axes):
        axis_id='x0' if kind=='horizontal_bar' else f'y{index}'
        values=[float(n.attrib['data-tick-value']) for n in svg.iter('{http://www.w3.org/2000/svg}text') if n.attrib.get('data-axis')==axis_id]
        expected=[axis['min']+i*axis['interval'] for i in range(axis['splitNumber']+1)]
        assert values==pytest.approx(expected)


def test_explicit_published_axis_range_is_preserved_in_svg():
    option=EChartsCompiler.compile(table(combo=True),'combo','核对')
    option['yAxis'][0].update(min=-10000,max=20000,interval=10000,splitNumber=3)
    option['yAxis'][1].update(min=-100,max=200,interval=100,splitNumber=3)
    svg=ET.fromstring(render_svg('核对','combo',option))
    ticks=[float(n.attrib['data-tick-value']) for n in svg.iter('{http://www.w3.org/2000/svg}text') if n.attrib.get('data-axis')=='y0']
    assert ticks==[-10000,0,10000,20000]


def test_scatter_numeric_axes_share_ticks_and_include_extremes():
    source=NormalizedDataTable(x_field_name='公司',axis_type='entity_comparison',categories=['甲','乙','丙'],
        series_data={'研发强度':[3,8,55],'毛利率':[-20,4,26]},series_units={'研发强度':'%','毛利率':'%'},
        primary_series_name='研发强度',secondary_series_name='毛利率')
    option=EChartsCompiler.compile(source,'scatter','研发与毛利率')
    svg=ET.fromstring(render_svg('研发与毛利率','scatter',option))
    for dimension, extremes in [('x',(3,55)),('y',(-20,26))]:
        axis=option[dimension+'Axis']
        assert axis['min']<=min(extremes) and axis['max']>=max(extremes)
        ticks=[float(n.attrib['data-tick-value']) for n in svg.iter('{http://www.w3.org/2000/svg}text') if n.attrib.get('data-axis')==dimension+'0']
        assert ticks==pytest.approx([axis['min']+i*axis['interval'] for i in range(axis['splitNumber']+1)])


def test_mixed_sign_dual_axes_share_the_same_zero_position():
    option=EChartsCompiler.compile(table(combo=True),'combo','零线对齐')
    left,right=option['yAxis']
    assert -left['min']/(left['max']-left['min'])==pytest.approx(-right['min']/(right['max']-right['min']))
