"""2026-11-20：行业指数点位不得混入个股股价横向对比。

实测 CHART-07-CFF9DD57：yAxis 同时含「商业航天」(886078.TI, 单位「点」) 与
中国卫星/航发动力等个股(单位「元」)，图把指数 1595.142 画成 1595 元。
"""
from __future__ import annotations

from chart_generator.data_formulation import DataFormulator
from chart_generator.models import EvidenceRef


def _price(name: str, value: float, unit: str) -> EvidenceRef:
    return EvidenceRef(
        record_id=f"R-{name}", domain="industry", entity=name,
        metric="close_price", value=value, unit=unit,
    )


def test_index_points_are_excluded_from_stock_price_comparison():
    table = DataFormulator._formulate_entity_cross_section(
        [
            _price("商业航天", 1595.142, "点"),
            _price("中国卫星", 46.1, "元"),
            _price("中国卫通", 19.5, "元"),
        ],
        ["商业航天", "中国卫星", "中国卫通"],
    )
    assert table is not None
    assert "商业航天" not in table.categories
    assert set(table.categories) == {"中国卫星", "中国卫通"}
    assert all(v < 1000 for v in table.series_data["收盘价"])


def test_all_index_points_returns_no_table():
    table = DataFormulator._formulate_entity_cross_section(
        [_price("商业航天", 1595.142, "点"), _price("半导体", 800.0, "点")],
        ["商业航天", "半导体"],
    )
    assert table is None
