"""2026-11-20 新增两个行业画像：人形机器人与储能。

机器人画像原本是工业机器人龙头，人形机器人链（关节/丝杠/灵巧手）会被它抢走；
储能也会被 battery 画像（锂电材料）抢走。两个新画像插在各自父画像之前，
并按 _index.json 的 order 生效。
"""

from chart_generator import chain_profile as cp
from chart_generator.chain_loader import load_all


def test_humanoid_robot_profile_wins_over_industrial_robot():
    assert cp.detect_profile("人形机器人")["key"] == "humanoid_robot"
    assert cp.detect_profile("人形机器人关节模组")["key"] == "humanoid_robot"
    # 工业机器人不受影响
    assert cp.detect_profile("工业机器人")["key"] == "robot"


def test_energy_storage_profile_wins_over_battery():
    assert cp.detect_profile("储能")["key"] == "energy_storage"
    assert cp.detect_profile("电化学储能系统")["key"] == "energy_storage"
    # 动力电池仍走 battery
    assert cp.detect_profile("动力电池")["key"] == "battery"


def test_new_profiles_have_core_fields():
    for key in ("humanoid_robot", "energy_storage"):
        prof = next(p for p in load_all(force_source="data").profiles if p["key"] == key)
        assert prof["kw"] and prof["leading_brand"] and prof["leading_upstream"]
        assert not set(prof["leading_brand"]) & set(prof["leading_upstream"])
