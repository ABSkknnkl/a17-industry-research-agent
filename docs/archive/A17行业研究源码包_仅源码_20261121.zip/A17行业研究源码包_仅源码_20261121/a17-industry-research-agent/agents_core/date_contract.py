"""五阶段共享的严格研究日历日期校验。"""
from __future__ import annotations

from datetime import date, datetime
from typing import Any


def strict_calendar_date(value: Any) -> Any:
    """只接受 date 或精确 YYYY-MM-DD；拒绝 datetime 与非补零字符串。

    保留原始字符串交给各 Pydantic 字段继续解析，因而同一助手可同时服务
    ``str`` 入口契约和 Agent 的 ``date`` 契约。
    """
    if isinstance(value, datetime):
        raise ValueError("研究截止日期必须是 YYYY-MM-DD，不能包含时间")
    if isinstance(value, str):
        try:
            parsed = date.fromisoformat(value)
        except ValueError as exc:
            raise ValueError("研究截止日期必须是真实存在的 YYYY-MM-DD 日期") from exc
        if parsed.isoformat() != value:
            raise ValueError("研究截止日期必须使用补零的 YYYY-MM-DD 格式")
    return value
