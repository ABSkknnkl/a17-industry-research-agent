"""One canonical view model rendered to Markdown and self-contained HTML via Jinja2."""

from __future__ import annotations

import logging
import re
from urllib.parse import urlsplit
from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader

from agents_core.financial_semantics import REPORT_BASIS_LABELS, format_report_rate
from agents_core.financial_semantics import metric_family
from report_fusion.models import ReportViewModel

# 标注通道判定类别的读者标签（与 scripts/diagnose_quantity_issues.py 同义）
_VERIFICATION_CATEGORY_LABELS = {
    "value_exact_structured": "结构化数值精确命中",
    "text_quote_only": "原文命中（实体/期间弱匹配）",
    "unit_currency_mismatch": "币种错配（待人工换算裁决）",
    "chapter_scope_only": "证据在库但不在本章检索子集",
}

logger = logging.getLogger(__name__)

TEMPLATES_DIR = Path(__file__).resolve().parent / "templates"
STYLES_DIR = Path(__file__).resolve().parent / "styles"

# 双模板：auto=智能配图（同花顺） / rich=更多图表（本项目）
_jinja_envs: dict[str, Environment] = {
    # loader 同时搜索模式目录与模板根：research_sections.html 等共享片段放在根目录。
    "auto": Environment(loader=FileSystemLoader([str(TEMPLATES_DIR / "auto"), str(TEMPLATES_DIR)]), autoescape=True),
    "rich": Environment(loader=FileSystemLoader([str(TEMPLATES_DIR / "rich"), str(TEMPLATES_DIR)]), autoescape=True),
}
# 兼容旧路径（templates/*.html 兜底）
_jinja_env = Environment(loader=FileSystemLoader(str(TEMPLATES_DIR)), autoescape=True)


def _jinja_for(chart_mode: str) -> Environment:
    mode = (chart_mode or "auto").strip().lower()
    return _jinja_envs.get(mode, _jinja_envs["auto"])

def _format_card_value(val: Any, unit: str | None) -> str:
    val_s = str(val if val is not None else "").strip()
    unit_s = str(unit or "").strip()
    if not unit_s:
        return val_s
    if unit_s in {"0-1", "0~1", "[0,1]", "0-100", "0~100"}:
        return f"{val_s} (区间 {unit_s})"
    if unit_s in ("日期", "时间", "时点", "无", "-"):
        return val_s
    if unit_s in ("倍数", "倍率"):
        unit_s = "倍"
    if unit_s in ("%", "％", "百分点", "个百分点"):
        rate_unit = "%" if unit_s in ("%", "％") else "个百分点"
        numeric = re.sub(r"\s*(?:[%％]|个?百分点)$", "", val_s)
        return format_report_rate(numeric, rate_unit)
    if val_s.endswith(unit_s):
        return val_s
    return f"{val_s} {unit_s}"

METRIC_DISPLAY_NAMES = {
    "parent_net_profit": "归母净利润",
    "net_profit": "净利润",
    "revenue": "营业收入",
    "operating_revenue": "营业收入",
    "operating_cash_flow": "经营性现金流净额",
    "cash_flow": "经营现金流",
    "net_margin": "销售净利率",
    "gross_margin": "毛利率",
    "roe": "净资产收益率(ROE)",
    "roa": "总资产收益率(ROA)",
    "debt_ratio": "资产负债率",
    "debt_asset_ratio": "资产负债率",
    "pe": "市盈率(PE)",
    "pe_ttm": "市盈率(TTM)",
    "pe_lyr": "市盈率(静)",
    "pe_dynamic": "市盈率(动态)",
    "pb": "市净率(PB)",
    "ps": "市销率(PS)",
    "concept_name": "概念板块",
    "industry_name": "所属行业",
    "bps": "每股净资产",
    "cfps": "每股经营现金流",
    "total_equity": "净资产",
    "total_market_cap": "总市值",
    "market_cap": "总市值",
    "circulating_market_cap": "流通市值",
    "float_market_cap": "流通市值",
    "latest_price": "最新股价",
    "close_price": "收盘价",
    "price": "价格",
    "change_pct": "最新涨跌幅",
    "yoy": "同比增长率",
    "revenue_yoy": "营收同比增长率",
    "net_profit_yoy": "净利同比增长率",
    "rd_expense": "研发费用",
    "rd_investment": "研发投入",
    "rd_ratio": "研发费用率",
    "rd_investment_ratio": "研发投入占营收比例",
    "total_assets": "总资产",
    "total_liabilities": "总负债",
    "eps": "每股收益(EPS)",
    "dividend_yield": "股息率",
    "gdp": "国内生产总值(GDP)",
    "cpi": "居民消费价格指数(CPI)",
    "ppi": "工业品出厂价格指数(PPI)",
}

CONFIDENCE_DISPLAY_NAMES = {
    "high": "高",
    "medium": "中",
    "low": "低",
}

def _format_confidence(conf: str) -> str:
    c = str(conf or "").strip().lower()
    return CONFIDENCE_DISPLAY_NAMES.get(c, conf or "中")

DELIVERY_STATUS_NAMES = {
    "ready": "审核通过（已交付）",
    "ready_scoped": "可交付（有限覆盖）",
    "ready_with_limits": "受限草稿 · 未通过正式质量门禁",
    "draft": "草稿待审",
    "reviewing": "审校中",
}

def _format_delivery_status(status: str) -> str:
    s = str(status or "").strip().lower()
    return DELIVERY_STATUS_NAMES.get(s, status or "已交付")

def _format_metric_label(metric: str) -> str:
    m = str(metric or "").strip()
    label = METRIC_DISPLAY_NAMES.get(m) or METRIC_DISPLAY_NAMES.get(m.lower())
    if label:
        return label
    key = m.lower()
    # 单位/口径后缀不是指标名的一部分：roe_pct / gross_margin_pct 应回到基础标签。
    for suffix, tail in (("_pct", ""), ("_ratio", ""), ("_yoy", "同比增速"), ("_growth", "增速")):
        if key.endswith(suffix):
            base = METRIC_DISPLAY_NAMES.get(key[: -len(suffix)])
            if base:
                return f"{base}{tail}"
    # 中文指标常带分隔符（单季度_营业收入）；去掉连接符比原样输出可读。
    if re.search(r"[\u4e00-\u9fa5]", m) and re.search(r"[_:：]", m):
        return re.sub(r"\s*[_]\s*", "", m).replace(":", "：", 1)
    return m

def _format_outlier_val(val: Any, metric: str = "", unit: str | None = None) -> str:
    s = str(val if val is not None else "").strip()
    if not s or s == "-":
        return "-"
    if unit:
        # 有单位就按单位展示：按数值量级猜「万/亿」会把 16_490_000 辆 说成「1649.00万元」。
        return _display_evidence_value(val, unit, metric)
    if "%" in s:
        return s
    try:
        f = float(s)
        m_lower = metric.lower()
        if re.search(r"(^|_)(pe|pb|ps)(_|$)", m_lower) or any(x in m_lower for x in ("市盈率", "市净率", "市销率")):
            return f"{f:.2f}倍"
        if any(r in m_lower for r in ["margin", "roe", "roa", "ratio", "rate", "率", "比"]):
            if abs(f) <= 100.0:
                return f"{f:.2f}%"
        if abs(f) >= 1e8:
            return f"{f / 1e8:.2f}亿元"
        if abs(f) >= 1e4:
            return f"{f / 1e4:.2f}万元"
        if abs(f) < 1.0 and abs(f) > 0.0001:
            return f"{f:.4f}"
        return f"{f:.2f}"
    except (ValueError, TypeError):
        return s

def _format_stat_text(text: str) -> str:
    def _repl(match):
        val = float(match.group(1))
        return f"{val:.6f}".rstrip("0").rstrip(".")
    return re.sub(r"([+-]?\d+(?:\.\d+)?(?:[eE][+-]?\d+))", _repl, str(text or ""))

def _normalize_dqa(dqa: dict[str, Any]) -> dict[str, Any]:
    if not dqa:
        return {}
    res = dict(dqa)
    outliers = dqa.get("outlier_items", [])
    if outliers:
        formatted_outliers = []
        for out in outliers:
            item = dict(out)
            orig_m = str(out.get("metric", ""))
            item["metric"] = _format_metric_label(orig_m)
            item["observed_value"] = _format_outlier_val(out.get("observed_value"), orig_m, out.get("unit"))
            item["expected_range"] = _format_stat_text(out.get("expected_range", ""))
            formatted_outliers.append(item)
        res["outlier_items"] = formatted_outliers
    return res


_MAX_CITATIONS = 8


def _citations(ids: list[str], lookup: dict[str, int]) -> str:
    """引用编号列表。超过 8 个时截断并标注总项数（B23-T8）。

    SEMI-Q4 实测：单条结论曾挂 77 个来源（全文 354 次引用），读者无法定位
    任何一条。截断后仍保留前 8 个可追溯编号，其余只报数量——完整映射在
    附录「原始数据穿透与事实证据索引」里。
    """
    nums = sorted({lookup[x] for x in ids if x in lookup})
    if not nums:
        return ""
    if len(nums) > _MAX_CITATIONS:
        shown = ",".join(f"来源{n}" for n in nums[:_MAX_CITATIONS])
        return f"[{shown} 等{len(nums)}项]"
    return "[" + ",".join(f"来源{n}" for n in nums) + "]"


def _display_value(value: object, limit: int = 96) -> str:
    if value is None:
        return "-"
    val_str = str(value).strip()
    if val_str.endswith("%"):
        try:
            num = float(val_str[:-1])
            val_str = f"{num:.2f}%"
        except (ValueError, TypeError):
            pass
    else:
        try:
            num = float(val_str)
            if "." in val_str:
                val_str = f"{num:.2f}"
        except (ValueError, TypeError):
            pass
    text = " ".join(val_str.split())
    return text if len(text) <= limit else text[: limit - 1] + "…"


DOMAIN_DISPLAY_NAMES = {
    "financials": "公司财务",
    "financial": "公司财务",
    "macro": "宏观经济",
    "industry": "行业数据",
    "policy": "政策法规",
    "valuation": "估值数据",
    "news": "市场资讯",
    "companies": "公司概况",
    "company": "公司概况",
    "reports": "研报观点",
    "report": "研报观点",
    "industry_chain": "产业链",
    "research": "行业研究",
}


def _format_domain_label(domain: str) -> str:
    d = str(domain or "").strip()
    return DOMAIN_DISPLAY_NAMES.get(d, DOMAIN_DISPLAY_NAMES.get(d.lower(), d))


def _display_evidence_value(value: object, unit: str | None = None, metric: str | None = None, *args: Any, **kwargs: Any) -> str:
    s = _display_value(value)
    if not unit:
        return s
    u = str(unit).strip()
    if u in ("日期", "时间", "时点", "无", "-"):
        return s
    if u in ("倍数", "倍率"):
        u = "倍"
    if u in ("%", "％", "百分点", "个百分点"):
        return _format_card_value(s, u)
    if not u or s.endswith(u):
        return s
    if u in ("元", "人民币", "CNY", "¥"):
        try:
            val_num = float(str(value).strip().replace(",", ""))
            if abs(val_num) >= 1e8:
                return f"{val_num / 1e8:.2f} 亿元"
            if abs(val_num) >= 1e4:
                return f"{val_num / 1e4:.2f} 万元"
        except (ValueError, TypeError):
            pass
    elif u == "股":
        try:
            val_num = float(str(value).strip().replace(",", ""))
            if abs(val_num) >= 1e8:
                return f"{val_num / 1e8:.2f} 亿股"
            if abs(val_num) >= 1e4:
                return f"{val_num / 1e4:.2f} 万股"
        except (ValueError, TypeError):
            pass
    elif u == "手":
        try:
            val_num = float(str(value).strip().replace(",", ""))
            if abs(val_num) >= 1e4:
                return f"{val_num / 1e4:.2f} 万手"
        except (ValueError, TypeError):
            pass
    return f"{s} {u}"


for _e in list(_jinja_envs.values()) + [_jinja_env]:
    _e.filters["display_value"] = _display_value
    _e.filters["evidence_val"] = _display_evidence_value
    _e.filters["format_metric"] = _format_metric_label
    _e.filters["format_domain"] = _format_domain_label
    _e.filters["format_confidence"] = _format_confidence
    _e.filters["format_status"] = _format_delivery_status


def _quality_summary(view: ReportViewModel) -> list[str]:
    """Reader-facing summary; original claims and machine paths stay in audit JSON."""
    from collections import Counter
    labels = {"required_financial_cell": "指定年度资料缺口", "appendix_fact": "附录待核验项",
        "unsupported_quantity": "定量断言待核验项", "chart_contract": "图表待核验项",
        "unsupported_causal_claim": "因果解释待核验项", "unsupported_direction_claim": "变化方向待核验项", "delivery_rule": "交付条件待完善项"}
    historical = [issue for issue in view.quality_issues
                  if issue.get("active") is False or issue.get("disposition") in {"isolated", "repaired", "removed"}]
    active = [issue for issue in view.quality_issues if issue not in historical]
    # Repetitions across paragraphs remain in audit JSON, but do not inflate reader-facing counts.
    unique = {(issue.get("code"), issue.get("entity"), issue.get("metric"), issue.get("year"),
               issue.get("claim") or issue.get("location")): issue for issue in active}
    counts = Counter(labels.get(issue.get("code"), "其他待核验项") for issue in unique.values())
    lines = [f"{label}：{count}项" for label, count in counts.items()]
    if historical:
        lines.append(f"已修复或移除的历史审计记录：{len(historical)}条（不属于当前交付阻断）")
    lines += [_reading_text(str(issue["claim"])) for issue in view.quality_issues
        if issue.get("code") == "required_financial_cell" and issue.get("claim")][:3]
    return lines + ["完整诊断见随报告提供的事实核验附件。"]


_READING_LABELS = {**REPORT_BASIS_LABELS, **METRIC_DISPLAY_NAMES,
                   "gross_margin": "销售毛利率", "方向一致率": "样本同向变动比例"}

# 内部标识到读者语言的兜底映射。上游（解读/写作/取数审计）会把这些标识
# 直接写进正文与质量条目，交付层必须再挡一道，否则读者会看到 `chain_structure`
# `financial_ratios` 这类字段名。只收“出现即确定含义”的词；`index`/`name`/`status`
# 这类通用英文词不进表，避免误伤正常表述。
_INTERNAL_TERM_LABELS = {
    "requirement_evidence_matrix": "需求—证据矩阵",
    "business_composition": "主营构成",
    "industry_chain_segments": "产业链环节数据",
    "industry_chain": "产业链",
    "chain_structure": "产业链结构",
    "chain_segment": "产业链环节",
    "main_business": "主营业务",
    "key_products": "主营产品",
    "financial_ratios": "财务比率",
    "gross_margin_range": "毛利率区间",
    "cash_to_net_profit": "净现比",
    "period_warning": "期间口径提示",
    "unit_unknown": "单位待确认",
    "entity_identity": "公司身份识别",
    "global_facts": "全局事实库",
    "comps_matrix": "可比公司矩阵",
    "key_metrics": "关键指标",
    "evidence_index": "证据索引",
    "data_quality": "数据质量",
    "calculations": "派生计算",
    "tiered_valuation_note": "分层估值说明",
    "supply_chain_relations": "供应链关系",
    "peer_membership": "可比样本归属",
    "robot_universal_search": "全网检索通道",
    "median_gross_margin": "毛利率中位数",
    "loss_or_high_multiple": "亏损或高估值倍数",
    "missing_period_end": "缺失期间截止日",
    "CNY": "人民币",
}
_INTERNAL_TERM_PATTERN = re.compile(
    # 前面允许出现「/」：指标组常写成 `产业链环节/main_business/business_composition`，
    # 排除「/」会让整组字段名漏过翻译。正文里的 URL 不经过本函数，不受影响。
    r"(?<![A-Za-z0-9_.])(" + "|".join(
        map(re.escape, sorted(_INTERNAL_TERM_LABELS, key=len, reverse=True))
    ) + r")(?![A-Za-z0-9_])"
)

# 带单位/口径后缀的指标名（net_margin_pct / roe_pct …）：基础标签在词表里就直接换掉，
# 后缀只是单位标记，不该出现在读者面前。
_METRIC_SUFFIX_PATTERN = re.compile(
    r"(?<![A-Za-z0-9_.])([a-z][a-z0-9_]+?)_(pct|ratio|growth|yoy)(?![A-Za-z0-9_])"
)
_METRIC_SUFFIX_LABELS = {"growth": "增速", "yoy": "同比增速", "pct": "", "ratio": ""}


def _metric_suffix_text(match: re.Match) -> str:
    base = METRIC_DISPLAY_NAMES.get(match.group(1))
    if not base:
        return match.group(0)
    return f"{base}{_METRIC_SUFFIX_LABELS[match.group(2)]}"

_READING_PATTERN = re.compile(
    r'(?P<protected>https?://[^\s<>）。，；]+|`[^`]+`|“[^”]*”|《[^》]*》|'
    r'(?<![A-Za-z0-9_])[A-Z][A-Z0-9]*[-_][A-Za-z0-9_-]+|\b\d{4,6}\.[A-Z]{2,5}\b)'
    r'|(?P<label>(?<![A-Za-z0-9_])(?:'
    + "|".join(map(re.escape, sorted(_READING_LABELS, key=len, reverse=True)))
    + r')(?![A-Za-z0-9_]))'
    r'|(?P<rate>(?<![A-Za-z0-9_])(?P<value>[+-]?\d+(?:\.\d+)?)(?P<unit>[%％]|个?百分点))'
)


# 日期 + 口径的机器写法（如 `2025-12-31（annual，consolidated）`）先合成为
# 投研读者惯用的期间表述，避免只替换单词后留下 "2025-12-31（年度，合并报表）"。
_PERIOD_BASIS = re.compile(
    r'(?P<date>20\d{2}-\d{2}-\d{2})\s*[（(]\s*'
    r'(?P<period>annual|half_year|ytd_q3|quarter)'
    r'(?:\s*[，,]\s*(?P<scope>consolidated|parent))?\s*[）)]'
)
_QUARTER_LABELS = {"annual": "年", "half_year": "年半年度", "ytd_q3": "年前三季度", "quarter": "年单季度"}
_SCOPE_LABELS = {"consolidated": "合并财务报表", "parent": "母公司财务报表"}


def _period_phrase(match: re.Match) -> str:
    year = match["date"][:4]
    scope = match["scope"]
    # 期间与口径都要保留：只写「2025年合并财务报表」会把前三季度读成全年。
    return f"{year}{_QUARTER_LABELS[match['period']]}{_SCOPE_LABELS.get(scope, '')}"


def _reading_text(text: str) -> str:
    def replace(match: re.Match) -> str:
        if match["protected"]:
            return match[0]
        if match["label"]:
            return _READING_LABELS[match["label"]]
        unit = "%" if match["unit"] in ("%", "％") else "个百分点"
        return format_report_rate(match["value"], unit)

    text = _PERIOD_BASIS.sub(_period_phrase, text)
    text = _INTERNAL_TERM_PATTERN.sub(lambda m: _INTERNAL_TERM_LABELS[m.group(1)], text)
    text = _METRIC_SUFFIX_PATTERN.sub(_metric_suffix_text, text)
    text = _READING_PATTERN.sub(replace, text)
    # 历史产物里「净资产收益率(净资产收益率(ROE))」这类自嵌套已在图表标题中固化，
    # 交付层再折叠一次，避免旧图表标题原样进正文。
    for _ in range(2):
        collapsed = re.sub(r"([\u4e00-\u9fa5]{2,12})[（(]\1[（(]([^（）()]{1,14})[）)][）)]", r"\1(\2)", text)
        if collapsed == text:
            break
        text = collapsed
    # 旧产物的截断尾巴「。……」：句末再加省略号是噪声。
    return text.replace("。……", "。")


_LEADING_CONNECTIVE = re.compile(
    r"^(?:(?:然而|但是|但)[，,；;：:]?|(?:因此|因而|此外|同时|不过|所以)[，,；;：:])\s*"
)

CONCLUSION_LIMIT = 240
HEADLINE_LIMIT = 200


def clamp_sentence(text: str, limit: int) -> str:
    """把超长条目截到 limit 字内，尽量停在句末，避免交付件出现整屏数据罗列。

    实测低空基线里有一条结论 4181 字——那不是结论，是把证据库逐条抄了一遍。
    事实本身留在附录索引与章内段落，摘要层只保留可读的判断。
    截断点不能落在数字中间（"43.6072" 截成 "43" 会凭空造出一个无据数字）。
    """
    s = " ".join(str(text or "").split())
    if len(s) <= limit:
        return s
    head = s[:limit]
    out = ""
    for punct in ("。", "；", "！", "？"):
        idx = head.rfind(punct)
        if idx >= limit * 0.55:
            out = head[: idx + 1]
            break
    if not out:
        idx = max(head.rfind("，"), head.rfind(","))
        if idx >= limit * 0.55:
            out = head[:idx].rstrip("，、,;；")
    if not out:
        out = head
    out = re.sub(r"[-+]?\d+(?:\.\d*)?$", "", out).rstrip("，、,;；：: ")
    if out.endswith(("。", "！", "？")):
        return out
    return out + "……"


def _norm_claim(text: str) -> str:
    return re.sub(r"[\s，。；、：,.;:（）()“”\"'—\-…]", "", str(text or ""))


def _drop_duplicated_risks(risks: list[str], boundaries: list[str]) -> list[str]:
    """摘要里的「风险提示」与「研究边界」同源（都来自 warnings），必须去重。

    实测两份基线：risks 恰好是 boundaries 的前 6 条，同一页上两栏内容一模一样。
    完全重复或一条完整包含另一条时只保留在边界说明里；真正独有的风险才留在风险栏。
    """
    known = [key for key in map(_norm_claim, boundaries) if key]
    kept: list[str] = []
    for risk in risks:
        key = _norm_claim(risk)
        if not key:
            continue
        if any(key == other or (len(key) >= 12 and (key in other or other in key)) for other in known):
            continue
        kept.append(risk)
    return kept


def _cover_subtitle(view: ReportViewModel) -> str:
    """封面副标题：一句结构化的定位语，而不是把整段核心研判压在封面上。

    实测低空基线把 300 余字的 headline 原样放在封面，且以「然而，」开头——
    封面承担的是一眼可读的定位，具体判断留给摘要页。
    """
    skip = {"行业定义与研究基础", "情景、风险与研究结论"}
    themes = [ch.title for ch in view.chapters if ch.title not in skip]
    core = "、".join(themes[:3]) or "产业格局与财务质量"
    return f"{view.subject}：{core}"


# ── 摘要导语可读化（2026-11-09 实测）─────────────────────────────────────────
# reconcile_text 出于审计目的，把叙述里的排名句替换成
# 「2023-01-01至2023-12-31（年度，合并报表，CNY，元）已覆盖样本4家，营业收入最高为
#  北方华创，负值企业为无（仅限该期间、范围和币种的已覆盖样本）」。事实齐全，
# 但当它占据摘要第一句时，读者先看到三行期间口径样板，再看到判断。
# 导语层做无损压缩：事实不变，顺序换成「判断在前、口径收进括号」。
_RANK_SEGMENT = re.compile(
    r"(\d{4})-\d{2}-\d{2}至(?:\d{4})-\d{2}-\d{2}（([^（）]*)）已覆盖样本(\d+)家，"
    r"(.+?)最高为([^，,；;。]+)，负值企业为([^，,；;。]+)（仅限该期间、范围和币种的已覆盖样本）"
)
_HEADLINE_CONNECTIVE = re.compile(r"^(?:但是|但|不过|然而|同时|此外|因此|所以)(?:本次|此次)?")
_HEADLINE_BOILERPLATE = "该测量期间或比较结论缺乏可核对的结构化观察值，暂不作判断"


def _rank_segment_summary(hits: list[tuple[int, int, str, str, str, str]]) -> str:
    """把同口径的多个年度排名段压成一句：年份跨度 + 判断 + 括号口径。"""
    # hits: (year, sample_size, metric, highest, negative, basis)
    years = sorted(h[0] for h in hits)
    span = f"{years[0]}–{years[-1]}年" if years[-1] > years[0] else f"{years[0]}年"
    metric, highest, negative, basis, n = hits[-1][2], hits[-1][3], hits[-1][4], hits[-1][5], hits[-1][1]
    if negative in {"无", "无（仅限该期间、范围和币种的已覆盖样本）"}:
        neg_text = "无负值企业"
    else:
        neg_text = f"负值企业为{negative}"
    basis_short = "".join(basis.split("，")[:2]) or "年度"
    return f"{span}，{n}家样本公司{metric}最高为{highest}，{neg_text}（{basis_short}口径）"


def _readable_headline(headline: str) -> str:
    text = _reading_text(str(headline or "").strip())
    parts = [p.strip() for p in re.split(r"[；;]", text) if p.strip()]
    rank_hits: list[tuple[int, int, str, str, str, str]] = []
    rebuilt: list[str] = []
    for part in parts:
        m = _RANK_SEGMENT.search(part)
        if m:
            year, basis, n, metric, highest, negative = (
                int(m[1]), m[2], int(m[3]), m[4].strip(), m[5].strip(), m[6].strip())
            rank_hits.append((year, n, metric, highest, negative, basis))
            tail = part[m.end():].lstrip("。，,、 ")
            if tail:
                rebuilt.append(tail)
            continue
        cleaned = part.replace(_HEADLINE_BOILERPLATE, "").strip("。，,、 ")
        if cleaned:
            rebuilt.append(cleaned)
    lead = _rank_segment_summary(rank_hits) if rank_hits else ""
    pieces = ([lead] if lead else []) + rebuilt
    out = "。".join(pieces)
    if out and not out.endswith(("。", "！", "？")):
        out += "。"
    return _HEADLINE_CONNECTIVE.sub("", out)


def _reading_view(view: ReportViewModel) -> ReportViewModel:
    """Translate reader text only. Keep evidence, raw amounts, identifiers and URLs."""
    view = view.model_copy(deep=True)
    summary = view.executive_summary
    summary.headline = (clamp_sentence(_readable_headline(summary.headline), HEADLINE_LIMIT)
                        or f"{view.subject}行业研究：产业格局、财务质量与估值参照")
    summary.risks = list(map(_reading_text, summary.risks))
    summary.research_boundaries = list(map(_reading_text, summary.research_boundaries))
    summary.risks = _drop_duplicated_risks(summary.risks, summary.research_boundaries)
    view.risk_boundaries = list(dict.fromkeys([*summary.risks, *summary.research_boundaries]))
    view.cover_subtitle = _cover_subtitle(view)
    for conclusion in summary.conclusions:
        conclusion.text = clamp_sentence(_reading_text(conclusion.text), CONCLUSION_LIMIT)
        conclusion.uncertainty = _reading_text(conclusion.uncertainty)
    summary.takeaways = [{key: _reading_text(value) for key, value in item.items()} for item in summary.takeaways]
    cards = list(summary.metric_cards)
    for chart in view.charts:
        chart.title = _reading_text(chart.title)
        chart.insight_goal = _reading_text(chart.insight_goal)
        chart.footnotes = list(map(_reading_text, chart.footnotes))
        if chart.subtitle:
            chart.subtitle = _reading_text(chart.subtitle)
    dqa = view.data_quality_appendix
    if isinstance(dqa, dict):
        sample_info = dqa.get("sample_info")
        if isinstance(sample_info, dict) and isinstance(sample_info.get("limitations"), list):
            sample_info["limitations"] = list(map(_reading_text, sample_info["limitations"]))
        for key in ("non_extrapolation_disclaimers",):
            if isinstance(dqa.get(key), list):
                dqa[key] = list(map(_reading_text, dqa[key]))
    for chapter in view.chapters:
        chapter.summary = _reading_text(chapter.summary)
        for section in chapter.sections:
            section.key_points = list(map(_reading_text, section.key_points))
            section.uncertainties = list(map(_reading_text, section.uncertainties))
            for paragraph in section.paragraphs:
                paragraph.text = _reading_text(paragraph.text)
            for callout in section.callouts:
                callout.title = _reading_text(callout.title)
                callout.text = _reading_text(callout.text)
            cards.extend(section.metric_cards)
            if table := section.comparison_table:
                table.title = _reading_text(table.title)
                table.columns = list(map(_reading_text, table.columns))
                table.rows = [[str(row[0]), *(_reading_text(str(cell)) for cell in row[1:])] for row in table.rows if row]
    for card in cards:
        card.label = _reading_text(card.label)
        # 指标卡片的 value 也可能塞着指标组/字段名（如「链条指标缺失项」），
        # 纯数字值不动，含字母的才走读者语言翻译。
        if isinstance(card.value, str) and re.search(r"[A-Za-z_]", card.value):
            card.value = _reading_text(card.value)
        if card.period:
            card.period = _reading_text(card.period)
    return view


def _chapter_limit(chapter: Any) -> str:
    if any(item.get("disposition") in {"isolated", "partially_retained"} for item in chapter.content_audit):
        return "本章仅呈现已核验的内容，其余结论待补充证据。"
    return ""


def _question_index(view: ReportViewModel) -> list[dict[str, Any]]:
    paragraphs = {p.paragraph_id: p for c in view.chapters for s in c.sections for p in s.paragraphs}
    charts = {c.chart_id: c for c in view.charts}
    requirements = {r.get("requirement_id"): r.get("label") for r in
                    view.data_quality_appendix.get("requirement_output_links", [])}
    result = []
    for answer in view.question_answers:
        linked = [paragraphs[pid] for pid in answer.get("paragraph_ids", []) if pid in paragraphs]
        figures = [charts[cid] for cid in answer.get("chart_ids", []) if cid in charts]
        tables = [table for chart in figures if (table := _question_series_table(chart))]
        tables.extend(answer.get("financial_tables") or [])
        excerpt = next((p for p in linked if p.kind in {"thesis", "comparison", "analysis", "chart_readout"}),
                       linked[0] if linked else None)
        if cash_ratios := answer.get("cash_ratios"):
            tables.append({"title": "经营现金流对归母净利润的覆盖倍数",
                           "columns": ["公司", "年度", "净现比"], "rows": cash_ratios})
        if divergence := answer.get("revenue_cash_divergence"):
            tables.append({"title": "收入增长而经营现金流未增长的年度",
                           "columns": ["公司", "年度", "营收（亿）", "经营现金流（亿）", "币种", "口径"],
                           "rows": [([*cells[:-1], REPORT_BASIS_LABELS.get(cells[-1], cells[-1])], ids)
                                    for cells, ids in divergence]})
        yoy_by_chart = [{
            p["period"]: p for p in chart.data_contract.get("points", [])
            if p.get("calculation") == "yoy_percent" and p.get("period") and p.get("value") is not None
        } for chart in figures]
        yoy_by_chart = [series for series in yoy_by_chart if series]
        comparison = None
        if len(yoy_by_chart) == 2 and re.search(r"增速.*(?:背离|差距)", answer["text"]):
            left, right = yoy_by_chart
            dates = sorted(period for period in left.keys() & right.keys()
                           if all(left[period].get(field) == right[period].get(field)
                                  for field in ("period_type", "period_start", "scope")))
            if dates:
                date = max(dates, key=lambda period: abs(left[period]["value"] - right[period]["value"]))
                a, b = left[date], right[date]
                diff = abs(a["value"] - b["value"])
                names = {
                    "nev_sales": "新能源汽车销量", "nev_exports": "新能源汽车出口量",
                }
                labels = [names.get(metric_family(str(p.get("metric") or ""))) for p in (a, b)]
                subjects = "与".join(labels) if all(labels) else "两项指标"
                comparison = {
                    "text": f"共同可比年度内，{date[:4]} 年{subjects}的同比增速差距最大，绝对差为 {diff:.2f} 个百分点。",
                    "evidence_ids": [*a["source_record_ids"], *b["source_record_ids"]],
                }
                excerpt = None
        if any(table.get("monthly") or table.get("readout") for table in tables):
            excerpt = None
        if comparison is None and divergence:
            matches: dict[str, list[str]] = {}
            refs = []
            for cells, evidence_ids in divergence:
                if tuple(cells[-2:]) == ("CNY", "consolidated"):
                    matches.setdefault(cells[0], []).append(cells[1])
                    refs.extend(evidence_ids)
            if matches:
                companies = "、".join(f"{company}（{'、'.join(years)} 年）" for company, years in matches.items())
                comparison = {
                    "text": f"样本中出现增收不增现的公司和年度为{companies}。后续需核对营运资金变化，判断现金流转弱的来源。",
                    "evidence_ids": refs,
                }
                excerpt = None
        result.append({
            **answer,
            "excerpt": excerpt,
            "figures": figures,
            "series_tables": tables,
            "comparison": comparison,
            "missing": list(dict.fromkeys([
                *(requirements[rid] for rid in answer.get("unmet_requirement_ids", []) if requirements.get(rid)),
                *([answer["revision_evidence_gap"]] if answer.get("revision_evidence_gap") else []),
            ])),
        })
    return result


def _conclusion_evidence(questions: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Carry verified question readouts into the final conclusion section."""
    findings = []
    for row in questions:
        if row["comparison"]:
            findings.append(row["comparison"])
        for table in row["series_tables"]:
            if table.get("readout"):
                if table.get("monthly"):
                    findings.append({"text": table["readout"], "evidence_ids": table["readout_evidence"],
                                     "section": "research-questions"})
                else:
                    findings.append({"text": table["readout"], "evidence_ids": table["readout_evidence"]})
    return findings


def _follow_up_metrics(questions: list[dict[str, Any]]) -> list[tuple[str, str]]:
    """Translate this report's measured distinctions into checks for the next update."""
    metrics = []
    if any(row["comparison"] and "出口" in row["text"] and "销量" in row["text"] for row in questions):
        metrics.append(("销量与出口增速",
                        "对照下一年度的同比差距和出口占销量的比重。若增速差迅速收窄，结合整车与散件结构、目的地及海外注册量检验出口放量是否持续。"))
    if any(table.get("monthly") for row in questions for table in row["series_tables"]):
        metrics.append(("国内乘用车月度零售渗透率",
                        "同步观察滚动均值和上年同月。若两者连续走弱，重新评估渗透趋势，核对燃油车和新能源车各自的销量变化。"))
    if any(row.get("revenue_cash_divergence") for row in questions):
        metrics.append(("收入与经营现金流",
                        "跟踪出现背离的企业在下一可比期间是否恢复同步。用应收、存货、应付和合同负债的变化区分营运资金占用与收付款时点。"))
    if any(row.get("cash_ratios") for row in questions):
        metrics.append(("净现比",
                        "沿用经营现金流除以归母净利润的口径，观察现金覆盖改善能否延续。归母净利润为负或接近零时，单列原值判断。"))
    if any("分组" in row["text"] and row.get("financial_tables") for row in questions):
        metrics.append(("组内毛利率与研发费用率",
                        "比较下一年度组内差异与两组均值差。若研发费用率变化，分别核对研发费用和营业收入，再结合披露的产品构成解释。"))
    return metrics


def _question_series_table(chart: Any) -> dict[str, Any] | None:
    """Give time-series figures a readable record-level counterpart."""
    contract = chart.data_contract
    points = [p for p in contract.get("points", []) if p.get("value") is not None]
    series = contract.get("series_order") or []
    if not points or contract.get("axis_type") != "time_series" or len(series) > 3:
        return None
    if (all(p.get("period_type") == "month" and p.get("unit") == "%" for p in points)
            and len(series) == 1 and len(points) >= 24):
        years: dict[str, list[dict]] = {}
        for point in sorted(points, key=lambda p: p["period"]):
            years.setdefault(point["period"][:4], []).append(point)
        rows = []
        means = []
        for year, observations in years.items():
            first, last = observations[0], observations[-1]
            peak = first
            drawdown = None
            for point in observations[1:]:
                if point["value"] >= peak["value"]:
                    peak = point
                elif drawdown is None or peak["value"] - point["value"] > drawdown[0]:
                    drawdown = (peak["value"] - point["value"], peak, point)
            first_value = f"{first['period'][5:7]} 月 · {first['value']:g}{first['unit']}"
            last_value = f"{last['period'][5:7]} 月 · {last['value']:g}{last['unit']}"
            mean = sum(p["value"] for p in observations) / len(observations)
            means.append(mean)
            decline = "—"
            refs = [p["record_id"] for p in observations]
            if drawdown:
                change, high, low = drawdown
                decline = f"{high['period'][5:7]} 月至 {low['period'][5:7]} 月 · {change:.2f} 个百分点"
            rows.append(([year, first_value, last_value, f"{mean:.2f}%", decline], refs))
        readout = ""
        readout_evidence = []
        if len(means) >= 2 and all(right > left for left, right in zip(means, means[1:])):
            readout = (
                "按自然年分段，各年可得月份的平均渗透率逐年上移，但部分年内出现明显回撤。"
                "跟踪时宜同时比较滚动均值和上年同月，观察回撤是否伴随连续数月走弱。"
            )
            readout_evidence = []
        return {"title": f"{chart.figure_number} · {series[0]}的自然年观测",
                "columns": ["自然年", "首个观测月", "末个观测月", "可得月均值", "年内最大回撤"],
                "note": "均值为实际观测月份的简单平均。回撤为同年峰值到随后低点的最大百分点差。",
                "monthly": True, "readout": readout, "readout_evidence": readout_evidence,
                "rows": rows}
    if not (any(p.get("calculation") == "yoy_percent" for p in points)
            and all(p.get("period_type") in {"annual", "ytd_month"} for p in points)):
        return None
    by_category = {(p["category"], p["series"]): p for p in points}
    rows = []
    for category in contract.get("categories", []):
        values, refs = [category[:4]], []
        for name in series:
            if point := by_category.get((category, name)):
                values.append(f"{point['value']:,.2f}{point['unit']}")
                refs.extend(point.get("source_record_ids") or [point["record_id"]])
            else:
                values.append("—")
        rows.append((values, refs))
    return {"title": f"{chart.figure_number} · {chart.title}",
            "columns": ["年度", *series], "rows": rows}


def _citation_numbers(ids: list[str], lookup: dict[str, int]) -> list[int]:
    return sorted({lookup[rid] for rid in ids if rid in lookup})


def _evidence_href(url: str | None) -> str | None:
    if not url:
        return None
    try:
        parsed = urlsplit(url)
        return url if parsed.scheme in {"http", "https"} and parsed.hostname else None
    except ValueError:
        return None


def _mentions_figure(text: str, chart: Any) -> bool:
    return bool(chart.chart_id in text or (
        chart.figure_number and re.search(rf"{re.escape(chart.figure_number)}(?!\d)", text)
    ))


def _chart_caption_notes(chart: Any) -> list[str]:
    """An A3 SVG may already include its title, source and footnotes."""
    svg_text = re.sub(r"\s+", "", unescape(re.sub(r"<[^>]*>", "", chart.svg)))
    return [note for note in dict.fromkeys([chart.source_line, *chart.footnotes])
            if note and re.sub(r"\s+", "", note) not in svg_text]


def render_markdown(view: ReportViewModel) -> str:
    view = _reading_view(view)
    lookup = {x.record_id: x.number for x in view.evidence_catalog}
    lines = [
        f"# {view.title}",
        "",
        f"- 研究时点：{view.as_of.isoformat()}",
        f"- 交付状态：{_format_delivery_status(view.delivery_status)}",
        f"- 报告编号：{view.report_id}",
        "",
        "## 执行摘要与核心研判",
        "",
        view.executive_summary.headline,
        "",
    ]
    if view.delivery_status == "ready_with_limits":
        lines[6:6] = ["> 受限草稿。核验详情见附录一。", ""]
    elif view.delivery_status == "ready_scoped":
        lines[6:6] = ["> 有限覆盖报告。研究范围和限制见下方说明。", ""]
    if view.executive_summary.metric_cards:
        lines += ["### 核心量化指标", ""]
        for mc in view.executive_summary.metric_cards:
            val_disp = _format_card_value(mc.value, mc.unit)
            lines.append(f"- **{mc.label}**：{val_disp} ({mc.period or '最新期'})")
        lines.append("")

    lines += ["### 核心结论与驱动", ""]
    for item in view.executive_summary.conclusions:
        lines.append(
            f"- ■ **{item.text}** {_citations(item.evidence_ids, lookup)}（置信度：{_format_confidence(item.confidence)}；不确定性：{item.uncertainty or '见研究边界'}）"
        )

    if view.executive_summary.risks:
        def _risk_str(x: Any) -> str:
            if isinstance(x, dict):
                return str(x.get("text") or x.get("risk") or x.get("title") or "")
            return str(x)
        lines += ["", "### 核心风险提示", *["- " + _risk_str(x) for x in view.executive_summary.risks]]
    elif view.executive_summary.research_boundaries:
        # 风险条目全部与边界重复时（两栏同源），摘要里保留一份合并说明，不留空档。
        lines += ["", "### 研究边界与风险提示",
                  *["- " + b for b in view.executive_summary.research_boundaries]]

    # A3 问题索引（方案 5.6）：以实际发布图与落位段落为准回答用户问题；
    # 无逐题数据时整节不出现，不产生空节。
    questions = _question_index(view)
    if questions:
        lines += ["", "## 研究问题与结论索引", ""]
        for row in questions:
            lines += [f"### {row['question_id']} · {row['text']}", ""]
            if paragraph := row["excerpt"]:
                lines += [paragraph.text + " " + _citations(paragraph.evidence_ids, lookup), ""]
            if comparison := row["comparison"]:
                lines += [comparison["text"] + " " + _citations(comparison["evidence_ids"], lookup), ""]
            lines.append(f"正文参见《{row['section_title']}》。")
            if row["figures"]:
                lines.append("相关图表：" + "、".join(c.figure_number or c.title for c in row["figures"]))
            if row["missing"]:
                lines.append("待核资料：" + "、".join(row["missing"]))
            for table in row["series_tables"]:
                lines += ["", f"**{table['title']}**", "",
                          "| " + " | ".join([*table["columns"], "依据"]) + " |",
                          "| " + " | ".join(["---"] * (len(table["columns"]) + 1)) + " |"]
                for cells, ids in table["rows"]:
                    lines.append("| " + " | ".join([*cells, _citations(ids, lookup)]) + " |")
                if table.get("note"):
                    lines += ["", table["note"]]
                if table.get("readout"):
                    refs = "" if table.get("monthly") else _citations(table["readout_evidence"], lookup)
                    lines += ["", f"{table['readout']} {refs}".rstrip()]

    charts_by_section: dict[str, list[Any]] = {}
    for chart in view.charts:
        charts_by_section.setdefault(chart.placement_section_id, []).append(chart)

    for chapter in view.chapters:
        lines += ["", f"## {chapter.title}", "", chapter.summary]
        if limitation := _chapter_limit(chapter):
            lines += ["", f"**数据局限**　{limitation}"]
        if view.report_depth == "brief":
            continue
        for section in chapter.sections:
            lines += ["", f"### {section.title}", ""]
            if section.key_points:
                lines += ["**本节要点**：", *["- " + kp for kp in section.key_points], ""]

            sec_charts = list(charts_by_section.get(section.section_id, []))
            rendered_chart_ids: set[str] = set()

            def _chart_block(chart: Any) -> list[str]:
                fig_title = f"{chart.figure_number or '图表'}：{chart.title}"
                return [
                    f"**{fig_title}**",
                    f"> 分析目的：{chart.insight_goal}；资料依据：{_citations(chart.evidence_ids, lookup)}",
                    "",
                    f"![{fig_title}](./charts/{chart.chart_id}.svg)",
                    "",
                ]

            for para in section.paragraphs:
                lines += [para.text + " " + _citations(para.evidence_ids, lookup), ""]
                # 就近锚定：若段落提及了图表或为解读段，将对应图表紧随段落后内联插入，避免小节末尾图表堆叠
                for chart in sec_charts:
                    if chart.chart_id in rendered_chart_ids:
                        continue
                    fn = chart.figure_number
                    is_match = False
                    if fn and fn in para.text:
                        is_match = True
                    elif chart.chart_id in para.text:
                        is_match = True
                    elif getattr(para, "kind", "") == "chart_readout" and not rendered_chart_ids:
                        is_match = True

                    if is_match:
                        lines += _chart_block(chart)
                        rendered_chart_ids.add(chart.chart_id)
                        break

            for card in section.metric_cards:
                lines += [f"- **{card.label}**：{_format_card_value(card.value, card.unit)}（{card.period or '期间见证据'}） {_citations(card.evidence_ids, lookup)}", ""]
            for callout in section.callouts:
                lines += [f"**{callout.title}**", callout.text + " " + _citations(callout.evidence_ids, lookup), ""]
            if section.comparison_table and section.comparison_table.columns:
                lines += [f"**{section.comparison_table.title or '对比表'}**", ""]
                header = "| " + " | ".join(section.comparison_table.columns) + " |"
                sep = "| " + " | ".join(["---"] * len(section.comparison_table.columns)) + " |"
                lines += [header, sep]
                for row in section.comparison_table.rows:
                    lines.append("| " + " | ".join(str(c) for c in row) + " |")
                lines.append("")

            # 剩余未被段落就近内联引用的图表，安全兜底渲染
            for chart in sec_charts:
                if chart.chart_id not in rendered_chart_ids:
                    lines += _chart_block(chart)
                    rendered_chart_ids.add(chart.chart_id)

            if section.uncertainties:
                lines += ["**待验证事项**", *["- " + x for x in section.uncertainties], ""]

    dqa = view.data_quality_appendix or {}
    sample_info = dqa.get("sample_info", {})
    outliers = dqa.get("outlier_items", [])
    conflicts = dqa.get("conflict_items", [])
    disclaimers = dqa.get("non_extrapolation_disclaimers", []) or view.executive_summary.research_boundaries

    # 复算结论块（2026-11-16 删）：依赖未合并的财务派生函数，findings 恒空、
    # 该节在实际数据下从未渲染。HTML 侧 research.conclusions 宏保留（自带
    # {% if %} 自卫，conclusions 非空时仍出）。

    lines += ["", "## 附录一：数据质量、异常值剔除与口径说明附录", ""]
    if view.delivery_status in ("ready_with_limits", "ready_scoped") or view.quality_issues:
        lines += ["### 核验与交付限制", *[f"- {line}" for line in _quality_summary(view)], ""]
    annotated = view.verification_warnings or []
    if annotated:
        lines += [
            f"### 部分核验标注（{len(annotated)} 项）",
            "",
            "以下数值断言的证据在报告证据库中可见，但绑定层未能自动认领"
            "（主体归一、章节检索预算或币种口径）；正文已保留原句，供人工复核：",
            "",
            "| 位置 | 断言 | 判定类别 | 命中证据 |",
            "|---|---|---|---|",
        ]
        for item in annotated:
            category = _VERIFICATION_CATEGORY_LABELS.get(
                str(item.get("verification_category")), str(item.get("verification_category") or "-"))
            evidence = "、".join(str(e) for e in (item.get("verification_evidence_ids") or [])) or "-"
            lines.append(f"| {item.get('location', '-')} | {item.get('claim', '-')} | {category} | {evidence} |")
        lines.append("")
    lines += [
        "### 1. 样本结构与期间基准说明",
        f"- **样本记录数**：本次结构化记录共 {sample_info.get('total_records', len(view.evidence_catalog))} 条微观与宏观数据记录；",
        f"- **覆盖企业数**：样本企业共 {sample_info.get('total_companies', len(set(x.entity for x in view.evidence_catalog if x.entity)))} 家，对标矩阵覆盖 {sample_info.get('comps_sample_size', 0)} 家观测企业，主营可比性另行核验；",
        f"- **估值梯队结构**：盈利分层标的 {sample_info.get('profitable_sample_size', 0)} 家；微利/亏损/高乘数梯队 {sample_info.get('loss_or_high_multiple_size', 0)} 家；",
        f"- **估值可用覆盖**：PE {sample_info.get('pe_available_count', 0)}/{sample_info.get('comps_sample_size', 0)}；PB {sample_info.get('pb_available_count', 0)}/{sample_info.get('comps_sample_size', 0)}。可用观测不等于主营可比或成熟基准；",
        f"- **财务基准期间**：主要依据 {'、'.join(sample_info.get('primary_periods', ['最新公开披露报告期']))} ；不同期间长度分别比较；",
    ]
    if sample_info.get("limitations"):
        lines += ["- **数据局限提示**：", *["  - " + lim for lim in sample_info["limitations"]]]

    lines += [
        "",
        "### 2. 异常值识别与剔除明细",
        "",
        "| 实体名称 | 涉及指标 | 原始观察值 | 期间 / 来源 | 检测规则 / 观测范围 | 处理规则与剔除理由 |",
        "|---|---|---|---|---|---|",
    ]
    if outliers:
        for out in outliers:
            m_label = _format_metric_label(out.get('metric', '-'))
            o_val = _format_outlier_val(out.get('observed_value', '-'), out.get('metric', ''), out.get('unit'))
            e_range = _format_stat_text(out.get('expected_range', '-'))
            refs = _citations(out.get('evidence_ids', []), lookup)
            lines.append(f"| {out.get('entity', '-')} | {m_label} | {o_val} | {out.get('period', '-')} {refs} | {e_range} | {out.get('treatment', '剔除')}: {out.get('reason', '-')} |")
    else:
        lines.append("| 本轮样本 | - | 未产生可报告离群项 | - | - | 小样本不作显著性判断；此结果不代表事实已核验 |")

    lines += [
        "",
        "### 3. 多源数据冲突与仲裁记录",
        "",
        "| 实体名称 | 冲突指标 | 报告期间 | 多源观测值 | 仲裁规则与处理方案 |",
        "|---|---|---|---|---|",
    ]
    if conflicts:
        for conf in conflicts:
            vals_str = " vs ".join(conf.get("observed_values", []))
            refs = _citations(conf.get('evidence_ids', []), lookup)
            lines.append(f"| {conf.get('entity', '-')} | {_format_metric_label(conf.get('metric', '-'))} | {conf.get('period', '-')} | {vals_str} | {conf.get('arbitration_rule', '法定审计公告优先')} {refs} |")
    else:
        lines.append("| 本轮样本 | - | - | 未记录冲突 | 未记录冲突不表示每条记录已取得独立来源验证 |")

    lines += [
        "",
        "### 4. 量化结论边界与非外推声明",
        *(["- " + d for d in disclaimers] if disclaimers else ["- 本报告量化结论仅基于公开审计数据及行业测算，不可脱离假设前提全行业线性外推。"]),
        "",
        "## 附录二：原始数据穿透与事实证据索引",
        "",
        "|序号|实体/指标|值|期间|领域|",
        "|---:|---|---|---|---|",
    ]
    for source in view.evidence_catalog:
        calculation = f"（由来源{'、'.join(map(str, source.input_source_numbers))}计算）" if source.input_source_numbers else ""
        lines.append(
            f"|来源{source.number}|{source.entity or view.subject} / {_format_metric_label(source.metric)}{calculation}|{_display_evidence_value(source.value, source.unit, source.metric)}|{source.period or '-'}|{_format_domain_label(source.domain)}|"
        )
    for source in view.evidence_catalog:
        if source.source_url:
            published = f"；披露日 {source.published_at}" if source.published_at else ""
            digest = f"；SHA-256 {source.document_sha256}" if source.document_sha256 else ""
            lines.append(f"\n来源{source.number}原始公告：{source.source_url}（{source.source_locator or '详见原文'}{published}{digest}）")
    lines += ["", f"> {view.disclaimer}"]
    return "\n".join(lines) + "\n"


def render_html(view: ReportViewModel) -> str:
    view = _reading_view(view)
    lookup = {x.record_id: x.number for x in view.evidence_catalog}
    charts_by_section: dict[str, list[Any]] = {}
    for chart in view.charts:
        charts_by_section.setdefault(chart.placement_section_id, []).append(chart)

    tokens_css = (STYLES_DIR / "tokens.css").read_text(encoding="utf-8") if (STYLES_DIR / "tokens.css").exists() else ""
    print_css = (STYLES_DIR / "print.css").read_text(encoding="utf-8") if (STYLES_DIR / "print.css").exists() else ""

    norm_view = view
    if view.data_quality_appendix:
        norm_view = view.model_copy(update={"data_quality_appendix": _normalize_dqa(view.data_quality_appendix)})

    mode = getattr(view, "chart_mode", None) or "auto"
    env = _jinja_for(mode)
    try:
        tpl = env.get_template("report.html")
    except Exception as exc:
        # 根模板（templates/*.html）已随死代码清理移除，原「降级到根模板」兜底不再存在，
        # 此处只记录上下文后向上抛出，避免静默降级为错误版式。
        logger.error(
            "report.html 模板加载失败（chart_mode=%s，目录=%s）: %s",
            mode, getattr(env.loader, "searchpath", None), exc,
        )
        raise
    rendered = tpl.render(
        view=norm_view,
        charts_by_section=charts_by_section,
        lookup=lookup,
        tokens_css=tokens_css,
        print_css=print_css,
        chart_mode=mode,
        format_card_value=_format_card_value,
        quality_summary=_quality_summary(view),
        chapter_limit=_chapter_limit,
        # A3 问题索引：模板有 {% if questions %} 保护，off 档不会渲染空节。
        citation_numbers=_citation_numbers,
        questions=_question_index(view),
        conclusion_findings=_conclusion_evidence(_question_index(view)),
        follow_up_metrics=_follow_up_metrics(_question_index(view)),
    )

    return rendered
