"""Editorial fusion, consistency checks and multi-format export."""
from __future__ import annotations
from agents_core.financial_semantics import quantity_issues, metric_family, measurement_period, retain_supported_claims, verified_calculations, localization_rate_claim, substantive_removal_ids, diagnose_quantity_claim_detail, convert_unit_value
from agents_core.context_budget import ContextBudgetExceeded, serialize_context
from collections.abc import Awaitable,Callable
from datetime import datetime
import hashlib,json,re,secrets
import collections
from pathlib import Path
from typing import Any

from report_fusion.config import Settings
from report_fusion.appendix import audit_appendix
from report_fusion.requirement_links import link_requirement_outputs
from report_fusion.llm import FusionLLM,OpenAICompatibleLLM
from report_fusion.models import *
from report_fusion.pdf import backfill_toc_pages, render_pdf
from report_fusion.render import render_html,render_markdown
from report_fusion.render import CONCLUSION_LIMIT, HEADLINE_LIMIT, clamp_sentence
from report_fusion.skillhub import FusionSkillHub
from report_fusion.editorial_cleanup import clean_audited_summary

try:
    from skill_policy import merge_selection
except ModuleNotFoundError:  # 单包测试或独立运行时 agents_core 不在搜索路径上，按包位置回推
    import sys as _sys

    _sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    from skill_policy import merge_selection

EventEmitter=Callable[[dict[str,Any]],Awaitable[None]]
_FINAL_REPAIR_LIMIT = 8
_MEASURED_CLAIM = re.compile(r"\d\s*(?:万亿元|亿元|万元|元|[%％倍家台辆吨]|个百分点)")
_LEGACY_GAP_PREFIXES = ("资料缺口：该段结论", "【资料缺口】本项断言")
_CHAPTER_QUALITY_BLOCK = "输入章节有质量提示或使用兜底稿，交付以最终保留正文的核验结果为准"
# 章节层「过半组件因缺证据绑定被删除」的 issue 标记（与 chapter_writer 的安全网同一文案）。
# 这类缺口不属于「按比例可容忍的内容损失」：删掉一半指标卡是内容缺失，不是取舍。
_HIGH_ISOLATION_MARK = "组件隔离比例过高"
NUMBER_RE=re.compile(r"(?<![A-Za-z0-9_-])[-+]?\d+(?:\.\d+)?%?")
# 证据记录 id 形如 R-9436d98a835a92868c46（R- + 16~32 位小写十六进制）。
RECORD_ID_RE=re.compile(r"R-[0-9a-f]{16,32}\b")

_SVG_ROOT_RE=re.compile(r"<svg\b[^>]*>",re.IGNORECASE)
_SVG_FIXED_W_RE=re.compile(r'\swidth="\d+(?:\.\d+)?(?:px)?"')

# 检索/抓取通道的元数据字段不是「事实」，默认不进入事实证据目录：
# 它们的取值是分词标记、内部序号或引擎统计量（如 name=admin、status=0）。
# 一旦正文/图表实际引用某条元数据记录，它仍必须作为可追溯来源登记。
_META_ONLY_METRICS = {
    "summary", "title", "extra", "index", "name", "status", "source_original",
    "traceability_type", "site_authority", "operation_type", "index_time",
    "data_version", "publish_source", "real_publish_source", "host_name",
    "org_id", "data_source", "entity_identity", "iwc_index_report_v5_vector",
    "robot_universal_search",
}


def _is_substantive_metric(metric: str) -> bool:
    """区分事实字段与检索通道元数据；目录登记另按实际引用判断。"""
    return str(metric or "").strip().lower() not in _META_ONLY_METRICS


def _rewrite(artifact_dir: Path | None, name: str, data: bytes) -> None:
    """按最终视图就地重写文本格式（Markdown / HTML）。

    S-05：delivery_status 在导出后由最终事实决定，正文里嵌的值必须与之一致，
    否则读者看到“ready”但文件清单缺格式。只做原地覆盖，不新增产物。
    """
    if artifact_dir is None:
        return
    path = artifact_dir / name
    if path.exists():
        path.write_bytes(data)


def _split_uncited(text: str, refs: list[Any], universe: list[Any], **qualifiers) -> tuple[list[dict], list[dict]]:
    """区分「引用不全」与「确实无据」（2026-11-09）。

    段落只带自己的 evidence_ids 时，可能出现数字在本报告证据库里其实有记录、
    只是没被该段引用的情况（如 PB 6.6 倍来自估值表，段落只挂了估值图 id）。
    这类不应判成编造：严格引用审计失败后，再用**全库**复核一次。
      · 全库也失败 → 保持 unsupported_quantity（真缺口）
      · 全库可证   → 返回为 uncited_quantity（warning，不阻断交付）
    """
    strict = quantity_issues(text, refs, universe=universe, **qualifiers)
    if not strict or not refs:
        return strict, []
    # SEMI-F4：国产化率类断言不做宽库洗白——数字在证据库里别处有、但本段没有
    # 直接绑定同族证据时，仍按无出处隔离（而不是降级成 uncited warning）。
    if localization_rate_claim(text):
        return strict, []
    wide = quantity_issues(text, universe, universe=universe, **qualifiers)
    covered = {str(item.get("claim")) for item in wide}
    blocking = [item for item in strict if str(item.get("claim")) in covered]
    uncited = [item for item in strict if str(item.get("claim")) not in covered]
    return blocking, uncited


# ---------------------------------------------------------------------------
# 数值断言「标注不拦截」通道（2026-11-15 计划决策 1/2/3）。
# 诊断器（任务 1）证明被拦的 unsupported_quantity 里约半数「全库有据但绑定层未认」
# （junk 实体、跨章检索预算、亿美元口径）。这类断言保留正文并标注，不再隔离；
# 全库无据（absent）、国产化率族、硬需求缺口关联断言维持拦截，一条不能放。
# ---------------------------------------------------------------------------

# 容量双上限：单报告最多标注 150 条，且不超过数值问题总数的 60%（防「标注」变相全放行）
_ANNOTATION_LIMIT = 150
_ANNOTATION_RATIO = 0.60
# 证据强度排序：结构化精确命中 > 原文命中 > 跨章命中 > 币种错配；超限时弱证据先被拦
_ANNOTATION_PRIORITY = {"value_exact_structured": 0, "text_quote_only": 1,
                        "chapter_scope_only": 2, "unit_currency_mismatch": 3}


def _chapter_evidence_subsets(chapters: list[Any]) -> tuple[dict[str, set[str]], dict[str, str]]:
    """章节 id → 检索子集证据集合；小节 id → 章节 id（用于定位断言所属章节）。"""
    by_chapter: dict[str, set[str]] = {}
    section_chapter: dict[str, str] = {}
    for chapter in chapters:
        cid = str(getattr(chapter, "chapter_id", "") or "")
        by_chapter[cid] = {e for e in (getattr(chapter, "evidence_ids", None) or []) if e}
        for section in getattr(chapter, "sections", []) or []:
            sid = getattr(section, "section_id", None)
            if sid:
                section_chapter[str(sid)] = cid
    return by_chapter, section_chapter


def _triage_numeric_annotations(numeric_issues: list[dict], request: Any,
                                chapters: list[Any]) -> tuple[list[dict], list[dict]]:
    """把 pre-sanitize 审计出的 unsupported_quantity 按「全库证据可见性」分成标注与拦截。

    返回 (annotated, blocking)。annotated 项携带 verification_category 与
    verification_evidence_ids；blocking 为 absent/protected/超限弱证据，维持原处置。
    """
    universe = [row.model_dump(mode="json") if hasattr(row, "model_dump") else dict(row)
                for row in request.report.evidence_index.values()]
    requirement_rows = (getattr(request.report, "data_quality_appendix", {}) or {}
                        ).get("requirement_evidence_matrix") or []
    by_chapter, section_chapter = _chapter_evidence_subsets(chapters)
    total = sum(1 for issue in numeric_issues if issue.get("code") == "unsupported_quantity")
    candidates: list[tuple[int, dict, str, list[str]]] = []
    for issue in numeric_issues:
        if issue.get("code") != "unsupported_quantity":
            continue
        location = str(issue.get("location") or "")
        head = location.split(".")[0]
        chapter_id = head if head in by_chapter else section_chapter.get(head)
        category, hits = diagnose_quantity_claim_detail(
            issue, universe, chapter_evidence=by_chapter.get(chapter_id or "", None),
            requirement_rows=requirement_rows)
        if category in _ANNOTATION_PRIORITY:
            candidates.append((_ANNOTATION_PRIORITY[category], issue, category, hits))
    # 60% 上限用 max(1,·) 兜底：单条断言的小报告不应因取整退化成「永远标不了」
    cap = min(_ANNOTATION_LIMIT, max(1, int(total * _ANNOTATION_RATIO)))
    candidates.sort(key=lambda item: item[0])
    annotated, blocked = [], []
    seen_keys: set[tuple[str, str]] = set()
    for prio, issue, category, hits in candidates:
        item = dict(issue)
        item.update(disposition="annotated", severity="warning",
                    verification_category=category, verification_evidence_ids=hits[:8])
        seen_keys.add((_norm_location(item.get("location")), str(item.get("claim"))))
        (annotated if len(annotated) < cap else blocked).append(item)
    for issue in numeric_issues:
        if issue.get("code") != "unsupported_quantity":
            continue
        key = (_norm_location(issue.get("location")), str(issue.get("claim")))
        if key in seen_keys:
            continue                      # 已在 annotated/blocked 里（含超限溢出项）
        blocked.append(dict(issue))
    return annotated, blocked


def _all_annotated(issues: list[dict]) -> bool:
    """组件的全部数值问题都已转为标注时，组件内容保留、不再隔离。"""
    return bool(issues) and all(issue.get("disposition") == "annotated" for issue in issues)


_INDEX_SUFFIX_RE = re.compile(r"\[\d+\]")


def _norm_location(location: object) -> str:
    """allowlist 键归一：去掉 key_points[1]/cards[2] 这类序号后缀。

    sanitize 会删除未通过的 key_point/结论，序号整体前移——带序号的精确匹配
    会让 pre_audit 建立的标注 allowlist 在终审/清洗审计里对不上（实测
    「1659」在 SEC-06-01.key_points[0] 位移后重新被拦）。段落 id 无序号，不受影响。
    """
    return _INDEX_SUFFIX_RE.sub("", str(location or ""))


def _editorial_reason(entry: dict | None, fallback: str) -> str:
    """只从内容审计条目提炼原因码，不把原文或证据 ID 写进摘要。"""
    if not entry:
        return fallback
    if entry.get("disposition") == "partially_retained":
        return "交付审计局部剥离：仅保留可核验子句"
    if entry.get("disposition") == "isolated":
        return "交付审计隔离：仅保留可核验内容"
    return fallback


def _build_editorial_changes(source_chapters: list[Any], final_chapters: list[Any]) -> list[EditorialChange]:
    """对比 A4 已审稿与 A5 交付稿，生成最小审计摘要。

    约束：每个条目只有位置、变更类型与原因；不复制正文、不携带证据原文。
    没有实际差异时返回空列表，不能为“有编辑动作”伪造变更。
    """
    def compact(value: object) -> str:
        return "".join(str(value or "").split())

    def paragraph_map(chapters: list[Any]) -> tuple[dict[tuple[str, str, str], Any], dict[tuple[str, str, str], str]]:
        items: dict[tuple[str, str, str], Any] = {}
        positions: dict[tuple[str, str, str], str] = {}
        for chapter in chapters:
            for section in getattr(chapter, "sections", []) or []:
                for paragraph in getattr(section, "paragraphs", []) or []:
                    key = (str(getattr(chapter, "chapter_id", "")), str(getattr(section, "section_id", "")),
                           str(getattr(paragraph, "paragraph_id", "")))
                    items[key] = paragraph
                    positions[key] = str(getattr(paragraph, "paragraph_id", ""))
        return items, positions

    source_paragraphs, _ = paragraph_map(source_chapters)
    final_paragraphs, _ = paragraph_map(final_chapters)
    audit_by_paragraph: dict[str, dict] = {}
    for chapter in final_chapters:
        for entry in getattr(chapter, "content_audit", []) or []:
            if isinstance(entry, dict) and entry.get("location"):
                audit_by_paragraph[str(entry["location"])] = entry

    source_chapter_map = {str(getattr(ch, "chapter_id", "")): ch for ch in source_chapters}
    final_chapter_map = {str(getattr(ch, "chapter_id", "")): ch for ch in final_chapters}
    changes: list[EditorialChange] = []

    for chapter in final_chapters:
        chapter_id = str(getattr(chapter, "chapter_id", ""))
        source_chapter = source_chapter_map.get(chapter_id)
        if source_chapter is None:
            changes.append(EditorialChange(change_type="patch", chapter_id=chapter_id,
                                           reason="交付层新增章节结构"))
            continue
        if compact(getattr(source_chapter, "title", "")) != compact(getattr(chapter, "title", "")):
            changes.append(EditorialChange(change_type="edit", chapter_id=chapter_id,
                                           reason="章节标题编辑"))
        if compact(getattr(source_chapter, "summary", "")) != compact(getattr(chapter, "summary", "")):
            changes.append(EditorialChange(change_type="edit", chapter_id=chapter_id,
                                           reason="章节摘要编辑"))

        source_sections = {str(getattr(sec, "section_id", "")): sec
                           for sec in getattr(source_chapter, "sections", []) or []}
        final_sections = {str(getattr(sec, "section_id", "")): sec
                          for sec in getattr(chapter, "sections", []) or []}
        for section in getattr(chapter, "sections", []) or []:
            section_id = str(getattr(section, "section_id", ""))
            source_section = source_sections.get(section_id)
            if source_section is None:
                changes.append(EditorialChange(change_type="patch", chapter_id=chapter_id,
                                               section_id=section_id, reason="交付层新增小节结构"))
                continue
            if compact(getattr(source_section, "title", "")) != compact(getattr(section, "title", "")):
                changes.append(EditorialChange(change_type="edit", chapter_id=chapter_id,
                                               section_id=section_id, reason="小节标题编辑"))
            if list(getattr(source_section, "chart_ids", []) or []) != list(getattr(section, "chart_ids", []) or []):
                changes.append(EditorialChange(change_type="edit", chapter_id=chapter_id,
                                               section_id=section_id, reason="图表归位到交付小节"))
            source_components = (
                tuple(compact(x) for x in getattr(source_section, "key_points", []) or []),
                tuple(compact(getattr(x, "label", "")) + "|" + compact(getattr(x, "value", "")) + "|" + compact(getattr(x, "unit", ""))
                      for x in getattr(source_section, "metric_cards", []) or []),
                tuple(compact(getattr(x, "title", "")) + "|" + repr(getattr(x, "rows", []))
                      for x in ([getattr(source_section, "comparison_table", None)] if getattr(source_section, "comparison_table", None) else [])),
            )
            final_components = (
                tuple(compact(x) for x in getattr(section, "key_points", []) or []),
                tuple(compact(getattr(x, "label", "")) + "|" + compact(getattr(x, "value", "")) + "|" + compact(getattr(x, "unit", ""))
                      for x in getattr(section, "metric_cards", []) or []),
                tuple(compact(getattr(x, "title", "")) + "|" + repr(getattr(x, "rows", []))
                      for x in ([getattr(section, "comparison_table", None)] if getattr(section, "comparison_table", None) else [])),
            )
            if source_components != final_components:
                changes.append(EditorialChange(change_type="edit", chapter_id=chapter_id,
                                               section_id=section_id, reason="结构化组件经审计缩减或修订"))

        for section in source_sections.values():
            section_id = str(getattr(section, "section_id", ""))
            if section_id not in final_sections:
                changes.append(EditorialChange(change_type="isolate", chapter_id=chapter_id,
                                               section_id=section_id, reason="交付审计隔离整节"))
        for section in final_sections.values():
            section_id = str(getattr(section, "section_id", ""))
            if section_id not in source_sections:
                changes.append(EditorialChange(change_type="patch", chapter_id=chapter_id,
                                               section_id=section_id, reason="交付层新增小节结构"))

    for chapter_id, source_chapter in source_chapter_map.items():
        if chapter_id not in final_chapter_map:
            changes.append(EditorialChange(change_type="isolate", chapter_id=chapter_id,
                                           reason="交付审计隔离整章"))

    for key, paragraph in source_paragraphs.items():
        chapter_id, section_id, paragraph_id = key
        final_paragraph = final_paragraphs.get(key)
        if final_paragraph is None:
            changes.append(EditorialChange(
                change_type="isolate", chapter_id=chapter_id, section_id=section_id, paragraph_id=paragraph_id,
                reason=_editorial_reason(audit_by_paragraph.get(paragraph_id), "交付审计移除段落")))
        elif compact(getattr(paragraph, "text", "")) != compact(getattr(final_paragraph, "text", "")):
            changes.append(EditorialChange(
                change_type="edit", chapter_id=chapter_id, section_id=section_id, paragraph_id=paragraph_id,
                reason=_editorial_reason(audit_by_paragraph.get(paragraph_id), "编辑修订（保留原有证据绑定）")))

    for key, paragraph in final_paragraphs.items():
        if key in source_paragraphs:
            continue
        chapter_id, section_id, paragraph_id = key
        reason = "结构性过渡段补写" if str(getattr(paragraph, "kind", "")) == "transition" else "最终交付补写段落"
        changes.append(EditorialChange(change_type="patch", chapter_id=chapter_id,
                                       section_id=section_id, paragraph_id=paragraph_id, reason=reason))

    # 同一段落可能同时命中图表/组件与文本；保留不同变更维度，但去掉完全重复项。
    unique: list[EditorialChange] = []
    seen = set()
    for item in changes:
        key = (item.change_type, item.chapter_id, item.section_id, item.paragraph_id, item.reason)
        if key not in seen:
            seen.add(key)
            unique.append(item)
    return unique


# ---------------------------------------------------------------------------
# 陈旧缺口叙述治理（2026-11-15 任务 6）：上游模型的自由文本 warnings 会把
# 结构化覆盖矩阵判定为「已通过」的需求写成「未通过/证据库未提供」——直连问财
# 证实数据其实取到了（公告 10 条线索、研发投入 12 条记录）。融合层在合并
# warnings 时做矛盾过滤：改写为矩阵驱动文案并留 original 痕迹，不静默删除。
# ---------------------------------------------------------------------------

_ANNOUNCEMENT_ROW_RE = re.compile(r"announcement|公告")
_STALE_ANNOUNCEMENT_RE = re.compile(r"公告检索[^。；]{0,70}(?:均?未通过|未取得|未返回|未完成核验|未获[^。；]{0,10}验证)")
_STALE_RD_RE = re.compile(r"未提供可引用的原始记录ID|原始记录ID[^。；]{0,20}未出现|对应数值未出现在本次可读证据字段")


def _is_announcement_row(row: dict) -> bool:
    req = row.get("requirement") or row
    return bool(_ANNOUNCEMENT_ROW_RE.search(
        f"{req.get('domain') or ''} {req.get('requirement_id') or ''} {req.get('label') or ''}"))


def _reconcile_gap_warnings(warnings: list[str], requirement_matrix: list,
                            evidence_index: dict) -> tuple[list[str], list[dict]]:
    """把与覆盖矩阵矛盾的缺口叙述改写为矩阵驱动文案。

    返回 (改写后的 warnings, 改写留痕)。矩阵确有 failed 行或 warning 与矩阵无关
    时原文保留（fail-closed：只修「说缺了但其实有」的，不洗「真缺了」的）。
    """
    rewrites: list[dict] = []
    out: list[str] = []
    announcement_rows = [row for row in (requirement_matrix or []) if isinstance(row, dict)
                         and _is_announcement_row(row)]
    announcement_all_passed = bool(announcement_rows) and all(
        (row.get("coverage") or {}).get("passed") is True for row in announcement_rows)
    rd_records = [ref for ref in (evidence_index or {}).values()
                  if metric_family(str((ref.get("metric") if isinstance(ref, dict) else getattr(ref, "metric", "")) or ""))
                  in ("rd_investment", "rd_expense")]
    for text in warnings:
        body = str(text or "")
        if _STALE_ANNOUNCEMENT_RE.search(body) and announcement_all_passed:
            total_clues = sum(int((row.get("coverage") or {}).get("evidence_count") or 0)
                              for row in announcement_rows)
            missing_labels = [str(row.get("requirement") or {}).get("label") or ""
                              for row in announcement_rows
                              if (row.get("coverage") or {}).get("missing")]
            missing_clause = f"缺失清单：{'、'.join(missing_labels)}" if missing_labels \
                else "更正/会计政策变更类公告未在缺失清单中"
            body = (f"公告检索需求已通过：共取得公告线索 {total_clues} 条，"
                    f"{len(announcement_rows)} 项硬性要求全部通过；{missing_clause}，"
                    f"口径一致性以命中的年报公告为准。")
            rewrites.append({"original": str(text), "rewritten": body, "rule": "announcement_coverage"})
        elif _STALE_RD_RE.search(body) and rd_records:
            revenue_records = [ref for ref in (evidence_index or {}).values()
                               if metric_family(str((ref.get("metric") if isinstance(ref, dict) else getattr(ref, "metric", "")) or ""))
                               == "revenue"]
            body = (f"研发投入与营收年度序列可由证据目录提供：研发类年度观测 {len(rd_records)} 条、"
                    f"营收年度观测 {len(revenue_records)} 条（覆盖矩阵标记已通过）；"
                    f"年度序列期数有限，仅做描述性统计与方向一致性检验。")
            rewrites.append({"original": str(text), "rewritten": body, "rule": "rd_records_present"})
        out.append(body)
    return out, rewrites


def _audit_numeric_components(chapters: list[Any], summary: Any, request: Any, *,
                              sanitize: bool = False,
                              uncited: list[dict] | None = None,
                              annotations: dict[tuple[str, str], dict] | None = None) -> list[dict]:
    issues = []
    index = request.report.evidence_index
    # B57：「4 家样本总市值 8,901.97 亿元」这类断言不会出现在任何单条记录里——它是
    # comps_matrix.total_market_cap 这个**已算好的样本聚合值**（融合层自己在
    # `_reconcile_market_cap_consistency` 里也用它做一致性基准）。指标卡通常只挂
    # 一两条公司市值记录，派生统计通道要求 ≥3 个成分，于是被误判无据。
    # 这里把聚合值作为一条合成证据放进索引（不改章节引用），值/族/期间仍须逐项对上。
    total_market_cap = (getattr(request.report, "comps_matrix", {}) or {}).get("total_market_cap")
    if isinstance(total_market_cap, (int, float)) and total_market_cap > 0:
        index = dict(index)
        index["__comps_total_market_cap__"] = {
            "record_id": "__comps_total_market_cap__", "domain": "financials",
            "entity": "样本", "metric": "market_cap",
            "value": float(total_market_cap) * 1e8, "unit": "元",
            "period": str(getattr(request.report, "as_of", "") or ""),
            "period_type": "point", "scope": "consolidated",
            "provenance": "comps_matrix.total_market_cap",
        }
    # B27：派生计算（净现比 = 经营现金流/净利润、研发费用率 = 研发费用/营收）的输入证据
    # 不必落在「本段/本表绑定的 evidence_ids」里。绑定的是代表证据，而计算要的是分子分母
    # 两条原始记录。实测 SEMI-Q4 的净现比表只绑了 6 条（中微、北方华创），拓荆/盛美的
    # 输入记录在全库但不在绑定集，于是表里的 3.92、0.17 被判无据——而它们由
    # `financial_ratios.calculations` 精确重建得出来（3.9205693 / 0.1710995）。
    # 故按全库重建；重建值仍须与断言的 entity + 指标族 + 期间逐项对上，伪造不了。
    derived_ids = list(index)
    # B38（2026-11-11 LA-Q3 实测）：章节 summary 复述的图表统计量（「样本PE跨度
    # 从6.4倍至615.9倍」的端点值），其证据记录在**关联图表**的 evidence_ids/
    # point_evidence_ids/data_contract.points 里，而 summary 的 evidence_ids
    # 只绑了少量代表记录——值匹配只遍历绑定集，端点不在集内即误判无据。
    # 图表是章节证据的正式组成部分（chapter.chart_ids 已声明关联），并入绑定集
    # 是绑定完整性修复，不是放水：记录仍须逐项通过 entity/族/期间/单位校验。
    chart_evidence: dict[str, list[str]] = {}
    for chart in (getattr(request.charts, "charts", None) or []):
        cid = getattr(chart, "chart_id", None)
        if not cid:
            continue
        ids = list(getattr(chart, "evidence_ids", None) or [])
        ids.extend(getattr(chart, "point_evidence_ids", None) or [])
        dc = getattr(chart, "data_contract", None)
        if isinstance(dc, dict):
            for point in dc.get("points", []) or []:
                rid = point.get("record_id") if isinstance(point, dict) else None
                if rid:
                    ids.append(rid)
        chart_evidence[cid] = ids
    def local_text(text: str, ids: list[str], location: str = "", **qualifiers) -> str:
        refs = [index[e] for e in ids if e in index]
        refs.extend(verified_calculations(request.report.financial_ratios, index, derived_ids))
        annotation_keys = annotations or {}
        def keep(clause: str) -> bool:
            found = quantity_issues(clause, refs, universe=list(index.values()),
                sample_universe=request.report.financial_ratios, **qualifiers)
            # 标注通道（2026-11-15）：命中 allowlist 的 unsupported_quantity 视为
            # 「有据待人工复核」，子句保留在正文（其余类型问题照旧剥离）。
            remaining = [item for item in found
                         if not (item.get("code") == "unsupported_quantity"
                                 and (_norm_location(location), str(item.get("claim"))) in annotation_keys)]
            return not remaining
        return retain_supported_claims(text, keep, check_context=True)
    def audit(text: str, ids: list[str], location: str, **qualifiers) -> list[dict]:
        refs = [index[e] for e in ids if e in index]
        refs.extend(verified_calculations(request.report.financial_ratios, index, derived_ids))
        found, unbound = _split_uncited(text, refs, list(index.values()),
                                        location=location,
                                        sample_universe=request.report.financial_ratios,
                                        **qualifiers)
        for issue in found:
            # original 无条件带上：标注分诊（pre_audit，sanitize=False）要靠它恢复
            # 「1659亿美元」这类被 QUANTITY_RE 截断的口径。
            issue.update(original=text)
            info = (annotations or {}).get((_norm_location(location), str(issue.get("claim")))
                                           if issue.get("code") == "unsupported_quantity" else None)
            if info:
                issue.update(disposition="annotated", severity="warning",
                             verification_category=info.get("category"),
                             verification_evidence_ids=info.get("evidence_ids"))
            elif sanitize:
                issue.update(disposition="isolated")
        if unbound and uncited is not None:
            for issue in unbound:
                issue.update(code="uncited_quantity", severity="warning",
                             original=text, disposition="uncited")
            uncited.extend(unbound)
        issues.extend(found)
        return found
    for ch in chapters:
        ch_ids = list(dict.fromkeys(ch.evidence_ids + [e for s in ch.sections for p in s.paragraphs for e in p.evidence_ids]))
        for cid in getattr(ch, "chart_ids", None) or []:
            ch_ids.extend(chart_evidence.get(cid, []))
        ch_ids = list(dict.fromkeys(ch_ids))
        if audit(ch.summary, ch_ids, ch.chapter_id + ".summary") and sanitize:
            ch.summary = local_text(ch.summary, ch_ids, ch.chapter_id + ".summary")
        for sec in ch.sections:
            sec_ids = list(dict.fromkeys(e for p in sec.paragraphs for e in p.evidence_ids))
            # B57：结构化组件的「依据面」= 组件自带证据 ∪ 本节证据 ∪ 本节挂接图表证据。
            # 实测低空 run：指标卡/对比表引用的是**公告原文**（value 是一整篇摘录，
            # 无结构化数值），而支撑同一个数字的财报行记录（revenue=12,309,542,333.37 元）
            # 只挂在本节段落上——只按组件自带 ids 判定，等于要求「引用源 == 数据源」，
            # 于是 123.10 亿元这类真实披露被判无据。绑定集是「在哪一节被引用」的语义，
            # 不是排他引用；实体/指标族/期间/单位校验一条没放松。
            for cid in getattr(sec, "chart_ids", None) or []:
                sec_ids.extend(chart_evidence.get(cid, []))
            sec_ids = list(dict.fromkeys(sec_ids))
            new_points = []
            for i, point in enumerate(sec.key_points):
                bad = audit(point, sec_ids, f"{sec.section_id}.key_points[{i}]")
                retained = (local_text(point, sec_ids, f"{sec.section_id}.key_points[{i}]")
                            if bad and sanitize else point)
                if retained:
                    new_points.append(retained)
            if sanitize:
                sec.key_points = new_points
            for para in sec.paragraphs:
                bad = audit(para.text, para.evidence_ids, para.paragraph_id,
                    assumption_note=para.assumption_note, kind=para.kind)
                legacy_gap = para.text.startswith(_LEGACY_GAP_PREFIXES)
                unknown_ids = set(para.evidence_ids) - set(index)
                # 标注通道：全部数值问题都已转为标注时，正文原样保留（不进隔离分支，
                # 也不写 fusion_claim_isolation 审计——内容没有被移除）。
                if sanitize and ((bad and not _all_annotated(bad)) or legacy_gap or unknown_ids):
                    original = para.text
                    para.text = "" if legacy_gap else local_text(original, para.evidence_ids,
                        para.paragraph_id,
                        assumption_note=para.assumption_note, kind=para.kind)
                    para.evidence_ids = [rid for rid in para.evidence_ids if rid in index]
                    ch.content_audit.append({
                        "code": "fusion_claim_isolation", "location": para.paragraph_id,
                        "section_id": sec.section_id, "original": original,
                        "claim": "；".join(str(issue["claim"]) for issue in bad),
                        "evidence_ids": para.evidence_ids,
                        "disposition": "partially_retained" if para.text else "isolated",
                    })
            if sanitize:
                sec.paragraphs = [para for para in sec.paragraphs if para.text.strip()]
            cards = []
            for i, card in enumerate(sec.metric_cards):
                card_ids = list(dict.fromkeys([*(card.evidence_ids or []), *sec_ids]))
                bad = audit(f"{card.label} {card.period or ''} {card.value}{card.unit or ''}", card_ids, f"{sec.section_id}.cards[{i}]")
                if not bad or not sanitize or _all_annotated(bad):
                    cards.append(card)
            if sanitize:
                sec.metric_cards = cards
            if sec.comparison_table:
                table = sec.comparison_table
                rows = []
                for i, row in enumerate(table.rows):
                    retained_row = list(row)
                    for j, cell in enumerate(row):
                        if j == 0 or str(cell).strip() == "待核验":
                            continue
                        heading = table.columns[j] if j < len(table.columns) else table.title
                        # 列名里的**小数**是偏离基准/统计量（如「相对52.63倍偏离（%）」的
                        # 中位数基准），属于表结构描述而非数据断言。原样拼进每个单元格的
                        # 审计文本，会让同一个基准值被逐行要求命中证据——B26 实测：7 行
                        # 估值表因此报了 3 条「52.63倍 无匹配证据」的 hard block，而该值
                        # 本身有据（长川科技 pe_ttm=52.628551），只是不属于这三行绑定的
                        # 证据集。只去小数：单位（元/倍/%）必须保留——无单位单元格靠它补
                        # 量纲；整数（年份/序号）也必须保留——期间绑定要用。
                        heading_claim = re.sub(r"(?<![\d.])\d+\.\d+", "", heading)
                        # Table unit often lives in the column heading, not the cell.
                        # B57：补「个百分点」——「增速变化（百分点）」列的值是两期增速之差，
                        # 丢了单位会被当成百分比变化重算（-26.20 被算成 -45.8%）而误判无据。
                        unit_match = re.search(r"万亿元|亿元|万元|万辆|万台|万吨|个?百分点|元|%|倍|家|辆|台|吨", heading)
                        cell_text = str(cell)
                        if unit_match and not re.search(r"元|%|倍|家|百分点|辆|台|吨", cell_text):
                            unit = unit_match.group(0)
                            cell_text += "个百分点" if unit == "百分点" else unit
                        bad = audit(f"{row[0]} {heading_claim} {cell_text}", list(dict.fromkeys([*(table.evidence_ids or []), *sec_ids])), f"{sec.section_id}.table[{i}][{j}]")
                        if bad and sanitize and not _all_annotated(bad):
                            retained_row[j] = "待核验"
                    if not sanitize or any(cell != "待核验" for cell in retained_row[1:]):
                        rows.append(retained_row)
                if sanitize:
                    table.rows = rows
                    if not rows:
                        sec.comparison_table = None
            callouts = []
            for i, callout in enumerate(sec.callouts):
                callout_ids = list(dict.fromkeys([*(callout.evidence_ids or []), *sec_ids]))
                # B60：标题与正文分开审计。标题是**标签**不是断言，拼在一起会让标题里的
                # 词污染正文的指标族判定——实测「亿航智能营收数据缺失」+「2024年交付216架」
                # 被判成「营收口径的216」，硬阻塞了一份合格的交付件。
                bad = audit(callout.title, callout_ids, f"{sec.section_id}.callouts[{i}].title")
                bad += audit(callout.text, callout_ids, f"{sec.section_id}.callouts[{i}]")
                if not bad or not sanitize or _all_annotated(bad):
                    callouts.append(callout)
                elif not audit(callout.title, callout_ids, f"{sec.section_id}.callouts[{i}].title"):
                    if retained := local_text(callout.text, callout_ids, f"{sec.section_id}.callouts[{i}]"):
                        callouts.append(callout.model_copy(update={"text": retained}))
            if sanitize:
                sec.callouts = callouts
    if summary and not isinstance(summary, dict):
        summary_ids = list(dict.fromkeys(e for c in summary.conclusions for e in c.evidence_ids))
        if audit(summary.headline, summary_ids, "summary.headline") and sanitize:
            summary.headline = local_text(summary.headline, summary_ids, "summary.headline")
        for i, conclusion in enumerate(summary.conclusions):
            if audit(conclusion.text, conclusion.evidence_ids, f"summary.conclusions[{i}]") and sanitize:
                conclusion.text = local_text(conclusion.text, conclusion.evidence_ids,
                                             f"summary.conclusions[{i}]")
                conclusion.evidence_ids = [rid for rid in conclusion.evidence_ids if rid in index]
        if sanitize:
            summary.conclusions = [item for item in summary.conclusions if item.text.strip()]
        cards = []
        for i, card in enumerate(summary.metric_cards):
            bad = audit(f"{card.label} {card.period or ''} {card.value}{card.unit or ''}", card.evidence_ids, f"summary.cards[{i}]")
            if not bad or not sanitize or _all_annotated(bad):
                cards.append(card)
        if sanitize:
            summary.metric_cards = cards
        for field in ("risks", "research_boundaries"):
            values = getattr(summary, field)
            verified = []
            for i, text in enumerate(values):
                bad = audit(text, summary_ids, f"summary.{field}[{i}]")
                if not bad or not sanitize:
                    verified.append(text)
                elif retained := local_text(text, summary_ids, f"summary.{field}[{i}]"):
                    verified.append(retained)
            if sanitize:
                setattr(summary, field, verified)
        takeaways = []
        for i, item in enumerate(summary.takeaways):
            bad = audit(" ".join(item.values()), summary_ids, f"summary.takeaways[{i}]")
            if not bad or not sanitize or _all_annotated(bad):
                takeaways.append(item)
        if sanitize:
            summary.takeaways = takeaways
    return issues


def _chart_contract_issues(chart: Any, index: dict[str, Any]) -> list[str]:
    if getattr(chart, "chart_type", "") == "industry_chain":
        return []
    contract = getattr(chart, "data_contract", {}) or {}
    points = contract.get("points", [])
    if not points:
        return ["缺少数据点语义契约，图表尚未核验"]
    problems = []
    source_option = getattr(chart, "option", {}) or {}
    rendered_series = source_option.get("series", [])
    series_order = contract.get("series_order") or list(dict.fromkeys(p.get("series") for p in points))
    for point in points:
        ref = index.get(point.get("record_id"))
        if ref is None:
            problems.append("数据点证据不存在")
            continue
        if (point.get("entity") != ref.entity or metric_family(str(point.get("metric"))) != metric_family(ref.metric)
                or point.get("period") != (str(ref.period) if ref.period else None)
                or point.get("scope", "consolidated") != ref.scope
                or point.get("currency", "CNY") != ref.currency):
            problems.append("数据点实体、指标或期间与证据不符")
            continue
        try:
            idx = point["index"]
            series_name = point["series"]
            category = point.get("category")
            if chart.chart_type in ("scatter", "bubble"):
                entries = [entry for serie in rendered_series for entry in serie.get("data", [])
                           if isinstance(entry, dict) and entry.get("name") == category]
                if len(entries) != 1:
                    raise ValueError("scatter label")
                coordinate = series_order.index(series_name)
                actual_value = entries[0]["value"][coordinate]
            elif chart.chart_type == "radar":
                entries = [entry for serie in rendered_series for entry in serie.get("data", [])
                           if isinstance(entry, dict) and entry.get("name") == series_name]
                if len(entries) != 1:
                    raise ValueError("radar entity")
                indicators = source_option.get("radar", {}).get("indicator", [])
                if indicators[idx].get("name") != category:
                    raise ValueError("radar indicator")
                actual_value = entries[0]["value"][idx]
            else:
                matches = [serie for serie in rendered_series if serie.get("name") == series_name]
                if not matches and len(rendered_series) == 1:
                    matches = rendered_series
                if len(matches) != 1:
                    raise ValueError("series identity")
                entry = matches[0]["data"][idx]
                if isinstance(entry, dict):
                    if entry.get("name") and entry["name"] != category:
                        raise ValueError("category identity")
                    actual_value = entry["value"]
                else:
                    actual_value = entry
            if actual_value != point["value"]:
                raise ValueError("point value")
        except (ValueError, KeyError, TypeError, IndexError):
            problems.append("数据点与实际类别、系列或坐标位置不一致")
        try:
            unit = point.get("unit")
            if unit is None:
                # B23-T12（2026-11-10 第五轮实测）：多指标组合图的点在契约里
                # 不单独标单位（unit=None），目标单位记录在 contract.series_units
                # 里，按**指标名**（category）索引。不取这个单位，所有组合图的
                # 数据点都会被判「数值或单位无可验证定义」而整图剔除。
                series_units = contract.get("series_units") or {}
                unit = series_units.get(point.get("category")) or series_units.get(point.get("series"))
            expected = float(ref.value)
            if getattr(ref, "unit", None) is None:
                # B23-T12（2026-11-10 第四轮实测）：估值类记录（PS/PB/PE）上游
                # 未标注单位，图表按惯例写「倍」。这不等于数值不可验证——按数值
                # 本体比较即可；单位缺失属于数据源限制，已在数据质量附录披露。
                pass
            else:
                expected = convert_unit_value(expected, ref.unit, unit)
            value = float(point["value"])
            digits = len(str(point["value"]).split(".")[1]) if "." in str(point["value"]) else 0
            if abs(value - expected) > 0.5 * 10 ** -digits + 1e-9:
                problems.append("图中数值无法由证据按声明单位换算")
        except (TypeError, ValueError, KeyError):
            problems.append("数据点数值或单位无可验证定义")
    source_option = getattr(chart, "option", {}) or {}
    actual = []
    def numbers(value: Any) -> None:
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            actual.append(float(value))
        elif isinstance(value, (list, tuple)):
            for item in value:
                numbers(item)
        elif isinstance(value, dict):
            numbers(value.get("value"))
    for series in source_option.get("series", []):
        numbers(series.get("data", []))
    wanted = [float(p["value"]) for p in points if isinstance(p.get("value"), (float, int))]
    if len(actual) != len(wanted):
        problems.append("渲染系列与数据点契约不一致")
    categories = contract.get("categories")
    if categories:
        axes = [source_option.get("xAxis", {}), source_option.get("yAxis", {})]
        axis_categories = [axis.get("data") for axis in axes if isinstance(axis, dict) and axis.get("data")]
        if axis_categories and categories not in axis_categories:
            problems.append("坐标轴样本标签与数据契约不一致")
    return list(dict.fromkeys(problems))


def _unsupported_chain_assignment(paragraph: Any, index: dict[str, Any]) -> bool:
    text = paragraph.text
    if not re.search(r"(?:归属|属于|位于|划归|分属|属).{0,80}(?:上游|中游|下游)", text):
        return False
    refs = [index[rid] for rid in paragraph.evidence_ids if rid in index]
    return (any(ref.entity and len(ref.entity) >= 2 and ref.entity in text for ref in refs)
            and not any(ref.domain in {"industry_chain", "reports", "news"} for ref in refs))


def _check_final_view(
    chapters: list[Any], embedded: list[Any], request: "ReportFusionRequest", summary: Any = None,
    appendix_view: dict | None = None,
    annotations: dict[tuple[str, str], dict] | None = None,
) -> tuple[list[str], list[str], list[dict]]:
    """对**最终要导出的对象**做校验，而不是复用编辑前的输入诊断。

    覆盖（V8 方案 §8.3 第 3 步）：
    - 未知证据引用（按最终章节的 evidence_ids 与新证据目录比对）
    - 图表挂载位置与 ready 状态
    - 关键图的 SVG 是否真实可读

    Returns:
        (blocking, warnings, annotated)。blocking 非空即不得宣告正式完成；
        annotated 为「全库有据但绑定层未认」的数值断言（标注放行，不阻塞）。
    """
    blocking: list[str] = []
    warnings: list[str] = []
    chart_quality = getattr(request.charts, 'quality', {}) if request.charts else {}
    chain_delivery = chart_quality.get("chain_delivery", {}) if isinstance(chart_quality, dict) else {}
    scoped_chart = next((chart for chart in embedded
        if getattr(chart, "chart_id", None) == chain_delivery.get("scoped_chart_id")
        and getattr(chart, "chart_type", None) == "industry_chain"
        and (getattr(chart, "data_contract", {}) or {}).get("scoped_classification") is True
        and request.options.scoped_chart_sha256
        and _sha(str(getattr(chart, "svg", "")).encode()) == request.options.scoped_chart_sha256
        and getattr(chart, "evidence_ids", None)
        and all(str(eid).startswith("chain2:") and eid in request.report.evidence_index
                and request.report.evidence_index[eid].domain == "industry_chain"
                for eid in chart.evidence_ids)), None)
    accepted_scope = (request.options.scoped_chain_classification
                      and chain_delivery.get("scope_applied") is True
                      and chain_delivery.get("status") == "partial"
                      and type(chain_delivery.get("verified_relations")) is int
                      and chain_delivery.get("verified_relations") == 0
                      and scoped_chart is not None)
    if chain_delivery.get("requested") and (chain_delivery.get("status") != "complete"
            or not isinstance(chain_delivery.get("verified_relations"), int)
            or isinstance(chain_delivery.get("verified_relations"), bool)
            or chain_delivery["verified_relations"] < 1):
        if accepted_scope:
            warnings.append("产业链覆盖限制：仅展示有证据支持的环节分类；工序关系尚未核验。")
        elif request.options.scoped_chain_classification or chain_delivery.get("scope_applied") is True:
            blocking.append("产业链关系未完整核验：已确认的分类图缺失或未通过完整性复验")
        else:
            warnings.append("产业链覆盖限制：关系未完整核验，仅展示已核实内容；" + str(chain_delivery.get("reason") or "证据不足"))
    requested_count = chart_quality.get('requested_count') if isinstance(chart_quality, dict) else None
    if isinstance(requested_count, int) and not isinstance(requested_count, bool) and requested_count > len(embedded):
        warnings.append(f"用户要求 {requested_count} 张图表，最终报告嵌入 {len(embedded)} 张；未用不足证据凑图")
    preferred_min = chart_quality.get("preferred_min_count") if isinstance(chart_quality, dict) else None
    if isinstance(preferred_min, int) and not isinstance(preferred_min, bool) and preferred_min > len(embedded):
        warnings.append(f"所选配图档位建议至少 {preferred_min} 张，最终报告嵌入 {len(embedded)} 张")
    if chapters and not any(para.text.strip() for chapter in chapters
                            for section in chapter.sections for para in section.paragraphs):
        blocking.append("报告正文没有可交付的核验段落")
    if request.options.verified_scope_only and not any(
        para.text.strip() and any(rid in request.report.evidence_index for rid in para.evidence_ids)
        for chapter in chapters for section in chapter.sections for para in section.paragraphs
    ):
        blocking.append("有限覆盖报告缺少带有效出处的正文")
    allowed = set(request.report.evidence_index)
    appendix = request.report.data_quality_appendix or {}
    boundary_ids: set[str] = set()
    automatic_announcements = {
        str(requirement.get("requirement_id"))
        for row in appendix.get("requirement_evidence_matrix") or []
        if isinstance(row, dict)
        and isinstance((requirement := row.get("requirement")), dict)
        and requirement.get("origin") == "automatic_announcement"
        and str(requirement.get("requirement_id") or "").startswith("announcement_search_")
        and requirement.get("domain") == "news"
        and requirement.get("acceptable_skill_ids") == ["announcement-search"]
    }

    def _declare_boundary(cell: dict) -> None:
        """B45：数据源结构性不覆盖 = 边界，不是缺口；如实申报但不阻断交付。"""
        rid = str(cell.get("requirement_id", ""))
        if rid in boundary_ids:
            return
        boundary_ids.add(rid)
        warnings.append(f"数据源边界：{cell.get('label', cell.get('requirement_id'))}"
                        f"（{cell.get('scope_note') or '该主体不在数据源覆盖范围'}）")

    def _disclose_unmet(cell: dict, label: str) -> None:
        warnings.append(f"研究覆盖限制：{label}：{cell.get('label', cell.get('requirement_id'))}；未作为已核实结论。")

    for cell in appendix.get("requested_requirement_coverage") or []:
        if not (cell.get("hard") and not cell.get("passed")):
            continue
        # 边界申报先于 annual_ 跳过：年度项虽由下方财务清单负责阻塞，边界信息仍需透出。
        if cell.get("out_of_scope"):
            _declare_boundary(cell)
            continue
        if (str(cell.get("requirement_id", "")) in automatic_announcements
                and str(cell.get("requirement_id", "")) in request.options.accepted_announcement_ids):
            warnings.append(
                f"公告核验限制：{cell.get('label', cell.get('requirement_id'))}未完成；"
                "财务更正及比较口径尚未核实，不能据此认定不存在更正。"
            )
            continue
        if str(cell.get("requirement_id", "")).startswith("annual_"):
            continue
        _disclose_unmet(cell, "必需研究数据缺口")
    required_cells = appendix.get("requested_financial_coverage") or appendix.get("sample_info", {}).get("requested_financial_coverage") or []
    for cell in required_cells:
        if not cell.get("passed"):
            if cell.get("out_of_scope"):
                _declare_boundary(cell)
                continue
            _disclose_unmet(cell, "指定年度指标缺口")

    # A generated chapter may claim that *no* citable R&D records exist even
    # though required annual records resolve in the evidence index.  Do not
    # silently sign a report that contradicts its own underlying evidence.
    has_citable_rd = any(
        cell.get("hard") and cell.get("passed")
        and any(
            (record := request.report.evidence_index.get(rid)) is not None
            and record.domain == "financials" and record.metric == "rd_investment"
            for rid in cell.get("evidence_record_ids") or []
        )
        for cell in required_cells if isinstance(cell, dict)
    )
    if has_citable_rd:
        for chapter in chapters:
            for section in getattr(chapter, "sections", []):
                for para in getattr(section, "paragraphs", []):
                    content = str(getattr(para, "text", ""))
                    if ("研发" in content and "未提供可引用" in content
                            and "原始记录ID" in content
                            and not any(word in content for word in ("部分", "个别", "某些"))):
                        blocking.append(
                            f"{getattr(para, 'paragraph_id', '?')} 称研发原始记录不可引用，"
                            "但必需年度指标已有可引用证据，请核对并修订正文"
                        )

    # Sector labels and financial multiples do not establish an enterprise's
    # upstream/downstream position.  Flag explicit assignments that cite only
    # those records, so the author can attach the actual membership evidence.
    for chapter in chapters:
        for section in getattr(chapter, "sections", []):
            for para in getattr(section, "paragraphs", []):
                if _unsupported_chain_assignment(para, request.report.evidence_index):
                    blocking.append(f"{getattr(para, 'paragraph_id', '?')} 企业产业链归属缺少对应来源，"
                                    "行业分类或财务指标不能证明环节归属，请核对并补充依据")

    def check_references(value: Any, location: str) -> None:
        if hasattr(value, "model_dump"):
            value = value.model_dump(mode="json")
        if isinstance(value, dict):
            for key, child in value.items():
                if key == "content_audit":
                    continue
                if key in ("evidence_ids", "evidence_record_ids", "point_evidence_ids") and isinstance(child, list):
                    unknown = {item for item in child if isinstance(item, str) and item} - allowed
                    if unknown:
                        blocking.append(f"{location} 含未知证据引用 {sorted(unknown)}")
                else:
                    check_references(child, f"{location}.{key}")
        elif isinstance(value, (list, tuple)):
            for index, child in enumerate(value):
                check_references(child, f"{location}[{index}]")

    check_references(chapters, "chapters")
    check_references(summary, "summary")
    check_references(appendix if appendix_view is None else appendix_view, "appendix")
    # 对**最终交付版附录**再审计一次（B23-T11）：真实流程传入的是已 clean 化的
    # safe_appendix，只报 clean 后仍存在的问题；直接构造请求的测试不传该参数，
    # 此时审计原始附录——两条路径都能拦住被篡改的附录。
    appendix_source = request.report
    if appendix_view is not None and hasattr(request.report, "model_copy"):
        appendix_source = request.report.model_copy(update={"data_quality_appendix": appendix_view})
    _, appendix_issues = audit_appendix(appendix_source)
    blocking.extend(f"{issue['location']} 附录断言未通过核验：{issue['claim']}" for issue in appendix_issues)

    for chapter in chapters:
        for section in getattr(chapter, "sections", []):
            for para in getattr(section, "paragraphs", []):
                unknown = set(getattr(para, "evidence_ids", []) or []) - allowed
                if unknown:
                    pid = getattr(para, "paragraph_id", "?")
                    blocking.append(f"{pid} 含未知证据引用 {sorted(unknown)}")

    embedded_map = {
        getattr(chart, "chart_id", ""): chart for chart in embedded
    }
    contract_failures: dict[str, list[str]] = {}
    for declared in (request.charts.charts if request.charts else []):
        if getattr(declared, "status", "") == "ready":
            problems = [*_chart_contract_issues(declared, request.report.evidence_index),
                        *_chart_comparability_issues(declared, request.report.evidence_index)]
            if problems:
                contract_failures[declared.chart_id] = list(dict.fromkeys(problems))
                blocking.extend(f"{declared.chart_id} {p}" for p in contract_failures[declared.chart_id])
    # 契约拒绝不等于文件缺失。数据错误保留一个根因；缺图只披露配图缺口。
    declared_ready = {
        c.chart_id
        for c in (request.charts.charts if request.charts else [])
        if getattr(c, "status", "") == "ready"
    }
    dropped = declared_ready - set(embedded_map)
    for cid in sorted(dropped):
        if cid not in contract_failures:
            warnings.append(f"{cid} 缺少可读图形（SVG 或图片），已省略该图")
    for chapter in chapters:
        for section in getattr(chapter, "sections", []):
            for cid in getattr(section, "chart_ids", []) or []:
                if cid not in embedded_map:
                    warnings.append(f"{getattr(section, 'section_id', '?')} 引用的图表 {cid} 未就绪")

    for chart in embedded:
        cid = getattr(chart, "chart_id", "?")
        unknown = set(getattr(chart, "evidence_ids", []) or []) - allowed
        if unknown:
            blocking.append(f"{cid} 含未知证据引用 {sorted(unknown)}")
        render_mode = getattr(chart, "render_mode", "") or ""
        # EmbeddedChart 的正文字段就叫 `svg`（不是 inline_svg）；
        # 兼容 image_uri 承载位图的 generated_image 模式。
        svg_payload = getattr(chart, "svg", None)
        readable = False
        if isinstance(svg_payload, str) and svg_payload.strip():
            if 'data-placeholder="true"' in svg_payload:
                # 占位图不是真实图形，不得计入 ready
                readable = False
            elif svg_payload.lstrip().startswith("<svg"):
                readable = True
            else:
                try:
                    readable = Path(svg_payload).is_file() and Path(svg_payload).stat().st_size > 0
                except OSError:
                    readable = False
        if render_mode == "generated_image":
            image_uri = getattr(chart, "image_uri", None)
            if isinstance(image_uri, str) and image_uri:
                try:
                    readable = Path(image_uri).is_file() and Path(image_uri).stat().st_size > 0
                except OSError:
                    readable = False
        if not readable:
            # 关键图 SVG 不可读：不得计入 ready，也不生成占位图冒充成功
            blocking.append(f"{cid} 的 SVG 文件不可读")
            try:
                chart.status = "failed"
            except Exception:
                pass
    numeric_issues = _audit_numeric_components(chapters, summary, request, annotations=annotations)
    # 标注通道（2026-11-15）：全库有据但绑定层未认的断言不阻塞，作为第三返回值
    # 交给 run() 写进 verification_warnings；absent/protected/超限项照旧 blocking。
    annotated_numeric = [issue for issue in numeric_issues if issue.get("disposition") == "annotated"]
    numeric_block = [issue for issue in numeric_issues if issue.get("disposition") != "annotated"]
    blocking.extend(f"{issue['location']} 数值断言无匹配证据：{issue['claim']}" for issue in numeric_block)
    return list(dict.fromkeys(blocking)), list(dict.fromkeys(warnings)), annotated_numeric


def _chart_comparability_issues(chart: Any, index: dict[str, Any]) -> list[str]:
    """Check source contracts independently of a generated eligibility flag."""
    if getattr(chart, "chart_type", "") == "industry_chain":
        return []
    refs = [index[p["record_id"]] for p in (getattr(chart, "data_contract", {}) or {}).get("points", [])
        if p.get("record_id") in index]
    if not refs:
        return []  # Missing point contracts are handled by the factual gate.
    temporal = getattr(chart, "chart_type", "") in ("line", "multi_line", "trend_line", "area", "stacked_area")
    # 2026-11-20 商业航天 v6：CHART-03「市盈率(动态)期间对比」契约 axis_type=time_series
    # （category 是 2025-12-31 / 2026-11-20 两个观测期），但 chart_type 是 bar，旧判据按
    # 横截面校验，逐实体期间集合不一致就直接判「缺少共同观测期间」并硬阻塞整份报告。
    # 契约声明为时间序列时，应按时序语义校验（检查期间形状而不是面板平衡）。
    contract = getattr(chart, "data_contract", {}) or {}
    temporal = temporal or str(contract.get("axis_type") or "") == "time_series"
    points = contract.get("points", [])
    temporal = temporal and all(p.get("period") and str(p["period"])[:4] in str(p.get("category", "")) for p in points)
    from agents_core.financial_semantics import chart_comparability_issues
    return chart_comparability_issues(refs, temporal=temporal)


def _fit_svg_for_page(svg:str)->str:
    """把带固定像素宽高的 SVG 根标签改成自适应页宽（2026-10-17）。

    起因：产业链图的确定性 SVG 根标签是 ``width="1440" height="1020"``（前端内联要
    像素级布局），但报告页在 A4 下的内容宽只有约 6.5in —— 原样嵌入会把右侧两栏裁掉。
    ECharts 那批 SVG 只写 viewBox 不写 width，天然自适应，所以历史没暴露这个问题。

    只改**根标签**的 width/height，不动 inner 元素与 viewBox（缩放靠 viewBox 完成）。
    """
    if not svg:
        return svg
    match=_SVG_ROOT_RE.search(svg)
    if not match:
        return svg
    tag=match.group(0)
    if not _SVG_FIXED_W_RE.search(tag):
        return svg
    fixed=re.sub(r'\swidth="[^"]*"',' width="100%"',tag)
    fixed=re.sub(r'\sheight="[^"]*"','',fixed)
    if "style=" not in fixed:
        fixed=fixed[:-1]+' style="max-width:100%;height:auto;display:block;margin:0 auto;">'
    return svg[:match.start()]+fixed+svg[match.end():]

# 并集合并后可挂载的总编审校规范上限
FUSION_SKILL_LIMIT = 10
SYSTEM_PROMPT="""你是行业研究报告总编辑。只能编辑已有内容，不能补充外部事实、数字或来源。skills 只提供编辑方法，绝不是事实来源。
返回JSON：headline；conclusions[{text,evidence_ids,confidence,uncertainty}]；risks；research_boundaries；terminology_map；chapter_transitions；paragraph_edits。
【重要约束规范】：
1. terminology_map 仅用于极少数专业术语或别名的一致性归一（例如将“动力锂电池”归一为“动力电池”）。
   - 严禁将专业术语、指标代码（如 PB、PE、ROE）替换为长句解释或名词定义；
   - 严禁将研究主题（如“人形机器人”、“新能源汽车”、“航天”）作为映射 key 替换为长句定义；
   - 映射后的目标词（value）必须是极简短的专有名词（不超过 8 个字），严禁包含逗号、句号、冒号、分号或任何解释性描述语句；如果不需别名归一，保持 terminology_map 为空字典 {}。
2. chapter_transitions 是 chapter_id 到承上启下过渡句的映射；
3. paragraph_edits 是 paragraph_id 到 {text, evidence_ids} 的微调映射（正文各章节内容已完成严格证据核对，通常必须保持为空字典 {}。严禁无故大段重写！保留已有证据支撑的比较、业务解释和判断边界，避免把解释压缩成数字复述。严禁改动任何数字、严禁增加任何未在原文中出现的数字，包括股票代码如 002085、年份、列表序号等；必须 100% 原样保留所有数字与精确字面值；必须完全复用原段落的 evidence_ids，严禁伪造不存在的证据编号）；
4. 所有证据ID必须来自输入；所有数字必须已存在于输入。"""

def _sha(data:bytes)->str:return hashlib.sha256(data).hexdigest()
def _numbers(value:object)->set[str]:return set(NUMBER_RE.findall(json.dumps(value,ensure_ascii=False,default=str)))

def _referenced_record_ids(payload: dict[str, Any]) -> set[str]:
    """收集 payload 里正文/摘要/图表实际引用到的证据 id。

    `evidence` 与 `allowed_evidence_ids` 必须排除：前者正是待裁剪对象；后者是全量 id
    清单，把它算进来会让「引用集」退化成「全集」，裁剪直接失效。
    """
    scope = {k: v for k, v in payload.items() if k not in {"evidence", "allowed_evidence_ids"}}
    return set(RECORD_ID_RE.findall(json.dumps(scope, ensure_ascii=False, default=str)))


def _trim_unreferenced_evidence(payload: dict[str, Any]) -> dict[str, Any]:
    """把证据索引收窄到「正文真正引用到的记录」，并同步收窄 allowed_evidence_ids。

    为什么可以裁：编辑模型的输入是**已经写好的章节**，它的任务是写摘要/结论/术语表
    和少量段落微调，不需要那些从未进入正文的证据。实测 SEMI-Q4：1955 条证据占
    payload 的 89%，7 章正文只引用 86 条——被裁掉的是 1.29MB 与编辑任务无关的上下文。

    为什么不顺手瘦身条目字段：编辑模型要靠 entity/metric/unit/period 判口径，少一个
    字段就可能把两个口径混为一谈。保留的条目原样传递，宁可少给、不可给残。
    """
    evidence = payload.get("evidence") or {}
    if not evidence:
        return payload
    keep = _referenced_record_ids(payload) & set(evidence)
    trimmed = dict(payload)
    trimmed["evidence"] = {rid: evidence[rid] for rid in evidence if rid in keep}
    allowed = payload.get("allowed_evidence_ids")
    if isinstance(allowed, list):
        # 模型引用一条它根本看不到的记录没有意义；服务端的证据校验另有
        # request.report.evidence_index 作为权威白名单，不依赖这个字段。
        trimmed["allowed_evidence_ids"] = [rid for rid in allowed if rid in keep]
    return trimmed


def _chapter_claims_recovered(chapters: list[Any], content_audit: list[dict],
                              input_issues: list[Any], *, loss_tolerated: bool = False) -> bool:
    """章节层的质量缺口是否已被处置到「可以交付」的程度。

    两条独立通道，任一成立即可：

    1. **逐段修复**（原语义）：所有 issue 都是「段落资料缺口」，且每条 content_audit
       都是 `repaired`——缺口被修好而不是被删掉。
    2. **损失容忍**（B28）：融合层已按内容损失率判定 ≤20%（T10），说明剩下的缺口
       是正常取舍。这条必须单独传进来，因为「整段移除」的 disposition 是
       `isolated`，永远不满足通道 1——而 T10 此前只删了 issues 里的
       `_CHAPTER_QUALITY_BLOCK`，没把结论传到这里，导致 `adapters.py` 的豁免钩子
       形同虚设，报告被「章节层 passed=False」一路钉死。

    兜底稿与「无 issue」都不构成豁免：前者是模板生成的内容（另一类问题），
    后者没有可豁免的对象。
    """
    if not input_issues:
        return False
    if any(getattr(chapter, "used_fallback", False) for chapter in chapters):
        return False
    # B29 安全网：损失容忍只针对「段落被删」这一种取舍，不能覆盖
    # 「组件隔离比例过高」——某章过半指标卡/对比表因缺绑定被删除，不是
    # 正常取舍而是内容大面积缺失。实测 CH-01/03/05/07 隔离 57%–80%，
    # 若被容忍通道放行，报告会带着 27 个被删组件标记为「可正式交付」。
    if loss_tolerated and any(_HIGH_ISOLATION_MARK in str(issue) for issue in input_issues):
        loss_tolerated = False
    repaired_all = bool(
        all(str(issue).startswith("段落资料缺口：") for issue in input_issues)
        and any(entry.get("code") == "chapter_claim_repair" and entry.get("replacement_evidence_ids")
                for entry in content_audit)
        # 跨章同键矛盾（flagged）是提示性条目，不阻塞交付，也就不该要求它被「修复」。
        and all(entry.get("disposition") == "repaired" for entry in content_audit
                if entry.get("code") != "cross_chapter_claim_conflict")
    )
    return repaired_all or loss_tolerated


def prepare_fusion_context(payload: dict[str, Any], system: str) -> tuple[str, dict[str, int]]:
    """Remove transport-only evidence metadata without dropping report content or citations."""
    original = json.dumps(payload, ensure_ascii=False, default=str)
    before = len(original.encode("utf-8")) + len(system.encode("utf-8"))
    try:
        prompt, size, budget = serialize_context(payload, system=system)
    except ContextBudgetExceeded:
        import copy
        compact = copy.deepcopy(payload)
        evidence = payload.get("evidence", {})
        aliases = {}
        text_content = json.dumps(payload.get("chapters", []), ensure_ascii=False, default=str)
        for key, value in evidence.items():
            canonical = str(value.get("record_id") or key)
            if (key != canonical and canonical in evidence and evidence[canonical] == value
                    and f"[{key}]" not in text_content):
                aliases[key] = canonical
        def rewrite_refs(node: Any) -> None:
            if isinstance(node, dict):
                for key, value in node.items():
                    if key in {"evidence_ids", "evidence_record_ids", "allowed_evidence_ids"} and isinstance(value, list):
                        node[key] = list(dict.fromkeys(aliases.get(item, item) for item in value))
                    else:
                        rewrite_refs(value)
            elif isinstance(node, list):
                for item in node:
                    rewrite_refs(item)
        rewrite_refs(compact)
        compact["evidence"] = {
            key: {k: v for k, v in value.items() if k not in {"trace_id", "skill_id"}}
            for key, value in evidence.items() if key not in aliases
        }
        serialized = json.dumps(compact, ensure_ascii=False, default=str)
        after = len(serialized.encode("utf-8")) + len(system.encode("utf-8"))
        try:
            prompt, size, budget = serialize_context(compact, system=system)
        except ContextBudgetExceeded:
            # B25：一级压缩（别名去重 + 去传输元数据）压不掉证据主体。二级改为按
            # 「正文引用集」收窄证据索引——编辑任务不需要未进入正文的证据。
            trimmed = _trim_unreferenced_evidence(compact)
            after_trim = (
                len(json.dumps(trimmed, ensure_ascii=False, default=str).encode("utf-8"))
                + len(system.encode("utf-8"))
            )
            try:
                prompt, size, budget = serialize_context(trimmed, system=system)
            except ContextBudgetExceeded as exc:
                raise ContextBudgetExceeded(
                    f"压缩前 {before} 字节，别名去重后 {after} 字节，"
                    f"证据收窄后 {after_trim} 字节；{exc}；必需内容超限"
                ) from exc
    return prompt, {"before_bytes": before, "after_bytes": size, "budget_bytes": budget}

def _is_total_market_cap_context(prefix: str) -> bool:
    """Require a total label in the number's own clause, without a company owner."""
    clause = re.split(r"[，,。；;\n：:]", prefix)[-1].strip()
    return bool(re.fullmatch(
        r"(?:样本(?:证券池)?|证券池|行业|板块)的?(?:总|合计)市值(?:约为|约|为|达|达到|合计|共计)?\s*",
        clause,
    ))


def _deduplicate_warnings(warnings: list[str]) -> list[str]:
    seen: list[str] = []
    for w in warnings:
        w_str = str(w).strip()
        if not w_str:
            continue
        is_subsumed = False
        for idx, existing in enumerate(seen):
            if w_str == existing:
                is_subsumed = True
                break
            if existing.startswith(w_str) or (len(w_str) >= 15 and w_str in existing):
                is_subsumed = True
                break
            if w_str.startswith(existing) or (len(existing) >= 15 and existing in w_str):
                seen[idx] = w_str
                is_subsumed = True
                break
        if not is_subsumed:
            seen.append(w_str)
    return seen

FUSION_SKILL_PLANNING_PROMPT = """你是研报融合与总编审校模块。
你必须基于待融合研报的整体结构（主题、章节数量与大纲、图表数量、证据量、数据质量预警等），自主调用 `invoke_skill` 工具选择指导本研报审校与融合的专业技能。
可用技能包括：
- executive-summary-synthesis：执行摘要与核心结论高度提炼
- report-consistency-audit：跨章节逻辑、术语与事实一致性审计
- report-visual-quality：图表图文混排与排版可读性优化
- evidence-catalog：可穿透证据目录与索引构建
必须调用 `invoke_skill` 并给出专业、针对性的调用理由。"""


def _user_research_boundaries(chapters: list[Any]) -> list[str]:
    from agents_core.remediation_boundaries import LIMITATIONS

    return list(dict.fromkeys(entry.get("text") for chapter in chapters
        for entry in getattr(chapter, "content_audit", [])
        if entry.get("code") == "user_research_boundary" and entry.get("disposition") == "accepted"
        and entry.get("text") in LIMITATIONS.values()))


class ReportFusionAgent:
    def __init__(self,*,settings:Settings|None=None,llm:FusionLLM|None=None,pdf_renderer=None,skillhub:FusionSkillHub|None=None)->None:
        self.settings=settings or Settings.from_env();self.llm=llm or OpenAICompatibleLLM(self.settings);self.pdf_renderer=pdf_renderer or render_pdf;self.skillhub=skillhub or FusionSkillHub()

    async def _plan_editorial_skills(
        self,
        request: ReportFusionRequest,
        record: Any,
    ) -> tuple[list[FusionSkill], dict[str, str]]:
        # 确定性路由始终先算：总编审校的标准四维规范是必备下限，
        # 它与模型规划取并集，模型漏选的规范由此补上。
        # 融合层技能元数据默认为 always=True（强制规范），因此不会被意图裁剪；
        # 保留 intent_text 参数是为了四层接口一致、将来新增条件性技能时能自动生效。
        policy_skills = self.skillhub.select()
        policy_reasons = {s.name: s.adaptation or "默认审校规范" for s in policy_skills}
        intent_text = " ".join(
            part for part in (
                getattr(getattr(request, "report", None), "subject", ""),
                " ".join(str(x) for x in (getattr(request, "warnings", None) or [])),
            ) if part
        )

        if (not request.options.verified_scope_only and self.llm.is_available
                and hasattr(self.llm, "plan_skills_with_tools")):
            try:
                tools = self.skillhub.get_tool_spec()
                user_prompt = json.dumps({
                    "subject": request.report.subject,
                    "as_of": request.report.as_of.isoformat(),
                    "chapter_count": len(request.chapters.chapters),
                    "chapters": [
                        {"chapter_id": c.chapter_id, "title": c.title, "sections_count": len(c.sections)}
                        for c in request.chapters.chapters
                    ],
                    "charts_count": len(request.charts.charts) if request.charts else 0,
                    "evidence_count": len(request.report.evidence_index),
                    "warnings_count": len(request.report.warnings) + len(request.chapters.warnings),
                }, ensure_ascii=False, default=str)

                planned = await self.llm.plan_skills_with_tools(
                    FUSION_SKILL_PLANNING_PROMPT, user_prompt, tools
                )
                if planned:
                    model_skills: list[FusionSkill] = []
                    reasons: dict[str, str] = {}
                    seen = set()
                    for item in planned:
                        sname = item.get("skill_name", "")
                        reason = item.get("reason", "")
                        skill = self.skillhub.get(sname)
                        if skill and sname not in seen:
                            seen.add(sname)
                            model_skills.append(skill)
                            reasons[sname] = reason or "大模型自主调用"
                            await record("skill_invoked_by_llm", skill=sname, reason=reasons[sname])
                    for s in self.skillhub.catalog.values():
                        if s.always and s.name not in seen:
                            seen.add(s.name)
                            model_skills.append(s)
                            reasons[s.name] = "总编基础审校规范"
                    if model_skills:
                        merged = merge_selection(
                            model_skills, policy_skills,
                            limit=FUSION_SKILL_LIMIT,
                            intent_text=intent_text,
                        )
                        merged_reasons: dict[str, str] = {}
                        for skill in merged.final:
                            if skill.name in reasons:
                                merged_reasons[skill.name] = reasons[skill.name]
                            else:
                                merged_reasons[skill.name] = policy_reasons.get(
                                    skill.name, skill.adaptation or "确定性路由补充"
                                )
                                await record(
                                    "skill_routed_by_policy",
                                    skill=skill.name,
                                    route_type="fast_skill_router",
                                    reason=merged_reasons[skill.name],
                                )
                        return merged.final, merged_reasons
            except Exception:
                pass

        await record("skill_routed_by_policy", skills=[s.name for s in policy_skills], route_type="fast_skill_router", reason="总编审校标准四维规范快速路由")
        return policy_skills, policy_reasons

    async def _repair_final_paragraphs(self, chapters, request, issues, record) -> str | None:
        """One bounded call for failed paragraphs; return a visible degradation warning."""
        index = request.report.evidence_index
        by_location: dict[str, list[dict]] = {}
        for issue in issues:
            by_location.setdefault(issue["location"], []).append(issue)
        pending = {}
        for chapter in chapters:
            for section in chapter.sections:
                for paragraph in section.paragraphs:
                    errors = by_location.get(paragraph.paragraph_id)
                    refs = {rid: index[rid] for rid in paragraph.evidence_ids if rid in index}
                    if errors and refs and len(pending) < _FINAL_REPAIR_LIMIT:
                        pending[paragraph.paragraph_id] = (chapter, section, paragraph, refs, errors)
        if not pending:
            return None

        system = (
            "修复失败的研报段落。仅使用对应段落的本地证据，保留已有证据支持的句子。"
            "禁止把未经验证的预测、因果或趋势改写成事实。"
            '返回 {"paragraphs":{"原段落ID":"完整修复文本"}}。'
        )
        payload = {
            pid: {"text": paragraph.text, "issues": errors,
                  "evidence": {rid: ref.model_dump(mode="json") for rid, ref in refs.items()}}
            for pid, (_, _, paragraph, refs, errors) in pending.items()
        }
        try:
            prompt, _, _ = serialize_context(payload, system=system)
            raw = await self.llm.generate_json(system, prompt)
            proposals = raw.get("paragraphs", {})
            if not isinstance(proposals, dict):
                await record("final_claim_repair_failed", error="invalid_paragraphs_payload",
                             selected=len(pending))
                return "最终修复未完成：模型返回的段落结构无效，已保留质量审计标注"
        except Exception as exc:
            await record("final_claim_repair_failed", error=type(exc).__name__,
                         selected=len(pending))
            return f"最终修复未完成（{type(exc).__name__}），已保留质量审计标注"

        repaired = 0
        for pid, (chapter, section, paragraph, refs, errors) in pending.items():
            proposed = proposals.get(pid)
            if not isinstance(proposed, str) or not proposed.strip() or proposed.strip() == paragraph.text:
                continue
            evidence = list(refs.values())
            evidence.extend(verified_calculations(request.report.financial_ratios, index, list(refs)))

            def supported(text: str) -> bool:
                return not quantity_issues(text, evidence, universe=list(index.values()),
                    assumption_note=paragraph.assumption_note, kind=paragraph.kind,
                    # B32：子集统计按样本清单核验
                    sample_universe=request.report.financial_ratios)

            retained = retain_supported_claims(paragraph.text, supported)
            if not supported(proposed) or (retained and retained not in proposed):
                continue
            # A rewrite must still contain evidence-supported content after the repair.
            if not retained and not _MEASURED_CLAIM.search(proposed):
                continue
            chapter.content_audit.append({
                "code": "fusion_claim_repair", "location": pid, "section_id": section.section_id,
                "original": paragraph.text, "claim": "；".join(str(item["claim"]) for item in errors),
                "evidence_ids": list(refs), "disposition": "repaired",
            })
            paragraph.text = proposed.strip()
            repaired += 1
        await record("final_claim_repair_completed", selected=len(pending), repaired=repaired)
        if repaired == 0:
            return "最终修复未产生可采纳段落，已保留质量审计标注"
        return None

    async def run(self,request:ReportFusionRequest,emit:EventEmitter|None=None,save_artifacts:bool=True)->ReportFusionResult:
        run_id=f"report-{datetime.now().strftime('%Y%m%d%H%M%S')}-{secrets.token_hex(4)}";report_id=f"REPORT-{secrets.token_hex(6).upper()}";artifact_dir=self.settings.output_dir/"runs"/run_id if save_artifacts else None;events=[]
        async def record(event:str,**details):
            item={"timestamp":datetime.now().astimezone().isoformat(),"event":event,"details":details};events.append(item)
            if emit:
                try:await emit(item)
                except Exception:pass
        await record("fusion_started",source_chapters=request.chapters.run_id)
        skills, skill_reasons = await self._plan_editorial_skills(request, record)
        await record("skills_applied",skills=[skill.name for skill in skills])
        issues,warnings=self._check_inputs(request)
        # 输入层的模板、篇章数和旧质量状态仅用于审计；交付只看清理后的终检。
        warnings.extend(issues)
        issues = []
        chapters=[c.model_copy(deep=True) for c in request.chapters.chapters]
        self._reconcile_market_cap_consistency(chapters, request)
        summary=self._default_summary(request)
        accepted=rejected=0;term_map={}
        if request.options.enable_editorial_llm and not request.options.verified_scope_only and self.llm.is_available:
            try:
                payload=self._editorial_payload(request);payload["skills"]=[{"name":skill.name,"instructions":skill.instructions} for skill in skills]
                prompt, packing = prepare_fusion_context(payload, SYSTEM_PROMPT)
                await record("context_budget_checked", **packing, stage="editorial")
                raw=await self.llm.generate_json(SYSTEM_PROMPT,prompt)
                summary,chapters,term_map,accepted,rejected,edit_warnings=self._apply_editorial(raw,request,chapters)
                warnings.extend(edit_warnings)
                await record("skill_linter_checked", accepted=accepted, rejected=rejected, passed=True)
                await record("editorial_completed",accepted=accepted,rejected=rejected)
            except Exception as exc:
                failure = str(exc)[:300] if isinstance(exc, ContextBudgetExceeded) else type(exc).__name__
                warnings.append(f"模型编辑失败，已使用规则融合：{failure}");await record("editorial_failed",error=failure)
        elif request.options.enable_editorial_llm and not request.options.verified_scope_only:
            warnings.append("未配置模型，已使用规则融合与确定性摘要")
            await record("skill_linter_checked", passed=not issues, issues=issues)
        else:
            await record("skill_linter_checked", passed=not issues, issues=issues)
        summary.research_boundaries = list(dict.fromkeys([*summary.research_boundaries, *_user_research_boundaries(chapters)]))
        embedded=self._embed_charts(request,chapters,warnings)
        # S-05：输入诊断（_check_inputs）只作内部审计基线；真正的交付判定
        # 必须针对**归位后的最终章节与嵌入图**再校验一次。
        requirement_matrix = (request.report.data_quality_appendix or {}).get("requirement_evidence_matrix") or []
        before_links = {row["requirement_id"]: row for row in link_requirement_outputs(requirement_matrix, chapters, embedded)}
        if request.options.enable_editorial_llm and not request.options.verified_scope_only and self.llm.is_available:
            initial_issues = _audit_numeric_components(chapters, summary, request)
            repair_warning = await self._repair_final_paragraphs(chapters, request, initial_issues, record)
            if repair_warning:
                warnings.append(repair_warning)
        # 标注通道（2026-11-15）：先做一次不清洗的审计，把「全库有据但绑定层未认」的
        # 数值断言挑出来（容量双上限：150 条 & 60%），后续清洗与终审共用这份 allowlist——
        # 标注子句保留正文，absent/protected/超限项照旧隔离。
        annotated_preview = []
        if not request.options.verified_scope_only:
            pre_audit = _audit_numeric_components(chapters, summary, request)
            annotated_preview, _blocked_preview = _triage_numeric_annotations(pre_audit, request, chapters)
        annotation_allowlist = {
            (_norm_location(item.get("location")), str(item.get("claim"))):
                {"category": item.get("verification_category"),
                 "evidence_ids": item.get("verification_evidence_ids")}
            for item in annotated_preview
        }
        uncited_quantities: list[dict] = []
        quality_issues = _audit_numeric_components(chapters, summary, request, sanitize=True,
                                                   uncited=uncited_quantities,
                                                   annotations=annotation_allowlist)
        summary_changes = clean_audited_summary(summary, request.report.subject)
        quality_issues.extend(summary_changes)
        for chapter in chapters:
            for section in chapter.sections:
                kept = []
                for para in section.paragraphs:
                    if _unsupported_chain_assignment(para, request.report.evidence_index):
                        reason = "企业产业链归属缺少对应来源"
                        chapter.content_audit.append({"code": "fusion_claim_isolation", "location": para.paragraph_id,
                            "section_id": section.section_id, "original": para.text, "claim": reason,
                            "reason": reason, "disposition": "isolated"})
                        warnings.append(f"研究覆盖限制：已移除 {para.paragraph_id} 的未核验企业环节归属。")
                    else:
                        kept.append(para)
                section.paragraphs = kept
        summary.research_boundaries.extend(note for note in warnings if note.startswith("研究覆盖限制："))
        content_audit = [entry for chapter in chapters for entry in chapter.content_audit]
        input_chapter_issues = request.chapters.quality.get("issues") or []
        # B23-T10（2026-11-10 SEMI-Q4 新 run 实测）：章节层报「段落资料缺口」
        # 是审计留痕（哪几段因缺乏可核验证据被移除）。内容损失很小时这是正常
        # 取舍，不该把整份报告钉在「受限草稿」；但大面积删除（>20%）仍阻塞，
        # 防止「删光换通过」。兜底稿是另一类问题（内容由确定性模板生成），
        # 有兜底章时不过滤。
        chapter_gap_texts = [
            str(issue) for issue in (request.chapters.quality.get("issues") or [])
            if str(issue).startswith("段落资料缺口：")
        ]
        has_fallback = any(getattr(chapter, "used_fallback", False) for chapter in chapters)
        chapter_loss_tolerated = False
        if chapter_gap_texts and not has_fallback:
            paragraph_total = sum(
                1 for chapter in chapters for section in chapter.sections
                for para in section.paragraphs if (para.text or "").strip()
            )
            lost_ids = [
                pid for text in chapter_gap_texts for pid in substantive_removal_ids(text)
            ]
            loss_base = paragraph_total + len(lost_ids)
            loss_ratio = len(lost_ids) / loss_base if loss_base else 0.0
            if loss_ratio <= 0.2:
                chapter_loss_tolerated = True
                warnings.append(
                    f"已移除 {len(lost_ids)} 段缺乏可核验证据的内容（占正文 {loss_ratio:.1%}），"
                    f"报告仅保留通过核验的部分"
                )
        # B28：章节缺口是否「已处置到可交付」。必须在损失容忍判定之后计算——
        # 否则 recovered 永远看不到 loss_tolerated，适配层的豁免钩子形同虚设。
        # 跨章同键矛盾（disposition=flagged）是 A4 的**报告型**审计，不参与「已修复」
        # 判定，否则这一条会永久堵死通道 1。
        recovered_chapter_claims = _chapter_claims_recovered(
            chapters, content_audit, input_chapter_issues,
            loss_tolerated=chapter_loss_tolerated,
        )
        cross_chapter_conflicts = [
            entry for entry in content_audit
            if entry.get("code") == "cross_chapter_claim_conflict"
        ]
        for entry in cross_chapter_conflicts:
            warnings.append(
                f"跨章结论冲突（告警，不阻断）：{entry.get('claim')}，涉及段落 {entry.get('location')}"
            )
        if recovered_chapter_claims:
            issues = [issue for issue in issues if issue != _CHAPTER_QUALITY_BLOCK]
        safe_appendix, appendix_issues = audit_appendix(request.report)
        # 附录问题统一由 _check_final_view 对**最终交付版**（safe_appendix）判定，
        # 这里只记录不阻塞，避免同一问题在 issues 与 final_blocking 里各报一次。
        quality_issues.extend(appendix_issues)
        quality_issues.extend(dict(code="chart_comparability", severity="error", location=c.chart_id,
            claim=problem, evidence_ids=c.evidence_ids, suggestion="补齐共同期间和测量范围后再比较")
            for c in (request.charts.charts if request.charts else []) if c.status == "ready"
            for problem in _chart_comparability_issues(c, request.report.evidence_index))
        invalid_chart_ids = {c.chart_id for c in (request.charts.charts if request.charts else [])
                             if _chart_contract_issues(c, request.report.evidence_index)}
        missing_graphics = {
            chart.chart_id for chart in embedded
            if 'data-placeholder="true"' in chart.svg
        }
        omitted_chart_ids = invalid_chart_ids | missing_graphics
        if omitted_chart_ids:
            embedded = [c for c in embedded if c.chart_id not in omitted_chart_ids]
            for chapter in chapters:
                for section in chapter.sections:
                    section.chart_ids = [cid for cid in section.chart_ids if cid not in omitted_chart_ids]
            quality_issues.extend(dict(code="chart_contract", severity="error", location=cid,
                evidence_ids=[], suggestion="修正图表语义契约后重新生成") for cid in sorted(invalid_chart_ids))
        final_blocking, final_warnings, annotated_final = _check_final_view(
            chapters, embedded, request, summary, appendix_view=safe_appendix,
            annotations=annotation_allowlist
        )
        if not chapters:
            final_blocking.append("报告正文没有可交付的核验段落")
        output_links = link_requirement_outputs(requirement_matrix, chapters, embedded)
        for row in output_links:
            before = before_links.get(row["requirement_id"], {})
            if row["hard"] and before.get("status") == "cited" and row["status"] == "not_cited":
                row["status"] = "answer_withheld"
                note = f"必答内容尚未通过核验：{row['label'] or row['requirement_id']}"
                final_warnings.append(f"研究覆盖限制：{note}，相关结论未列入交付范围。")
        safe_appendix["requirement_output_links"] = output_links
        appendix = request.report.data_quality_appendix or {}
        cells = appendix.get("requested_financial_coverage") or appendix.get("sample_info", {}).get("requested_financial_coverage") or []
        quality_issues.extend(dict(code="required_financial_cell", severity="warning", location=cell.get("requirement_id"),
            claim=cell.get("label"), evidence_ids=cell.get("evidence_record_ids", []), suggestion="补齐指定年度指标")
            for cell in cells if not cell.get("passed"))
        known_claims = {str(q.get("claim", "")) for q in quality_issues}
        quality_issues.extend(dict(code="delivery_rule", severity="error", location="report", claim=problem,
            evidence_ids=[], suggestion="解决质量问题后重新融合") for problem in issues if problem not in known_claims)
        if artifact_dir and (quality_issues or content_audit or uncited_quantities):
            artifact_dir.mkdir(parents=True, exist_ok=True)
            (artifact_dir / "fact_audit.json").write_text(json.dumps({
                "quality_issues": quality_issues, "content_audit": content_audit,
                "uncited_quantities": uncited_quantities,
            }, ensure_ascii=False, indent=2), encoding="utf-8")
        for w in final_warnings:
            if w not in warnings:
                warnings.append(w)
            if w.startswith(("公告核验限制：", "产业链覆盖限制：", "研究覆盖限制：")) and w not in summary.research_boundaries:
                summary.research_boundaries.append(w)
        used_evidence = {
            evidence_id
            for chapter in chapters
            for section in chapter.sections
            for paragraph in section.paragraphs
            for evidence_id in paragraph.evidence_ids
        }
        used_evidence.update(
            evidence_id
            for conclusion in summary.conclusions
            for evidence_id in conclusion.evidence_ids
        )
        used_evidence.update(
            evidence_id for chart in embedded for evidence_id in chart.evidence_ids
        )
        def referenced_ids(value: Any) -> set[str]:
            if hasattr(value, "model_dump"):
                value = value.model_dump(mode="json")
            if isinstance(value, dict):
                found = set()
                for key, child in value.items():
                    if key in ("evidence_ids", "evidence_record_ids") and isinstance(child, list):
                        found.update(e for e in child if isinstance(e, str))
                    else:
                        found.update(referenced_ids(child))
                return found
            if isinstance(value, list):
                return set().union(*(referenced_ids(child) for child in value)) if value else set()
            return set()
        used_evidence.update(referenced_ids(chapters))
        used_evidence.update(referenced_ids(summary))
        used_evidence.update(referenced_ids(safe_appendix))
        used_evidence.update(rid for evidence_id in tuple(used_evidence)
                             if (ref := request.report.evidence_index.get(evidence_id)) is not None
                             for rid in ref.input_record_ids)
        ordered_evidence = [
            evidence
            for evidence_id, evidence in request.report.evidence_index.items()
            if evidence_id in used_evidence
        ]
        # 元数据字段（如 industry_name/site_authority）不参与默认展示，但一旦
        # 正文、图表或附录实际引用了该 ID，它就必须进入证据目录；否则交付视图
        # 会同时“引用一个 ID”又“找不到该 ID”，追溯链断裂且契约无法通过。
        source_numbers = {ref.record_id: index for index, ref in enumerate(ordered_evidence, 1)}
        catalog=[EvidenceSource(number=i,record_id=e.record_id,label=f"{e.entity or request.report.subject} / {e.metric}",domain=e.domain,metric=e.metric,entity=e.entity,value=e.value,unit=e.unit,period=e.period,source_url=e.source_url,source_locator=e.source_locator,published_at=e.published_at,document_sha256=e.document_sha256,
                                input_source_numbers=[source_numbers[rid] for rid in e.input_record_ids if rid in source_numbers]) for i,e in enumerate(ordered_evidence,1)]
        # 陈旧缺口叙述治理（2026-11-15）：只处理上游模型自由文本（report/chapters 的
        # warnings），融合层自身的确定性告警（产业链/公告核验边界）不在处理范围。
        reconciled_upstream, stale_gap_rewrites = _reconcile_gap_warnings(
            [*request.report.warnings, *request.chapters.warnings],
            requirement_matrix, request.report.evidence_index)
        all_warnings=_deduplicate_warnings([*reconciled_upstream,*(request.charts.warnings if request.charts else []),*warnings,*issues])
        if annotated_final:
            all_warnings.append(
                f"部分核验：{len(annotated_final)} 条数值断言的证据在全库可见但绑定层未认"
                f"（主体归一/章节检索预算/币种口径），已在数据质量附录标注，未阻塞交付")
        consistency=ConsistencyReport(passed=not issues,issues=issues,warnings=warnings,accepted_edits=accepted,rejected_edits=rejected,terminology_map=term_map)
        km_list = []
        for km in getattr(request.report, "key_metrics", []):
            if isinstance(km, dict):
                km_list.append(km)
            elif hasattr(km, "model_dump"):
                km_list.append(km.model_dump(mode="json"))

        cm_dict = None
        cm_obj = getattr(request.report, "comps_matrix", None)
        if isinstance(cm_obj, dict):
            cm_dict = cm_obj
        elif hasattr(cm_obj, "model_dump"):
            cm_dict = cm_obj.model_dump(mode="json")

        # S-05 + R4：delivery_status 先按**已知**事实取一个确定性初值，
        # 导出后若事实变化再统一重渲染三格式，保证 MD/HTML/PDF 来自同一最终视图。
        # 2026-11-20：A2 语义分析整体失败（模型不可达/超时）时，正文只是确定性
        # 回退结果，不能按「有限覆盖正式稿」交付。此前 run-20261120165956 在
        # 全部模型调用失败、68 次重试全灭的情况下仍标 ready_scoped，属于把
        # 模型故障伪装成正常交付；这里降为受限草稿并写明原因。
        semantic_failed = str(getattr(request.report, "semantic_status", "") or "") == "failed"
        model_limit_reasons: list[str] = []
        if semantic_failed:
            model_limit_reasons.append("语义分析未完成（模型调用失败），本报告仅为确定性回退草稿")
        provisional_limits = bool(issues or final_blocking or semantic_failed)
        scoped_limits = request.options.verified_scope_only or any(
            w.startswith(("公告核验限制：", "产业链覆盖限制：")) for w in warnings
        )
        # A3 逐题主答 → 问题索引：只引用**交付版**里真实存在的小节/段落/证据/图表。
        # removed 段落（B23 审计隔离）与失效证据不能出现在索引里，否则索引指向空话。
        question_answers: list[dict[str, Any]] = []
        for answer in request.chapters.question_answers:
            section = next((s for c in chapters for s in c.sections
                            if s.section_id == answer.get("section_id")), None)
            if not section or not answer.get("text"):
                continue
            candidates = set(answer.get("paragraph_ids") or [])
            refs = set(answer.get("evidence_record_ids") or [])
            paragraphs = [p for p in section.paragraphs
                          if p.paragraph_id in candidates and (not refs or refs.intersection(p.evidence_ids))]
            # A4 的质量过滤可能移除了原绑定段落（Q-3 的 P-02-02-01/05 被隔离，
            # 但同一小节仍有 P-02-02-02/03/04）。若继续只认旧 paragraph_ids，
            # 问题索引会指向空数组，用户看到“问题存在但没有答案”。
            if not paragraphs and not answer.get("revision_evidence_gap"):
                paragraphs = [
                    p for p in section.paragraphs
                    if p.evidence_ids and set(p.evidence_ids) & set(request.report.evidence_index)
                ]
            linked_charts = [c for c in embedded if c.chart_id in (answer.get("chart_ids") or [])
                             and 'data-placeholder="true"' not in c.svg]
            chart_records = {rid for chart in linked_charts for rid in chart.evidence_ids}
            if chart_records:
                linked = [p for p in paragraphs if chart_records.intersection(p.evidence_ids)]
                if linked:
                    paragraphs = linked
            answer_refs = (
                refs if refs and any(refs.intersection(p.evidence_ids) for p in paragraphs)
                else {rid for paragraph in paragraphs for rid in paragraph.evidence_ids}
            )
            question_answers.append({
                **answer,
                "section_title": section.title,
                "paragraph_ids": [p.paragraph_id for p in paragraphs],
                "evidence_record_ids": sorted(answer_refs.intersection(
                    rid for p in paragraphs for rid in p.evidence_ids
                ).intersection(request.report.evidence_index)),
                "chart_ids": [c.chart_id for c in linked_charts],
                "financial_tables": [],
            })

        editorial_changes = _build_editorial_changes(request.chapters.chapters, chapters)
        # Audit candidates can include transient calculation observations. The
        # report catalog links their actual source rows, while fact_audit keeps
        # the original diagnostic identifiers.
        published_issues = []
        for issue in quality_issues:
            issue = dict(issue)
            issue["active"] = issue.get("disposition") not in {"isolated", "repaired", "removed"}
            ids = issue.get("evidence_ids") or []
            sources, transient = [], []
            for rid in ids:
                if rid in request.report.evidence_index:
                    sources.append(rid)
                elif rid.startswith("derived:"):
                    transient.append(rid)
                    sources.extend(source for source in rid.removeprefix("derived:").split("/")
                                   if source in request.report.evidence_index)
                elif rid == "__comps_total_market_cap__":
                    transient.append(rid)
                else:
                    sources.append(rid)
            if transient:
                issue = {**issue, "evidence_ids": list(dict.fromkeys(sources)), "calculation_candidate_ids": transient}
            published_issues.append(issue)
        view=ReportViewModel(
            report_id=report_id,
            title=f"{request.report.subject}行业研究报告",
            subject=request.report.subject,
            as_of=request.report.as_of,
            tone=request.options.tone,
            report_depth=request.options.report_depth,
            visual_style=request.options.visual_style,
            chart_mode=getattr(request.options, "chart_mode", "auto") or "auto",
            delivery_status="ready_with_limits" if provisional_limits else ("ready_scoped" if scoped_limits else "ready"),
            delivery_blocked=bool(final_blocking or issues),
            delivery_block_reason="；".join([*(str(item) for item in (final_blocking or issues)), *model_limit_reasons]),
            executive_summary=summary,
            chapters=chapters,
            charts=embedded,
            evidence_catalog=catalog,
            data_quality_appendix=safe_appendix,
            warnings=all_warnings,
            quality_issues=published_issues,
            fact_audit={"schema_version": "1", "delivery_policy": "substantive_errors_only_v1", "unsupported_quantities": sum(q.get("code") == "unsupported_quantity" for q in quality_issues), "localization_claims_isolated": sum(1 for q in quality_issues if localization_rate_claim(str(q.get("claim") or ""))), "uncited_quantities": len(uncited_quantities), "formal_verified": not (issues or final_blocking) and not annotated_final, "chapter_claims_recovered": recovered_chapter_claims, "stale_gap_rewrites": stale_gap_rewrites, "summary_changes": summary_changes},
            verification_status="partial" if annotated_final else "verified",
            verification_warnings=annotated_final,
            verification_summary={
                "annotated": len(annotated_final),
                "remaining_blocking": len(final_blocking),
                "by_reason": dict(sorted(collections.Counter(
                    str(item.get("verification_category")) for item in annotated_final).items())),
            },
            key_metrics=km_list,
            comps_matrix=cm_dict,
            question_answers=question_answers,
            editorial_changes=editorial_changes,
        )
        artifacts=[];successful=[]
        # 最终交付视图是引用完整性的事实来源：无论某个 ID 出现在章节、
        # 图表点、摘要、质量记录还是附录，只要实际引用且证据索引中存在，
        # 就必须登记进目录。这样新增字段不会再次造成“正文有引用、目录没记录”。
        view_data = view.model_dump(mode="json")
        referenced = referenced_ids(view_data)
        catalog_ids = {item.record_id for item in view.evidence_catalog}
        source_numbers.update({item.record_id: item.number for item in view.evidence_catalog})
        next_number = len(view.evidence_catalog) + 1
        for evidence_id in sorted(referenced - catalog_ids):
            evidence = request.report.evidence_index.get(evidence_id)
            if evidence is None:
                continue
            view.evidence_catalog.append(EvidenceSource(
                number=next_number,
                record_id=evidence.record_id,
                label=f"{evidence.entity or request.report.subject} / {evidence.metric}",
                domain=evidence.domain,
                metric=evidence.metric,
                entity=evidence.entity,
                value=evidence.value,
                unit=evidence.unit,
                period=evidence.period,
                source_url=evidence.source_url,
                source_locator=evidence.source_locator,
                published_at=evidence.published_at,
                document_sha256=evidence.document_sha256,
                input_source_numbers=[
                    source_numbers[rid] for rid in evidence.input_record_ids
                    if rid in source_numbers
                ],
                period_type=evidence.period_type,
            ))
            source_numbers[evidence.record_id] = next_number
            next_number += 1
        if artifact_dir:artifact_dir.mkdir(parents=True,exist_ok=True)
        if artifact_dir:
            final_charts_dir = artifact_dir / "charts"
            final_charts_dir.mkdir(parents=True, exist_ok=True)
            for chart in view.charts:
                (final_charts_dir / f"{chart.chart_id}.svg").write_text(chart.svg, encoding="utf-8")
        md=render_markdown(view);html=render_html(view)
        async def save(kind:str,name:str,data:bytes):
            if not data.strip():
                raise ValueError("empty export")
            if artifact_dir:
                path=artifact_dir/name;path.write_bytes(data);artifacts.append(ArtifactEntry(kind=kind,uri=str(path.resolve()),sha256=_sha(data),size_bytes=len(data)))
            successful.append(kind);await record("format_exported",format=kind,size=len(data))
        for fmt in request.options.formats:
            try:
                if fmt=="markdown":await save("markdown","report.md",md.encode())
                elif fmt=="html":await save("html","report.html",html.encode())
                else:
                    pdf_bytes=await self.pdf_renderer(html,self.settings.pdf_timeout_seconds)
                    await save("pdf","report.pdf",pdf_bytes)
                    # 目录页码只有排完版才知道：以刚生成的 PDF 为准回填 HTML，
                    # 让单看 HTML 的读者也能看到与 PDF 一致的页码。
                    if artifact_dir and "html" in successful:
                        filled=backfill_toc_pages(html,pdf_bytes)
                        if filled!=html:
                            _rewrite(artifact_dir,"report.html",filled.encode())
                            html=filled
            except Exception as exc:
                warnings.append(f"{fmt} 导出失败：{type(exc).__name__}");await record("format_failed",format=fmt,error=type(exc).__name__)

        # S-05：状态与交付资格由**最终事实**决定——实际成功格式数、最终校验结论、
        # 以及真实产出文件，不再依赖“失败字符串里有没有 failed”这类推断。
        missing_formats = [f for f in request.options.formats if f not in successful]
        empty_outputs = []
        for entry in artifacts:
            try:
                if Path(entry.uri).stat().st_size <= 0:
                    empty_outputs.append(entry.kind)
            except OSError:
                empty_outputs.append(entry.kind)
        final_blocking = list(dict.fromkeys([*issues, *final_blocking]))
        if missing_formats:
            warnings.append(f"缺失交付格式：{'、'.join(missing_formats)}（非完整交付）")
        if empty_outputs:
            warnings.append(f"导出文件为空：{'、'.join(empty_outputs)}")
            successful = [fmt for fmt in successful if fmt not in empty_outputs]
            artifacts = [a for a in artifacts if a.kind not in empty_outputs]

        if not successful:
            status = "failed"
            final_blocking.append("所有交付格式均未成功导出，暂无可读成稿")
        elif final_blocking:
            status = "partial"
        else:
            status = "completed"

        # delivery_status 反映最终的正式交付能力：
        # - failed / partial / 缺格式 / 仍有阻塞项  → ready_with_limits
        # - 仅剩非阻断的技术性提示                  → ready
        consistency.quality_issues = quality_issues
        consistency.passed = not final_blocking
        consistency.issues = list(final_blocking)
        has_substantive_limit = bool(final_blocking)
        final_delivery = "ready_with_limits" if has_substantive_limit else ("ready_scoped" if scoped_limits else "ready")
        previous_delivery = view.delivery_status

        # R4（V8 最终方案 §7.3 步骤 6）：三种格式必须来自**同一最终视图**。
        # 只要交付状态相对初值发生变化，MD/HTML/PDF 全部按新视图重出；
        # 任一格式重出失败就撤销该格式的发布资格（不能留旧文件冒充满分交付）。
        view.delivery_blocked = bool(final_blocking or issues)
        view.delivery_block_reason = "；".join(
            str(item) for item in (final_blocking or issues)
        )
        view.verification_summary["remaining_blocking"] = len(final_blocking)
        view.fact_audit["formal_verified"] = not final_blocking and not annotated_final
        if final_delivery != previous_delivery:
            view.delivery_status = final_delivery
            revoked: list[str] = []
            if "markdown" in successful:
                try:
                    md = render_markdown(view)
                    _rewrite(artifact_dir, "report.md", md.encode())
                except Exception as exc:
                    revoked.append("markdown")
                    warnings.append(f"markdown 重渲染失败：{type(exc).__name__}")
                    await record("format_failed", format="markdown", error=type(exc).__name__)
            if "html" in successful:
                try:
                    html = render_html(view)
                    _rewrite(artifact_dir, "report.html", html.encode())
                except Exception as exc:
                    revoked.append("html")
                    warnings.append(f"html 重渲染失败：{type(exc).__name__}")
                    await record("format_failed", format="html", error=type(exc).__name__)
            if "pdf" in successful:
                # PDF 由 HTML 渲染而来：PDF 必须基于重渲染后的最终 HTML
                try:
                    pdf_bytes = await self.pdf_renderer(html, self.settings.pdf_timeout_seconds)
                    _rewrite(artifact_dir, "report.pdf", pdf_bytes)
                    if "html" in successful:
                        filled = backfill_toc_pages(html, pdf_bytes)
                        if filled != html:
                            _rewrite(artifact_dir, "report.html", filled.encode())
                            html = filled
                except Exception as exc:
                    revoked.append("pdf")
                    warnings.append(f"pdf 重渲染失败：{type(exc).__name__}")
                    await record("format_failed", format="pdf", error=type(exc).__name__)

            if revoked:
                # 撤销发布资格：从可交付格式中移除，并把状态降为部分交付
                successful = [f for f in successful if f not in revoked]
                artifacts = [a for a in artifacts if a.kind not in revoked]
                for fmt in revoked:
                    try:
                        (artifact_dir / {"markdown": "report.md", "html": "report.html", "pdf": "report.pdf"}[fmt]).unlink(missing_ok=True)
                    except OSError:
                        pass
                status = "partial" if successful else "failed"
        else:
            view.delivery_status = final_delivery

        # 重渲染/撤销阶段的警告也必须进入最终清单（此前在重渲染前就定稿会漏掉）
        pending_warnings = list(dict.fromkeys([*all_warnings, *warnings]))

        if artifact_dir:
            extra_paths = list((artifact_dir / "charts").glob("*.svg")) if (artifact_dir / "charts").exists() else []
            if (artifact_dir / "fact_audit.json").exists():
                extra_paths.append(artifact_dir / "fact_audit.json")
            for extra in extra_paths:
                content = extra.read_bytes()
                artifacts.append(ArtifactEntry(kind="svg" if extra.suffix == ".svg" else "json", uri=str(extra.resolve()), sha256=_sha(content), size_bytes=len(content)))
            view_path=artifact_dir/"report_view.json";view_data=(view.model_dump_json(indent=2)+"\n").encode();view_path.write_bytes(view_data);artifacts.append(ArtifactEntry(kind="json",uri=str(view_path.resolve()),sha256=_sha(view_data),size_bytes=len(view_data)))
            consistency_path=artifact_dir/"consistency_report.json";consistency_data=(consistency.model_dump_json(indent=2)+"\n").encode();consistency_path.write_bytes(consistency_data);artifacts.append(ArtifactEntry(kind="json",uri=str(consistency_path.resolve()),sha256=_sha(consistency_data),size_bytes=len(consistency_data)))
            # manifest 最后生成，保证 sha256/size 对应真实落盘内容（重渲染后已变化）
            refreshed = []
            for entry in artifacts:
                try:
                    data = Path(entry.uri).read_bytes()
                except OSError:
                    continue
                refreshed.append(ArtifactEntry(kind=entry.kind, uri=entry.uri, sha256=_sha(data), size_bytes=len(data)))
            manifest={"report_id":report_id,"generated_at":datetime.now().astimezone().isoformat(),"artifacts":[x.model_dump(mode="json") for x in refreshed]}
            manifest_data=(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n").encode();manifest_path=artifact_dir/"manifest.json";manifest_path.write_bytes(manifest_data);refreshed.append(ArtifactEntry(kind="json",uri=str(manifest_path.resolve()),sha256=_sha(manifest_data),size_bytes=len(manifest_data)))
            artifacts = refreshed
        result=ReportFusionResult(run_id=run_id,report_id=report_id,subject=request.report.subject,status=status,formats=successful,applied_skills=[AppliedSkill(name=s.name,description=s.description,source=s.source,adaptation=skill_reasons.get(s.name, s.adaptation)) for s in skills],artifacts=artifacts,consistency=consistency,warnings=pending_warnings,artifact_dir=str(artifact_dir.resolve()) if artifact_dir else None, editorial_changes=editorial_changes)
        await record("fusion_completed",status=status,formats=successful,missing_formats=missing_formats)
        if artifact_dir:(artifact_dir/"events.jsonl").write_text("".join(json.dumps(x,ensure_ascii=False)+"\n" for x in events),encoding="utf-8")
        return result

    def _check_inputs(self,request:ReportFusionRequest)->tuple[list[str],list[str]]:
        issues=[];warnings=[];allowed=set(request.report.evidence_index);charts={c.chart_id for c in (request.charts.charts if request.charts else []) if c.status=="ready"}
        if request.chapters.quality.get("passed") is False or any(c.used_fallback for c in request.chapters.chapters):
            issues.append(_CHAPTER_QUALITY_BLOCK)
        if len(request.chapters.chapters)!=7:issues.append("章节结果不是7章")
        if sum(len(c.sections) for c in request.chapters.chapters)!=21:issues.append("章节结果不是21节")
        seen=set()
        for chapter in request.chapters.chapters:
            for section in chapter.sections:
                for para in section.paragraphs:
                    unknown=set(para.evidence_ids)-allowed
                    if unknown:issues.append(f"{para.paragraph_id} 含未知证据引用")
                    compact="".join(para.text.split())
                    if compact in seen:warnings.append(f"{para.paragraph_id} 与其他段落内容重复")
                    seen.add(compact)
                if set(section.chart_ids)-charts:warnings.append(f"{section.section_id} 含未就绪图表引用")
        self._audit_cross_chapter_consistency(request, issues, warnings)
        return list(dict.fromkeys(issues)),list(dict.fromkeys(warnings))

    def _audit_cross_chapter_consistency(self, request: ReportFusionRequest, issues: list[str], warnings: list[str]) -> None:
        comps = getattr(request.report, "comps_matrix", {}) or {}
        tot = comps.get("total_market_cap")
        canonical_wan_yi = None
        if tot is not None:
            try:
                tot_f = float(tot)
                canonical_wan_yi = round(tot_f / 10000.0, 2)
            except (ValueError, TypeError):
                pass

        mcap_scales: dict[str, list[str]] = {}
        for ch in request.chapters.chapters:
            for s in ch.sections:
                for p in s.paragraphs:
                    for match in re.finditer(r"([0-9]+(?:\.[0-9]+)?)\s*(万亿|亿)(?:元)?", p.text):
                        if not _is_total_market_cap_context(p.text[:match.start()]):
                            clause = re.split(r"[，,。；;\n：:]", p.text[:match.start()])[-1].strip()
                            if re.fullmatch(r"(?:总|合计)市值(?:约为|约|为|达|达到|合计|共计)?\s*", clause):
                                warnings.append(f"{ch.chapter_id}/{p.paragraph_id} 总市值归属不明确，保留原文，请人工核验是否属于样本总额")
                            continue
                        val = float(match.group(1))
                        if match.group(2) == "亿":
                            val /= 10000.0
                        mcap_scales.setdefault(str(val), []).append(f"{ch.chapter_id}/{p.paragraph_id}")

        if canonical_wan_yi:
            drift_detected = False
            for val_str in mcap_scales:
                try:
                    val_f = float(val_str)
                    if (abs(val_f - canonical_wan_yi * 10) / (canonical_wan_yi * 10) < 0.2) or \
                       (abs(val_f - canonical_wan_yi / 10) / (canonical_wan_yi / 10) < 0.2):
                        drift_detected = True
                        break
                except (ValueError, ZeroDivisionError):
                    pass
            if drift_detected or len(mcap_scales) > 1:
                warnings.append(f"检测到跨章节总市值数量级冲突，总编辑已启用事实基准自动对齐（标准基准: {canonical_wan_yi}万亿元）")

        if request.charts:
            chart_map = {c.chart_id: c for c in request.charts.charts}
            for ch in request.chapters.chapters:
                for s in ch.sections:
                    for cid in s.chart_ids:
                        c = chart_map.get(cid)
                        if c and c.recommended_chapter_id and c.recommended_chapter_id != ch.chapter_id:
                            warnings.append(f"{s.section_id} 挂载了非推荐章节图表 {cid} (推荐: {c.recommended_chapter_id})，总编辑将执行定向归位")

    def _reconcile_market_cap_consistency(self, chapters: list[ChapterDraft], request: ReportFusionRequest) -> None:
        comps = getattr(request.report, "comps_matrix", {}) or {}
        tot = comps.get("total_market_cap")
        if tot is None:
            return
        try:
            tot_f = float(tot)
            canonical_val = round(tot_f / 10000.0, 2)
        except (ValueError, TypeError):
            return

        def _reconcile_text(text: str, is_metric_card: bool = False) -> str:
            if not text:
                return text
            def _repl_wan_yi(m: re.Match) -> str:
                val_str = m.group(1)
                try:
                    val = float(val_str)
                    if not ((abs(val - canonical_val * 10) / (canonical_val * 10) < 0.2) or \
                            (abs(val - canonical_val / 10) / (canonical_val / 10) < 0.2)):
                        return m.group(0)
                except (ValueError, ZeroDivisionError):
                    return m.group(0)

                if not is_metric_card:
                    # Bind the number to the total in its own clause. A nearby
                    # sample total cannot establish ownership of a company fact.
                    if not _is_total_market_cap_context(text[:m.start()]):
                        return m.group(0)

                return m.group(0).replace(val_str, str(canonical_val))

            return re.sub(r"([0-9]+(?:\.[0-9]+)?)\s*万亿(?:元)?", _repl_wan_yi, text)

        for ch in chapters:
            ch.summary = _reconcile_text(ch.summary)
            for s in ch.sections:
                for p in s.paragraphs:
                    p.text = _reconcile_text(p.text)
                for mc in s.metric_cards:
                    is_mc_target = _is_total_market_cap_context(str(getattr(mc, "label", "")))
                    mc.value = _reconcile_text(mc.value, is_metric_card=is_mc_target)

    def _default_summary(self,request:ReportFusionRequest)->ExecutiveSummary:
        conclusions=[]
        for item in request.report.insights[:10]:
            ids=[x for x in item.get("evidence_record_ids",[]) if x in request.report.evidence_index]
            conclusions.append(ReportConclusion(text=clamp_sentence(str(item.get("conclusion") or item.get("title") or ""), CONCLUSION_LIMIT),evidence_ids=ids,confidence=item.get("confidence","medium") if item.get("confidence") in {"high","medium","low"} else "medium",uncertainty="结论受当前样本、口径与研究时点限制"))
        if not conclusions:
            for chapter in request.chapters.chapters:
                if chapter.summary:
                    conclusions.append(ReportConclusion(text=clamp_sentence(chapter.summary, CONCLUSION_LIMIT),evidence_ids=chapter.evidence_ids[:8],uncertainty="需结合章节中的资料边界理解"))
        else:
            # 补充后三章（竞争格局、标的对标、投资建议）关键论点，确保全量7章完整覆盖
            existing_texts = " ".join(c.text for c in conclusions)
            for chapter in request.chapters.chapters:
                if chapter.chapter_id in {"CH-05", "CH-06", "CH-07"} and chapter.summary:
                    if len(conclusions) < 12 and chapter.summary[:30] not in existing_texts:
                        conclusions.append(ReportConclusion(text=f"【{chapter.title}】{clamp_sentence(chapter.summary, CONCLUSION_LIMIT)}",evidence_ids=chapter.evidence_ids[:8],confidence="high",uncertainty="结合公司披露与行业对标口径"))

        metric_cards: list[MetricCardDraft] = []
        seen_card_labels: set[str] = set()
        for sec in [s for ch in request.chapters.chapters for s in ch.sections]:
            for mc in sec.metric_cards:
                lbl = mc.label.strip()
                if lbl and lbl not in seen_card_labels:
                    seen_card_labels.add(lbl)
                    metric_cards.append(mc)
                    if len(metric_cards) >= 8:
                        break
            if len(metric_cards) >= 8:
                break

        if len(metric_cards) < 8:
            for km in getattr(request.report, "key_metrics", []):
                name = str(getattr(km, "name", "") or (km.get("name") if isinstance(km, dict) else "") or getattr(km, "metric", "") or (km.get("metric") if isinstance(km, dict) else "") or "核心指标").strip()
                if name and name not in seen_card_labels:
                    seen_card_labels.add(name)
                    val = getattr(km, "value", None) if not isinstance(km, dict) else km.get("value")
                    unit = getattr(km, "unit", None) if not isinstance(km, dict) else km.get("unit")
                    if isinstance(val, (int, float)) and unit not in ("%", "％", "百分点", "个百分点"):
                        val_str = f"{val:,.2f}"
                    else:
                        val_str = str(val) if val is not None else "-"
                    period = getattr(km, "period", None) if not isinstance(km, dict) else km.get("period")
                    eids = getattr(km, "evidence_record_ids", []) if not isinstance(km, dict) else km.get("evidence_record_ids", [])
                    metric_cards.append(MetricCardDraft(
                        label=name,
                        value=val_str,
                        unit=unit,
                        period=str(period or ""),
                        evidence_ids=eids,
                    ))
                    if len(metric_cards) >= 8:
                        break

        return ExecutiveSummary(
            headline=(str(request.report.executive_summary or "").strip()
                      or f"本报告围绕{request.report.subject}的行业基础、成长性、产业链、竞争、财务与风险进行系统梳理。"),
            conclusions=conclusions,
            risks=list(request.report.warnings)[:8],
            research_boundaries=list(dict.fromkeys([*request.report.warnings,*request.report.data_quality.get("limitations",[])])) or ["结论仅适用于报告列示的资料范围和研究时点"],
            metric_cards=metric_cards[:8],
        )

    def _editorial_payload(self,request:ReportFusionRequest)->dict[str,Any]:
        return {"subject":request.report.subject,"as_of":request.report.as_of,"existing_summary":self._default_summary(request).model_dump(mode="json"),"chapters":[c.model_dump(mode="json") for c in request.chapters.chapters],"allowed_evidence_ids":list(request.report.evidence_index),"evidence":{k:v.model_dump(mode="json") for k,v in request.report.evidence_index.items()},"final_instruction":request.options.final_instruction}

    def _apply_editorial(self,raw:dict[str,Any],request:ReportFusionRequest,chapters:list[ChapterDraft])->tuple[ExecutiveSummary,list[ChapterDraft],dict[str,str],int,int,list[str]]:
        allowed_ids=set(request.report.evidence_index)
        allowed_numbers=_numbers(self._editorial_payload(request))
        # Structural integers 1..30 (chapter/section/figure indices) are structural metadata, not ungrounded external numbers
        allowed_numbers.update(str(i) for i in range(1, 31))
        accepted=rejected=0;warnings=[]
        allowed_magnitudes = {number.removesuffix("%") for number in allowed_numbers}
        def valid_text(text: str) -> bool:
            return {number.removesuffix("%") for number in _numbers(text)} <= allowed_magnitudes
        default=self._default_summary(request)
        conclusions=[]
        for item in raw.get("conclusions",[]):
            ids=item.get("evidence_ids",[]);text=clamp_sentence(str(item.get("text","")), CONCLUSION_LIMIT)
            if text and set(ids)<=allowed_ids and valid_text(text):
                try:conclusions.append(ReportConclusion(text=text,evidence_ids=ids,confidence=item.get("confidence","medium"),uncertainty=str(item.get("uncertainty",""))));accepted+=1
                except Exception:rejected+=1
            else:rejected+=1
        headline=clamp_sentence(str(raw.get("headline","")).strip(), HEADLINE_LIMIT)
        if not headline or not valid_text(headline):headline=default.headline;rejected+=1
        def _extract_str(v: Any) -> str:
            if isinstance(v, dict):
                return str(v.get("text") or v.get("title") or v.get("risk") or v.get("description") or "").strip()
            return str(v or "").strip()
        raw_risks = raw.get("risks", [])
        if isinstance(raw_risks, str):
            raw_risks = [raw_risks]
        elif isinstance(raw_risks, (list, tuple)) and len(raw_risks) > 5 and all(isinstance(x, str) and len(x) == 1 for x in raw_risks):
            raw_risks = ["".join(raw_risks)]
        risks = [_extract_str(x) for x in raw_risks if _extract_str(x) and valid_text(_extract_str(x))] or default.risks

        raw_boundaries = raw.get("research_boundaries", [])
        if isinstance(raw_boundaries, str):
            raw_boundaries = [raw_boundaries]
        elif isinstance(raw_boundaries, (list, tuple)) and len(raw_boundaries) > 5 and all(isinstance(x, str) and len(x) == 1 for x in raw_boundaries):
            raw_boundaries = ["".join(raw_boundaries)]
        boundaries = [_extract_str(x) for x in raw_boundaries if _extract_str(x) and valid_text(_extract_str(x))] or default.research_boundaries
        summary=ExecutiveSummary(headline=headline,conclusions=conclusions or default.conclusions,risks=risks,research_boundaries=boundaries,metric_cards=default.metric_cards)
        raw_term_map = raw.get("terminology_map", {})
        term_map: dict[str, str] = {}
        subject = str(request.report.subject or "").strip()
        invalid_puncts = ("，", "。", "、", "；", "：", ",", ";", ":", "\n")
        standard_financial_acronyms = {"PE", "PB", "PS", "ROE", "ROA", "ROIC", "CAGR", "EBITDA", "EPS", "TTM"}
        if isinstance(raw_term_map, dict):
            for k, v in raw_term_map.items():
                old = str(k).strip()
                new = str(v).strip()
                if not old or not new or _numbers(new):
                    continue
                if old == subject or (subject and subject in old):
                    continue
                if old.upper() in standard_financial_acronyms:
                    continue
                if len(new) > 8 or any(p in new for p in invalid_puncts):
                    continue
                if len(new) > len(old) * 2 + 2:
                    continue
                term_map[old] = new
        paragraph_map = {p.paragraph_id: p for c in chapters for s in c.sections for p in s.paragraphs}
        withheld = {}
        for chapter in chapters:
            sections = {section.section_id: section for section in chapter.sections}
            for item in chapter.content_audit:
                if (item.get("code") == "chapter_claim_repair" and item.get("disposition") == "isolated"
                        and item.get("revision_status") != "removed"):
                    if section := sections.get(item.get("section_id")):
                        withheld[item["location"]] = (section, item)
        rejected_pids: list[str] = []
        for pid, edit in raw.get("paragraph_edits", {}).items():
            para = paragraph_map.get(pid)
            restoration = withheld.get(pid) if para is None else None
            text = str(edit.get("text", "")).strip() if isinstance(edit, dict) else ""
            ids = edit.get("evidence_ids", []) if isinstance(edit, dict) else []
            known_ids = isinstance(ids, list) and all(isinstance(rid, str) and rid in allowed_ids for rid in ids)
            legacy_gap = para is not None and para.text.startswith(_LEGACY_GAP_PREFIXES)
            if not (para or restoration) or not text or not known_ids or not valid_text(text):
                rejected_pids.append(pid)
                continue
            refs = [request.report.evidence_index[rid] for rid in ids]
            refs.extend(verified_calculations(request.report.financial_ratios, request.report.evidence_index, ids))
            if (legacy_gap or restoration) and (not refs or not _MEASURED_CLAIM.search(text)):
                rejected_pids.append(pid)
                continue
            if quantity_issues(text, refs, universe=list(request.report.evidence_index.values()),
                               assumption_note=para.assumption_note if para else None,
                               kind=para.kind if para else "analysis"):
                rejected_pids.append(pid)
                continue
            if restoration:
                section, entry = restoration
                section.paragraphs.append(ParagraphDraft(paragraph_id=pid, text=text, evidence_ids=ids))
                entry["disposition"] = "repaired"
                entry["replacement_evidence_ids"] = ids
            elif para is not None:
                para.text = text
                para.evidence_ids = ids
            accepted += 1
        rejected += len(rejected_pids)
        if rejected_pids:
            warnings.append(
                f"审校防幻觉拦截：已拦截 {len(rejected_pids)} 处未获数据证据授权的段落微调（涉及 {', '.join(rejected_pids[:3])}{' 等' if len(rejected_pids) > 3 else ''}），全量保留各章节原始事实数据"
            )
        transitions=raw.get("chapter_transitions",{})
        for chapter in chapters:
            transition=str(transitions.get(chapter.chapter_id,"")).strip()
            if transition and valid_text(transition):
                first=chapter.sections[0];first.paragraphs.insert(0,ParagraphDraft(paragraph_id=f"TRANS-{chapter.chapter_id}",kind="transition",text=transition,evidence_ids=[]));accepted+=1
            elif transition:rejected+=1
        for old,new in term_map.items():
            for chapter in chapters:
                chapter.summary=chapter.summary.replace(old,new)
                for section in chapter.sections:
                    for para in section.paragraphs:para.text=para.text.replace(old,new)
        return summary,chapters,term_map,accepted,rejected,warnings

    def _embed_charts(self,request:ReportFusionRequest,chapters:list[ChapterDraft],warnings:list[str])->list[EmbeddedChart]:
        chart_map={c.chart_id:c for c in (request.charts.charts if request.charts else []) if c.status=="ready"}
        
        # 1. Map candidate sections where chapters referenced cid
        chart_sec_candidates: dict[str, list[tuple[ChapterDraft, SectionDraft]]] = {}
        for ch in chapters:
            for s in ch.sections:
                for cid in s.chart_ids:
                    chart_sec_candidates.setdefault(cid, []).append((ch, s))

        assigned_placements: dict[str, str] = {}
        assigned_sections: set[str] = set()

        for cid, chart in chart_map.items():
            candidates = chart_sec_candidates.get(cid, [])
            rec_ch_id = getattr(chart, "recommended_chapter_id", None)

            target_sec_id = None
            # Priority 1: Candidate section matching recommended_chapter_id
            if rec_ch_id and candidates:
                for ch, s in candidates:
                    if ch.chapter_id == rec_ch_id:
                        target_sec_id = s.section_id
                        break

            # Priority 2: Recommended chapter exists, place into best section within that chapter
            if not target_sec_id and rec_ch_id:
                for ch in chapters:
                    if ch.chapter_id == rec_ch_id and ch.sections:
                        # Find semantic section match first
                        matched_sec = None
                        t_lower = chart.title.lower()
                        for s in ch.sections:
                            s_title = s.title.lower()
                            if ("利润" in t_lower or "收入" in t_lower or "盈利" in t_lower) and ("收入" in s_title or "利润" in s_title or "盈利" in s_title):
                                matched_sec = s
                                break
                            if ("负债" in t_lower or "现金" in t_lower or "资产" in t_lower) and ("负债" in s_title or "现金" in s_title or "质量" in s_title):
                                matched_sec = s
                                break
                            if ("估值" in t_lower or "pe" in t_lower or "pb" in t_lower or "市值" in t_lower) and ("估值" in s_title or "参照" in s_title or "水平" in s_title):
                                matched_sec = s
                                break
                            if ("份额" in t_lower or "集中度" in t_lower or "排名" in t_lower) and ("结构" in s_title or "集中度" in s_title or "参与者" in s_title):
                                matched_sec = s
                                break

                        # Count current assignments per section in this chapter
                        sec_counts = {s.section_id: sum(1 for p in assigned_placements.values() if p == s.section_id) for s in ch.sections}

                        # If matched section is not overloaded (<= 2 charts), use it
                        if matched_sec and sec_counts.get(matched_sec.section_id, 0) < 3:
                            target_sec_id = matched_sec.section_id
                        else:
                            # Otherwise choose least-loaded section in this chapter
                            best_sec = min(ch.sections, key=lambda s: sec_counts.get(s.section_id, 0))
                            target_sec_id = best_sec.section_id
                        break

            # Priority 3: First candidate section where cid appeared (DO NOT use dict overwrite which picks last!)
            if not target_sec_id and candidates:
                target_sec_id = candidates[0][1].section_id

            # Priority 4: Title / topic heuristic
            if not target_sec_id:
                for ch in chapters:
                    if "现金" in chart.title and "05" in ch.chapter_id:
                        for s in ch.sections:
                            if "现金" in s.title:
                                target_sec_id = s.section_id
                                break
                    elif ("态势" in chart.title or "增长" in chart.title or "营收" in chart.title) and ("05" in ch.chapter_id or "02" in ch.chapter_id):
                        for s in ch.sections:
                            if "收入" in s.title or "规模" in s.title or "盈利" in s.title:
                                target_sec_id = s.section_id
                                break
                    if target_sec_id:
                        break

            # Priority 5: Fallback to first available section in chapters
            if not target_sec_id and chapters and chapters[0].sections:
                target_sec_id = chapters[0].sections[0].section_id

            assigned_placements[cid] = target_sec_id
            assigned_sections.add(target_sec_id)

        # Synchronize section.chart_ids across all chapters to enforce Single-Placement Lock
        for ch in chapters:
            for s in ch.sections:
                s.chart_ids = [cid for cid in chart_map if assigned_placements.get(cid) == s.section_id]

        # Determine physical reading order across chapters and sections (DEF-03)
        ordered_chart_ids: list[str] = []
        for ch in chapters:
            for s in ch.sections:
                for cid in s.chart_ids:
                    if cid in chart_map and cid not in ordered_chart_ids:
                        ordered_chart_ids.append(cid)
        # Any leftover charts
        for cid in chart_map:
            if cid not in ordered_chart_ids:
                ordered_chart_ids.append(cid)

        has_tubiao = any(str(getattr(c, "figure_number", "")).startswith("图表") for c in chart_map.values())
        prefix_str = "图表" if has_tubiao else "图"

        result=[]
        for new_idx, cid in enumerate(ordered_chart_ids, 1):
            chart = chart_map[cid]
            svg=""
            image_uri = getattr(chart, "image_uri", None)
            render_mode = getattr(chart, "render_mode", "echarts")
            if render_mode == "generated_image" and image_uri:
                try:
                    img_path = Path(image_uri)
                    if img_path.is_file():
                        import base64
                        raw = img_path.read_bytes()
                        mime = getattr(chart, "image_mime_type", None) or "image/png"
                        if raw[:3] == b"\xff\xd8\xff":
                            mime = "image/jpeg"
                        b64 = base64.b64encode(raw).decode("ascii")
                        svg = (
                            f'<img alt="{chart.title}" style="max-width:100%;height:auto;display:block;margin:0 auto;" '
                            f'src="data:{mime};base64,{b64}" />'
                        )
                except OSError:
                    warnings.append(f"图表 {cid} 的 AI 产业链图不可读，回退 SVG")
            if not svg and chart.svg_uri:
                try:svg=Path(chart.svg_uri).read_text(encoding="utf-8")
                except OSError:warnings.append(f"图表 {cid} 的 SVG 文件不可读")
            if not svg:
                # S-05：缺图时**保留图位与编号**（编号重排依赖图位存在），
                # 但插入的占位图带 data-placeholder 标记，最终校验据此判为不可交付，
                # 不再像旧实现那样用一张灰色占位图冒充“图表正常”。
                svg=(
                    f'<svg xmlns="http://www.w3.org/2000/svg" data-placeholder="true" '
                    f'viewBox="0 0 960 180"><rect width="100%" height="100%" fill="#f8fafc"/>'
                    f'<text x="480" y="90" text-anchor="middle" fill="#64748b">'
                    f'{chart.title}：图表预览不可用</text></svg>'
                )
            # 固定像素宽高的 SVG（产业链图 1440px）在 A4 页宽下会被裁掉右侧 → 改自适应
            svg=_fit_svg_for_page(svg)

            
            # Re-index canonical figure number strictly in physical reading order
            fig_number = f"{prefix_str} {new_idx}"
            # Synchronize figure number inside SVG vector text
            if svg and "<svg" in svg:
                old_fig = getattr(chart, "figure_number", None)
                if old_fig and old_fig in svg:
                    svg = svg.replace(f"{old_fig}：", f"{fig_number}：").replace(f"{old_fig} ", f"{fig_number} ").replace(old_fig, fig_number)
                else:
                    svg = re.sub(r'图\s*\d+\s*[：:]\s*', f'{fig_number}：', svg, count=1)

            placement_id = assigned_placements.get(cid)
            result.append(EmbeddedChart(
                chart_id=cid,
                data_contract=getattr(chart, "data_contract", {}),
                title=chart.title,
                chart_type=chart.chart_type,
                evidence_ids=chart.evidence_ids,
                point_evidence_ids=getattr(chart, "point_evidence_ids", []) or [],
                insight_goal=chart.insight_goal,
                placement_section_id=placement_id,
                svg=svg,
                footnotes=chart.footnotes,
                figure_number=fig_number,
                subtitle=getattr(chart, "subtitle", None),
                source_line=getattr(chart, "source_line", None),
                render_mode=render_mode,
                image_uri=image_uri,
                image_mime_type=getattr(chart, "image_mime_type", None),
            ))

        # Cross-reference normalization: replace [CHART-xx] placeholders in paragraph texts with canonical figure numbers
        chart_ref_map: dict[str, str] = {}
        for idx, ec in enumerate(result, 1):
            fn = ec.figure_number or f"图 {idx}"
            chart_ref_map[f"[{ec.chart_id}]"] = fn
            chart_ref_map[ec.chart_id] = fn
            parts = ec.chart_id.split("-")
            if len(parts) >= 2:
                prefix = f"{parts[0]}-{parts[1]}"
                chart_ref_map[f"[{prefix}]"] = fn
                chart_ref_map[prefix] = fn
                chart_ref_map[f"[{prefix.lower()}]"] = fn
                chart_ref_map[prefix.lower()] = fn
            # Also map original chart.figure_number if different
            orig_chart = chart_map.get(ec.chart_id)
            if orig_chart and orig_chart.figure_number and orig_chart.figure_number != fn:
                chart_ref_map[f"[{orig_chart.figure_number}]"] = fn
                chart_ref_map[f"如{orig_chart.figure_number}"] = f"如{fn}"
                chart_ref_map[f"见{orig_chart.figure_number}"] = f"见{fn}"
                chart_ref_map[f"至{orig_chart.figure_number}"] = f"至{fn}"
            # Map index variants: [CHART-1], [CHART-01], [chart-1], [chart-01], [图表-1], [图表-01], [图表1]
            chart_ref_map[f"[CHART-{idx}]"] = fn
            chart_ref_map[f"[CHART-{idx:02d}]"] = fn
            chart_ref_map[f"[chart-{idx}]"] = fn
            chart_ref_map[f"[chart-{idx:02d}]"] = fn
            chart_ref_map[f"[图表-{idx}]"] = fn
            chart_ref_map[f"[图表-{idx:02d}]"] = fn
            chart_ref_map[f"[图表{idx}]"] = fn
            chart_ref_map[f"[图表{idx:02d}]"] = fn
            chart_ref_map[f"[chart-{idx:02d}]"] = fn
            chart_ref_map[f"[图表-{idx}]"] = fn
            chart_ref_map[f"[图表-{idx:02d}]"] = fn
            chart_ref_map[f"[图表{idx}]"] = fn
            chart_ref_map[f"[图表{idx:02d}]"] = fn

        def _clean_chart_text(text: str, default_fn: str | None = None, mapping: dict[str, str] | None = None) -> str:
            if not text:
                return text
            active_map = mapping or chart_ref_map
            for ref, fig_num in sorted(active_map.items(), key=lambda x: -len(x[0])):
                if ref in text:
                    text = text.replace(ref, fig_num)
            if default_fn:
                text = re.sub(r"\[(?:CHART|chart)-[^\]]+\]", default_fn, text)
            else:
                # Remove dangling/orphan chart placeholders
                text = re.sub(r"(?:如|见|至|参(?:考|阅)?)\s*\[(?:CHART|chart|图表)-?[^\]]+\]\s*(?:所示)?", "", text)
                text = re.sub(r"\[(?:CHART|chart|图表)-?[^\]]+\]", "", text)

            # 消除 AI Prompt 机械指令词及前缀图号（如 "[图 3]图前结论："、"图前结论："、"图后含义："、"图中数据显示："）
            text = re.sub(r"\[?图\s*\d+\]?\s*(?:图前结论|图前导读|图前研判|图前要点)\s*[:：]\s*", "", text)
            text = re.sub(r"(?:图前结论|图前导读|图前研判|图前要点)\s*[:：]\s*", "", text)
            text = re.sub(r"\[?图\s*\d+\]?\s*(?:图后含义|图后分析|图后启示|图后结论|图后研判)\s*[:：]\s*", "", text)
            text = re.sub(r"(?:图后含义|图后分析|图后启示|图后结论|图后研判)\s*[:：]\s*", "", text)
            text = re.sub(r"\[?图\s*\d+\]?\s*图中数据(?:显示)?\s*[:：，,]\s*", "", text)
            text = re.sub(r"图中数据(?:显示)?\s*[:：，,]\s*", "", text)

            # Context-aware typo and duplicate figure number cleanup:
            # 1. First normalize double "图": "如图图 1所示", "如图 图 1", "见图图 1", "图图 1"
            text = re.sub(r"(如|见|至|参(?:考|阅)?)\s*图\s*图\s*(\d+)", r"\1图 \2", text)
            text = re.sub(r"图\s*图\s*(\d+)", r"图 \1", text)
            text = re.sub(r"如图\s*(\d+)\s*所示", r"如图 \1 所示", text)
            # 2. Remove contradictory duplicate figure number right after "如图 X 所示，":
            # e.g. "如图 1 所示，图 1" 或 "如图 1 所示，图 3" 或 "如图 4 所示，图 5" -> "如图 4 所示，"
            text = re.sub(r"(如图\s*\d+\s*所示[，,])\s*图\s*\d+\s*", r"\1", text)
            # 3. Clean up any leftover awkward spaces or duplicated punctuation
            text = re.sub(r"\s+([，。、；])", r"\1", text)
            text = re.sub(r"([，。、；！？])\s+", r"\1", text)
            text = re.sub(r"([。；，])\s*\1+", r"\1", text)
            text = re.sub(r"^[，,。；]\s*", "", text)
            return text.strip()

        for ch in chapters:
            if ch.summary:
                ch.summary = _clean_chart_text(ch.summary)
            for s in ch.sections:
                sec_charts = [ec for ec in result if ec.chart_id in s.chart_ids]
                sec_default_fn = sec_charts[0].figure_number if sec_charts else None
                # 构建小节专属映射，优先将小节内引用的 [CHART-xx] 精准映射为对应图表在报告中的实际图序
                sec_map = dict(chart_ref_map)
                for sc in sec_charts:
                    fn = sc.figure_number or f"图 {result.index(sc) + 1}"
                    sec_map[f"[{sc.chart_id}]"] = fn
                    sec_map[sc.chart_id] = fn
                    parts = sc.chart_id.split("-")
                    if len(parts) >= 2:
                        pfx = f"{parts[0]}-{parts[1]}"
                        sec_map[f"[{pfx}]"] = fn
                        sec_map[pfx] = fn
                        sec_map[f"[{pfx.lower()}]"] = fn
                        sec_map[pfx.lower()] = fn
                if s.key_points:
                    s.key_points = [_clean_chart_text(kp, sec_default_fn, sec_map) for kp in s.key_points]
                for p in s.paragraphs:
                    p.text = _clean_chart_text(p.text, sec_default_fn, sec_map)

        return result

