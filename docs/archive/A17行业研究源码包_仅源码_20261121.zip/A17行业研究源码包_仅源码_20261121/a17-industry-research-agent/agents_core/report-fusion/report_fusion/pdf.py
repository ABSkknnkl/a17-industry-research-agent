from __future__ import annotations

import asyncio
import re
from pathlib import Path
from urllib.parse import unquote

_TOC_ENTRY_RE = re.compile(r'<li class="toc[^"]*">[\s\S]{0,400}?href="#([^"]+)"')
_TOC_PAGE_SLOT_RE = re.compile(r'<span class="pg">\s*</span>')


def _destination_pages(data: bytes, targets: list[str]) -> list[str]:
    import pymupdf

    destinations = {}
    with pymupdf.open(stream=data, filetype="pdf") as doc:
        for page in doc:
            for link in page.get_links():
                name = unquote(link.get("nameddest", ""))
                if name and link.get("page", -1) >= 0:
                    destinations[name] = str(link["page"] + 1)
        missing = set(targets) - set(destinations)
        if missing:
            raise ValueError(f"PDF目录目标缺少可解析的页码：{sorted(missing)}")
    return [destinations[target] for target in targets]


def backfill_toc_pages(html: str, pdf_bytes: bytes) -> str:
    """把 PDF 里实测到的章节页码写回 HTML 目录。

    PDF 的目录页码由 `render_pdf` 在浏览器里反复排版得出，HTML 文件本身拿不到分页，
    于是单独交付 HTML 时目录右栏是空的。这里以**同一份 HTML 渲染出的 PDF**为准，
    把页码回填进 HTML，让两种交付物的目录一致（页码即 PDF 页码）。
    任何一步对不上（缺锚点、页码数量不符）都原样返回，宁可不填也不写错页码。
    """
    targets = [unquote(m.group(1)) for m in _TOC_ENTRY_RE.finditer(html)]
    if not targets:
        return html
    try:
        pages = _destination_pages(pdf_bytes, targets)
    except Exception:
        return html
    if len(pages) != len(targets):
        return html
    filled = iter(pages)
    try:
        return _TOC_PAGE_SLOT_RE.sub(lambda _m: f'<span class="pg">{next(filled)}</span>', html)
    except StopIteration:
        return html


async def render_pdf(html: str, timeout_seconds: float = 180) -> bytes:
    from playwright.async_api import async_playwright

    async def work():
        async with async_playwright() as p:
            options = {} if Path(p.chromium.executable_path).is_file() else {"channel": "chrome"}
            browser = await p.chromium.launch(headless=True, **options)
            try:
                page = await browser.new_page(viewport={"width": 1440, "height": 1000})
                await page.emulate_media(media="print")
                await page.set_content(html, wait_until="load")
                await page.evaluate("document.fonts && document.fonts.ready")
                pdf_options = dict(format="A4", print_background=True, prefer_css_page_size=True,
                    display_header_footer=True,
                    header_template='<div style="font-size:8px;width:100%;text-align:center;">' +
                        ('受限草稿' if 'data-delivery-status="ready_with_limits"' in html else
                         '有限覆盖' if 'data-delivery-status="ready_scoped"' in html else '') + '</div>',
                    footer_template='<div style="font-size:9px;color:#64748b;width:100%;text-align:center;">第 <span class="pageNumber"></span> / <span class="totalPages"></span> 页</div>')
                targets = await page.evaluate("""() => Array.from(document.querySelectorAll(
                    '.toc li, .toc-list li')).map(li => {
                    const href = li.querySelector('a[href^="#"]')?.getAttribute('href');
                    const target = href ? decodeURIComponent(href.slice(1)) : '';
                    if (!target || !document.getElementById(target)) {
                        throw new Error('目录条目缺少有效的正文锚点');
                    }
                    return target;
                })""")
                # Pass 1 measures physical destinations, never duplicate title text.
                initial_bytes = await page.pdf(**pdf_options)
                if not targets:
                    return initial_bytes
                data = initial_bytes
                printed = [""] * len(targets)
                # Numbers can reflow a long TOC; only return a stable PDF.
                for _ in range(5):
                    numbers = _destination_pages(data, targets)
                    if numbers == printed:
                        return data
                    await page.evaluate("""(pages) => {
                        document.querySelectorAll('.toc li, .toc-list li').forEach((li, idx) => {
                            const pg = li.querySelector('.pg');
                            if (!pg) throw new Error('目录条目缺少页码栏');
                            pg.textContent = pages[idx];
                        });
                    }""", numbers)
                    printed = numbers
                    data = await page.pdf(**pdf_options)
                raise ValueError("PDF目录分页未能稳定，不能交付错误页码")
            finally:
                await browser.close()

    return await asyncio.wait_for(work(), timeout=timeout_seconds)
