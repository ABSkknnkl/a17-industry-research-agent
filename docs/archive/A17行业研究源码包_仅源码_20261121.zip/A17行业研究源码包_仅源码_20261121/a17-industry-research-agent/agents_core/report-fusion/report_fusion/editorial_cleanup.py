"""Clean the audited summary without manufacturing replacement claims."""
from __future__ import annotations

import re

from report_fusion.models import ExecutiveSummary


_ROW_POINTER = re.compile(
    r"逐年数值不在结论中罗列[，,]?\s*见\s*(?:evidence_record_ids|证据记录(?:编号)?)\s*与关键指标表[。；;]?"
)
_CONFLICT = re.compile(r"[^。；;]*来源观测值[^。；;]*数值冲突[^。；;]*[。；;]?")


def clean_audited_summary(summary: ExecutiveSummary, subject: str) -> list[dict]:
    """Remove empty pointers and duplicates; keep unresolved observations in boundaries."""
    changes: list[dict] = []
    boundaries = list(summary.research_boundaries)
    conclusions = []
    seen = {}
    for i, item in enumerate(summary.conclusions):
        original = item.text
        text = _ROW_POINTER.sub('', original).strip()
        for match in _CONFLICT.finditer(text):
            boundaries.append(match.group().strip())
        text = _CONFLICT.sub('', text).strip()
        # A period/as-of prefix alone is not a conclusion after its assertion was removed.
        if re.fullmatch(r"(?:【[^】]*】\s*)*[。；;\s]*", text):
            text = ''
        key = re.sub(r"[\s。；;]+", '', text)
        if key and key not in seen:
            item.text = text
            seen[key] = item
            conclusions.append(item)
        elif key:
            prior = seen[key]
            prior.evidence_ids = list(dict.fromkeys([*prior.evidence_ids, *item.evidence_ids]))
        if text != original or not key or seen.get(key) is not item:
            changes.append({'code': 'summary_cleanup', 'location': f'summary.conclusions[{i}]',
                            'original': original, 'replacement': text,
                            'disposition': 'repaired' if key else 'isolated',
                            'reason': '移除内部字段指引、空壳结论，合并重复结论；冲突观测保留在研究边界'})
    summary.conclusions = conclusions
    headline = _ROW_POINTER.sub('', summary.headline).strip()
    if _CONFLICT.search(headline):
        boundaries.append(headline)
        headline = ''
    if not headline or not re.sub(r"【[^】]*】|[。；;\s]", '', headline):
        headline = next((c.text for c in conclusions if subject in c.text),
                        conclusions[0].text if conclusions else f"{subject}行业研究：已核验证据与研究边界。")
    if headline != summary.headline:
        changes.append({'code': 'summary_cleanup', 'location': 'summary.headline',
                        'original': summary.headline, 'replacement': headline, 'disposition': 'repaired',
                        'reason': '使用终检后保留的结论替换空壳或冲突观测标题'})
    summary.headline = headline
    summary.research_boundaries = list(dict.fromkeys(boundaries))
    return changes
