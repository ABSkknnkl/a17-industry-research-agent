"""B60：callout 的标题与正文必须分开做数值审计。

真实事故（2026-11-12 低空 rev 重跑）：交付件因
「SEC-03-02.callouts[1] 数值断言无匹配证据：216架」被判 ready_with_limits。
216 架来自问财新闻原文「亿航智能2024财年实现 eVTOL 销售与交付216架」，
本可被原文命中通道证实；但融合层把 callout 标题「亿航智能营收数据缺失」拼进
正文再审计，标题里的「营收」把 216 归到 revenue 族，于是 216架 永远绑不上营收口径。
标题是标签、不是断言，分开审计即可。
"""
from __future__ import annotations

from types import SimpleNamespace as NS

from agents_core.financial_semantics import quantity_issues
from report_fusion.agent import _audit_numeric_components

NEWS = {
    "record_id": "R1", "domain": "news", "entity": "亿航智能", "metric": "summary",
    "value": "亿航智能2024财年实现eVTOL销售与交付216架，较2023年的52架增长315%。",
    "unit": None, "period": "2025-03-13",
}
REVENUE = {
    "record_id": "R2", "domain": "financials", "entity": "亿航智能", "metric": "revenue",
    "value": 4.56, "unit": "亿元", "period": "2024-12-31",
}
CALLOUT_TEXT = (
    "亿航智能EH216-S已集齐TC/AC/PC/OC四证、2024年交付216架，"
    "但2024与2025年度营收数据缺失。"
)


def _request(index: dict) -> NS:
    return NS(
        report=NS(evidence_index=index, financial_ratios=[], comps_matrix={}, as_of="2026-11-11"),
        charts=None,
        chapters=NS(warnings=[]),
    )


def test_callout_title_does_not_leak_metric_family_into_body():
    index = {"R1": NEWS, "R2": REVENUE}
    callout = NS(title="亿航智能营收数据缺失", text=CALLOUT_TEXT, evidence_ids=["R1"])
    section = NS(section_id="SEC-03-02", paragraphs=[], key_points=[], metric_cards=[],
                 comparison_table=None, callouts=[callout], chart_ids=[])
    chapter = NS(chapter_id="CH-03", title="产业链", summary="",
                 evidence_ids=["R1", "R2"], sections=[section])

    assert _audit_numeric_components([chapter], None, _request(index)) == []


def test_concatenating_title_and_body_is_what_broke_it():
    """守住这条判据：拼接写法确实会把 216架 归到营收口径。"""
    issues = quantity_issues(
        "亿航智能营收数据缺失 " + CALLOUT_TEXT, [NEWS, REVENUE], universe=[NEWS, REVENUE]
    )
    assert any(i["claim"] == "216架" and i["metric"] == "revenue" for i in issues)
    # 正文单独审计时，216 架能被新闻原文证实
    assert quantity_issues(CALLOUT_TEXT, [NEWS, REVENUE], universe=[NEWS, REVENUE]) == []


def test_sanitized_summary_still_passes_contextual_audit(monkeypatch):
    def contextual_issues(text, evidence, **kwargs):
        rejected = "无依据" in text or ("本章结论" in text and "份额3%" in text)
        return [{"code": "unsupported_quantity", "claim": "3%"}] if rejected else []

    monkeypatch.setattr("report_fusion.agent.quantity_issues", contextual_issues)
    chapter = NS(chapter_id="CH-06", summary="本章结论。无依据。份额3%。",
                 evidence_ids=[], chart_ids=[], sections=[])
    request = _request({})
    _audit_numeric_components([chapter], None, request, sanitize=True)
    assert chapter.summary == "本章结论。"
    assert _audit_numeric_components([chapter], None, request) == []
