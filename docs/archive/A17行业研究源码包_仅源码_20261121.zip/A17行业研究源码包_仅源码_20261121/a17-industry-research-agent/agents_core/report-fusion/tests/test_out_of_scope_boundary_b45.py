"""B45（2026-11-11）报告融合层：out_of_scope 边界不阻塞交付，但要如实申报。

与 data-fetcher 侧的判据测试配套
（agents_core/data-fetcher/tests/test_out_of_scope_boundary_b45.py）。
"""

from __future__ import annotations

from datetime import date

from report_fusion.agent import _check_final_view
from report_fusion.models import (
    ChapterResult,
    ChapterDraft,
    EvidenceRef,
    InterpretationReport,
    ParagraphDraft,
    ReportFusionRequest,
    SectionDraft,
)


def _request(appendix: dict) -> ReportFusionRequest:
    """用真实请求模型构造：_check_final_view 后续会跑 audit_appendix，
    假对象少字段会直接 AttributeError，反而测不到本用例关心的判定。"""
    return ReportFusionRequest(
        report=InterpretationReport(
            report_id="b45", subject="测试行业", as_of=date(2026, 11, 11),
            status="completed", data_quality_appendix=appendix,
        ),
        chapters=ChapterResult(
            run_id="b45", subject="测试行业", as_of=date(2026, 11, 11), status="completed",
            chapters=[],
        ),
        charts=None,
    )


def test_out_of_scope_cell_is_warning_not_blocking() -> None:
    req = _request({
        "requested_requirement_coverage": [{
            "requirement_id": "annual_x",
            "label": "亿航智能 2024年全年 revenue",
            "hard": True,
            "passed": False,
            "out_of_scope": True,
            "scope_note": "该主体无 A 股证券代码，不在数据源覆盖范围",
        }],
    })
    blocking, warnings, _annot = _check_final_view([], [], req)
    assert not any("亿航" in item for item in blocking)
    assert any("亿航" in item for item in warnings)


def test_ordinary_gap_is_disclosed() -> None:
    req = _request({
        "requested_requirement_coverage": [{
            "requirement_id": "news_x",
            "label": "某公司事件记录",
            "hard": True,
            "passed": False,
            "out_of_scope": False,
        }],
    })
    blocking, warnings, _ = _check_final_view([], [], req)
    assert not blocking
    assert any("某公司事件记录" in item for item in warnings)


def test_out_of_scope_annual_financial_cell_is_warning_not_blocking() -> None:
    req = _request({
        "requested_financial_coverage": [{
            "requirement_id": "annual_x",
            "label": "亿航智能 2024年全年 revenue",
            "hard": True,
            "passed": False,
            "out_of_scope": True,
            "scope_note": "该主体无 A 股证券代码，不在数据源覆盖范围",
        }],
    })
    blocking, warnings, _annot = _check_final_view([], [], req)
    assert not any("亿航" in item for item in blocking)
    assert any("亿航" in item for item in warnings)


def test_automatic_announcement_gap_is_disclosed_without_waiving_financial_data() -> None:
    req = _request({
        "requirement_evidence_matrix": [{"requirement": {
            "requirement_id": "announcement_search_auto",
            "origin": "automatic_announcement",
            "domain": "news", "acceptable_skill_ids": ["announcement-search"],
        }}],
        "requested_requirement_coverage": [{
            "requirement_id": "announcement_search_auto", "label": "甲公司年报公告检索",
            "hard": True, "passed": False,
        }],
        "requested_financial_coverage": [{
            "requirement_id": "annual_revenue", "label": "甲公司2024年营业收入",
            "hard": True, "passed": False,
        }],
    })
    blocking, warnings, _ = _check_final_view([], [], req)
    assert not blocking
    assert any("甲公司年报公告检索" in item for item in warnings)
    req.options.accepted_announcement_ids = ["announcement_search_auto"]
    blocking, warnings, _annot = _check_final_view([], [], req)
    assert not any("甲公司年报公告检索" in item for item in blocking)
    assert any("甲公司年报公告检索" in item and "未核实" in item for item in warnings)
    assert any("甲公司2024年营业收入" in item for item in warnings)


def test_announcement_gap_with_unknown_origin_is_disclosed() -> None:
    req = _request({"requested_requirement_coverage": [{
        "requirement_id": "announcement_search_unknown", "label": "用户要求的更正公告",
        "hard": True, "passed": False,
    }]})
    blocking, warnings, _ = _check_final_view([], [], req)
    assert not blocking
    assert any("用户要求的更正公告" in item for item in warnings)


def test_claim_of_no_citable_rd_records_conflicts_with_required_evidence() -> None:
    req = _request({"requested_financial_coverage": [{
        "requirement_id": "annual_rd", "label": "甲公司 2023年全年 rd_investment",
        "hard": True, "passed": True, "evidence_record_ids": ["rd-2023"],
    }]})
    req.report.evidence_index["rd-2023"] = EvidenceRef(record_id="rd-2023", domain="financials", metric="rd_investment")
    paragraph = ParagraphDraft(paragraph_id="P-01", text="研发投入年度序列未提供可引用的原始记录ID。")
    chapter = ChapterDraft(chapter_id="CH-01", title="研发", summary="", sections=[
        SectionDraft(section_id="SEC-01", title="研发", paragraphs=[paragraph])
    ])

    blocking = _check_final_view([chapter], [], req)[0]
    assert any("P-01" in item and "研发" in item and "核对" in item for item in blocking)


def test_claim_of_missing_rd_records_is_not_contradicted_by_unrelated_revenue() -> None:
    req = _request({"requested_financial_coverage": [{
        "requirement_id": "annual_revenue", "label": "甲公司 2023年全年 revenue",
        "hard": True, "passed": True, "evidence_record_ids": ["revenue-2023"],
    }]})
    req.report.evidence_index["revenue-2023"] = EvidenceRef(record_id="revenue-2023", domain="financials", metric="revenue")
    paragraph = ParagraphDraft(paragraph_id="P-01", text="研发投入年度序列未提供可引用的原始记录ID。")
    chapter = ChapterDraft(chapter_id="CH-01", title="研发", summary="", sections=[
        SectionDraft(section_id="SEC-01", title="研发", paragraphs=[paragraph])
    ])

    blocking = _check_final_view([chapter], [], req)[0]
    assert not any("P-01" in item and "研发" in item for item in blocking)


def test_sector_label_does_not_prove_company_chain_position() -> None:
    req = _request({})
    req.report.evidence_index["sector"] = EvidenceRef(
        record_id="sector", domain="industry", metric="industry_name", entity="甲公司", value="半导体设备"
    )
    paragraph = ParagraphDraft(
        paragraph_id="P-01", text="甲公司归属下游场景应用环节。", evidence_ids=["sector"]
    )
    chapter = ChapterDraft(chapter_id="CH-01", title="行业", summary="", sections=[
        SectionDraft(section_id="SEC-01", title="行业", paragraphs=[paragraph])
    ])

    blocking = _check_final_view([chapter], [], req)[0]
    assert any("P-01" in item and "产业链归属" in item for item in blocking)


def test_independent_chain_evidence_does_not_trigger_sector_only_gate() -> None:
    req = _request({})
    req.report.evidence_index["chain"] = EvidenceRef(
        record_id="chain", domain="industry_chain", metric="company_membership", entity="甲公司"
    )
    paragraph = ParagraphDraft(
        paragraph_id="P-01", text="甲公司归属下游场景应用环节。", evidence_ids=["chain"]
    )
    chapter = ChapterDraft(chapter_id="CH-01", title="行业", summary="", sections=[
        SectionDraft(section_id="SEC-01", title="行业", paragraphs=[paragraph])
    ])

    blocking = _check_final_view([chapter], [], req)[0]
    assert not any("P-01" in item and "产业链归属" in item for item in blocking)
