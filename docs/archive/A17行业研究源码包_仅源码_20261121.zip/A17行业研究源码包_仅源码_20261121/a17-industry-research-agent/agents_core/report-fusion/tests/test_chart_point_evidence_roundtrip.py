"""A3 点级证据必须真实穿过 A5 契约并参与摘要数值审计。"""
from __future__ import annotations

from types import SimpleNamespace as NS

from chart_generator.models import ChartSpec as A3ChartSpec
from report_fusion.agent import _audit_numeric_components
from report_fusion.agent import ReportFusionAgent
from report_fusion.config import Settings
from report_fusion.models import (
    ChartResult, ChapterDraft, ChapterResult, EvidenceRef, FusionOptions,
    InterpretationReport, ReportFusionRequest, SectionDraft,
    ChartSpec as A5ChartSpec,
)


def test_a3_point_evidence_survives_a5_parsing_and_numeric_audit():
    point = {
        "record_id": "R-POINT", "domain": "financials", "entity": "公司甲",
        "metric": "net_margin", "value": 12.3, "unit": "%",
        "period": "2025-12-31", "period_type": "annual",
    }
    other = {
        "record_id": "R-OTHER", "domain": "financials", "entity": "公司甲",
        "metric": "net_margin", "value": 88.8, "unit": "%",
        "period": "2025-12-31", "period_type": "annual",
    }
    a3_chart = A3ChartSpec(
        chart_id="C-POINT", title="公司甲净利率", chart_type="bar",
        option={"series": [{"name": "净利率", "data": [12.3]}]},
        evidence_ids=["R-OTHER"], point_evidence_ids=["R-POINT"],
        insight_goal="核验公司盈利能力", data_fingerprint="fixture",
    )

    # 必须经过 A3 实际序列化 JSON，再由 A5 的独立契约解析，不能直接共享对象。
    parsed = A5ChartSpec.model_validate_json(a3_chart.model_dump_json())
    assert parsed.point_evidence_ids == ["R-POINT"]

    chapter = NS(
        chapter_id="CH-05", title="财务分析",
        summary="公司甲2025年销售净利率为12.3%。",
        evidence_ids=[], chart_ids=["C-POINT"], sections=[],
    )
    request = NS(
        report=NS(
            evidence_index={"R-POINT": point, "R-OTHER": other},
            financial_ratios=[], comps_matrix={}, as_of="2025-12-31",
        ),
        charts=NS(charts=[parsed]), chapters=NS(warnings=[]),
    )

    assert _audit_numeric_components([chapter], None, request) == []


def test_legacy_chart_without_point_evidence_still_parses():
    parsed = A5ChartSpec.model_validate({
        "chart_id": "C-LEGACY", "title": "旧图表", "chart_type": "bar",
        "evidence_ids": ["R-OTHER"],
    })
    assert parsed.point_evidence_ids == []


def test_embedded_chart_preserves_point_evidence_in_final_view(tmp_path):
    point = EvidenceRef.model_validate({
        "record_id": "R-POINT", "domain": "financials", "entity": "公司甲",
        "metric": "net_margin", "value": 12.3, "unit": "%", "period": "2025-12-31",
    })
    report = InterpretationReport(
        report_id="A1", subject="测试行业", as_of="2025-12-31", status="completed",
        evidence_index={"R-POINT": point},
    )
    chapter = ChapterDraft(
        chapter_id="CH-01", title="第一章", summary="公司盈利分析",
        sections=[SectionDraft(
            section_id="SEC-01-01", title="盈利能力", chart_ids=["C-POINT"],
        )],
    )
    chapters = ChapterResult(
        run_id="C1", subject="测试行业", as_of="2025-12-31", status="completed",
        chapters=[chapter],
    )
    charts = ChartResult(charts=[A5ChartSpec(
        chart_id="C-POINT", title="净利率", chart_type="bar",
        evidence_ids=["R-POINT"], point_evidence_ids=["R-POINT"],
    )])
    request = ReportFusionRequest(
        report=report, chapters=chapters, charts=charts,
        options=FusionOptions(enable_editorial_llm=False, formats=["markdown"]),
    )
    embedded = ReportFusionAgent(settings=Settings(output_dir=tmp_path))._embed_charts(
        request, [chapter], []
    )
    assert embedded[0].point_evidence_ids == ["R-POINT"]
    assert embedded[0].model_dump(mode="json")["point_evidence_ids"] == ["R-POINT"]

