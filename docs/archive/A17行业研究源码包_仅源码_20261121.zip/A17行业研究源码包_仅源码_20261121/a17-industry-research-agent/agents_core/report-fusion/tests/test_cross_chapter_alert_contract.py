"""A4 跨章同键矛盾 → A5 告警的衔接契约。

两个必须锁死的行为
------------------
1. A4 产出的 ``cross_chapter_claim_conflict`` 条目（``disposition=flagged``）在 A5
   里表现为**告警**，不进 blocking；段落 id 要出现在告警文案里，方便人工定位。
2. 这类条目**不得**影响「章节层缺口已处置」的判定：它是提示性的，不是需要修复的
   缺口。否则一个 warning 级别条目就能把所有走「逐段修复」通道的报告钉死在
   partial。
"""

from __future__ import annotations

from types import SimpleNamespace

from report_fusion.agent import _chapter_claims_recovered


def _chapter(chapter_id: str, audit: list[dict]):
    section = SimpleNamespace(section_id=f"{chapter_id}-SEC-01", paragraphs=[],
                              chart_ids=[])
    return SimpleNamespace(
        chapter_id=chapter_id, used_fallback=False,
        sections=[section], content_audit=list(audit),
    )


def _audit(code: str, disposition: str) -> dict:
    return {"code": code, "disposition": disposition, "location": "P-01-01-01",
            "replacement_evidence_ids": ["R-fix"]}


def _issues() -> list[str]:
    return ["段落资料缺口：CH-01 P-01-01-01"]


def test_flagged_cross_chapter_conflict_does_not_block_recovery() -> None:
    chapters = [_chapter("CH-01", [_audit("chapter_claim_repair", "repaired")])]
    assert _chapter_claims_recovered(chapters, chapters[0].content_audit, _issues())


def test_flagged_entry_alone_still_blocks_recovery() -> None:
    chapters = [_chapter("CH-01", [_audit("cross_chapter_claim_conflict", "flagged")])]
    assert not _chapter_claims_recovered(chapters, chapters[0].content_audit, _issues())


def test_unrepaired_gap_still_blocks_recovery() -> None:
    chapters = [_chapter("CH-01", [
        _audit("chapter_claim_repair", "repaired"),
        _audit("chapter_claim_repair", "isolated"),
    ])]
    assert not _chapter_claims_recovered(chapters, chapters[0].content_audit, _issues())
