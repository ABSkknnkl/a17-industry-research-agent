"""部分核验标注的交付可见性（2026-11-15 任务 4，渲染层）。

MD/HTML/PDF 的数据质量附录必须出现「部分核验标注（N 项）」小节：
列出位置、断言、判定类别与命中证据，样式为中性表格（不复用红色告警）。
"""
from __future__ import annotations

from report_fusion.models import ReportViewModel
from report_fusion.render import render_html, render_markdown


def _view(**overrides) -> ReportViewModel:
    base = dict(
        report_id="r", title="行业报告", subject="行业", as_of="2026-11-01",
        tone="professional", report_depth="standard", visual_style="deep_research",
        delivery_status="ready_with_limits", chapters=[],
        executive_summary={"headline": "研究资料"},
        verification_status="partial",
        verification_warnings=[{
            "code": "unsupported_quantity", "severity": "warning", "disposition": "annotated",
            "location": "SEC-01-02.key_points[0]", "claim": "1659亿美元",
            "verification_category": "text_quote_only",
            "verification_evidence_ids": ["R-SEMI"],
        }],
        verification_summary={"annotated": 1, "remaining_blocking": 0,
                              "by_reason": {"text_quote_only": 1}},
    )
    base.update(overrides)
    return ReportViewModel(**base)


def test_markdown_appendix_lists_annotation_items():
    rendered = render_markdown(_view())
    assert "部分核验标注（1 项）" in rendered
    assert "SEC-01-02.key_points[0]" in rendered
    assert "1659亿美元" in rendered
    assert "原文命中" in rendered
    assert "R-SEMI" in rendered


def test_html_appendix_lists_annotation_items_in_both_templates():
    for rendered in (render_html(_view()), render_html(_view().model_copy(update={"chart_mode": "rich"}))):
        assert "部分核验标注" in rendered
        assert "SEC-01-02.key_points[0]" in rendered
        assert "1659亿美元" in rendered


def test_verified_view_has_no_annotation_section():
    view = _view(verification_status="verified", verification_warnings=[],
                 verification_summary={})
    rendered = render_markdown(view)
    assert "部分核验标注" not in rendered


def test_annotation_section_uses_neutral_styling_not_alert_red():
    """标注表格用中性样式，不得复用红色告警配色。"""
    rendered = render_html(_view())
    assert "verification-annotation-table" in rendered
    assert "--negative-red" not in rendered.split("verification-annotation-table")[1][:600]
