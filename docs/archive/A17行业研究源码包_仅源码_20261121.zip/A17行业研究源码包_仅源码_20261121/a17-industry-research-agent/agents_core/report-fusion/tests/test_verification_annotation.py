"""融合层「标注不拦截」通道（2026-11-15 任务 2，TDD）。

背景：诊断器（任务 1）证明被拦的 unsupported_quantity 里约半数「全库有据但绑定层
未认」（junk 实体、跨章预算、亿美元口径）。本文件锁定标注通道的边界：
  - 有据（结构化/原文/跨章/币种错配）→ disposition=annotated，正文保留，不阻塞交付；
  - 全库无据（absent）/ 国产化率 / 硬需求缺口 → 维持拦截，一条不能放；
  - 容量双上限（150 条 & 60%），超限时强证据优先标注、弱证据维持拦截；
  - 仅有标注：consistency.passed=true、formal_verified=false、
    verification_status="partial"、delivery_status="ready_with_limits"。

全部离线、零配额。
"""
from __future__ import annotations

import asyncio
import json
from datetime import date
from pathlib import Path
from types import SimpleNamespace as NS

import report_fusion.agent as fusion_agent
from report_fusion.agent import ReportFusionAgent, _triage_numeric_annotations
from report_fusion.models import (
    ChapterDraft,
    ChapterResult,
    ChartResult,
    FusionOptions,
    InterpretationReport,
    ParagraphDraft,
    ReportFusionRequest,
    SectionDraft,
)


class _NoLLM:
    is_available = False

    async def generate_json(self, *_a, **_k):
        raise AssertionError("离线测试不应调用模型")


def _issue(claim: str, *, metric=None, entity=None, year=None, location="SEC-01-01.key_points[0]",
           original=None, code="unsupported_quantity", **extra) -> dict:
    return {"code": code, "severity": "error", "location": location, "claim": claim,
            "metric": metric, "entity": entity, "year": year,
            "original": original or f"断言{claim}。", "evidence_ids": [], **extra}


def _request_stub(index: dict, requirement_rows=None, chapters=()) -> NS:
    return NS(
        report=NS(evidence_index=index,
                  data_quality_appendix={"requirement_evidence_matrix": requirement_rows or []},
                  financial_ratios=None, comps_matrix={}, as_of="2026-11-13"),
        charts=NS(charts=[]),
        chapters=NS(chapters=list(chapters)),
    )


# --- 直接分诊测试 -------------------------------------------------------------

def test_macro_text_quote_is_annotated_not_blocked():
    """「1659亿美元」全库原文可见 → 标注放行，不进 blocking。"""
    index = {"R1": {"record_id": "R1", "domain": "reports", "entity": None, "metric": "summary",
                    "value": "SEMI预计2026年全球半导体设备销售额将达到1659亿美元，同比增长23.2%。"}}
    req = _request_stub(index)
    issue = _issue("1659", entity="预计", year=2026,
                   original="SEMI预计2026年全球设备销售额1659亿美元。")
    annotated, blocking = _triage_numeric_annotations([issue], req, list(req.chapters.chapters))
    assert not blocking
    assert len(annotated) == 1
    item = annotated[0]
    assert item["disposition"] == "annotated"
    assert item["severity"] == "warning"
    assert item["verification_category"] == "text_quote_only"
    assert item["verification_evidence_ids"] == ["R1"]
    assert item["claim"] == "1659"          # 原 claim/位置保留
    assert item["location"] == issue["location"]


def test_absent_claim_still_blocked():
    """全库无据的「8.46倍」维持拦截。"""
    index = {"R2": {"record_id": "R2", "domain": "financials", "entity": "中微公司",
                    "metric": "gross_margin", "value": 45.0, "unit": "%", "period": "2025-12-31"}}
    req = _request_stub(index)
    issue = _issue("8.46倍", metric="pe", entity="拓荆科技", year=2025,
                   original="拓荆科技动态市盈率8.46倍。")
    annotated, blocking = _triage_numeric_annotations([issue], req, [])
    assert annotated == []
    assert len(blocking) == 1 and blocking[0]["claim"] == "8.46倍"


def test_localization_rate_still_blocked():
    """国产化率族同值命中也不放行（SEMI-F4）。"""
    index = {"R3": {"record_id": "R3", "domain": "reports", "entity": None, "metric": "summary",
                    "value": "2025年国产设备国产化率约45%，较上年提升。"}}
    req = _request_stub(index)
    issue = _issue("45%", metric="localization_rate", entity=None, year=2025,
                   original="2025年国产设备国产化率约45%。")
    annotated, blocking = _triage_numeric_annotations([issue], req, [])
    assert annotated == []
    assert len(blocking) == 1


def test_hard_requirement_gap_still_blocked():
    """硬需求缺口（亿航智能 2025 年报）关联断言不放行。"""
    index = {"R4": {"record_id": "R4", "domain": "financials", "entity": "亿航智能",
                    "metric": "revenue", "value": 4.56, "unit": "亿元", "period": "2024-12-31"}}
    rows = [{"requirement": {"requirement_id": "annual_x", "label": "亿航智能 2025年全年 revenue",
                             "hard": True, "entity_names": ["亿航智能"],
                             "period_ends": ["2025-12-31"], "metric_families": ["revenue"]},
             "coverage": {"passed": False, "missing": ["2025-12-31"], "evidence_count": 0}}]
    req = _request_stub(index, requirement_rows=rows)
    issue = _issue("4.56亿元", metric="revenue", entity="亿航智能", year=2025,
                   original="亿航智能2025年营业收入4.56亿元。")
    annotated, blocking = _triage_numeric_annotations([issue], req, [])
    assert annotated == []
    assert len(blocking) == 1


def test_capacity_cap_blocks_weakest_evidence_first(monkeypatch):
    """超上限时：强证据先标注，弱证据（同批内排序靠后）维持拦截。"""
    monkeypatch.setattr(fusion_agent, "_ANNOTATION_LIMIT", 3)
    monkeypatch.setattr(fusion_agent, "_ANNOTATION_RATIO", 0.5)
    index = {
        "R-strong-a": {"record_id": "R-strong-a", "domain": "financials", "entity": "北方华创",
                       "metric": "revenue", "value": 3.2, "unit": "亿元", "period": "2025-12-31"},
        "R-strong-b": {"record_id": "R-strong-b", "domain": "financials", "entity": "中微公司",
                       "metric": "revenue", "value": 5.8, "unit": "亿元", "period": "2025-12-31"},
        "R-text": {"record_id": "R-text", "domain": "reports", "entity": None, "metric": "summary",
                   "value": "2026年全球市场规模预计达到1659亿美元。"},
    }
    req = _request_stub(index)
    issues = [
        _issue("3.2亿元", metric="revenue", entity="北方华创", year=2025,
               location="SEC-01-01.key_points[0]", original="北方华创2025年营收3.2亿元。"),
        _issue("5.8亿元", metric="revenue", entity="中微公司", year=2025,
               location="SEC-01-01.key_points[1]", original="中微公司2025年营收5.8亿元。"),
        _issue("1659", entity="预计", year=2026, location="SEC-01-02.key_points[0]",
               original="预计2026年全球市场规模达到1659亿美元。"),
        _issue("1659", entity="预计", year=2026, location="SEC-01-02.key_points[1]",
               original="预计2026年全球市场规模达到1659亿美元。"),
        _issue("1659", entity="预计", year=2026, location="SEC-01-02.key_points[2]",
               original="预计2026年全球市场规模达到1659亿美元。"),
        _issue("1659", entity="预计", year=2026, location="SEC-01-02.key_points[3]",
               original="预计2026年全球市场规模达到1659亿美元。"),
    ]
    annotated, blocking = _triage_numeric_annotations(issues, req, [])
    assert len(annotated) == 3                                  # cap = min(3, 6*0.5)
    # 两条结构化命中必须全部在标注里；剩余名额给了排序靠前的原文命中
    assert {i["claim"] for i in annotated if i["verification_category"] == "value_exact_structured"} == {"3.2亿元", "5.8亿元"}
    assert len(blocking) == 3
    assert all(i["claim"] == "1659" for i in blocking)          # 弱证据被拦


def test_chapter_scope_outside_subset_annotated():
    """证据在库但不在本章检索子集 → 标注（chapter_scope_only）。"""
    index = {"R9": {"record_id": "R9", "domain": "financials", "entity": "北方华创",
                    "metric": "revenue", "value": 3.2, "unit": "亿元", "period": "2025-12-31"}}
    chapter = NS(chapter_id="CH-01", evidence_ids={"R-other"},
                 sections=[NS(section_id="SEC-01-01")])
    req = _request_stub(index, chapters=[chapter])
    issue = _issue("3.2亿元", metric="revenue", entity="北方华创", year=2025,
                   location="SEC-01-01.key_points[0]", original="北方华创2025年营业收入3.2亿元。")
    annotated, blocking = _triage_numeric_annotations([issue], req, [chapter])
    assert not blocking and len(annotated) == 1
    assert annotated[0]["verification_category"] == "chapter_scope_only"


# --- run() 集成测试 ------------------------------------------------------------

def _report() -> InterpretationReport:
    return InterpretationReport.model_validate({
        "report_id": "R-ANNO", "subject": "测试行业", "as_of": "2026-10-31",
        "status": "completed",
        "evidence_index": {
            "R-SEMI": {"record_id": "R-SEMI", "domain": "industry", "entity": None,
                       "metric": "summary",
                       "value": "国际半导体产业协会（SEMI）预计2026年全球半导体设备销售额将达到1659亿美元，同比增长23.2%。"},
        },
        "data_quality_appendix": {"requirement_evidence_matrix": []},
        "insights": [], "warnings": [],
    })


def _chapters() -> ChapterResult:
    chapters = []
    for i in range(1, 8):
        sections = []
        for j in range(1, 4):
            text = "各节按证据梳理行业现状，口径统一。"
            eids: list[str] = []
            if i == 1 and j == 1:
                text = "SEMI预计2026年全球设备销售额1659亿美元，景气度延续。"
                eids = ["R-SEMI"]
            sections.append(SectionDraft(
                section_id=f"SEC-{i:02d}-0{j}", title=f"节{j}", purpose="目的",
                key_points=["要点"],
                paragraphs=[ParagraphDraft(paragraph_id=f"P-{i:02d}-0{j}-01",
                                           kind="analysis", text=text, evidence_ids=eids)],
            ))
        chapters.append(ChapterDraft(chapter_id=f"CH-{i:02d}", title=f"第{i}章",
                                     summary=f"第{i}章摘要", sections=sections))
    return ChapterResult(run_id="ch-run", source_report_id="R-ANNO", subject="测试行业",
                         as_of=date(2026, 10, 31), status="completed", outline_version="v1",
                         chapters=chapters)


def _request() -> ReportFusionRequest:
    return ReportFusionRequest(report=_report(), chapters=_chapters(),
                               charts=ChartResult(charts=[]),
                               options=FusionOptions(formats=["markdown"],
                                                     enable_editorial_llm=False))


def test_annotation_only_yields_partial_verification(tmp_path):
    """仅有标注：不阻塞交付，但 verification_status=partial + ready。"""
    agent = ReportFusionAgent(llm=_NoLLM())
    result = asyncio.run(agent.run(_request(), save_artifacts=True))
    view_entry = next(a for a in result.artifacts if a.uri.endswith("report_view.json"))
    view = json.loads(Path(view_entry.uri).read_text(encoding="utf-8"))
    assert view["verification_status"] == "partial"
    assert view["delivery_status"] == "ready"
    assert view["fact_audit"]["formal_verified"] is False
    assert result.consistency.passed is True
    assert result.status == "completed"
    summary = view["verification_summary"]
    assert summary["annotated"] >= 1 and summary["remaining_blocking"] == 0
    assert summary["by_reason"].get("text_quote_only", 0) >= 1
    annotated = [q for q in view["quality_issues"] if q.get("disposition") == "annotated"]
    assert annotated and all(q["severity"] == "warning" for q in annotated)
    assert any(q["claim"] == "1659" for q in annotated)
    assert not any("数值断言无匹配证据" in issue for issue in result.consistency.issues)


def test_annotation_allowlist_survives_keypoint_index_shift():
    """sanitize 移除前面的 key_point 后序号前移，allowlist 仍要命中（2026-11-15 实测回归）。

    真实事故：pre_audit 在 SEC-06-01.key_points[1] 标注了「1659」，sanitize 删掉
    key_points[0] 后它变成 key_points[0]，带序号的精确匹配让终审重新把它判成无据。
    """
    index = {"R1": {"record_id": "R1", "domain": "reports", "entity": None, "metric": "summary",
                    "value": "SEMI预计2026年全球半导体设备销售额将达到1659亿美元。"}}
    req = _request_stub(index)
    issue = _issue("1659", entity="预计", year=2026, location="SEC-06-01.key_points[1]",
                   original="SEMI预计2026年全球设备销售额1659亿美元。")
    annotated, _blocked = _triage_numeric_annotations([issue], req, [])
    assert len(annotated) == 1
    allowlist = {fusion_agent._norm_location(item["location"]): item["claim"]
                 for item in annotated}
    assert allowlist == {"SEC-06-01.key_points": "1659"}
    # 位移后的位置仍能命中同一 allowlist 键
    assert fusion_agent._norm_location("SEC-06-01.key_points[0]") in allowlist
