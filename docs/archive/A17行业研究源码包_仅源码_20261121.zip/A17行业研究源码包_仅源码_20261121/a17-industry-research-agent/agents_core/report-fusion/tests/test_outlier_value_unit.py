"""Outlier display formatting must respect the source unit.

Regression
----------
``_format_outlier_val`` used to guess a money scale purely from magnitude:
anything ``>= 1e4`` became ``万元``.  A vehicle-sales outlier of ``16_490_000 辆``
was therefore printed as ``1649.00万元`` in the data-quality appendix -- a wrong
unit on a real number, which is worse than an ugly one.
"""

from __future__ import annotations

from report_fusion.render import _format_outlier_val


def test_vehicle_count_is_not_rendered_as_money() -> None:
    text = _format_outlier_val(16_490_000, "销量", "辆")
    assert "万元" not in text
    assert "辆" in text


def test_money_unit_is_respected() -> None:
    assert _format_outlier_val(1, "营业收入", "百万元").endswith("百万元")


def test_rate_keeps_its_percent() -> None:
    assert _format_outlier_val(3.24, "毛利率", "%") == "3.24%"


def test_without_unit_legacy_behaviour_is_unchanged() -> None:
    # Callers that do not know the unit keep the old heuristic output.
    assert _format_outlier_val(3.24, "gross_margin") == "3.24%"
    assert _format_outlier_val("-", "revenue") == "-"
