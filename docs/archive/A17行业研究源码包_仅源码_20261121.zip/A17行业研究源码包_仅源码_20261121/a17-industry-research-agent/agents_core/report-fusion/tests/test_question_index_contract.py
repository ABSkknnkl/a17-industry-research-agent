"""A3 逐题主答 → A5 问题索引的端到端契约。

从分支 ``test_agent.py`` 抽取该用例（不整文件覆盖主仓 test_agent.py——两侧
`_check_final_view` 契约不同）。锁定四件事：

1. ``question_answers`` 在融合层做**交付版过滤**：removed 段落/证据/图表不得出现在
   报告视图（索引只引用最终正文里真实存在的东西）；
2. auto 与 rich 两版式都渲染问题索引与结论索引锚点；
3. 引用编号在两个前缀（``source-`` / ``src-``）下都能跳到证据目录；
4. Markdown 出现题目原文。
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

import pytest

from report_fusion import ReportFusionAgent, ReportFusionRequest
from report_fusion.config import Settings
from report_fusion.models import ChapterResult, FusionOptions, InterpretationReport


def inputs() -> tuple[InterpretationReport, ChapterResult]:
    report = InterpretationReport.model_validate({"report_id": "A1", "subject": "测试行业", "as_of": "2026-09-01", "status": "completed", "insights": [{"conclusion": "市场规模为100亿元", "confidence": "high", "evidence_record_ids": ["R1"]}], "evidence_index": {"R1": {"record_id": "R1", "domain": "industry", "entity": "测试行业", "metric": "市场规模", "value": 100, "unit": "亿元", "period": "2026-06-30"}}})
    chapters = []
    for ci in range(1, 8):
        sections = []
        for si in range(1, 4):
            sections.append({"section_id": f"SEC-{ci:02d}-{si:02d}", "title": f"第{ci}章第{si}节", "purpose": "分析", "paragraphs": [{"paragraph_id": f"P-{ci}-{si}", "text": "根据现有资料形成审慎判断。", "evidence_ids": ["R1"]}]})
        chapters.append({"chapter_id": f"CH-{ci:02d}", "title": f"第{ci}章", "summary": "本章基于现有资料展开。", "sections": sections, "evidence_ids": ["R1"]})
    result = ChapterResult.model_validate({"run_id": "C1", "subject": "测试行业", "as_of": "2026-09-01", "status": "completed", "chapters": chapters})
    return report, result


@pytest.mark.parametrize("chart_mode, source_anchor", [("auto", "source-1"), ("rich", "src-1")])
def test_question_and_conclusion_indices_use_final_report_evidence(tmp_path, chart_mode, source_anchor):
    report, chapters = inputs()
    chapters.question_answers = [{
        "question_id": "Q-1",
        "text": "本期市场规模如何？",
        "section_id": "SEC-01-01",
        "paragraph_ids": ["P-1-1", "removed-paragraph"],
        "evidence_record_ids": ["R1", "removed-evidence"],
        "chart_ids": ["removed-chart"],
    }]
    result = asyncio.run(ReportFusionAgent(settings=Settings(output_dir=tmp_path)).run(
        ReportFusionRequest(report=report, chapters=chapters,
                            options=FusionOptions(formats=["markdown", "html"],
                                                  chart_mode=chart_mode, enable_editorial_llm=False))))
    root = Path(result.artifact_dir)
    question, = json.loads((root / "report_view.json").read_text())["question_answers"]
    assert question["paragraph_ids"] == ["P-1-1"]
    assert question["evidence_record_ids"] == ["R1"]
    assert question["chart_ids"] == []
    html = (root / "report.html").read_text()
    assert 'href="#research-questions"' in html
    assert 'href="#research-conclusions"' in html
    assert f'href="#{source_anchor}">[1]</a>' in html
    assert 'id="SEC-01-01"' in html
    assert "本期市场规模如何？" in (root / "report.md").read_text()


def test_question_answer_falls_back_to_remaining_section_paragraphs(tmp_path):
    """原绑定段落被 A4 质量过滤移走后，问题索引必须回退到同小节剩余段落。"""
    report, chapters = inputs()
    chapters.question_answers = [{
        "question_id": "Q-3",
        "text": "行业发展驱动因素与潜在风险是什么？",
        "section_id": "SEC-02-02",
        "paragraph_ids": ["removed-paragraph"],
        "evidence_record_ids": ["removed-evidence"],
        "chart_ids": [],
    }]
    result = asyncio.run(ReportFusionAgent(settings=Settings(output_dir=tmp_path)).run(
        ReportFusionRequest(report=report, chapters=chapters,
                            options=FusionOptions(formats=["markdown", "html"],
                                                  chart_mode="auto", enable_editorial_llm=False))))
    root = Path(result.artifact_dir)
    question, = json.loads((root / "report_view.json").read_text())["question_answers"]
    assert question["paragraph_ids"] == ["P-2-2"]
    assert question["evidence_record_ids"] == ["R1"]
    assert question["section_title"] == "第2章第2节"
