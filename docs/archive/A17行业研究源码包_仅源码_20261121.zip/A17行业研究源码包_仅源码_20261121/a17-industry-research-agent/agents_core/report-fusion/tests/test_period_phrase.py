"""Reading-view period phrases must not drop the reporting period.

Regression
----------
``_period_phrase`` returned ``f"{year}年{scope_label}"`` whenever a scope was
present, so ``2025-09-30（ytd_q3，consolidated）`` was rewritten as
``2025年合并财务报表`` -- the "前三季度" qualifier vanished and the sentence then
read as a full-year figure.
"""

from __future__ import annotations

from report_fusion.render import _PERIOD_BASIS, _period_phrase


def _phrase(text: str) -> str:
    match = _PERIOD_BASIS.search(text)
    assert match is not None, text
    return _period_phrase(match)


def test_scope_does_not_drop_the_period() -> None:
    assert _phrase("2025-09-30（ytd_q3，consolidated）") == "2025年前三季度合并财务报表"


def test_annual_with_scope_still_reads_naturally() -> None:
    assert _phrase("2025-12-31（annual，parent）") == "2025年母公司财务报表"


def test_period_without_scope_is_unchanged() -> None:
    assert _phrase("2025-06-30（half_year）") == "2025年半年度"


def test_quarter_with_scope() -> None:
    assert _phrase("2025-03-31（quarter，consolidated）") == "2025年单季度合并财务报表"
