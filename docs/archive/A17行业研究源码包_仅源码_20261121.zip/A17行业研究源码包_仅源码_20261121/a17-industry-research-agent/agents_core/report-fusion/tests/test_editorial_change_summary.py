from __future__ import annotations

import asyncio
import json
from pathlib import Path

from report_fusion.agent import ReportFusionAgent, _build_editorial_changes
from report_fusion.config import Settings
from report_fusion.models import (
    ChapterResult, FusionOptions, InterpretationReport, ReportFusionRequest,
    ReportViewModel,
)


def _inputs():
    report = InterpretationReport.model_validate({
        "report_id": "A1", "subject": "测试行业", "as_of": "2026-09-01", "status": "completed",
        "insights": [{"conclusion": "市场规模为100亿元", "confidence": "high",
                      "evidence_record_ids": ["R1"]}],
        "evidence_index": {"R1": {"record_id": "R1", "domain": "industry", "entity": "测试行业",
                                  "metric": "市场规模", "value": 100, "unit": "亿元",
                                  "period": "2026-06-30"}},
    })
    chapters = []
    for ci in range(1, 8):
        sections = []
        for si in range(1, 4):
            sections.append({
                "section_id": f"SEC-{ci:02d}-{si:02d}", "title": f"第{ci}章第{si}节",
                "purpose": "分析",
                "paragraphs": [{"paragraph_id": f"P-{ci}-{si}",
                                "text": "根据现有资料形成审慎判断。", "evidence_ids": ["R1"]}],
            })
        chapters.append({"chapter_id": f"CH-{ci:02d}", "title": f"第{ci}章",
                         "summary": "本章基于现有资料展开。", "sections": sections,
                         "evidence_ids": ["R1"]})
    return report, ChapterResult.model_validate({
        "run_id": "C1", "subject": "测试行业", "as_of": "2026-09-01",
        "status": "completed", "chapters": chapters,
    })


def test_editorial_diff_reports_edit_patch_isolate_without_body_or_evidence():
    _, source = _inputs()
    from report_fusion.models import ParagraphDraft
    source.chapters[0].sections[0].paragraphs.append(ParagraphDraft(
        paragraph_id="P-ISOLATED", text="将被隔离的正文。", evidence_ids=["R1"]))
    final = source.model_copy(deep=True)
    final.chapters[0].summary = "修订后的章节摘要。"
    final.chapters[0].sections[0].paragraphs[0].text = "修订后的正文。"
    final.chapters[0].sections[0].paragraphs.pop(1)
    final.chapters[0].content_audit = [{
        "code": "fusion_claim_isolation", "location": "P-ISOLATED",
        "section_id": "SEC-01-01", "disposition": "isolated",
        "original": "不可复制到摘要中的正文。", "evidence_ids": ["R1"],
    }]
    # 结构性补写段（A5 可能生成过渡段）；只记录位置与原因。
    final.chapters[0].sections[0].paragraphs.append(ParagraphDraft(
        paragraph_id="TRANS-CH-01", kind="transition", text="过渡文字不应进入摘要。", evidence_ids=[]))

    changes = _build_editorial_changes(source.chapters, final.chapters)
    payload = [item.model_dump(mode="json") for item in changes]
    kinds = {item["change_type"] for item in payload}
    reasons = " ".join(item["reason"] for item in payload)
    assert {"edit", "patch", "isolate"}.issubset(kinds)
    assert any(item["paragraph_id"] == "P-1-1" for item in payload)
    assert any(item["paragraph_id"] == "P-ISOLATED" and "审计隔离" in item["reason"] for item in payload)
    assert any(item["paragraph_id"] == "TRANS-CH-01" and item["change_type"] == "patch" for item in payload)
    serialized = json.dumps(payload, ensure_ascii=False)
    assert "修订后的正文" not in serialized
    assert "不可复制到摘要中的正文" not in serialized
    assert "过渡文字不应进入摘要" not in serialized
    assert "R1" not in serialized


def test_unchanged_chapters_produce_no_fake_editorial_changes():
    _, source = _inputs()
    assert _build_editorial_changes(source.chapters, source.model_copy(deep=True).chapters) == []


def test_a4_file_is_read_only_and_isolate_is_summarized(tmp_path):
    report, chapters = _inputs()
    chapters.quality = {"passed": False, "issues": ["段落资料缺口：P-01-01 已被上游移除"]}
    chapters.warnings = ["段落资料缺口：P-01-01 已被上游移除"]
    chapters.chapters[0].sections[0].paragraphs[0].text = "市场规模为999亿元。"
    chapter_file = tmp_path / "chapter_result.json"
    chapter_file.write_text(chapters.model_dump_json(indent=2), encoding="utf-8")
    original_bytes = chapter_file.read_bytes()

    result = asyncio.run(ReportFusionAgent(settings=Settings(output_dir=tmp_path)).run(
        ReportFusionRequest(
            report=report, chapters=chapters,
            options=FusionOptions(enable_editorial_llm=False, formats=["markdown"]),
        )
    ))
    assert chapter_file.read_bytes() == original_bytes
    assert chapters.chapters[0].sections[0].paragraphs[0].text == "市场规模为999亿元。"

    view = json.loads((Path(result.artifact_dir) / "report_view.json").read_text())
    assert view["editorial_changes"]
    assert any(item["change_type"] == "isolate" for item in view["editorial_changes"])
    assert "999" not in json.dumps(view["editorial_changes"], ensure_ascii=False)
    assert any("段落资料缺口" in warning for warning in view["warnings"])
    # 旧融合视图缺少 editorial_changes 时仍可解析，不得要求旧任务重跑。
    old = dict(view)
    old.pop("editorial_changes", None)
    assert ReportViewModel.model_validate(old).editorial_changes == []
