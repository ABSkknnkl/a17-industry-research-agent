from __future__ import annotations
from agents_core.call_ledger import apply_thinking_params, model_call, tracked_post

import json
from typing import Any, Protocol

import httpx

from chapter_writer.config import Settings


import asyncio
import logging
import re

logger = logging.getLogger(__name__)


def clean_and_parse_json(content: Any) -> dict[str, Any]:
    if isinstance(content, dict):
        return content
    if not isinstance(content, str):
        raise ValueError(f"LLM response must be string or dict, got {type(content).__name__}")

    text = content.strip()
    if not text:
        raise ValueError("LLM response content is empty")
    text = re.sub(r"<think>[\s\S]*?</think>", "", text).strip()

    if text.startswith("```"):
        lines = text.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].startswith("```"):
            lines = lines[:-1]
        text = "\n".join(lines).strip()

    try:
        parsed = json.loads(text)
        if isinstance(parsed, dict):
            return parsed
    except json.JSONDecodeError:
        pass

    match = re.search(r"\{[\s\S]*\}", text)
    if match:
        candidate = match.group(0)
        try:
            parsed = json.loads(candidate)
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            pass

        # 启发式自愈：修复字符串内部未转义的独立双引号（如 "summary": "xxx政策转"放量发展"阶段xxx"）
        try:
            healed = re.sub(r'(?<![:,\{\[\s])"(?![:,\}\]\s\n\r])', '”', candidate)
            parsed = json.loads(healed)
            if isinstance(parsed, dict):
                return parsed
        except Exception:
            pass

    raise ValueError("Failed to parse LLM response as JSON object")


class ChapterLLM(Protocol):
    @property
    def is_available(self) -> bool: ...
    async def generate_json(self, system: str, user: str) -> dict[str, Any]: ...
    async def plan_skills_with_tools(
        self, system: str, user: str, tools: list[dict[str, Any]]
    ) -> list[dict[str, str]]: ...


class OpenAICompatibleLLM:
    def __init__(self, settings: Settings):
        self.settings = settings
        self._client: httpx.AsyncClient | None = None

    @property
    def is_available(self) -> bool:
        return bool(self.settings.llm_api_key and self.settings.llm_model)

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            timeout = httpx.Timeout(
                self.settings.llm_timeout_seconds,
                connect=30.0,
                read=self.settings.llm_timeout_seconds,
            )
            limits = httpx.Limits(
                max_keepalive_connections=20,
                max_connections=20,
                keepalive_expiry=30.0,
            )
            self._client = httpx.AsyncClient(timeout=timeout, limits=limits)
        return self._client

    async def aclose(self) -> None:
        if self._client is not None and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> "OpenAICompatibleLLM":
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.aclose()

    @model_call
    async def plan_skills_with_tools(
        self,
        system: str,
        user: str,
        tools: list[dict[str, Any]],
    ) -> list[dict[str, str]]:
        if not self.is_available:
            raise RuntimeError("planning skills requires LLM_API_KEY and LLM_MODEL")

        payload: dict[str, Any] = {
            "model": self.settings.llm_model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "tools": tools,
            "tool_choice": "auto",
            "max_tokens": self.settings.llm_max_tokens,
        }
        # 2026-10-17：默认关闭思考（LLM_THINKING=disabled）。该端点开启思考时
        # 同等任务实测 10.4s→5.8s（关闭后），长任务差距更大。thinking 优先，
        # 未配置时才回退 reasoning_effort，避免两个参数互相打架。
        apply_thinking_params(payload, model=self.settings.llm_model,
                thinking=self.settings.llm_thinking,
                reasoning_effort=self.settings.llm_reasoning_effort)

        choice: dict[str, Any] = {}
        for attempt in range(3):
            client = self._get_client()
            try:
                response = await tracked_post(client, 
                    f"{self.settings.llm_base_url}/chat/completions",
                    headers={"Authorization": f"Bearer {self.settings.llm_api_key}"},
                    json=payload,
                )
                response.raise_for_status()
                choice = response.json()["choices"][0]["message"]
                break
            except Exception as e:
                if isinstance(e, httpx.HTTPStatusError) and 400 <= e.response.status_code < 500 and e.response.status_code != 429:
                    raise
                err_msg = type(e).__name__
                if attempt < 2:
                    logger.warning("plan_skills attempt %d failed (%s), retrying...", attempt + 1, err_msg)
                    if isinstance(e, (httpx.TimeoutException, httpx.HTTPError)):
                        try:
                            await client.aclose()
                        except Exception:
                            pass
                        self._client = None
                    await asyncio.sleep(1.5 * (attempt + 1))
                else:
                    raise

        planned: list[dict[str, str]] = []
        tool_calls = choice.get("tool_calls") or []
        if tool_calls:
            for tc in tool_calls:
                fn = tc.get("function", {})
                try:
                    args = clean_and_parse_json(fn.get("arguments", "{}"))
                except Exception:
                    args = {}
                sname = args.get("skill_name", "")
                reason = args.get("reason", "")
                if sname:
                    planned.append({"skill_name": sname, "reason": reason})
        else:
            content = choice.get("content", "")
            try:
                parsed = clean_and_parse_json(content)
                if isinstance(parsed, dict) and "skills" in parsed:
                    for item in parsed["skills"]:
                        if isinstance(item, dict) and "skill_name" in item:
                            planned.append({
                                "skill_name": item["skill_name"],
                                "reason": item.get("reason", ""),
                            })
                        elif isinstance(item, str):
                            planned.append({"skill_name": item, "reason": "模型自主调用"})
            except Exception:
                pass

        return planned

    @model_call
    async def generate_json(self, system: str, user: str) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": self.settings.llm_model,
            "temperature": 0.2,
            "max_tokens": self.settings.llm_max_tokens,
            "response_format": {"type": "json_object"},
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
        }
        # 2026-10-17：默认关闭思考（LLM_THINKING=disabled）。该端点开启思考时
        # 同等任务实测 10.4s→5.8s（关闭后），长任务差距更大。thinking 优先，
        # 未配置时才回退 reasoning_effort，避免两个参数互相打架。
        apply_thinking_params(payload, model=self.settings.llm_model,
                thinking=self.settings.llm_thinking,
                reasoning_effort=self.settings.llm_reasoning_effort)

        last_err: Exception | None = None
        for attempt in range(3):
            client = self._get_client()
            try:
                response = await tracked_post(client, 
                    f"{self.settings.llm_base_url}/chat/completions",
                    headers={"Authorization": f"Bearer {self.settings.llm_api_key}"},
                    json=payload,
                )
                response.raise_for_status()
                content = response.json()["choices"][0]["message"].get("content", "")
                return clean_and_parse_json(content)
            except Exception as e:
                last_err = e
                if isinstance(e, httpx.HTTPStatusError) and 400 <= e.response.status_code < 500 and e.response.status_code != 429:
                    raise
                err_msg = type(e).__name__
                if attempt < 2:
                    logger.warning("chapter generate_json attempt %d failed (%s), retrying...", attempt + 1, err_msg)
                    if isinstance(e, (httpx.TimeoutException, httpx.HTTPError)):
                        try:
                            await client.aclose()
                        except Exception:
                            pass
                    import secrets
                    jitter = 0.8 + (secrets.randbelow(40) / 100.0)
                    sleep_time = (2.0 ** attempt) * 2.0 * jitter
                    await asyncio.sleep(sleep_time)
                else:
                    raise last_err

