"""Bounded generate-audit-repair chapter writing agent."""

from __future__ import annotations

import os
import re
import re

from agents_core.financial_semantics import (
    CLAIM_METRICS,
    QUANTITY_RE,
    _sample_names,
    _tier_names,
    aggregate_component_ids,
    measurement_period,
    mask_chart_references,
    metric_family,
    quantity_issues,
    retain_supported_claims,
    verified_calculations,
)
from agents_core.context_budget import ContextBudgetExceeded, serialize_context


# ── 证据值的呈现变体（2026-11-09 审计 P0-1）─────────────────────────────────
# 数据集按元存长数字（39659744191.36），正文按亿元带千分位写（39,659.74亿元）。
# 旧 R3 只做「值字符串原样子串匹配」，金额类证据永远绑不上，数值语义校验
# 对全部金额产生假阳性（SEMI-Q1 实测 277 条「无据」中真无出处≈0）。
_REMOVAL_ENTRY = re.compile(r"(P-[\w-]+)\s*因质量问题被整段移除(?:（([^）]*)）)?")


def _substantive_removal_ids(gap_text: str) -> list[str]:
    """「段落资料缺口」里算实质内容损失的段落 id（B23-T10）。

    排除原因**只有**「与其他段落重复」的条目——去重不是内容损失。
    """
    lost: list[str] = []
    for pid, reason in _REMOVAL_ENTRY.findall(str(gap_text or "")):
        reasons = [r for r in re.split(r"[、,，]", reason or "") if r.strip()]
        if reasons and all("重复" in r for r in reasons):
            continue
        lost.append(pid)
    return lost


def _issue_kind(message: str) -> str:
    """从段落报错里抽「问题类别」，用于移除留痕时的摘要（B23-T1）。

    输入形如 "P-01-01-01 数值语义未通过：20%（需同实体…）"；
    输出 "数值语义未通过"——保留诊断类型，不带已失效的具体数值。
    """
    text = str(message or "").strip()
    text = re.sub(r"^P-[\w-]+\s+", "", text)
    for sep in ("：", ":", "（", "("):
        idx = text.find(sep)
        if idx > 0:
            text = text[:idx]
            break
    return text.strip()


def magnitude_variants(value: Any, unit: str | None = None) -> list[str]:
    try:
        v = float(str(value).replace(",", ""))
    except (TypeError, ValueError):
        return []
    u = str(unit or "").strip()
    # 百分比/倍数/个百分点等比率类：字面值已足够，补千分位与不同精度写法。
    # B29：必须覆盖 1 位与整数写法——模型写卡常按「17.8倍」「48%」舍入，
    # 只给 2/4 位时这些卡永远匹配不上，会被当成「缺证据绑定」整卡隔离
    # （实测 CH-03 8/10 张被删）。舍入不是错值，最终仍由 quantity_issues
    # 按容差独立复核（17.8✅ 18✅ 17.6❌）。
    if u in ("%", "％", "倍", "个百分点", "‰") or not u:
        if not (v == v and abs(v) < 1e15):
            return []
        return [f"{v:,.4f}", f"{v:,.2f}", f"{v:,.1f}", f"{v:,.0f}"]
    scales = {"元": 1.0, "万元": 1e-4, "亿元": 1e-8, "万亿元": 1e-12}
    base = scales.get(u)
    if base is None:  # 未知单位，不猜
        return []
    outs: list[str] = []
    for target, factor in (("万亿元", 1e-12), ("亿元", 1e-8), ("万元", 1e-4), ("元", 1.0)):
        x = v * factor
        if 0.01 <= abs(x) < 1e5:
            for dec in (2, 1, 0):
                s = f"{x:.{dec}f}{target}"
                outs.append(s)
                outs.append(f"{x:,.{dec}f}{target}")
    return outs


def _evidence_index_dicts(index: Any) -> dict[str, dict]:
    """把报告证据索引统一成 {id: dict}，供指标卡跨章绑定使用。"""
    out: dict[str, dict] = {}
    for key, value in (index or {}).items():
        if hasattr(value, "model_dump"):
            out[key] = value.model_dump(mode="json")
        elif isinstance(value, dict):
            out[key] = dict(value)
    return out


def _remediation_claims_supported(text: str, refs: list[str], evidence: dict[str, dict]) -> bool:
    """Accept exact source statements or a narrowly structured numerical observation."""
    def clauses(value: str) -> list[str]:
        return [re.sub(r"\s+", "", part).strip("。！？.!?；;，,") for part in
                re.split(r"[。！？!?；;，,]|(?<!\d)\.(?!\d)", value) if part.strip()]

    claims = clauses(text)
    if not claims:
        return False
    aliases = {"revenue": ("营业收入", "营业总收入", "营收"),
               "parent_net_profit": ("归母净利润", "归属于母公司净利润"),
               "net_profit": ("净利润",), "gross_margin": ("毛利率",)}
    for claim in claims:
        supported = False
        for ref in refs:
            record = evidence[ref]
            raw = record.get("raw_fields") or {}
            quotes = [record.get("value"), record.get("text"), record.get("excerpt"),
                      raw.get("literal_excerpt") if isinstance(raw, dict) else None]
            if any(claim in clauses(value) for value in quotes if isinstance(value, str)):
                supported = True
                break
            entity = str(record.get("entity") or record.get("entity_name") or "").strip()
            period = str(record.get("period") or record.get("period_end") or "")
            year = re.match(r"(20\d{2})", period)
            unit = str(record.get("unit") or "").strip()
            value = record.get("value")
            family = metric_family(str(record.get("metric") or ""))
            names = aliases.get(family, ())
            if entity and year and unit and isinstance(value, (int, float)) and not isinstance(value, bool) and names:
                number = str(value)
                if number.endswith(".0"):
                    number = number[:-2]
                pattern = (re.escape(entity) + r"(?:于)?" + year.group(1) + r"年(?:的)?(?:合并报表)?(?:"
                           + "|".join(map(re.escape, names)) + r")(?:为|是|达到)?" + re.escape(number) + re.escape(unit))
                if re.fullmatch(pattern, claim):
                    supported = True
                    break
        if not supported:
            return False
    return True


_AGGREGATE_CARD_MARK = re.compile(r"样本|梯队|合计|中位数|中枢|区间")


def _bind_aggregate_metric_card(
    label: str,
    value: str,
    unit: str | None,
    period: str | None,
    evidence_pool: dict[str, dict],
    financial_ratios: list[dict] | None,
) -> list[str]:
    """聚合卡绑定（B32-D4）：样本合计/中位数 → 绑到子集全部输入记录。

    「4 家样本总市值 1000 亿元」的值不在任何单条记录里，而在样本子集
    （financial_ratios 的 4 家）的求和里。核验走 quantity_issues 的
    sample_universe 通道（B32 审计侧已实现），命中后返回子集的全部
    record_id——读者可逐条回溯，而不是绑一个看不见的合计值。

    只对 label 含「样本/梯队/合计/中位数」的卡启用，避免普通卡误走。
    按指标族逐个尝试：族的 canonical 名与 label 的关键词（总市值/PB/PE…）
    由 metric_family 各自解析，不要求字面一致。
    """
    if not financial_ratios or not _AGGREGATE_CARD_MARK.search(str(label or "")):
        return []
    claim = f"{label}：{value}{unit or ''}".strip()
    if period and str(period).strip():
        claim = f"{claim}（{str(period).strip()}）"
    # 绑定范围与核验范围一致：命中梯队用梯队子集，否则用全样本。
    matched_tier = next(
        (t for t in {str(r.get("valuation_tier") or "").strip()
                     for r in financial_ratios if isinstance(r, dict)}
         if t and t in claim),
        None,
    )
    scope = _tier_names(financial_ratios, matched_tier) if matched_tier else _sample_names(financial_ratios)
    by_family: dict[str, list[dict]] = {}
    for rec in evidence_pool.values():
        if not isinstance(rec, dict):
            continue
        fam = metric_family(str(rec.get("metric") or ""))
        if not fam:
            continue
        by_family.setdefault(fam, []).append(rec)
    for _fam, recs in sorted(by_family.items()):
        if quantity_issues(claim, recs, universe=list(evidence_pool.values()),
                           sample_universe=financial_ratios):
            continue
        return [str(r.get("record_id")) for r in recs
                if isinstance(r, dict) and r.get("record_id")
                and str(r.get("entity") or "") in scope]
    return []


def _bind_derived_metric_card(
    label: str,
    value: str,
    unit: str | None,
    derived: list[dict] | None,
) -> list[str]:
    """派生值卡片绑定（B31）：命中后返回计算的**输入记录 id**。

    `verified_calculations` 产出的记录 id 形如
    `derived:R-ocf/R-np`——伪 id 不能写进交付件，读者回溯不到；
    这里换成它依赖的两条真证据。核验仍走 `_bind_metric_card` 的
    quantity_issues 复核，错值与主体不符照样绑不上。
    """
    pool = {str(d.get("record_id")): d for d in (derived or []) if d.get("record_id")}
    if not pool:
        return []
    hits = _bind_metric_card(label, value, unit, pool, set(pool), _evidence_variants_cache(pool))
    ids: list[str] = []
    for rid in hits:
        for part in str(rid).removeprefix("derived:").split("/"):
            if part and part not in ids:
                ids.append(part)
    return ids


def _evidence_variants_cache(evidence_dict: dict[str, dict]) -> dict[str, list[str]]:
    cache = evidence_dict.get("_magnitude_variants")
    if not isinstance(cache, dict):
        cache = {}
        for eid, rec in evidence_dict.items():
            cache[eid] = magnitude_variants(rec.get("value"), rec.get("unit"))
        evidence_dict["_magnitude_variants"] = cache
    return cache


def _bind_metric_card(
    label: str,
    value: str,
    unit: str | None,
    evidence_dict: dict[str, dict],
    allowed: set[str],
    variants_cache: dict[str, list[str]],
) -> list[str]:
    """指标卡量级绑定（P0-1 残余①，2026-11-10）。

    卡片 value 常写「3,965.97亿元」而证据按元存长数字，旧逻辑只看
    evidence_ids 是否非空，模型没显式绑定就一律记缺陷（审计实测指标卡
    是「部分降级」的主要残余来源）。这里按段落同款量级变体匹配候选
    证据，再合成「label：value」文本交给 quantity_issues 独立复核
    实体/期间/指标族/容差——复核不过不绑定，缺陷照记，错值卡片不能
    靠变体蒙混过关。
    """
    display = f"{value}{unit or ''}".strip()
    if not display:
        return []
    text = f"{label}：{display}" if str(label or "").strip() else display
    bound: list[str] = []
    for eid, rec in evidence_dict.items():
        if eid not in allowed or eid == "_magnitude_variants":
            continue
        val_str = str(rec.get("value", "")).strip()
        hit = bool(val_str and len(val_str) >= 2 and val_str in display)
        if not hit:
            hit = any(v and v in display for v in variants_cache.get(eid, ()))
        if not hit:
            continue
        entity_str = str(rec.get("entity") or rec.get("entity_name") or "").strip()
        # 实体一致性收紧：证据带实体名而卡片 label 里没有它时，不绑定
        # （value 相撞但主体不同的卡片不能借量级变体冒领证据）。
        if entity_str and str(label or "") and entity_str not in str(label):
            continue
        try:
            issues = quantity_issues(text, [rec])
        except Exception:
            continue
        if any(item.get("code") == "unsupported_quantity" for item in issues):
            continue
        bound.append(eid)
    return bound

import asyncio
import httpx
from collections.abc import Awaitable, Callable
from datetime import datetime
import json
from pathlib import Path
import re
import secrets
from typing import Any


from chapter_writer.config import Settings
from chapter_writer.llm import ChapterLLM, OpenAICompatibleLLM
from chapter_writer.net_cash_ratio import (
    apply_net_cash_ratio_guard,
    build_net_cash_ratio_policy,
)
from chapter_writer.models import (
    AppliedSkill, ChapterDraft, ChapterQualityReport, ChapterWritingRequest, ChapterWritingResult,
    ParagraphDraft, SectionDraft,
)
from chapter_writer.outline import DEFAULT_OUTLINE, OUTLINE_VERSION
from chapter_writer.retriever import DynamicEvidenceRetriever
from chapter_writer.skillhub import WritingSkill, WritingSkillHub

try:
    from skill_policy import merge_selection
except ModuleNotFoundError:  # 单包测试或独立运行时 agents_core 不在搜索路径上，按包位置回推
    import sys as _sys

    _sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    from skill_policy import merge_selection

from skill_policy.requests import resolve_requested_skills

EventEmitter=Callable[[dict[str,Any]],Awaitable[None]]

def prepare_chapter_context(payload: dict[str, Any], system: str) -> tuple[str, dict[str, Any]]:
    """Drop duplicated and optional chapter context; never truncate required evidence."""
    packet = dict(payload)
    context = dict(packet.get('context') or {})
    packet['context'] = context
    omitted = []
    for key in ('global_facts', 'global_facts_prompt'):
        if key in context:
            context.pop(key)
            omitted.append('context.' + key)
    details = {'omitted_sections': omitted}
    packet['context_packing'] = details
    for key in ('assignment_hints', 'primary_requirements', 'requirement_evidence_matrix.details', 'comps_matrix', 'financial_ratios', 'industry_chain_segments', 'findings', 'outline_hints', 'insights', None):
        try:
            text, size, budget = serialize_context(packet, system=system)
            details.update(bytes=size, budget_bytes=budget)
            text, size, budget = serialize_context(packet, system=system)
            details.update(bytes=size, budget_bytes=budget)
            return text, details
        except ContextBudgetExceeded:
            if key is None:
                raise
            if key == 'requirement_evidence_matrix.details':
                matrix = context.get('requirement_evidence_matrix')
                if isinstance(matrix, list):
                    compacted = []
                    for row in matrix:
                        if not isinstance(row, dict):
                            continue
                        requirement, coverage = row.get('requirement') or {}, row.get('coverage') or {}
                        req_fields = ('requirement_id','label','domain','hard','min_records','expected_metric_groups',
                                      'requires_entity_code','requires_period_end','requires_published_at',
                                      'acceptable_skill_ids','entity_names','period_ends','metric_families')
                        cov_fields = ('requirement_id','label','domain','hard','passed','evidence_count','evidence_record_ids','missing')
                        compacted.append({'requirement':{k:requirement[k] for k in req_fields if k in requirement},
                                          'coverage':{k:coverage[k] for k in cov_fields if k in coverage}})
                    if compacted != matrix:
                        context['requirement_evidence_matrix'] = compacted
                        omitted.append('context.requirement_evidence_matrix.details')
                continue
            if context.get(key):
                context[key] = None if isinstance(context[key], dict) else []
                omitted.append('context.' + key)
    raise AssertionError('unreachable')

NUMBER_RE=re.compile(r"(?<![A-Za-z0-9_-])[-+]?\d+(?:\.\d+)?%?")
YEAR_OR_ORDINAL_RE=re.compile(r"^(?:19\d\d|20\d\d|[1-9]|10)$")

# 审计隔离后，只保留图表占位符而无论述的段落会被改写为显式缺口句。
# 该标记用于豁免段落去重检查（不同小节可以出现相同的缺口说明）。
GAP_NOTICE_MARK = "本项量化解读未通过证据核验"

_CHART_TAG_RE = re.compile(r"\[[^\]]*\]")
_CHART_BODY_NOISE_RE = re.compile(r"[，,。；;、：:！!？?\s]")
_CHART_LEAD_RE = re.compile(r"如图\s*所示[，,]\s*")

# 图表对齐用的指标别名。主仓 CLAIM_METRICS 不含这些行业量纲词，缺它们会让
# 「销量/渗透率」类图表永远匹配不到正文指标族。行业扩展时在此追加。
CHART_ALIGN_METRIC_ALIASES: dict[str, str] = {
    "销量": "nev_sales", "出口量": "nev_exports", "出口": "nev_exports",
    "渗透率": "nev_penetration",
}

_CC_PERIOD_RE = re.compile(
    r"(20\d{2}\s*年(?:\s*(?:全年|年度|上半年|前三季度|第[一二三四1-4]季度|一季度|二季度|三季度|四季度))?"
    r"|全年|年度|上半年|前三季度|当季|单季)"
)
_CC_SCOPE_RE = re.compile(
    r"(中国市场|国内市场|全球市场|海外市场|行业整体|合并口径|母公司口径|中国|国内|全球|海外|行业)"
)
_CC_CLAUSE_RE = re.compile(r"[。；;\n！？!?]")
_CC_METRIC_BOUNDARY = "，,；;：:（("
_CC_ENTITY_RE = re.compile(
    r"[\u4e00-\u9fff]{2,10}(?:时代|汽车|锂能|股份|集团|科技|能源|电子|半导体|材料|电池|控股|电气|重工|工业|装备|新能源|有限公司)"
)


def paragraph_body(text: str) -> str:
    """去掉图表占位符与格式标点后，段落的实际论述部分。"""
    body = _CHART_TAG_RE.sub("", text or "")
    body = body.replace("如图", "").replace("所示", "")
    return _CHART_BODY_NOISE_RE.sub("", body)


def has_chart_discussion(text: str) -> bool:
    """段落是否有可挂图的论述；显式缺口句属于已隔离正文，不算解读。"""
    body = paragraph_body(text)
    return bool(body) and GAP_NOTICE_MARK not in body


def strip_chart_tag(text: str, chart_id: str) -> str:
    """移除未就绪图表的图号，并清掉只为该图号存在的「如图…所示」引子。"""
    cleaned = (text or "").replace(f"[{chart_id}]", "")
    cleaned = _CHART_LEAD_RE.sub("", cleaned)
    return cleaned.strip()


def chart_section_score(section: Any, chart_evidence: set[str]) -> tuple:
    """优先选择已有对齐解读的 chart_readout 小节，其次有正文且证据重叠的小节。"""
    discussion = [p for p in section.paragraphs if has_chart_discussion(p.text)]
    readouts = [p for p in discussion if p.kind == "chart_readout"]
    aligned = [p for p in readouts if chart_evidence & set(p.evidence_ids)]
    section_evidence = {e for p in section.paragraphs for e in p.evidence_ids}
    return (bool(aligned), bool(chart_evidence & section_evidence), bool(readouts), bool(discussion),
            len(chart_evidence & section_evidence))


def _align_chart_reference(section: Any, chart_id: str, chart: Any) -> bool:
    """把图号挂到「证据相交且指标族对得上」的段落；挂不上就剥离并写缺口。"""
    evidence_ids = set(chart.get("evidence_ids", []) if isinstance(chart, dict) else chart.evidence_ids)
    contract = (chart.get("data_contract") if isinstance(chart, dict) else getattr(chart, "data_contract", {})) or {}
    points = contract.get("points") or []
    families = {metric_family(str(point.get("metric") or "")) for point in points}
    metric_terms = {**CLAIM_METRICS, **CHART_ALIGN_METRIC_ALIASES}
    tag = f"[{chart_id}]"
    matched = []
    for paragraph in section.paragraphs:
        if not has_chart_discussion(paragraph.text):
            continue
        first_sentence = re.split(r"[。；;！？!?]", _CHART_TAG_RE.sub("", paragraph.text), maxsplit=1)[0].casefold()
        # 自动挂图会把图号放在段首论断上，因此既有引用与新增引用用同一套局部判定。
        lead = re.split(r"限制|上述|仍需|尚需", first_sentence, maxsplit=1)[0]
        mentions = {family for term, family in metric_terms.items() if term.casefold() in lead}
        if (not evidence_ids or evidence_ids.intersection(paragraph.evidence_ids)) and (
            not families or families.intersection(mentions)
        ):
            matched.append(paragraph)
        elif tag in paragraph.text:
            paragraph.text = strip_chart_tag(paragraph.text, chart_id)
    if not matched:
        note = f"{chart_id} 暂无与图表证据对应的正文解读。"
        if note not in section.uncertainties:
            section.uncertainties.append(note)
        return any(has_chart_discussion(p.text) for p in section.paragraphs)
    if not any(tag in paragraph.text for paragraph in matched):
        target = next((paragraph for paragraph in matched if paragraph.kind == "chart_readout"), matched[0])
        target.text = f"如图 {tag} 所示，{target.text}"
    note = f"{chart_id} 暂无与图表证据对应的正文解读。"
    section.uncertainties = [item for item in section.uncertainties if item != note]
    return True


def drop_chart_tag_from_section(section: Any, chart_id: str) -> None:
    """移除本小节里不再合法的图号；只剩引子时写成显式缺口句，不造空段。"""
    for para in section.paragraphs:
        if f"[{chart_id}]" not in (para.text or ""):
            continue
        cleaned = strip_chart_tag(para.text, chart_id)
        para.text = cleaned or (
            f"关于「{section.title}」，{GAP_NOTICE_MARK}；"
            "相关图表引用已移除，待补充可核验解读。"
        )


def _claim_entity(text: str, start: int, refs: list[Any]) -> str:
    """优先用段落证据的实体名绑定数值；没有证据时退回公司名后缀识别。"""
    candidates: list[tuple[int, str]] = []
    for ref in refs:
        if hasattr(ref, "model_dump"):
            ref = ref.model_dump(mode="json")
        if not isinstance(ref, dict):
            continue
        name = str(ref.get("entity") or ref.get("entity_name") or "")
        if not name:
            continue
        for match in re.finditer(re.escape(name), text):
            if match.start() < start:
                candidates.append((match.start(), name))
    if candidates:
        return max(candidates)[1]
    matches = [m for m in _CC_ENTITY_RE.finditer(text) if m.start() < start]
    return matches[-1].group(0) if matches else ""


def _nearest_metric(text: str, number_start: int) -> tuple[str, str] | None:
    """把数值绑定到同一子句内紧邻的指标，避免把别家公司的数字配给前文指标。"""
    boundary = max((text.rfind(ch, 0, number_start) for ch in _CC_METRIC_BOUNDARY), default=-1) + 1
    window = text[boundary:number_start]
    terms = [(window.rfind(term), term) for term in CLAIM_METRICS if term in window]
    if not terms:
        return None
    position, term = max(terms)
    gap = len(window) - (position + len(term))
    if gap > 8:
        return None
    return term, CLAIM_METRICS[term]


def _cross_chapter_claim_audit(
    chapters: list[ChapterDraft], evidence: dict[str, Any] | None = None
) -> list[dict[str, Any]]:
    """标记跨章同键但数值互斥的结论。

    只记录、不改写正文。期间/范围/单位不同的数值属于不同键，永不判为冲突；
    最多记录两条，避免同一批矛盾把审计刷爆。
    """
    rows = []
    for chapter in chapters:
        for section in chapter.sections:
            for paragraph in section.paragraphs:
                refs = [
                    evidence[rid] for rid in paragraph.evidence_ids
                    if evidence and rid in evidence
                ]
                for sentence in _CC_CLAUSE_RE.split(paragraph.text):
                    text = sentence.strip()
                    if not text:
                        continue
                    period_match = _CC_PERIOD_RE.search(text)
                    scope_match = _CC_SCOPE_RE.search(text)
                    for match in QUANTITY_RE.finditer(text):
                        unit = match.group(2)
                        if not unit:
                            continue
                        metric = _nearest_metric(text, match.start())
                        if metric is None:
                            continue
                        term, family = metric
                        entity = _claim_entity(text, match.start(), refs)
                        raw = match.group(1).replace(",", "").replace("−", "-")
                        try:
                            value = float(raw)
                        except ValueError:
                            continue
                        unit = "%" if unit in ("%", "％") else unit
                        decimals = len(raw.split(".", 1)[1]) if "." in raw else 0
                        rows.append({
                            "family": family, "metric": term, "entity": entity,
                            "value": value, "unit": unit, "decimals": decimals,
                            "period": re.sub(r"\s+", "", period_match.group(1)) if period_match else "",
                            "scope": scope_match.group(1) if scope_match else "",
                            "chapter_id": chapter.chapter_id, "section_id": section.section_id,
                            "paragraph_id": paragraph.paragraph_id, "text": text,
                        })
    by_key: dict[tuple[str, str, str, str, str], list[dict[str, Any]]] = {}
    for row in rows:
        by_key.setdefault(
            (row["family"], row["entity"], row["period"], row["scope"], row["unit"]),
            [],
        ).append(row)
    conflicts = []
    for key, group in by_key.items():
        pair = None
        for i, left in enumerate(group):
            for right in group[i + 1:]:
                if left["chapter_id"] == right["chapter_id"]:
                    continue
                tolerance = 0.5 * 10 ** (-min(left["decimals"], right["decimals"]))
                if abs(left["value"] - right["value"]) > tolerance:
                    pair = (left, right)
                    break
            if pair:
                break
        if not pair:
            continue
        left, right = pair
        claim = (
            f"{left['entity'] + ' ' if left['entity'] else ''}{left['metric']}"
            f"（{left['period'] or '未标注期间'}／{left['scope'] or '未标注范围'}）"
            f"{left['chapter_id']} 为 {left['value']:g}{left['unit']}，"
            f"{right['chapter_id']} 为 {right['value']:g}{right['unit']}"
        )
        conflicts.append({
            "code": "cross_chapter_claim_conflict",
            "location": f"{left['section_id']}/{right['section_id']}",
            "section_id": left["section_id"],
            "claim": claim,
            "disposition": "flagged",
            "chapter_ids": [left["chapter_id"], right["chapter_id"]],
            "paragraph_ids": [left["paragraph_id"], right["paragraph_id"]],
        })
        for chapter in chapters:
            if chapter.chapter_id in (left["chapter_id"], right["chapter_id"]):
                entry = dict(conflicts[-1])
                if not any(
                    existing.get("code") == entry["code"]
                    and existing.get("claim") == entry["claim"]
                    and existing.get("location") == entry["location"]
                    for existing in chapter.content_audit
                ):
                    chapter.content_audit.append(entry)
        if len(conflicts) >= 2:
            break
    return conflicts

# 单章写作规范的默认预算；强制规范与用户显式选择优先保留。
CHAPTER_SKILL_LIMIT = 10

_NARRATIVE_KINDS = {"analysis", "thesis", "comparison", "chart_readout"}
_READOUT = re.compile(
    r"从.{0,32}(?:到|至).{0,32}(?:上升|下降|持平|回落|提高|扩大|收窄)"
    r"|由于|归因于|不能据此|仅能|不足以判断|仍需核对|仍需结合|无法判断"
)


def _lists_numbers(paragraph: ParagraphDraft) -> bool:
    if paragraph.kind not in _NARRATIVE_KINDS or not paragraph.evidence_ids or _READOUT.search(paragraph.text):
        return False
    clauses = [part.strip() for part in re.split(r"[。；;！!？?\n]", paragraph.text) if part.strip()]
    counts = [sum(bool(unit) for _, unit in QUANTITY_RE.findall(part)) for part in clauses]
    return bool(counts and all(counts) and sum(counts) >= 2)

SYSTEM_PROMPT="""你是机构级证券与行业研究报告章节写作智能体。你必须将内容组织成可直接供前端/PDF排版的结构化组件，而不是连续长文章。
严格要求：
1. 只使用输入 context 中的 evidence、insights、findings、comps_matrix、financial_ratios、industry_chain_segments 和 charts 信息，严禁捏造事实和数字。研发比率以 `evidence` 和图表中的年度点为准，正文和表头写明「研发费用率」或「研发投入占营收比例」，避免混用含糊的「研发强度」。`financial_ratios` 仅是最新一期摘要，不得把它未列出的年份写成缺失。
   数据缺口叙述必须与 context.coverage_truth 一致：coverage.passed=true 的需求严禁写成「未通过」「未取得」「证据库未提供」；真实限制只能依据 coverage_truth 的 missing 字段与 evidence_count 描述（如「年度序列仅 N 期」）。
2. 写作风格采用“断言主旨驱动 (Thesis-Driven)”：
   - 先回答本节问题，再选支撑判断的关键数字。把明细、平行指标和重复读数留给表格或指标卡；`key_points` 与摘要只保留读者需要记住的结论。
   - 每段只承担一个判断：给出证据对应的主体、期间和口径，然后说明变化、差异或业务含义。同一段的核心数字共用一次解读，无需逐个数字补一句归因。
   - 有同口径对照时解释方向和差异。有直接披露时注明谁披露了什么，才写成因。只有单期数字时交代该数字能回答什么；若要继续解释，指出具体还缺哪项数据。避免“值得关注”“总体向好”等空句。
   - 摘要概括本章最重要的判断，篇幅随证据和问题决定；无需为了凑字增加背景或重复结论。
3. `kind` 必须选用受控枚举：
   - `thesis`：本节核心判断与影响；
   - `evidence`：直接数据论据与口径引用；
   - `comparison`：横向同业对标或纵向历史周期对比；
   - `chart_readout`：图表邻接解读（图前结论、图中拐点、图后含义三段式）；
   - `risk`：风险、反例与制约因素；
   - `methodology`：口径与测算方法；
   - `transition`：必要的承上启下；
   - `analysis` / `scenario`：综合分析或情景推演。
4. 页面组件抽取（充分利用上下文中的量化资产）：
   - `metric_cards`：若本节涉及关键量化指标（如市值、增速、杜邦ROE、净现比、估值溢价），提炼 1~3 个指标卡：label, value, unit, period, evidence_ids。涉及多公司合计/中位数时，label 必须写明成分数（如「4 家样本总市值」「成熟盈利 3 家 PB 中位数」）——审计按成分数核验子集统计，缺家数的聚合值会被隔离。
   - `comparison_table`：若本节涉及多企业横向对标或三档情景推演，提炼结构化对比表：title, columns, rows, evidence_ids；
   - `callouts`：若本节存在关键风险提示、政策边界或不可外推声明，提炼为 callout：type("risk"|"boundary"|"highlight"), title, text, evidence_ids；
   - `layout_hint`：根据图文关系选择：text_only, chart_right, chart_full, comparison_table, metrics_grid。
5. 图文协同与显式强锚点：挂接的 `chart_ids` 必须在对应小节正文中提供具有分析深度的邻接解读（段落 `kind` 优先选用 `chart_readout`）。【强制约束】正文引用图表时必须显式出现对应图表的完整占位符（如 `[CHART-xx]`），严禁仅写模糊的“如图所示”而遗漏 `[CHART-xx]` 标签！排版引擎将统一映射为最终图表顺序编号。【严禁捏造未挂接图表占位符】：若本小节未挂接图表（`chart_ids` 为空），严禁在正文中插入任何 `[CHART-xx]` 占位符或图表引用！只能引用在上下文 `charts` 中真实存在的图表 ID！
6. 风险与情景推演规范（尤其针对第七章或预测性章节）：
   - 仅在输入提供可核验的测算依据时写量化情景，区分假设与结果；概率和阈值需要来源。
   - 资料只支持定性判断时，写清触发条件、待观察指标和判断边界；情景数量随证据决定。
   - 必须包含非外推声明 (Non-extrapolation Disclaimer，建议放置在 callout 中)：根据本报告的证据说明已覆盖的主体、财务口径和期间，以及这些样本对本行业的代表性边界。不要套用其他行业的主体、产品或术语，也不要编造未纳入的样本类别。
7. 全局事实与一致性锚点（强制约束）：严格遵循输入及上下文中的 `global_facts`。凡提及行业/样本总市值，必须统一按照 `global_facts` 给出，严禁在不同章节出现数量级矛盾（如 22.14万亿 与 2.21万亿 的10倍冲突）；凡提及重点企业产业链环节归属，必须与 `global_facts` 保持绝对一致，严禁同一标的在上中下游反复横跳！
8. 非宏观章节套话禁令：除宏观综述或宏观驱动专章外，其余产业、竞争、财务等章节严禁重复展开脱节宏观指标（如社融、工业增加值）的周期无效性免责声明套话！保持对本行业真实财务、业务与竞争态势的专注。
9. 返回严格 JSON 格式（【极其重要规范】：你的输出必须且只能是一个纯合法的 JSON 对象。严禁在输出开头添加任何 Markdown 标题如 "# 标题" 或引言文字；严禁输出任何 ```json 代码块外围文本；正文内部出现的双引号若非 JSON 键值语法边界，一律使用中文双引号“”或转义）：
{
  "chapter_id": "CH-xx",
  "title": "...",
  "summary": "用最短篇幅概括本章有证据的核心判断",
  "sections": [
    {
      "section_id": "SEC-xx-xx",
      "title": "...",
      "purpose": "...",
      "key_points": ["核心要点1", "核心要点2"],
      "paragraphs": [
        {"paragraph_id": "P-xx-xx-01", "kind": "thesis", "text": "...", "evidence_ids": ["..."], "assumption_note": null}
      ],
      "chart_ids": ["..."],
      "uncertainties": ["..."],
      "metric_cards": [{"label": "...", "value": "...", "unit": "...", "period": "...", "evidence_ids": ["..."]}],
      "comparison_table": null,
      "callouts": [],
      "layout_hint": "chart_right"
    }
  ]
}"""


def extract_numbers(text:str)->list[str]:
    return NUMBER_RE.findall(mask_chart_references(text))


AEROSPACE_CANONICAL_SEGMENTS: dict[str, str] = {
    "中国卫星": "中游卫星研制与系统总装",
    "铖昌科技": "上游相控阵T/R芯片与核心元器件",
    "中兴通讯": "下游/地面系统与终端通信设备",
    "航天电子": "中游航天电子元器件与集成",
    "上海瀚讯": "中游卫星通信载荷与系统集成",
    "航天环宇": "上游/中游地面测控天线与微波部件",
    "移远通信": "下游通信模组与应用终端",
    "中国卫通": "下游卫星运营与综合通信服务",
    "光威复材": "上游碳纤维及复合材料",
    "中材科技": "上游特种纤维与复合材料",
    "国机精工": "上游特种轴承与精密部件",
    "大族激光": "上游激光加工与先进装备",
    "九丰能源": "上游特种气体与推进能源供给",
    "海格通信": "中游北斗导航与卫星通信终端",
}


def extract_global_quantitative_anchor(report: Any) -> dict[str, Any]:
    comps_matrix = getattr(report, "comps_matrix", None)
    if isinstance(comps_matrix, dict):
        comps = comps_matrix.get("entries") or comps_matrix.get("comps") or []
        total_mc = comps_matrix.get("total_market_cap")
        median_pe = comps_matrix.get("median_pe")
        median_pb = comps_matrix.get("median_pb")
        median_gross_margin = comps_matrix.get("median_gross_margin")
    else:
        comps = (getattr(comps_matrix, "entries", None) or getattr(comps_matrix, "comps", [])) if comps_matrix else []
        total_mc = getattr(comps_matrix, "total_market_cap", None) if comps_matrix else None
        median_pe = getattr(comps_matrix, "median_pe", None) if comps_matrix else None
        median_pb = getattr(comps_matrix, "median_pb", None) if comps_matrix else None
        median_gross_margin = getattr(comps_matrix, "median_gross_margin", None) if comps_matrix else None

    if not total_mc and comps:
        mc_list = [
            (c.get("market_cap") if isinstance(c, dict) else getattr(c, "market_cap", 0)) or 0
            for c in comps
        ]
        total_mc = sum(mc_list)

    mc_val = round(total_mc, 2) if total_mc else 0.0
    mc_wan_yi = round(mc_val / 10000.0, 2)
    if mc_val >= 10000:
        mc_str = f"{mc_val:,.2f} 亿元（约 {mc_wan_yi:.2f} 万亿元）"
    elif mc_val > 0:
        mc_str = f"{mc_val:,.2f} 亿元（约 {mc_wan_yi:.2f} 万亿元）"
    else:
        mc_str = "暂无汇总数据"

    total_companies = len(comps) if comps else 0
    profitable_count = sum(
        1 for c in comps
        if (c.get("valuation_tier") if isinstance(c, dict) else getattr(c, "valuation_tier", None)) == "profitable"
    ) if comps else 0
    loss_count = total_companies - profitable_count if total_companies else 0

    # Resolve subject for domain-specific canonical dictionaries
    subj = ""
    meta = getattr(report, "metadata", None)
    if isinstance(meta, dict):
        subj = meta.get("industry") or meta.get("subject") or ""
    elif meta:
        subj = getattr(meta, "industry", "") or getattr(meta, "subject", "") or ""
    if not subj and hasattr(report, "subject"):
        subj = getattr(report, "subject", "") or ""

    is_aerospace = any(k in str(subj) for k in ("航天", "卫星", "低轨"))
    canonical_segments: dict[str, str] = dict(AEROSPACE_CANONICAL_SEGMENTS) if is_aerospace else {}

    # Resolve company canonical segments dynamically
    for seg in getattr(report, "industry_chain_segments", []):
        s_name = getattr(seg, "segment_name", "") or (seg.get("segment_name", "") if isinstance(seg, dict) else "")
        reps = getattr(seg, "representative_companies", []) or (seg.get("representative_companies", []) if isinstance(seg, dict) else [])
        for comp in reps:
            c_str = str(comp).strip()
            if c_str and not re.match(r"^\d{6}\.[A-Z]{2}$", c_str) and not c_str.replace(".", "").isdigit():
                if c_str not in canonical_segments:
                    canonical_segments[c_str] = s_name

    return {
        "market_cap_val": mc_val,
        "market_cap_wan_yi": mc_wan_yi,
        "market_cap_str": mc_str,
        "total_companies": total_companies,
        "profitable_count": profitable_count,
        "loss_count": loss_count,
        "median_pe": median_pe,
        "median_pb": median_pb,
        "median_gross_margin": median_gross_margin,
        "canonical_segments": canonical_segments,
    }


def format_global_facts_prompt(facts: dict[str, Any]) -> str:
    lines = [
        "【全篇全局量化基准与事实锚点（强制约束，所有章节必须保持高度一致，严禁互相矛盾）】",
    ]
    if facts.get("total_companies"):
        lines.append(f"- 样本公司总数：{facts['total_companies']} 家（成熟盈利：{facts['profitable_count']} 家，早期/亏损/高估值：{facts['loss_count']} 家）")
    if facts.get("market_cap_str") and facts["market_cap_str"] != "暂无汇总数据":
        lines.append(f"- 样本总市值标准基准：{facts['market_cap_str']}（全篇必须以此为准，严禁在不同章节出现 22.14万亿 vs 2.21万亿 的10倍冲突！）")
    if facts.get("median_pe") is not None:
        lines.append(f"- 估值与盈利中枢：成熟标的 PE(TTM) 中位数 {facts['median_pe']} 倍，PB 中位数 {facts.get('median_pb')} 倍，销售毛利率中枢 {facts.get('median_gross_margin')}%")
    if facts.get("canonical_segments"):
        lines.append("- 核心标的产业链环节锁定字典（严禁同一企业在不同章节环节归属不一致）：")
        for comp, seg in list(facts["canonical_segments"].items())[:12]:
            lines.append(f"  * {comp}: {seg}")
    return "\n".join(lines)


def _clear_repaired_paragraph_warnings(warning: str | None, accepted: set[str]) -> str | None:
    if not warning or not accepted:
        return warning
    match = re.match(r"^(段落资料缺口：CH-\d{2}\s+)(.*)$", warning)
    if not match:
        return warning
    remaining = []
    for part in match.group(2).split("；"):
        paragraph = re.match(r"^(P-\d{2}-\d{2}-\d{2})\s+(因质量问题被整段移除|与其他段落重复)", part)
        if not paragraph or paragraph.group(1) not in accepted:
            remaining.append(part)
    return match.group(1) + "；".join(remaining) if remaining else None


class ChapterWriterAgent:
    def __init__(self,*,settings:Settings|None=None,llm:ChapterLLM|None=None,skillhub:WritingSkillHub|None=None)->None:
        self.settings=settings or Settings.from_env(); self.llm=llm or OpenAICompatibleLLM(self.settings); self.skillhub=skillhub or WritingSkillHub()

    async def _plan_chapter_skills(
        self,
        outline_chapter: Any,
        context: dict[str, Any],
        request: ChapterWritingRequest,
    ) -> list[tuple[WritingSkill, str, str]]:
        # Every applicable writing rule is already included by policy. A model
        # planning round cannot improve that union; avoid one paid call per chapter.
        policy_skills = self.skillhub.select(outline_chapter.chapter_id)
        requested, _ = resolve_requested_skills(
            request.selected_skills, self.skillhub.catalog, stage="writing",
        )
        requested = [s for s in requested
                     if s.always or outline_chapter.chapter_id in s.chapters]
        requested_names = {s.name for s in requested}
        merged = merge_selection(
            [], policy_skills, requested_skills=requested, limit=CHAPTER_SKILL_LIMIT,
        )
        return [
            (skill, "用户显式选择；按适用章节加载" if skill.name in requested_names
             else skill.adaptation or "章节大纲特征匹配",
             "user" if skill.name in requested_names else "policy")
            for skill in merged.final
        ]

    async def run(self,request:ChapterWritingRequest,emit:EventEmitter|None=None,save_artifacts:bool=True)->ChapterWritingResult:
        run_id=f"chapters-{datetime.now().strftime('%Y%m%d%H%M%S')}-{secrets.token_hex(4)}"
        artifact_dir=self.settings.output_dir/"runs"/run_id if save_artifacts else None
        events:list[dict[str,Any]]=[]
        async def record(event:str,**details:Any)->None:
            item={"timestamp":datetime.now().astimezone().isoformat(),"event":event,"details":details}; events.append(item)
            if emit:
                try: await emit(item)
                except Exception: pass
        await record("chapter_writing_started",source_report_id=request.report.report_id)
        outline=request.outline or DEFAULT_OUTLINE
        allowed_evidence=set(request.report.evidence_index)
        # B30：指标卡绑定池 = 全量索引（与本章检索子集解耦）。见 _audit_chapter 处注释。
        self._card_evidence_pool = _evidence_index_dicts(request.report.evidence_index)
        ready_charts={c.chart_id:c for c in (request.charts.charts if request.charts else []) if c.status=="ready"}
        global_facts=extract_global_quantitative_anchor(request.report)
        global_facts_prompt=format_global_facts_prompt(global_facts)
        retriever = DynamicEvidenceRetriever(request)
        # 净现比口径守卫（2026-11-15 真实 run 验证后默认开启：7 处无据断言被改写、
        # 已核验数字不受影响）。策略在全章写作前算一次：只认 A2 已核验、
        # 且分母明确为归母净利润的结果；正文自算或口径不符时改写为缺口句。
        # A4_NET_CASH_RATIO_GUARD=0 可整体关闭。
        net_cash_policy: dict[str, Any] | None = None
        if os.getenv("A4_NET_CASH_RATIO_GUARD", "1") == "1":
            net_cash_policy = build_net_cash_ratio_policy(request.report)
        concurrency = getattr(self.settings, "max_concurrency", 7)
        semaphore = asyncio.Semaphore(concurrency)
        if artifact_dir:
            (artifact_dir / "chapters").mkdir(parents=True, exist_ok=True)

        _, unavailable_skills = resolve_requested_skills(
            request.selected_skills, self.skillhub.catalog, stage="writing",
        )
        if unavailable_skills:
            await record("skill_skipped", skills=unavailable_skills,
                         reason="写作阶段没有对应规范，分析技能不一定存在写作映射")
        selected_by_chapter: dict[str, list[WritingSkill]] = {}
        skill_reasons: dict[str, str] = {}
        # D-11：跨章共享的越界证据留痕通道（asyncio 单线程事件循环内 append 安全；
        # _audit_chapter 内为同步调用，无 await 打断）。汇入 result.warnings，不触发重写。
        foreign_drops: list[str] = []
        remediation_failures: list[str] = []

        async def _write_chapter(outline_chapter: Any) -> tuple[ChapterDraft, str | None, str | None]:
            async with semaphore:
                context = retriever.retrieve(outline_chapter.chapter_id, outline_chapter)
                context["global_facts"] = global_facts
                context["global_facts_prompt"] = global_facts_prompt
                if net_cash_policy is not None:
                    context["net_cash_ratio_policy"] = net_cash_policy["prompt"]
                planned_skills = await self._plan_chapter_skills(outline_chapter, context, request)
                selected_by_chapter[outline_chapter.chapter_id] = [skill for skill, _, _ in planned_skills]
                for skill, reason, route_type in planned_skills:
                    skill_reasons[skill.name] = reason
                    if route_type == "user":
                        await record("skill_requested", chapter_id=outline_chapter.chapter_id, skill=skill.name, reason=reason)
                    elif route_type == "llm":
                        await record("skill_invoked_by_llm", chapter_id=outline_chapter.chapter_id, skill=skill.name, reason=reason)
                    else:
                        await record("skill_routed_by_policy", chapter_id=outline_chapter.chapter_id, skill=skill.name, route_type="fast_skill_router", reason=reason)
                context["skills"] = [{"name": skill.name, "instructions": skill.instructions} for skill, _, _ in planned_skills]
                await record("skill_loaded", chapter_id=outline_chapter.chapter_id,
                             skills=[s.name for s, _, _ in planned_skills],
                             planner="chapter_policy", model_planning_calls=0)
                chapter, fallback_id, warning = await self._generate_audited_chapter(
                    request, outline_chapter, context, ready_charts, global_facts, record, foreign_drops
                )
                # 守卫必须跑在人工修订**之前**：否则用户已通过复验的修订会被改写成
                # 缺口句，出现「补救内容静默丢失 + content_audit 自相矛盾」。
                if net_cash_policy is not None:
                    apply_net_cash_ratio_guard([chapter], net_cash_policy)
                revisions = self._apply_remediation_revisions(
                    chapter, outline_chapter, request.remediation_revisions,
                    _evidence_index_dicts(request.report.evidence_index), request.report.financial_ratios,
                )
                warning = _clear_repaired_paragraph_warnings(warning, {
                    item["target_id"] for item in revisions if item["status"] == "accepted" and not item.get("boundary")
                })
                for revision in revisions:
                    chapter.content_audit.append({"code": "user_research_boundary" if revision.get("boundary") else "user_paragraph_revision",
                        "location": revision["target_id"], "disposition": revision["status"], "reason": revision["reason"],
                        **({"text": revision["text"]} if revision.get("boundary") else {})})
                rejected = [item for item in revisions if item["status"] == "rejected"]
                if rejected:
                    detail = "；".join(f"{item['target_id']} 人工修订未通过复验：{item['reason']}" for item in rejected)
                    remediation_failures.append(detail)
                    warning = f"{warning}；{detail}" if warning else f"段落资料缺口：{chapter.chapter_id} {detail}"
                if artifact_dir:
                    (artifact_dir / "chapters" / f"{chapter.chapter_id}.json").write_text(
                        chapter.model_dump_json(indent=2) + "\n", encoding="utf-8"
                    )
                return chapter, fallback_id, warning

        chapter_results = await asyncio.gather(*[_write_chapter(c) for c in outline])
        await record("skills_planned", skills={chapter_id: [skill.name for skill in skills] for chapter_id, skills in selected_by_chapter.items()})
        chapters: list[ChapterDraft] = [item[0] for item in chapter_results]
        fallback_ids = [item[1] for item in chapter_results if item[1] is not None]
        warnings = list(request.report.warnings) + [item[2] for item in chapter_results if item[2] is not None] + list(dict.fromkeys(foreign_drops))
        issues=self._audit_package(chapters,allowed_evidence,ready_charts,global_facts,
                                   evidence=_evidence_index_dicts(request.report.evidence_index))
        issues.extend(remediation_failures)
        # 「段落资料缺口」不在这里无条件升级——见下方按内容损失比例分级（B23-T10）。
        # B23-T7（2026-11-10 SEMI-Q4 实测）：旧口径「引用证据数 / 全库证据数」
        # 天然是个位数（该 run 2.36%、Q3 双跑 3.6%/2.9%），读起来像「章节只有
        # 2% 有据」，实际是「引用了全库 2% 的证据」——两个概念。改为段落覆盖率：
        # 至少绑定一条证据的段落 / 有内容的段落。
        bound_paragraphs = 0
        total_paragraphs = 0
        for chapter in chapters:
            for section in chapter.sections:
                for para in section.paragraphs:
                    if not (para.text or "").strip():
                        continue
                    total_paragraphs += 1
                    if para.evidence_ids:
                        bound_paragraphs += 1
        coverage = bound_paragraphs / total_paragraphs if total_paragraphs else 0
        # 「段落资料缺口」仍升级为章级 issue（质量审计语义：有内容被拦截就该
        # 让调用方知道）。是否因此阻塞交付，由 report_fusion 按**内容损失率**
        # 判定（B23-T10）——移除少量无据内容是正常取舍，不该永久「受限草稿」。
        issues.extend(item[2] for item in chapter_results
                      if item[2] and item[2].startswith("段落资料缺口："))
        if fallback_ids: issues.append(f"{len(fallback_ids)} 章使用确定性兜底稿")
        status="completed" if not fallback_ids and not issues else "partial"
        quality=ChapterQualityReport(passed=not issues,chapter_count=len(chapters),section_count=sum(len(c.sections) for c in chapters),evidence_coverage=min(coverage,1),issues=issues,fallback_chapter_ids=fallback_ids)
        applied=[]
        for skill in self.skillhub.catalog.values():
            chapters_used=[chapter_id for chapter_id,skills in selected_by_chapter.items() if any(s.name == skill.name for s in skills)]
            if chapters_used:
                adaptation = skill_reasons.get(skill.name, skill.adaptation)
                applied.append(AppliedSkill(name=skill.name,description=skill.description,source=skill.source,adaptation=adaptation,chapters=chapters_used))
        result=ChapterWritingResult(run_id=run_id,source_report_id=request.report.report_id,subject=request.report.subject,as_of=request.report.as_of,status=status,outline_version=OUTLINE_VERSION if request.outline is None else "custom-1",model_name=self.settings.llm_model if self.llm.is_available else "deterministic-fallback",applied_skills=applied,chapters=chapters,quality=quality,warnings=warnings+issues+[f"写作阶段没有对应技能：{name}" for name in unavailable_skills],artifact_dir=str(artifact_dir.resolve()) if artifact_dir else None,question_answers=retriever.summarize_question_answers(chapters))
        await record("chapter_writing_completed",status=status,chapters=len(chapters),fallbacks=len(fallback_ids))
        if artifact_dir:
            artifact_dir.mkdir(parents=True,exist_ok=True)
            (artifact_dir/"request.json").write_text(request.model_dump_json(indent=2)+"\n",encoding="utf-8")
            (artifact_dir/"input_report.json").write_text(request.report.model_dump_json(indent=2)+"\n",encoding="utf-8")
            (artifact_dir/"input_charts.json").write_text((request.charts.model_dump_json(indent=2) if request.charts else "{}")+"\n",encoding="utf-8")
            (artifact_dir/"chapter_result.json").write_text(result.model_dump_json(indent=2)+"\n",encoding="utf-8")
            (artifact_dir/"events.jsonl").write_text("".join(json.dumps(x,ensure_ascii=False)+"\n" for x in events),encoding="utf-8")
        return result

    async def _generate_audited_chapter(
        self, request: ChapterWritingRequest, outline_chapter: Any,
        context: dict[str, Any], ready_charts: dict[str, Any],
        global_facts: dict[str, Any], record: Callable[..., Awaitable[None]], drop_log: list[str],
    ) -> tuple[ChapterDraft, str | None, str | None]:
        """Shared generation, repair and evidence audit for full and targeted writing."""
        allowed_evidence = set(request.report.evidence_index)
        # B30：同一入口也可能被定向重写单独调用，绑定池在这里再设一次。
        self._card_evidence_pool = _evidence_index_dicts(request.report.evidence_index)
        global_facts_prompt = context["global_facts_prompt"]
        chapter = None
        errors: list[str] = []
        paragraph_warning = None
        if self.llm.is_available:
            for attempt in range(request.options.max_repairs + 1):
                try:
                    payload = {
                        "outline": outline_chapter.model_dump(mode="json"),
                        "subject": request.report.subject,
                        "as_of": request.report.as_of.isoformat(),
                        "audience": request.options.audience,
                        "style": request.options.style,
                        "target_length": request.options.target_length,
                        "instruction": request.options.instruction,
                        "context": context,
                        "global_facts": global_facts_prompt,
                        "previous_errors": errors,
                    }
                    # The model client owns request retries; do not multiply them here.
                    prompt, packing = prepare_chapter_context(payload, SYSTEM_PROMPT)
                    await record("context_budget_checked", chapter_id=outline_chapter.chapter_id,
                                 **packing)
                    raw = await self.llm.generate_json(SYSTEM_PROMPT, prompt)
                    chapter = ChapterDraft.model_validate(raw)
                    chapter.content_audit = []
                    if any(not section.paragraphs for section in chapter.sections):
                        raise ValueError("生成章节含空节")
                    errors = self._audit_chapter(chapter, outline_chapter, allowed_evidence, ready_charts, context, global_facts, drop_log=drop_log)
                    await record("skill_linter_checked", chapter_id=outline_chapter.chapter_id, passed=not errors, issues=errors)
                    await record("chapter_attempt", chapter_id=outline_chapter.chapter_id, attempt=attempt + 1, issues=errors)
                    quarantined = []
                    for section in chapter.sections:
                        card_errors = [issue for issue in errors if issue.startswith(f"{section.section_id} 指标卡「")
                                       and issue.endswith("数值缺少证据绑定")]
                        for issue in card_errors:
                            label = issue.split("「", 1)[1].split("」", 1)[0]
                            section.metric_cards = [card for card in section.metric_cards if card.label != label]
                        table_error = f"{section.section_id} 对比表数值缺少证据绑定"
                        if table_error in errors:
                            section.comparison_table = None
                        removed = card_errors + ([table_error] if table_error in errors else [])
                        if removed:
                            chapter.content_audit.extend({
                                "code": "chapter_component_isolation", "location": section.section_id,
                                "section_id": section.section_id, "claim": issue, "disposition": "isolated",
                            } for issue in removed)
                            quarantined.extend(removed)
                    if quarantined:
                        errors = self._audit_chapter(chapter, outline_chapter, allowed_evidence,
                            ready_charts, context, global_facts, drop_log=drop_log)
                    if not errors:
                        if quarantined:
                            # B23-T9（2026-11-10 SEMI-Q4 新 run 实测）：组件隔离
                            # （删掉缺绑定的卡/表后重审通过）是「已处理」，不是
                            # 「未解决」。旧实现把它写成「段落资料缺口：…」前缀，
                            # 会被升级为章级 issue → quality.passed=False → 报告
                            # 永久「受限草稿」，而终态其实 33/33 张卡全绑定
                            # （被删的卡已不在交付件里）。
                            # 改为独立「组件隔离」warning（进 result.warnings 留痕、
                            # 不进 issues）；只有隔离比例 >50% 才仍判未通过，
                            # 防止「把内容删光换通过」。
                            remaining_cards = sum(len(sec.metric_cards) for sec in chapter.sections)
                            total_cards = remaining_cards + len(quarantined)
                            isolation_ratio = len(quarantined) / total_cards if total_cards else 0.0
                            if isolation_ratio > 0.5:
                                paragraph_warning = (
                                    f"段落资料缺口：{chapter.chapter_id} 组件隔离比例过高"
                                    f"（{len(quarantined)}/{total_cards}）：{'；'.join(quarantined)}"
                                )
                            else:
                                paragraph_warning = (
                                    f"组件隔离：{chapter.chapter_id} {'；'.join(quarantined)}"
                                    f"（已从交付件移除，保留内容仍通过核验）"
                                )
                        if attempt < request.options.max_repairs:
                            await self._add_numeric_readout(
                                chapter, outline_chapter, allowed_evidence, ready_charts, context, global_facts, record,
                            )
                        break
                    positions = {p.paragraph_id: (si, pi) for si, section in enumerate(chapter.sections)
                                 for pi, p in enumerate(section.paragraphs)}
                    failures = {pid: [issue for issue in errors if issue.startswith(pid + " ")]
                                for pid in positions}
                    failures = {pid: issues for pid, issues in failures.items() if issues}
                    if failures and all(any(issue in group for group in failures.values()) for issue in errors):
                        # B28：`quarantined` 是**已从交付件删除**的组件（缺绑定的卡/表），
                        # 属于「已处置」，不能当成「未解决的残留」写进终态 issue。
                        # 旧实现 `unresolved = list(quarantined)` 把删卡动作记成了缺陷，
                        # 实测 7 章共留下 25 条「指标卡缺绑定」，而交付件里 0 张无绑定卡。
                        # 安全网：隔离比例 >50% 仍记 issue，防「删光换通过」（与上方
                        # `not errors` 分支同一判据）。
                        unresolved = []
                        if quarantined:
                            remaining_cards = sum(len(sec.metric_cards) for sec in chapter.sections)
                            total_cards = remaining_cards + len(quarantined)
                            isolation_ratio = len(quarantined) / total_cards if total_cards else 0.0
                            if isolation_ratio > 0.5:
                                unresolved.append(
                                    f"{chapter.chapter_id} 组件隔离比例过高"
                                    f"（{len(quarantined)}/{total_cards}）：{'；'.join(quarantined)}"
                                )
                        remaining_repairs = request.options.max_repairs - attempt
                        for pid, para_issues in failures.items():
                            si, pi = positions[pid]
                            original = chapter.sections[si].paragraphs[pi]
                            repair_payload = {"subject": request.report.subject,
                                "section_id": chapter.sections[si].section_id,
                                "paragraph": original.model_dump(mode="json"), "issues": para_issues,
                                "evidence": context.get("evidence", {})}
                            await record("paragraph_repair_started", chapter_id=chapter.chapter_id,
                                         section_id=chapter.sections[si].section_id, paragraph_id=pid,
                                         issues=para_issues, evidence_ids=original.evidence_ids)
                            repaired = False
                            reason = "repair_disabled"
                            if remaining_repairs > 0:
                                remaining_repairs -= 1
                                try:
                                    reason = "audit_failed"
                                    repair_system = SYSTEM_PROMPT + "\n只返回修复后的单个段落 JSON，保持 paragraph_id。"
                                    prompt, _, _ = serialize_context(repair_payload, system=repair_system)
                                    raw = await self.llm.generate_json(repair_system, prompt)
                                    replacement = ParagraphDraft.model_validate(raw)
                                    if replacement.paragraph_id != pid:
                                        raise ValueError("paragraph_id 不一致")
                                    trial = chapter.model_copy(deep=True)
                                    trial.sections[si].paragraphs[pi] = replacement
                                    trial_issues = self._audit_chapter(trial, outline_chapter, allowed_evidence,
                                        ready_charts, context, global_facts)
                                    if not any(issue.startswith(pid + " ") for issue in trial_issues) and not (set(trial_issues) - set(errors)):
                                        chapter.sections[si].paragraphs[pi] = trial.sections[si].paragraphs[pi]
                                        repaired = True
                                        reason = "passed"
                                except Exception as exc:
                                    reason = type(exc).__name__
                            disposition = "repaired"
                            if not repaired:
                                evidence = context.get("evidence", {})
                                refs = [evidence[rid] for rid in original.evidence_ids if rid in evidence]
                                refs.extend(verified_calculations(context.get("financial_ratios", []), evidence, original.evidence_ids))
                                retained = retain_supported_claims(original.text, lambda clause: not quantity_issues(
                                    clause, refs, universe=list(evidence.values()),
                                    assumption_note=original.assumption_note, kind=original.kind,
                                ))
                                trial = chapter.model_copy(deep=True)
                                if retained and retained != original.text:
                                    trial.sections[si].paragraphs[pi].text = retained
                                    trial_errors = self._audit_chapter(trial, outline_chapter,
                                        allowed_evidence, ready_charts, context, global_facts)
                                    if any(issue.startswith(pid + " ") for issue in trial_errors):
                                        retained = ""
                                else:
                                    retained = ""
                                chapter.sections[si].paragraphs[pi] = original.model_copy(update={
                                    "text": retained, "evidence_ids": original.evidence_ids if retained else [],
                                })
                                disposition = "partially_retained" if retained else "isolated"
                                # B23-T1（2026-11-10 SEMI-Q4 实测）：旧实现在这里无条件
                                # `unresolved.extend(para_issues)`，把**修复前**的报错永久
                                # 留档。段落随后被裁剪/整段移除，报错已不成立，却仍写入
                                # 终态 quality.issues——该 run 因此列出 229 条「数值语义未
                                # 通过」，终态重跑只有 10 段真不通过（虚高 20 倍），报告被
                                # 永久钉在「受限草稿」。
                                # 正确语义：unresolved 只承载**终态残留**（下面 remaining），
                                # 被裁剪掉的旧报错只进 content_audit 留痕；整段被移除属真
                                # 内容缺口，用一句概述留痕而非复述逐条数字报错。
                                if not retained:
                                    # 整段被移除 = 真内容缺口。留痕只记「哪类问题」，不复述
                                    # 逐条数值（20%/45% 之类已随段落移除不再成立）。
                                    # 措辞保持中性：移除原因可能是数值无据，也可能是重复。
                                    kinds = list(dict.fromkeys(
                                        _issue_kind(item) for item in para_issues
                                    ))
                                    unresolved.append(
                                        f"{pid} 因质量问题被整段移除"
                                        + (f"（{'、'.join(k for k in kinds if k)}）" if any(kinds) else "")
                                    )
                            chapter.content_audit.append({
                                "code": "chapter_claim_repair", "location": pid,
                                "section_id": chapter.sections[si].section_id,
                                "original": original.text, "claim": "；".join(para_issues),
                                "evidence_ids": original.evidence_ids, "disposition": disposition,
                                "reason": reason,
                            })
                            await record("paragraph_repair_completed", chapter_id=chapter.chapter_id,
                                         paragraph_id=pid, passed=repaired, reason=reason, issues=para_issues)
                        remaining = self._audit_chapter(chapter, outline_chapter, allowed_evidence,
                            ready_charts, context, global_facts, drop_log=drop_log)
                        for section in chapter.sections:
                            section.paragraphs = [para for para in section.paragraphs if para.text.strip()]
                        if remaining:
                            unresolved.extend(remaining)
                        if unresolved:
                            # B23-T1：同一段落可能在多个 attempt 重复报同一问题，去重后
                            # 再落 warning，避免 issue 文本指数级膨胀。
                            deduped = list(dict.fromkeys(unresolved))
                            paragraph_warning = f"段落资料缺口：{chapter.chapter_id} {'；'.join(deduped)}"
                        break
                    chapter = None
                except Exception as exc:
                    errors = [str(exc)[:500] if isinstance(exc, ContextBudgetExceeded) else type(exc).__name__]
                    await record("chapter_attempt_failed", chapter_id=outline_chapter.chapter_id, attempt=attempt + 1, error=errors[0])
                    if isinstance(exc, (ContextBudgetExceeded, httpx.HTTPError, TimeoutError)):
                        break
        fallback_id = None
        warning = paragraph_warning
        if chapter is None:
            chapter = self._fallback_chapter(request, outline_chapter, context, ready_charts, global_facts)
            fallback_id = outline_chapter.chapter_id
            warning = f"{outline_chapter.chapter_id} 使用确定性兜底稿：{'；'.join(errors) if errors else '未配置模型'}"
            await record("chapter_fallback", chapter_id=outline_chapter.chapter_id)
            fb_errors = self._audit_chapter(chapter, outline_chapter, allowed_evidence, ready_charts, context, global_facts, drop_log=drop_log)
            await record("skill_linter_checked", chapter_id=outline_chapter.chapter_id, passed=not fb_errors, issues=fb_errors)
        return chapter, fallback_id, warning

    async def _add_numeric_readout(
        self, chapter, outline, allowed_evidence, charts, context, global_facts, record,
    ) -> None:
        """Use one remaining repair slot to interpret an otherwise valid numeric list."""
        candidate = next(((si, pi) for si, section in enumerate(chapter.sections)
                          for pi, para in enumerate(section.paragraphs) if _lists_numbers(para)), None)
        if candidate is None:
            return
        si, pi = candidate
        section = chapter.sections[si]
        paragraph = section.paragraphs[pi]
        evidence = context.get("evidence") or {}
        refs = {rid: evidence[rid] for rid in paragraph.evidence_ids if rid in evidence}
        if not refs:
            return
        system = (
            "给通过事实核验的投研段落补一到两句简洁解读。只依据所给记录，说明这些数字"
            "支持的比较或业务判断。解释因果必须有直接披露；如果缺证据，指出具体缺少的科目"
            "或材料。保持原有事实，不重复数字，不新增量化断言，不写套话。"
            '只返回 JSON {"interpretation":"要追加到段末的解读"}。'
        )
        try:
            prompt, _, _ = serialize_context({
                "section_title": section.title, "purpose": section.purpose,
                "paragraph": paragraph.text, "evidence": refs,
            }, system=system)
            raw = await self.llm.generate_json(system, prompt)
            value = raw.get("interpretation")
            explanation = value.strip() if isinstance(value, str) else ""
            accepted = False
            if (explanation and len(explanation) <= 160 and explanation not in paragraph.text
                    and not any(unit for _, unit in QUANTITY_RE.findall(explanation))
                    and _READOUT.search(explanation)):
                trial = chapter.model_copy(deep=True)
                paragraph_trial = trial.sections[si].paragraphs[pi]
                separator = "" if paragraph.text.rstrip().endswith(("。", "！", "？", ".", "!", "?")) else "。"
                paragraph_trial.text = paragraph.text.rstrip() + separator + explanation
                if not self._audit_chapter(trial, outline, allowed_evidence, charts, context, global_facts):
                    section.paragraphs[pi] = paragraph_trial
                    accepted = True
        except Exception as exc:
            await record("numeric_readout_skipped", paragraph_id=paragraph.paragraph_id,
                         reason=type(exc).__name__)
            return
        await record("numeric_readout_checked", paragraph_id=paragraph.paragraph_id, accepted=accepted)

    def _apply_remediation_revisions(
        self, chapter: ChapterDraft, outline: Any, revisions: list[dict[str, Any]],
        evidence: dict[str, dict[str, Any]], financial_ratios: Any = None,
    ) -> list[dict[str, Any]]:
        """Reinsert a requested paragraph only after the ordinary chapter audit."""
        results = []
        for revision in revisions:
            target = str(revision.get("target_id") or "")
            match = re.fullmatch(r"P-(\d{2})-(\d{2})-\d{2}", target)
            if not match or chapter.chapter_id != f"CH-{match.group(1)}":
                continue
            section_id = f"SEC-{match.group(1)}-{match.group(2)}"
            section = next((s for s in chapter.sections if s.section_id == section_id), None)
            refs = revision.get("evidence_refs") or []
            if revision.get("target_kind") == "methodology":
                from agents_core.remediation_boundaries import LIMITATIONS
                text = LIMITATIONS.get(str(revision.get("template") or ""))
                if not section or not text or text != revision.get("text") or refs:
                    results.append({"target_id": target, "status": "rejected", "reason": "研究边界或目标段落无效"})
                    continue
                boundary_id = f"{target}-LIMIT"
                section.paragraphs = [p for p in section.paragraphs if p.paragraph_id != boundary_id]
                section.paragraphs.append(ParagraphDraft(paragraph_id=boundary_id, kind="methodology", text=text))
                results.append({"target_id": target, "status": "accepted", "reason": "已保留研究边界，缺口仍需复核",
                                "boundary": True, "text": text})
                continue
            if (not section or not isinstance(refs, list) or not refs or set(refs) - set(evidence)
                    or any("review_excluded" in (evidence[r].get("issues") or []) for r in refs)):
                results.append({"target_id": target, "status": "rejected", "reason": "目标段落或有效证据不可用"})
                continue
            paragraph = ParagraphDraft(paragraph_id=target, text=str(revision.get("text") or ""), evidence_ids=refs)
            normalized = "".join(paragraph.text.split())
            if any("".join(existing.text.split()) == normalized for part in chapter.sections
                   for existing in part.paragraphs if existing.paragraph_id != target):
                results.append({"target_id": target, "status": "rejected", "reason": "修订内容与现有段落重复"})
                continue
            if not _remediation_claims_supported(paragraph.text, refs, evidence):
                results.append({"target_id": target, "status": "rejected", "reason": "修订事实无法由所选原文或结构化数据逐句核实"})
                continue
            trial = chapter.model_copy(deep=True)
            for part in trial.sections:
                part.paragraphs = [paragraph.model_copy(deep=True)] if part.section_id == section_id else []
                part.chart_ids, part.metric_cards, part.callouts = [], [], []
                part.comparison_table = None
            problems = self._audit_chapter(trial, outline, set(evidence), {},
                {"evidence": evidence, "financial_ratios": financial_ratios or []})
            if problems:
                results.append({"target_id": target, "status": "rejected", "reason": "；".join(problems)})
                continue
            section.paragraphs = [p for p in section.paragraphs if p.paragraph_id != target] + [paragraph]
            chapter.evidence_ids = list(dict.fromkeys([*chapter.evidence_ids, *refs]))
            results.append({"target_id": target, "status": "accepted", "reason": "已通过章节证据和数值核验"})
        return results

    def _audit_chapter(
        self,
        chapter: ChapterDraft,
        outline: Any,
        allowed: set[str],
        charts: dict[str, Any],
        context: dict[str, Any] | None = None,
        global_facts: dict[str, Any] | None = None,
        drop_log: list[str] | None = None,
    ) -> list[str]:
        issues = []
        # D-11 修复：越界证据被过滤时必须留痕。drop_log 是一条**独立于 issues 的软通道**——
        # issues 非空会触发本章重写/兜底（越界引用不应导致整章作废），而 drop_log 汇入
        # result.warnings，使“模型引用了非本章证据”这一事实可观测、可据以评估提示词质量。
        def _note_dropped(where: str, foreign: set[str]) -> None:
            if drop_log is not None and foreign:
                drop_log.append(
                    f"{chapter.chapter_id} {where}引用了非本章/未授权证据 {sorted(foreign)}，已剔除（越界留痕）"
                )

        if chapter.chapter_id != outline.chapter_id:
            issues.append("chapter_id 与大纲不一致")
        if [s.section_id for s in chapter.sections] != [s.section_id for s in outline.sections]:
            issues.append("section_id 或章节顺序与大纲不一致")
        seen_text = set()
        evidence_dict = (context.get("evidence") or {}) if context else {}
        if context is not None and "evidence" in context:
            allowed = allowed.intersection(evidence_dict)

        # Consistency repair: fix 22.14万亿 vs 2.21万亿 scale anomaly in chapter summary
        if global_facts and global_facts.get("market_cap_wan_yi"):
            cw = global_facts["market_cap_wan_yi"]
            cw_str = f"{cw}万亿元"
            cm_str = f"{cw * 10000:.2f}亿元"
            wrong_pattern = r"2\.21\s*万亿(?:元)?" if cw > 10 else r"22\.14\s*万亿(?:元)?"
            chapter.summary = re.sub(wrong_pattern, cw_str, chapter.summary)
            if cw <= 10:
                chapter.summary = re.sub(r"221411(?:\.07)?\s*亿元", cm_str, chapter.summary)

        derived_cache: list[dict] | None = None
        for section in chapter.sections:
            expected = next((x for x in outline.sections if x.section_id == section.section_id), None)
            if expected:
                section.title = expected.title
                section.purpose = expected.purpose

            # Consistency repair in section key_points
            if global_facts and global_facts.get("market_cap_wan_yi"):
                cw = global_facts["market_cap_wan_yi"]
                cw_str = f"{cw}万亿元"
                cm_str = f"{cw * 10000:.2f}亿元"
                wrong_pattern = r"2\.21\s*万亿(?:元)?" if cw > 10 else r"22\.14\s*万亿(?:元)?"
                section.key_points = [
                    re.sub(r"221411(?:\.07)?\s*亿元", cm_str, re.sub(wrong_pattern, cw_str, kp)) if cw <= 10 else re.sub(wrong_pattern, cw_str, kp)
                    for kp in section.key_points
                ]

            for para in section.paragraphs:
                unknown = set(para.evidence_ids) - allowed
                if unknown:
                    _note_dropped(f"段落 {para.paragraph_id} ", unknown)
                    para.evidence_ids = [e for e in para.evidence_ids if e in allowed]

                # Consistency repair in paragraph text
                if global_facts and global_facts.get("market_cap_wan_yi"):
                    cw = global_facts["market_cap_wan_yi"]
                    cw_str = f"{cw}万亿元"
                    cm_str = f"{cw * 10000:.2f}亿元"
                    wrong_pattern = r"2\.21\s*万亿(?:元)?" if cw > 10 else r"22\.14\s*万亿(?:元)?"
                    para.text = re.sub(wrong_pattern, cw_str, para.text)
                    if cw <= 10:
                        para.text = re.sub(r"221411(?:\.07)?\s*亿元", cm_str, para.text)

                # Entity chain segment consistency repair
                if "中国卫星等上游" in para.text:
                    para.text = para.text.replace("中国卫星等上游", "中国卫星等中游总装")
                if "中国卫星、铖昌科技等上游" in para.text:
                    para.text = para.text.replace("中国卫星、铖昌科技等上游", "铖昌科技等上游核心部件与中国卫星等中游总装")
                if "铖昌科技、中国卫星等上游核心部件" in para.text:
                    para.text = para.text.replace("铖昌科技、中国卫星等上游核心部件", "铖昌科技等上游核心部件与中国卫星等中游总装")

                # Filter out pure years (19xx, 20xx) and small list ordinals (1-10)
                nums = extract_numbers(para.text)
                substantive_nums = [n for n in nums if not YEAR_OR_ORDINAL_RE.match(n.strip())]

                # R4（V8 最终方案 §7.2）：**假设说明不能为已发生的事实数字提供依据**。
                # 旧实现的 `or para.assumption_note` 让模型自填任意一句"综合测算"
                # 就能豁免缺证据检查。现在只有 kind 维度（scenario/risk/methodology/
                # transition）保留窄通道；assumption_note 一律不构成豁免。
                if substantive_nums and not para.evidence_ids and not (
                    para.kind in ("scenario", "risk", "methodology", "transition")
                    and bool(re.search(r"假设|情景|如果|若|设定|敏感性", para.text))
                ):
                    matched_eids: list[str] = []
                    variants_cache = _evidence_variants_cache(evidence_dict)
                    for eid, rec in evidence_dict.items():
                        if eid not in allowed or eid == "_magnitude_variants":
                            continue
                        val_str = str(rec.get("value", "")).strip()
                        metric_str = str(rec.get("metric", "")).strip()
                        entity_str = str(rec.get("entity", "")).strip()
                        if val_str and len(val_str) >= 2 and val_str in para.text:
                            matched_eids.append(eid)
                        elif any(v and v in para.text for v in variants_cache.get(eid, ())):
                            # 量级换算后命中（亿元/万元/千分位）。绑定只扩候选池，
                            # 数值语义校验仍会核对实体、期间、指标族与容差，不会放行错值。
                            matched_eids.append(eid)
                        elif metric_str and len(metric_str) >= 2 and metric_str in para.text:
                            if entity_str and entity_str in para.text:
                                matched_eids.append(eid)
                    if not matched_eids:
                        # P0-1 残余②（2026-11-10）：派生合计绑定。条款明示
                        # 「合计/总和」且点名 ≥2 实体时，绑定同指标族成分
                        # 记录；数值是否真为成分之和由 quantity_issues 的
                        # 派生合计通道独立复核，错和仍会判无据。
                        pool = [evidence_dict[e] for e in allowed
                                if e in evidence_dict and e != "_magnitude_variants"]
                        derived = aggregate_component_ids(para.text, pool)
                        if derived:
                            matched_eids = derived
                    if matched_eids:
                        para.evidence_ids = list(dict.fromkeys(matched_eids))

                # R4：第二道检查与第一道同口径；assumption_note 不再是豁免项。
                if substantive_nums and not para.evidence_ids and not (
                    para.kind in ("scenario", "risk", "methodology", "transition")
                    and bool(re.search(r"假设|情景|如果|若|设定|敏感性", para.text))
                ):
                    issues.append(f"{para.paragraph_id} 数字缺少证据支撑（假设说明不能替代证据）")

                semantic_refs = [evidence_dict[eid] for eid in para.evidence_ids if eid in evidence_dict]
                semantic_refs.extend(verified_calculations((context or {}).get("financial_ratios", []), evidence_dict, para.evidence_ids))
                for sentence in re.split(r"[。；;\n]", para.text):
                    proposition = re.sub(r"“[^”]*”|《[^》]*》", "", sentence)
                    if not re.search(r"由于.+[，,].+|(?:导致|驱动|推动|带动|造成)(?!因素)", proposition):
                        continue
                    if re.search(r"资料缺|数据缺|证据不足|假设|情景", sentence):
                        continue
                    claim = re.sub(r"\s+", "", sentence).strip()
                    supporting_texts = [re.sub(r"\s+", "", str(ref.get("value", "")))
                                        for ref in semantic_refs if isinstance(ref, dict)]
                    if claim and not any(claim in text for text in supporting_texts):
                        issues.append(f"{para.paragraph_id} 因果判断缺少独立依据")
                semantic_issues = quantity_issues(para.text,
                    semantic_refs,
                    universe=list(evidence_dict.values()), assumption_note=para.assumption_note,
                    kind=para.kind, location=para.paragraph_id,
                    # B32：子集统计按样本清单核验（「25 家样本合计」只在样本内求和）
                    sample_universe=(context or {}).get("financial_ratios"))
                issues.extend(f"{para.paragraph_id} 数值语义未通过：{item['claim']}（需同实体、指标和期间证据）" for item in semantic_issues)
                normalized = "".join(para.text.split())
                if normalized in seen_text:
                    issues.append(f"{para.paragraph_id} 与其他段落重复")
                seen_text.add(normalized)
                if len(para.text) > 1000:
                    issues.append(f"{para.paragraph_id} 段落过长")

            # Prune charts that do not belong to this chapter
            valid_cids = []
            for cid in section.chart_ids:
                if cid in charts:
                    chart_obj = charts[cid]
                    rec_ch = getattr(chart_obj, "recommended_chapter_id", None) or (
                        chart_obj.get("recommended_chapter_id") if isinstance(chart_obj, dict) else None
                    )
                    if not rec_ch or rec_ch == outline.chapter_id:
                        valid_cids.append(cid)
            section.chart_ids = valid_cids

            # Ground structured UI components & fix metric cards
            if section.metric_cards:
                for mc in section.metric_cards:
                    if getattr(mc, "evidence_ids", None):
                        _note_dropped("指标卡 ", set(mc.evidence_ids) - allowed)
                        mc.evidence_ids = [e for e in mc.evidence_ids if e in allowed]
                    # R4（V8 最终方案 §7.1）：指标卡是证据承载对象——
                    # 承载数值却无任何合法证据绑定，必须计入审计问题，
                    # 不能因为"看起来结构化"就默认可信。
                    mc_value = str(getattr(mc, "value", "") or "")
                    if mc_value and extract_numbers(mc_value) and not getattr(mc, "evidence_ids", None):
                        # P0-1 残余①（2026-11-10）：先尝试量级变体自动绑定，
                        # 复核不过（错值/主体不符）才记缺陷。
                        # B30：绑定池放宽到**全量索引**。同一张卡在检索到该记录的
                        # 章节能绑上、没检索到的章节被整卡隔离，属检索随机性造成的
                        # 内容损失（实测 4 章隔离率 57%–80%）。核验标准不变——仍由
                        # quantity_issues 校验实体/期间/指标族/数值，错值照样绑不上。
                        card_pool = getattr(self, "_card_evidence_pool", None) or evidence_dict
                        bound = _bind_metric_card(
                            str(getattr(mc, "label", "") or ""), mc_value,
                            getattr(mc, "unit", None),
                            card_pool, set(card_pool),
                            _evidence_variants_cache(card_pool),
                        )
                        if bound:
                            mc.evidence_ids = bound
                        else:
                            # B31：派生值（净现比等）不在原始证据里，只在
                            # financial_ratios.calculations。命中后绑到它的两条
                            # 输入记录，读者仍可回溯，不用「derived:」伪 id。
                            if derived_cache is None:
                                derived_cache = verified_calculations(
                                    (context or {}).get("financial_ratios", []),
                                    card_pool, list(card_pool),
                                )
                            derived_bound = _bind_derived_metric_card(
                                str(getattr(mc, "label", "") or ""), mc_value,
                                getattr(mc, "unit", None), derived_cache,
                            )
                            if derived_bound:
                                mc.evidence_ids = [e for e in derived_bound if e in card_pool]
                            else:
                                # B32-D4：聚合卡（样本合计/中位数）——值在子集统计里，
                                # 不在任何单条记录。命中后绑到子集全部输入记录。
                                aggregate_bound = _bind_aggregate_metric_card(
                                    str(getattr(mc, "label", "") or ""), mc_value,
                                    getattr(mc, "unit", None),
                                    str(getattr(mc, "period", "") or ""),
                                    card_pool, (context or {}).get("financial_ratios"),
                                )
                                if aggregate_bound:
                                    mc.evidence_ids = [e for e in aggregate_bound if e in card_pool]
                    if mc_value and extract_numbers(mc_value) and not getattr(mc, "evidence_ids", None):
                        issues.append(
                            f"{section.section_id} 指标卡「{getattr(mc, 'label', '')}」数值缺少证据绑定"
                        )
                    if global_facts and global_facts.get("market_cap_wan_yi") and "市值" in mc.label:
                        cw = global_facts["market_cap_wan_yi"]
                        if "22.14" in str(mc.value):
                            mc.value = f"{cw}万亿"
                        elif "221411" in str(mc.value):
                            mc.value = f"{cw * 10000:.2f}"
            if section.comparison_table and getattr(section.comparison_table, "evidence_ids", None):
                _note_dropped("对比表 ", set(section.comparison_table.evidence_ids) - allowed)
                section.comparison_table.evidence_ids = [e for e in section.comparison_table.evidence_ids if e in allowed]
            # R4：对比表同样承载数值——行内含实质数字却无证据绑定，记为审计问题
            if section.comparison_table is not None:
                table_rows = getattr(section.comparison_table, "rows", None) or []
                table_eids = getattr(section.comparison_table, "evidence_ids", None) or []
                row_nums: list[str] = []
                for row in table_rows:
                    cells = row if isinstance(row, (list, tuple)) else (
                        list(row.values()) if isinstance(row, dict) else [row]
                    )
                    for cell in cells:
                        row_nums.extend(
                            n for n in extract_numbers(str(cell))
                            if not YEAR_OR_ORDINAL_RE.match(n.strip())
                        )
                if row_nums and not table_eids:
                    issues.append(
                        f"{section.section_id} 对比表数值缺少证据绑定"
                    )
            if section.callouts:
                for co in section.callouts:
                    if getattr(co, "evidence_ids", None):
                        _note_dropped("callout ", set(co.evidence_ids) - allowed)
                        co.evidence_ids = [e for e in co.evidence_ids if e in allowed]

        # Auto-attach any unattached charts designated for this chapter
        attached_cids = {cid for s in chapter.sections for cid in s.chart_ids}
        chapter_charts = [
            cid for cid, c in charts.items()
            if getattr(c, "recommended_chapter_id", None) == outline.chapter_id
        ]
        for cid in chapter_charts:
            if cid not in attached_cids:
                c_eids = set(getattr(charts[cid], "evidence_ids", []))
                best_sec = None
                best_overlap = -1
                for s in chapter.sections:
                    sec_eids = {e for p in s.paragraphs for e in p.evidence_ids}
                    overlap = len(c_eids & sec_eids)
                    if overlap > best_overlap:
                        best_overlap = overlap
                        best_sec = s
                if best_sec is not None:
                    best_sec.chart_ids.append(cid)
                    attached_cids.add(cid)

        # 图号只能挂在「证据相交且指标族对得上」的段落上；挂不上的从正文剥离，
        # 并把缺口写进 uncertainties，而不是无条件加一句「如图所示」。
        for section in chapter.sections:
            for cid in section.chart_ids:
                if not _align_chart_reference(section, cid, charts[cid]):
                    issues.append(f"{section.section_id} 图表解读缺少可核验证据")

        chapter.evidence_ids = list(dict.fromkeys(e for s in chapter.sections for p in s.paragraphs for e in p.evidence_ids))
        chapter.chart_ids = list(dict.fromkeys(c for s in chapter.sections for c in s.chart_ids))
        return list(dict.fromkeys(issues))

    def _fallback_chapter(
        self,
        request: ChapterWritingRequest,
        outline: Any,
        context: dict[str, Any],
        charts: dict[str, Any],
        global_facts: dict[str, Any] | None = None,
    ) -> ChapterDraft:
        evidence_by_id = context["evidence"]
        evidence_ids = list(evidence_by_id)
        universe = list(evidence_by_id.values())
        insights = context["insights"]
        chapters = []
        ch_charts = [
            c.chart_id
            for c in charts.values()
            if getattr(c, "recommended_chapter_id", None) == outline.chapter_id
        ]
        for index, section in enumerate(outline.sections):
            possible = [cid for i, cid in enumerate(ch_charts) if i % max(1, len(outline.sections)) == index][:1]
            chart_prefix = f"如图 [{possible[0]}] 所示，" if possible else ""
            chosen: list[str] = []
            base = ""
            if index < len(insights):
                insight = insights[index]
                claim = str(insight.get("conclusion") or insight.get("title") or "").strip()
                ids = insight.get("evidence_record_ids") or []
                if claim and ids and all(rid in evidence_by_id for rid in ids):
                    refs = [evidence_by_id[rid] for rid in ids]
                    if not quantity_issues(claim, refs, universe=universe):
                        base, chosen = claim, list(dict.fromkeys(ids))
            if not chosen:
                for eid in evidence_ids[index::3]:
                    item = evidence_by_id[eid]
                    period = measurement_period(item)
                    entity, unit, value = item.get("entity"), item.get("unit"), item.get("value")
                    if isinstance(value, str) and item.get("domain") in {"news", "reports", "events", "industry_chain"}:
                        excerpt = " ".join(value.split())
                        if excerpt and len(excerpt) <= 240:
                            claim = f"来源记载：{excerpt.rstrip('。')}。"
                            if not quantity_issues(claim, [item], universe=universe):
                                base, chosen = claim, [eid]
                                break
                    metric = metric_family(item.get("metric", ""))
                    label = next((term for term, key in CLAIM_METRICS.items()
                                  if key == metric and re.search(r"[\u4e00-\u9fff]", term)), None)
                    if (not period or not entity or not unit or not label or type(value) not in (int, float)
                            or item.get("scope", "consolidated") != "consolidated"
                            or item.get("currency", "CNY") != "CNY"
                            or any("conflict" in issue for issue in item.get("issues", []))):
                        continue
                    claim = f"{entity}截至{period[1].isoformat()}的{label}为{value}{unit}。"
                    if not quantity_issues(claim, [item], universe=universe):
                        base, chosen = claim + f"该数字是单期观察，判断{label}变化仍需核对同口径的前期数据。", [eid]
                        break
            text = chart_prefix + (base or f"“{section.title}”缺少可用于判断的直接证据。")
            chapters.append(
                SectionDraft(
                    section_id=section.section_id,
                    title=section.title,
                    purpose=section.purpose,
                    key_points=[],
                    paragraphs=[
                        ParagraphDraft(
                            paragraph_id=f"P-{outline.chapter_id[-2:]}-{index+1:02d}-01",
                            kind="chart_readout" if possible else "analysis",
                            text=text,
                            evidence_ids=chosen,
                        )
                    ],
                    chart_ids=possible,
                    uncertainties=[] if chosen else ["缺少与本节直接相关的可验证资料"],
                )
            )
        all_ids = list(dict.fromkeys(e for s in chapters for p in s.paragraphs for e in p.evidence_ids))
        chart_ids = list(dict.fromkeys(c for s in chapters for c in s.chart_ids))
        return ChapterDraft(
            chapter_id=outline.chapter_id,
            title=outline.title,
            summary=f"本章围绕{outline.title}整理现有证据，并明确资料边界。",
            sections=chapters,
            evidence_ids=all_ids,
            chart_ids=chart_ids,
            used_fallback=True,
        )

    def _audit_package(
        self,
        chapters: list[ChapterDraft],
        allowed: set[str],
        charts: dict[str, Any],
        global_facts: dict[str, Any] | None = None,
        evidence: dict[str, Any] | None = None,
    ) -> list[str]:
        issues = []
        if len(chapters) != 7:
            issues.append("报告不是7章")
        if sum(len(x.sections) for x in chapters) != 21:
            issues.append("报告不是21节")
        if len({x.chapter_id for x in chapters}) != len(chapters):
            issues.append("章节ID重复")

        # Single-Placement Lock: verify and enforce each chart appears in AT MOST ONE section across the entire report
        seen_cids: dict[str, tuple[str, str]] = {}
        for chapter in chapters:
            for section in chapter.sections:
                for para in section.paragraphs:
                    if set(para.evidence_ids) - allowed:
                        issues.append("存在未知证据引用")

                clean_cids = []
                for cid in section.chart_ids:
                    if cid not in charts:
                        issues.append(f"{section.section_id} 存在未就绪图表引用 {cid}")
                        drop_chart_tag_from_section(section, cid)
                        continue
                    chart_obj = charts[cid]
                    rec_ch = getattr(chart_obj, "recommended_chapter_id", None) or (
                        chart_obj.get("recommended_chapter_id") if isinstance(chart_obj, dict) else None
                    )
                    # If chart was explicitly recommended for another chapter, remove from here
                    if rec_ch and rec_ch != chapter.chapter_id:
                        drop_chart_tag_from_section(section, cid)
                        continue
                    # If chart was already placed elsewhere, enforce single placement
                    if cid in seen_cids:
                        drop_chart_tag_from_section(section, cid)
                        continue
                    seen_cids[cid] = (chapter.chapter_id, section.section_id)
                    clean_cids.append(cid)
                section.chart_ids = clean_cids
            chapter.chart_ids = list(dict.fromkeys(c for s in chapter.sections for c in s.chart_ids))

        # Ensure all ready charts designated for a chapter are placed in that chapter.
        # 空节必须显式处理：可以保留合法挂接，但不得访问 paragraphs[0]，也不补空壳图注。
        for cid, chart_obj in charts.items():
            rec_ch = getattr(chart_obj, "recommended_chapter_id", None) or (
                chart_obj.get("recommended_chapter_id") if isinstance(chart_obj, dict) else None
            )
            if rec_ch and cid not in seen_cids:
                target_ch = next((c for c in chapters if c.chapter_id == rec_ch), None)
                if target_ch and target_ch.sections:
                    chart_evidence = set(getattr(chart_obj, "evidence_ids", []) or [])
                    target_sec = max(
                        target_ch.sections,
                        key=lambda s: chart_section_score(s, chart_evidence),
                        default=None,
                    )
                    if target_sec is None:
                        continue
                    target_sec.chart_ids.append(cid)
                    target_ch.chart_ids = list(dict.fromkeys(c for s in target_ch.sections for c in s.chart_ids))
                    seen_cids[cid] = (target_ch.chapter_id, target_sec.section_id)

        # 已挂图但全节没有实际论述（空节或只剩隔离句）：保留合法挂接，记录解读缺口。
        for chapter in chapters:
            for section in chapter.sections:
                for cid in section.chart_ids:
                    if not _align_chart_reference(section, cid, charts[cid]):
                        issues.append(f"{section.section_id} 图表解读缺少可核验证据")

        # Cross-chapter market cap consistency audit
        mc_values = []
        for ch in chapters:
            for sec in ch.sections:
                for p in sec.paragraphs:
                    for m in re.finditer(r"(\d+(?:\.\d+)?)\s*万亿", p.text):
                        val = float(m.group(1))
                        if val > 0.05:
                            mc_values.append((ch.chapter_id, val))
        if mc_values:
            vals = [v for _, v in mc_values]
            if max(vals) > min(vals) * 3.0:
                issues.append(f"跨章节总市值存在量级冲突：最高 {max(vals)} 万亿，最低 {min(vals)} 万亿")

        # 跨章同键结论只报告、不改正文；是否阻断由 A5 按严重级别决定。
        _cross_chapter_claim_audit(chapters, evidence)

        return list(dict.fromkeys(issues))
