"""Small shared contracts for reporting periods and comparable observations.

Publication/retrieval dates never substitute for a financial measurement period.
"""
from __future__ import annotations

from collections import defaultdict
from collections.abc import Callable
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
import math
import re
from typing import Any


# ── 金额单位（唯一真值表）─────────────────────────────────────────────────
# P-01：金额单位必须按**完整单位**解析，不能靠子串包含。
# 旧实现 `if "万" in u` 先于「百」分支命中，导致「百万元」被当成「万元」（差 100 倍）、
# 「千万元」同样被当成「万元」（差 1000 倍）；「万亿元」则被「亿」分支吃掉（差 1 万倍）。
# 这里以元为基准维护显式倍率表，所有模块（A1 解析 / A2 归一 / A3 轴单位）共用同一份。
MONEY_UNIT_SCALES: dict[str, int] = {
    '元': 1,
    '千元': 1_000,
    '万元': 10_000,
    '百万元': 1_000_000,
    '千万元': 10_000_000,
    '亿元': 100_000_000,
    '万亿元': 1_000_000_000_000,
}
# 兼容旧数据/旧别名：不带"元"字的量级后缀、以及纯币种标记。
_MONEY_ALIAS_SCALES: dict[str, int] = {
    '万': 10_000,
    '亿': 100_000_000,
    '万亿': 1_000_000_000_000,
}
_MONEY_CURRENCY_TOKENS = frozenset({'人民币', 'cny', 'rmb', '¥', '元人民币', '人民币元'})
_MONEY_PREFIX_SCALES: dict[str, int] = {
    '万亿': 10**12, '亿': 10**8, '百万': 10**6, '千万': 10**7, '万': 10**4, '千': 10**3,
}
_MONEY_UNKNOWN_TOKENS = frozenset({'unknown', 'legacy_unknown', 'none', 'nan', 'null', '-'})


def normalize_money_unit(unit: Any) -> str | None:
    """把来源单位清洗成标准金额单位；无法识别一律返回 None（不按量级猜）。

    仅做**结构化**解析（币种标记 + 量级前缀 + 元），不做任意子串包含匹配：
    「百万元/千万元/万亿元」必须整体识别，避免再次被「万」「亿」截获。
    """
    if unit is None:
        return None
    text = str(unit).strip().replace(' ', '').replace('\u3000', '')
    if not text:
        return None
    if text.casefold() in _MONEY_UNKNOWN_TOKENS:
        return None
    if text in MONEY_UNIT_SCALES:
        return text
    if text in _MONEY_ALIAS_SCALES:
        return text
    low = text.casefold()
    if low in _MONEY_CURRENCY_TOKENS or text in _MONEY_CURRENCY_TOKENS:
        return '元'
    core = low
    for token in ('人民币', 'cny', 'rmb', '¥'):
        core = core.replace(token, '')
    if core in {'', '元'}:
        return '元'
    match = re.fullmatch(r'(万亿|亿|百万|千万|万|千)?(?:元)?', core)
    if match and match.group(1):
        prefix = match.group(1)
        if prefix in _MONEY_PREFIX_SCALES:
            # 反查等价的标准单位名（保证「万」→「万元」这类别名落到同一键）。
            for name, scale in MONEY_UNIT_SCALES.items():
                if scale == _MONEY_PREFIX_SCALES[prefix]:
                    return name
    return None


def money_scale(unit: Any) -> int | None:
    """返回该金额单位相对「元」的倍率；不可识别返回 None。"""
    name = normalize_money_unit(unit)
    if name is None:
        return None
    if name in MONEY_UNIT_SCALES:
        return MONEY_UNIT_SCALES[name]
    return _MONEY_ALIAS_SCALES.get(name)


def money_to_yuan(value: Any, unit: Any) -> Decimal | None:
    """金额还原到「元」（Decimal，避免浮点误差）；单位不可信返回 None。"""
    scale = money_scale(unit)
    if scale is None or value is None:
        return None
    try:
        if isinstance(value, bool):
            return None
        return Decimal(str(value)) * Decimal(scale)
    except (InvalidOperation, ValueError, TypeError):
        return None


def money_to_yi(value: Any, unit: Any) -> Decimal | None:
    """金额换算到「亿元」（项目 A2 的统一金额基准）。"""
    yuan = money_to_yuan(value, unit)
    if yuan is None:
        return None
    return yuan / Decimal(100_000_000)


def convert_unit_value(value: Any, source_unit: Any, target_unit: Any) -> float:
    """Convert only explicitly compatible units, shared by chart and prose audits."""
    number = float(value)
    if isinstance(value, bool) or not math.isfinite(number):
        raise ValueError("non-finite quantity")
    source, target = str(source_unit or '').strip(), str(target_unit or '').strip()
    if source == target:
        return number
    source_money, target_money = money_scale(source), money_scale(target)
    if source_money is not None and target_money is not None:
        return float(Decimal(str(value)) * source_money / target_money)
    for scales in (
        {'辆': 1, '万辆': 10_000, '亿辆': 100_000_000},
        {'台': 1, '万台': 10_000, '亿台': 100_000_000},
        {'套': 1, '万套': 10_000, '亿套': 100_000_000},
        {'吨': 1, '万吨': 10_000},
        {'%': 1, '％': 1, '百分比': 1},
        {'kWh': 1, 'MWh': 1_000, 'GWh': 1_000_000},
        {'kW': 1, 'MW': 1_000, 'GW': 1_000_000},
    ):
        if source in scales and target in scales:
            return float(Decimal(str(value)) * scales[source] / scales[target])
    raise ValueError(f"incompatible units: {source!r} -> {target!r}")


def choose_display_money_unit(values: list[Any], units: list[Any]) -> str:
    """按同轴全部可绘点的**规范金额**（元）选唯一展示单位（P-14）。

    规则与 A3 各路径共用：先还原到元，再按最大绝对值选 亿元 / 万元 / 元。
    没有任何可信单位时返回空串（不可比较），不按数值量级猜。
    """
    base_values: list[float] = []
    for value, unit in zip(values, units):
        scale = money_scale(unit)
        if scale is None:
            continue
        try:
            if isinstance(value, bool):
                continue
            base_values.append(abs(float(value)) * scale)
        except (TypeError, ValueError):
            continue
    if not base_values:
        return ''
    maximum = max(base_values)
    if maximum >= 1e8:
        return '亿元'
    if maximum >= 1e4:
        return '万元'
    return '元'


_CHART_REFERENCE = re.compile(r"\[CHART-[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*\]")
_EVIDENCE_HASH = re.compile(r"(?<![A-Za-z0-9_])R-[0-9a-f]{12,64}(?![A-Za-z0-9_])", re.IGNORECASE)


def mask_chart_references(text: str) -> str:
    """Ignore chart identifiers during fact checks while preserving offsets."""
    return _CHART_REFERENCE.sub(lambda match: " " * len(match.group()), text)


_ISO_DATE = re.compile(r'(?<!\d)((?:19|20)\d{2}-\d{2}-\d{2})(?!\d)')
_NAMED_PERIOD = re.compile(r'(20\d{2})(?:年|-\d{2}-\d{2})')
# 与上方 MONEY_UNIT_SCALES 同源（2026-11-15 分支合并统一）。旧表缺千元/百万元/
# 千万元，导致这三类来源单位在 _display_value / 变化换算处直接不可换算——同一份
# 报告里「1 亿元」能核、「500 百万元」不能核。走同一真值表后行为只是**增**：
# 原本可换算的单位换算结果不变。
_MONEY_SCALES = dict(MONEY_UNIT_SCALES)


REPORT_BASIS_LABELS = {
    "annual": "年度", "consolidated": "合并报表", "parent": "母公司报表",
    "half_year": "半年度", "quarter": "单季度", "ytd_q3": "前三季度",
    "rate_observation_change": "比率观测值变化",
}


# 检索/抓取通道的元数据字段不是业务指标：取值是分词标记、内部序号或引擎统计量
# （status=0、site_authority=3、traceability_type=0）。它们一旦进入图表，读者看到的
# 就是「低空经济 site_authority 趋势」这类看不懂的曲线，等同于报告出错；进入证据索引
# 则会把「引擎标记」当一个事实来背书。图表层与证据层统一按本名单剔除。
# report_fusion 自带的黑名单是本集合的子集（历史各自维护），口径以本模块为准。
META_ONLY_METRICS = frozenset({
    "summary", "title", "extra", "index", "name", "status", "source_original",
    "traceability_type", "trace_info", "site_authority", "operation_type",
    "index_time", "modify_time", "publish_time", "publish_date", "data_version",
    "publish_source", "real_publish_source", "host_name", "org_id", "data_source",
    "entity_identity", "doc_type", "channel", "uid", "para_index", "score",
    "content", "url", "id", "iwc_index_report_v5_vector", "robot_universal_search",
})


def is_meta_only_metric(metric: Any) -> bool:
    """该 metric 是否为检索通道元数据（不能当业务指标出图或作证据）。"""
    return str(metric or "").strip().lower() in META_ONLY_METRICS


def format_report_rate(value: Any, unit: str) -> str:
    try:
        number = Decimal(str(value).strip().replace(",", ""))
        rounded = number.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    except InvalidOperation:
        return f"{value}{unit}"
    if not number.is_finite():
        return f"{value}{unit}"
    if number and not rounded:
        prefix = "负值，绝对值" if number < 0 else ""
        return f"{prefix}小于0.01{unit}"
    return f"{rounded:.2f}{unit}"


def _valid_iso_dates(text: str) -> list[tuple[int, int, date]]:
    dates = []
    for match in _ISO_DATE.finditer(text):
        try:
            dates.append((match.start(), match.end(), date.fromisoformat(match.group(1))))
        except ValueError:
            pass
    return dates


def _rate_points(value: float, unit: str) -> float | None:
    if unit.strip().lower() in ('%', '％', '百分比', 'percent', 'percentage'):
        return value
    if unit.strip().lower() in ('ratio', '0-1'):
        return value * 100
    return None


def period_shape(end: date | None, label: str = '', *, point: bool = False) -> dict[str, Any]:
    if end is None:
        return dict(period_start=None, period_type='unknown')
    if point:
        return dict(period_start=end, period_type='point')
    if '单季' in label or '当季' in label:
        month = ((end.month - 1) // 3) * 3 + 1
        return dict(period_start=date(end.year, month, 1), period_type='quarter')
    if '累计' in label and end.month not in (3, 6, 9, 12):
        return dict(period_start=date(end.year, 1, 1), period_type='ytd_month')
    kinds = {(12, 31): 'annual', (9, 30): 'ytd_q3', (6, 30): 'half_year', (3, 31): 'q1'}
    kind = kinds.get((end.month, end.day), 'month')
    if '累计' in label:
        # 年末累计值就是全年值；只有 3/6/9 月末的累计值才是年内累计。
        kind = _cumulative_kind(end)
    return dict(period_start=date(end.year, 1 if kind != 'month' else end.month, 1), period_type=kind)


def source_report_period(text: str) -> date | None:
    """Only an explicitly named report, not an announcement date in surrounding text."""
    hits = re.findall(r'(20\d{2})年?\s*(三季报|前三季度|一季报|第一季度|中报|半年报|半年度|年报|年度报告)', text)
    periods = {date(int(y), *({'三季报': (9, 30), '前三季度': (9, 30),
                '一季报': (3, 31), '第一季度': (3, 31), '中报': (6, 30),
                '半年报': (6, 30), '半年度': (6, 30), '年报': (12, 31),
                '年度报告': (12, 31)}[tag])) for y, tag in hits}
    return next(iter(periods)) if len(periods) == 1 else None


# ── 期间口径（标签优先于频率字段）────────────────────────────────────────
# P0-1：期间证据优先级。来源明确的期间字段/标签 > 日期形状推导。
# 这里的别名只覆盖**期间限定词**，不把「当月值」当成指标名的一部分。
_PERIOD_KIND_ALIASES = {
    'annual': 'annual', 'year': 'annual', '年': 'annual', '年度': 'annual',
    '全年': 'annual', '年报': 'annual',
    'half_year': 'half_year', '半年': 'half_year', '半年度': 'half_year', '中报': 'half_year',
    'quarter': 'quarter', '季': 'quarter', '季度': 'quarter', '单季': 'quarter', '当季': 'quarter',
    'q1': 'q1', '一季度': 'q1', '第一季度': 'q1',
    'ytd_q3': 'ytd_q3', '前三季度': 'ytd_q3', '三季报': 'ytd_q3',
    'ytd_month': 'ytd_month', '累计': 'ytd_month',
    'month': 'month', '月': 'month', '月度': 'month', '当月': 'month', '当月值': 'month',
    'point': 'point', '日': 'point', '时点': 'point',
}
_PERIOD_YEAR_START_KINDS = frozenset({'annual', 'half_year', 'ytd_q3', 'q1', 'ytd_month'})


def normalize_period_kind(value: Any) -> str | None:
    """把来源期间字段（周期/期间类型/中文标签）归一为期间枚举；不识别返回 None。"""
    if value in (None, ''):
        return None
    return _PERIOD_KIND_ALIASES.get(str(value).strip().casefold())


def period_start_for(kind: str, end: date) -> date | None:
    """按期间类型给出共同起点；unknown 不推导。"""
    if kind in _PERIOD_YEAR_START_KINDS:
        return date(end.year, 1, 1)
    if kind == 'quarter':
        return date(end.year, ((end.month - 1) // 3) * 3 + 1, 1)
    if kind == 'month':
        return date(end.year, end.month, 1)
    if kind == 'point':
        return end
    return None


def _date_shape_kind(end: date) -> str:
    return {(12, 31): 'annual', (9, 30): 'ytd_q3', (6, 30): 'half_year', (3, 31): 'q1'}.get(
        (end.month, end.day), 'month'
    )


def _cumulative_kind(end: date | None) -> str:
    # 年末累计 = 全年；其余月份的累计值仍是年内累计（保留既有 ytd_month 语义）。
    if end is not None and (end.month, end.day) == (12, 31):
        return 'annual'
    return 'ytd_month'


def label_period_kind(label: str, end: date | None) -> str | None:
    """从指标名/字段名里的期间限定词读出期间类型。

    `周期=月` 描述的是序列频率；`累计值` 才是期间口径。因此标签优先于频率字段：
    动力电池「合计:累计值」在 12/31 仍是全年累计，不能被降成单月。
    """
    text = str(label or '').strip().casefold()
    if not text:
        return None
    if '当月值' in text or '当月' in text or '月度' in text:
        return 'month'
    if '累计值' in text or '累计' in text or '年累计' in text:
        return _cumulative_kind(end)
    if '单季' in text or '当季' in text:
        return 'quarter'
    if '年度值' in text or '全年' in text or '年度' in text or '年报' in text:
        # 只有年末才可能是全年；其它月份的年累计按 ytd_month 处理。
        return 'annual' if end is not None and (end.month, end.day) == (12, 31) else 'ytd_month'
    return None


def resolve_source_period(
    end: date | None,
    label: str = '',
    *,
    source_period: Any = None,
    explicit_type: Any = None,
    explicit_start: Any = None,
    point: bool = False,
) -> tuple[dict[str, Any], bool]:
    """A1/A2/A3 共用的期间解析。返回 (qualifiers, period_conflict)。

    优先级：显式期间类型 > 指标标签 > 来源周期字段 > 日期形状。
    显式期间字段与标签指向不同区间时判为冲突，记录仍保留原值但退出量化核验。
    """
    if end is None:
        return dict(period_start=None, period_type='unknown'), False
    if point:
        return dict(period_start=end, period_type='point'), False
    explicit_kind = normalize_period_kind(explicit_type)
    label_kind = label_period_kind(label, end)
    source_kind = normalize_period_kind(source_period)
    conflict = False
    if explicit_kind and label_kind:
        conflict = period_start_for(explicit_kind, end) != period_start_for(label_kind, end)
    chosen = explicit_kind or label_kind or source_kind or _date_shape_kind(end)
    start = period_start_for(chosen, end)
    parsed_start = _parse_loose_date(explicit_start)
    if parsed_start is not None:
        if chosen != 'unknown' and start is not None and parsed_start != start:
            conflict = True
        else:
            start = parsed_start
    return dict(period_start=start, period_type=chosen), conflict


def _parse_loose_date(value: Any) -> date | None:
    if value in (None, ''):
        return None
    text = str(value).strip()
    try:
        return date.fromisoformat(text[:10])
    except ValueError:
        return None


def measurement_period(value: Any) -> tuple[date, date, str] | None:
    data = _as_dict(value)
    raw_end = data.get("period_end") or data.get("period")
    if not raw_end or "period_conflict" in (data.get("issues") or []):
        return None
    try:
        end = date.fromisoformat(str(raw_end)[:10])
        kind = data.get("period_type") or "unknown"
        shape = period_shape(end, "单季" if kind == "quarter" else "", point=kind == "point")
        if kind == "unknown":
            kind = shape["period_type"]
        raw_start = data.get("period_start")
        start = date.fromisoformat(str(raw_start)[:10]) if raw_start else shape["period_start"]
        expected_ends = {"annual": (12,31), "half_year": (6,30), "ytd_q3": (9,30), "q1": (3,31)}
        if kind in expected_ends and (end.month, end.day) != expected_ends[kind]:
            return None
        if start > end:
            return None
        return start, end, kind
    except (TypeError, ValueError):
        return None


def comparable_key(record: Any, *, include_year: bool = True) -> tuple | None:
    period = measurement_period(record)
    if period is None:
        return None
    start, end, kind = period
    data = _as_dict(record)
    return (end if include_year else (end.month, end.day), kind,
            start if include_year else (start.month, start.day),
            data.get("scope", "consolidated"), data.get("currency", "CNY"))


def verified_calculations(rows: list[dict], index: dict[str, Any], allowed_ids: list[str]) -> list[dict]:
    """Only recalculate declared formulas using the same entity and full duration."""
    import math
    observations = []
    for row in rows:
        for metric, calc in (row.get("calculations") or {}).items():
            ids = calc.get("input_record_ids") or []
            if len(ids) != 2 or not set(ids).issubset(allowed_ids) or any(rid not in index for rid in ids):
                continue
            a, b = (_as_dict(index[rid]) for rid in ids)
            entity = a.get("entity") or a.get("entity_name")
            if not entity or entity != (b.get("entity") or b.get("entity_name")) or row.get("company") != entity:
                continue
            pa, pb = measurement_period(a), measurement_period(b)
            if pa is None or pa != pb or a.get("scope", "consolidated") != b.get("scope", "consolidated") or a.get("currency", "CNY") != b.get("currency", "CNY"):
                continue
            formula = {
                "cash_to_net_profit": ("operating_cash_flow", "parent_net_profit", 1, "倍"),
                "rd_ratio": ("rd_expense", "revenue", 100, "%"),
            }.get(metric)
            if formula is None:
                continue
            numerator, denominator, multiplier, unit = formula
            expected = f"{numerator}/{denominator}" + ("*100" if multiplier == 100 else "")
            if (calc.get("formula") != expected or metric_family(a.get("metric", "")) != numerator
                    or metric_family(b.get("metric", "")) != denominator):
                continue
            try:
                scales = {"元": 1, "万元": 1e4, "亿元": 1e8, "CNY": 1, "RMB": 1}
                base = float(b["value"]) * scales[b["unit"]]
                if not math.isfinite(base) or base <= 0 or (metric == "cash_to_net_profit" and base < 5e6):
                    continue
                value = float(a["value"]) * scales[a["unit"]] / base * multiplier
            except (TypeError, ValueError, ZeroDivisionError, KeyError):
                continue
            if not math.isfinite(value):
                continue
            observations.append(dict(record_id="derived:" + "/".join(ids), entity=entity,
                metric=metric, value=value, unit=unit, period=str(pa[1]), period_start=str(pa[0]),
                period_type=pa[2], scope=a.get("scope", "consolidated"), currency=a.get("currency", "CNY")))
    return observations


def financial_calculation_rows(ratios: list[dict], comps: dict | None) -> list[dict]:
    """Keep the A2 formulas attached to their operands through both text gates."""
    rows = list(ratios)
    for entry in (comps or {}).get("entries") or []:
        if not isinstance(entry, dict):
            continue
        calculation = (entry.get("metric_provenance") or {}).get("net_margin")
        if isinstance(calculation, dict) and calculation.get("input_record_ids"):
            rows.append({"company": entry.get("company_name"), "calculations": {"net_margin": calculation}})
    return rows


def covered_data_gap_filter(index: dict[str, Any], coverage_rows: list[dict],
                            ratios: list[dict]) -> Callable[[str], str]:
    """Build a filter for missing-data statements contradicted by verified source records."""
    coverage = {row["requirement_id"]: row for row in coverage_rows
                if row.get("requirement_id") and row.get("passed")}
    segment_ids = coverage.get("business_composition", {}).get("evidence_record_ids", [])
    segment_complete = bool(segment_ids) and all(
        rid in index and (ref := _as_dict(index[rid])).get("skill_id") == "official-segment"
        and ref.get("segment_name") and ref.get("source_url") and ref.get("value") is not None
        for rid in segment_ids
    )
    ratio_entities = {
        item["entity"] for item in verified_calculations(ratios, index, list(index))
        if item["metric"] == "rd_ratio"
    }
    all_entities = {
        str(ref.get("entity") or ref.get("entity_name")) for value in index.values()
        if (ref := _as_dict(value)).get("entity") or ref.get("entity_name")
    }

    def keep(sentence: str) -> bool:
        if (segment_complete and re.search(r"主营业务构成|分产品(?:收入|构成)", sentence)
                and re.search(r"未在.{0,12}提供|未提供.{0,8}(?:构成明细|分产品数据)|没有.{0,8}构成明细", sentence)):
            return bool(re.search(r"历史|其他年度|资本化|分部利润|供应商|地区", sentence))
        if "研发" not in sentence:
            return True
        if limited := re.search(r"研发(?:强度|费用率).{0,8}(?:仅|只能)([^。；;，,]+)(?:可计算|可核验)", sentence):
            named = {name for name in ratio_entities if name in limited[1]}
            if named and ratio_entities - named:
                return False
        if re.search(r"研发(?:费用|投入).{0,16}(?:未.{0,8}提供|缺失|无可用)", sentence):
            named = {name for name in all_entities if len(name) >= 3 and name in sentence}
            if named and named <= ratio_entities and not re.search(r"资本化|分部|季度|历史", sentence):
                return False
        return True

    return lambda text: retain_supported_claims(text, keep)


def claim_period_matches(context: str, ref: dict, year: int | None, family: str | None) -> bool:
    period = measurement_period(ref)
    qualifiers = r"全年|年度|年报|上半年|半年度|中报|半年报|前三季度|三季报|第一季度|一季度|一季报|第二季度|第三季度|第四季度|单季|当季"
    if period is None:
        flow = metric_family(str(ref.get("metric", ""))) in ("revenue", "parent_net_profit", "net_profit", "operating_cash_flow", "gross_margin", "net_margin", "revenue_yoy", "net_profit_yoy", "cash_to_net_profit")
        return not (flow or year or re.search(qualifiers, context))
    start, end, kind = period
    named = list(_NAMED_PERIOD.finditer(context))
    claimed_date = None
    if named:
        last = named[-1]
        year = int(last.group(1))
        if '-' in last.group(0):
            try:
                claimed_date = date.fromisoformat(last.group(0))
            except ValueError:
                return False
            if end != claimed_date:
                return False
    if year and end.year != year:
        return False
    # The latest explicit ISO date/year scopes this observation's duration.
    label = context[named[-1].end():] if named else context
    quarter_match = re.search(r"第?([一二三四1-4])季度", label)
    quarter = ("一二三四".find(quarter_match.group(1)) + 1 if quarter_match and quarter_match.group(1) in "一二三四" else int(quarter_match.group(1)) if quarter_match else None)
    if re.search(r"前三季度|三季报", label):
        return (start.month,start.day,end.month,end.day) == (1,1,9,30) and kind != "quarter"
    if re.search(r"上半年|半年度|中报|半年报", label):
        return (start.month,start.day,end.month,end.day) == (1,1,6,30) and kind != "quarter"
    if "一季报" in label:
        return (start.month,start.day,end.month,end.day) == (1,1,3,31)
    if quarter:
        month = (quarter-1)*3+1
        final_month = quarter*3
        final_day = 30 if quarter in (2,3) else 31
        return (start.month,start.day,end.month,end.day) == (month,1,final_month,final_day)
    if re.search(r"单季|当季", label):
        return kind in ("quarter","q1")
    if re.search(r"全年|年度|年报", label):
        return kind == "annual" and (start.month,start.day,end.month,end.day) == (1,1,12,31)
    # A bare financial year denotes the full year, unless an explicit cutoff date is supplied.
    flow = family in ("revenue","parent_net_profit","net_profit","operating_cash_flow","gross_margin","net_margin","revenue_yoy","net_profit_yoy","cash_to_net_profit")
    if year and flow and claimed_date is None and not re.search(r"截至|截止|年初至今|\d{1,2}月", label):
        return kind == "annual"
    return True


# B33：formula 写法 → 指标族。与 `financial_ratios.calculations` 里的
# formula 字段（B27 派生通道）配套——calculations 的 key 是 canonical 名
# （rd_ratio / cash_to_net_profit），而报告正文/卡片写的是中文 formula。
# **只收含「/」的比率写法**（枚举白名单）：「/」不会出现在普通指标词里，
# 子串匹配安全；毛利率/净利率等普通词已在 aliases 精确表，进子串表反而
# 会误吃「净利率同比增长率」这类复合词（把变化值当水平值放行）。
_FORMULA_FAMILY_ALIASES = {
    "研发费用/营业收入": "rd_ratio",
    "研发费用/营收": "rd_ratio",
    "研发投入/营业收入": "rd_investment_ratio",
    "研发投入/营收": "rd_investment_ratio",
    "经营活动现金流/归母净利润": "cash_to_net_profit",
    "经营活动现金流/净利润": "cash_to_net_profit",
    "经营现金流/归母净利润": "cash_to_net_profit",
    "经营现金流/净利润": "cash_to_net_profit",
    "经营性现金流/净利润": "cash_to_net_profit",
}


def _compact_metric(text: str) -> str:
    """去掉全部空白（含全角空格 U+3000）。

    供应商字段名常带空格（问财返回「研发费用 / 营业收入」，而别名表登记的是
    紧凑写法「研发费用/营业收入」），英文别名（revenue growth）也要容忍多余
    空格。查表时两侧统一按本函数比较。
    """
    return re.sub(r"\s+", "", text)


def metric_family(metric: str) -> str:
    """Exact aliases. In particular dynamic PE is never TTM, float cap never total."""
    key = re.sub(r'[\[［].*?[\]］]', '', metric).strip().casefold()
    aliases = {
        '最新市盈率ttm': 'pe_ttm', '市盈率ttm': 'pe_ttm', '市盈率(ttm)': 'pe_ttm',
        '最新动态市盈率': 'pe_dynamic', '动态市盈率': 'pe_dynamic', '市盈率(动)': 'pe_dynamic',
        '最新静态市盈率': 'pe_lyr', '静态市盈率': 'pe_lyr', '市盈率(静)': 'pe_lyr',
        '净利润': 'net_profit', '营业收入同比增长率': 'revenue_yoy', '归母净利润同比增长率': 'net_profit_yoy', '营业收入': 'revenue', '营业总收入': 'revenue', '营收': 'revenue',
        # B38（2026-11-11 SEMI-Q2 实测）：增速族近义词归一。LLM 指标需求给的
        # metric_terms 是自然语言变体（收入同比增长率/营收增速/收入增速/
        # revenue growth），而数据记录 canonical 名是 revenue_yoy——此前四词
        # 全不在表内，族匹配永假，「数据齐备仍判必需缺口」硬阻塞。精确别名
        # 整词匹配，不误吃「净利率同比增长率」类复合词（B33 教训保持）。
        '收入同比增长率': 'revenue_yoy', '营业收入增速': 'revenue_yoy',
        '收入增速': 'revenue_yoy', '营收增速': 'revenue_yoy',
        '营收同比增长率': 'revenue_yoy', 'revenue growth': 'revenue_yoy',
        'revenue growth rate': 'revenue_yoy', '营收同比增长': 'revenue_yoy',
        '净利润同比增长率': 'net_profit_yoy', '净利润增速': 'net_profit_yoy',
        '归母净利润增速': 'net_profit_yoy', '净利增速': 'net_profit_yoy',
        'net profit growth': 'net_profit_yoy',
        '归母净利润': 'parent_net_profit', '归属于母公司股东的净利润': 'parent_net_profit',
        '归属于母公司所有者的净利润': 'parent_net_profit',
        '经营活动产生的现金流量净额': 'operating_cash_flow', '经营现金流': 'operating_cash_flow',
        '研发费用': 'rd_expense', '研发投入': 'rd_investment', '研发费用率': 'rd_ratio',
        # 供应商（问财）返回的字段名是「研发支出」，语义等于研发投入合计
        # （含费用化与资本化）；不映射会让年度研发需求判 metric_mismatch，
        # 数据明明取到了却仍算未覆盖（SEMI-Q1 实测 12/12 全红）。
        '研发支出': 'rd_investment', '研发支出合计': 'rd_investment',
        '研发投入合计': 'rd_investment',
        '研发费用占营业收入的比例': 'rd_ratio', '研发投入占营业收入比例': 'rd_investment_ratio',
        '研发投入占比': 'rd_investment_ratio',
        # 「研发强度」是比率口径，不是金额：默认按研发费用率、按投入口径则归
        # 研发投入占比。三档分开，避免用研发金额画强度图（SEMI-F2）。
        '研发强度': 'rd_ratio', '研发费用占比': 'rd_ratio',
        '研发投入强度': 'rd_investment_ratio', '研发投入占营收比': 'rd_investment_ratio',
        '光伏新增装机量': 'pv_new_capacity', '中国光伏新增装机量': 'pv_new_capacity',
        '中国光伏新增装机容量': 'pv_new_capacity', '光伏新增装机容量': 'pv_new_capacity',
        '新增光伏装机容量': 'pv_new_capacity',
        '新能源汽车销量': 'nev_sales', '中国新能源汽车销量': 'nev_sales',
        '新能源汽车:销量:累计值': 'nev_sales', '新能源汽车：销量：累计值': 'nev_sales',
        '新能源汽车:销量:汽车:纯电动:累计值': 'bev_sales',
        '新能源汽车:销量:汽车:插电式混合动力:累计值': 'phev_sales',
        '纯电动汽车销量': 'bev_sales', '纯电动销量': 'bev_sales', '纯电销量': 'bev_sales',
        '插电式混合动力汽车销量': 'phev_sales', '插混汽车销量': 'phev_sales', '插混销量': 'phev_sales',
        '市场渗透率': 'nev_penetration', '新能源汽车市场渗透率': 'nev_penetration',
        '中国新能源汽车市场渗透率': 'nev_penetration',
        '经营活动现金流净额': 'operating_cash_flow',
        '经营活动现金流量净额': 'operating_cash_flow',
        '销售毛利率': 'gross_margin', '毛利率': 'gross_margin',
        '销售净利率': 'net_margin', '净利率': 'net_margin',
        '资产负债率': 'debt_ratio', '负债率': 'debt_ratio',
        'debt to asset ratio': 'debt_ratio', 'debt ratio': 'debt_ratio',
        '最新总市值': 'market_cap', '总市值': 'market_cap',
        '最新a股流通市值': 'circulating_market_cap', 'a股流通市值': 'circulating_market_cap',
        '流通市值': 'circulating_market_cap',
        # SEMI-F4：国产化率类独立成族，媒体/事件/行情等无关同值百分比不得为其背书。
        '国产化率': 'localization_rate', '国产替代率': 'localization_rate',
        '自主可控率': 'localization_rate', '本地化率': 'localization_rate',
        '国产化比例': 'localization_rate', '国产替代比例': 'localization_rate',
        '国产化程度': 'localization_rate', '国产设备市占率': 'localization_rate',
    }
    if key in aliases:
        return aliases[key]
    # B47（2026-11-11 SEMI-N1 实测）：指标名**内部**空白不归一会让族判定退化为
    # 原字符串——数据里是「研发费用 / 营业收入」（斜杠两侧带空格），别名表登记
    # 「研发费用/营业收入」，于是精确表不中、formula 子串也不中，需求
    # `rd_expense_ratio_series` 误报「缺少指标组」。两侧统一去空白比较即可，
    # 语义不变、也不引入通用子串匹配（B33 教训：不能让「营业收入」吃掉
    # 「营业收入同比增长率」）。
    compact = _compact_metric(key)
    if compact != key:
        for alias_key, family in aliases.items():
            if _compact_metric(alias_key) == compact:
                return family
    # B33：formula 写法的**子串**别名（含「/」的比率表达）。卡片 label 常带
    # 实体名/期间前缀（「中微公司研发费用/营业收入（2026前三季度）」），精确
    # 匹配不到，导致 `financial_ratios.calculations.rd_ratio` 里精确存在的值
    # 接不进派生绑定通道（Q1 实测 6 张比率卡全隔离 → 整题 blocked）。
    # 只收枚举白名单、不做通用子串匹配——否则「营业收入」会误吃
    # 「营业收入同比增长率」（上面的精确命中不受影响）。
    for formula, family in _FORMULA_FAMILY_ALIASES.items():
        if formula in key or (compact != key and _compact_metric(formula) in compact):
            return family
    # 「国产化率（按金额）」「市盈率(动)」一类尾部括号注记：整词未命中时
    # 剥掉尾部括号再试一次（不影响上面显式登记的括号别名）。
    stripped = re.sub(r'[（(][^）)]*[）)]\s*$', '', key).strip()
    if stripped in aliases:
        return aliases[stripped]
    if compact != key:
        compact_stripped = _compact_metric(stripped)
        for alias_key, family in aliases.items():
            if _compact_metric(alias_key) == compact_stripped:
                return family
    return key


def chart_comparability_issues(refs: list[Any], *, temporal: bool) -> list[str]:
    """Check observed measurement contracts before selection and again at delivery."""
    if not refs:
        return []
    rows = [_as_dict(ref) for ref in refs]
    problems = []
    if any("review_excluded" in (row.get("issues") or []) for row in rows):
        problems.append("存在人工核对后未采用的来源记录，不能用于图表")
    if any(measurement_period(row) is None for row in rows):
        problems.append("缺少有效观测期间，只能作为受限资料展示，不能正式比较")
    groups: dict[str, list[dict]] = {}
    for row in rows:
        groups.setdefault(metric_family(str(row.get("metric") or "")), []).append(row)
    for records in groups.values():
        if len({r.get("scope", "consolidated") for r in records}) > 1 or len({r.get("currency", "CNY") for r in records}) > 1:
            problems.append("比较样本的测量范围或币种不一致")
        periods = {measurement_period(r) for r in records if measurement_period(r) is not None}
        if temporal:
            shapes = {("point",) if kind == "point" else
                      ("quarter", 3) if kind in ("quarter", "q1") else
                      (kind, (end.year - start.year) * 12 + end.month - start.month + 1, start.day)
                      for start, end, kind in periods}
            if len(shapes) > 1:
                problems.append("时间序列混合不同长度或定义的报告期间")
        elif len({r.get("entity") or r.get("entity_name") for r in records}) > 1:
            # B49（2026-11-11 低空 run 实测）：原判据是「多实体 + 多期间 → 不可比」，
            # 把合法的**平衡面板**（每个实体都有相同的各期，如纵横/宗申各 2024+2025）
            # 也判成「缺少共同观测期间」，CHART-01/02/04 三张分组比较图被误拦。
            # 正确语义是「各实体的期间集合不一致」才不可比（非平衡面板 / 期间不相交）。
            per_entity: dict[str, set] = {}
            for record in records:
                period = measurement_period(record)
                if period is None:
                    continue  # 缺期间由上面的显式告警负责，不在此重复判定
                key = str(record.get("entity") or record.get("entity_name"))
                per_entity.setdefault(key, set()).add(period)
            if len({frozenset(periods) for periods in per_entity.values()}) > 1:
                problems.append("横截面样本缺少共同观测期间，不能作同期间比较")
    return list(dict.fromkeys(problems))

# Terms describe measurements, not merely a matching number somewhere in a record.
CLAIM_METRICS = {
    '新能源汽车销量': 'nev_sales', '新能源汽车': 'nev_sales',
    '新能源汽车市场渗透率': 'nev_penetration',
    '纯电动汽车销量': 'bev_sales', '纯电动销量': 'bev_sales', '纯电销量': 'bev_sales',
    '纯电动': 'bev_sales',
    '插电式混合动力汽车销量': 'phev_sales', '插混汽车销量': 'phev_sales',
    '插混销量': 'phev_sales', '插电式混合动力': 'phev_sales', '插混': 'phev_sales',
    '营业收入同比增长率': 'revenue_yoy', '营收同比': 'revenue_yoy', '营收增速': 'revenue_yoy',
    '归母净利润同比增长率': 'net_profit_yoy', '利润增速': 'net_profit_yoy',
    '营业收入': 'revenue', '营收': 'revenue', '归母净利润': 'parent_net_profit',
    '归母净利': 'parent_net_profit', '净利润': 'net_profit',
    '经营现金流': 'operating_cash_flow', '经营活动现金流': 'operating_cash_flow',
    '经营活动产生的现金流量净额': 'operating_cash_flow',
    '研发费用率': 'rd_ratio', 'rd_ratio': 'rd_ratio',
    # B33：formula 写法（含「/」）必须先于其分子/分母词登记命中——词表选择是
    # 「位置+最长优先」，9 字的 formula 稳赢 4 字的「营业收入」（否则比率断言
    # 会被拆成 revenue 金额族，派生记录 rd_ratio 对不上 → Q1 六张比率卡全隔离）。
    '研发费用/营业收入': 'rd_ratio', '研发费用/营收': 'rd_ratio',
    '经营活动现金流/归母净利润': 'cash_to_net_profit', '经营活动现金流/净利润': 'cash_to_net_profit',
    '经营现金流/归母净利润': 'cash_to_net_profit', '经营现金流/净利润': 'cash_to_net_profit',
    '研发强度': 'rd_ratio', '研发费用占比': 'rd_ratio',
    '研发投入强度': 'rd_investment_ratio', '研发投入占比': 'rd_investment_ratio',
    '研发投入占营收比例': 'rd_investment_ratio', '研发投入占营业收入比例': 'rd_investment_ratio',
    '研发投入占营业收入的比例': 'rd_investment_ratio', '研发投入/营业收入': 'rd_investment_ratio',
    '研发费用': 'rd_expense', '研发投入': 'rd_investment', '研发支出': 'rd_investment',
    '毛利率': 'gross_margin', '净利率': 'net_margin', '净现比': 'cash_to_net_profit',
    'gross_margin': 'gross_margin', 'net_margin': 'net_margin',
    '动态市盈率': 'pe_dynamic', 'PE(TTM)': 'pe_ttm', 'PE（TTM）': 'pe_ttm',
    'TTM': 'pe_ttm', '市盈率': 'pe', '市净率': 'pb', 'PB': 'pb',
    '流通市值': 'circulating_market_cap', '总市值': 'market_cap', '资产负债率': 'debt_ratio',
    'ROE': 'roe', '净资产收益率': 'roe', '最新价': 'latest_price', '股价': 'latest_price',
    # SEMI-F4 国产化率类断言：数值只能由同族结构化证据支撑。
    '国产化率': 'localization_rate', '国产替代率': 'localization_rate',
    '自主可控率': 'localization_rate', '本地化率': 'localization_rate',
    '国产化比例': 'localization_rate', '国产替代比例': 'localization_rate',
    '国产化程度': 'localization_rate', '国产设备市占率': 'localization_rate',
}

# 国产化率断言的**来源类型**白名单（SEMI-F4）：研报/行业/宏观/产业链/公告可用；
# 媒体新闻、事件抽取、行情与财务记录不能为其背书（否则毛利率 45% 这类同值指标
# 会被误当成「国产化率 45%」的出处）。
LOCALIZATION_SOURCE_DOMAINS = frozenset({
    "reports", "report", "industry", "macro", "industry_chain",
    "announcement", "announcements", "official",
})
_LOCALIZATION_RATE_RE = re.compile(
    "|".join(("国产化率", "国产替代率", "自主可控率", "本地化率",
              "国产化比例", "国产替代比例", "国产化程度", "国产设备市占率")))


def localization_rate_claim(text: str) -> bool:
    """句子是否包含国产化率类断言（SEMI-F4 门禁识别器）。"""
    return bool(_LOCALIZATION_RATE_RE.search(text or ""))
QUANTITY_RE = re.compile(r'(?<![\dA-Za-z])([-+−]?\d[\d,]*(?:\.\d+)?(?:[eE][-+]?\d+)?)\s*'
                         r'(万亿元|亿元|万元|万台|亿台|万套|亿套|万颗|亿颗|颗|元|%|％|倍|家|万辆|辆|万吨|吨|架|台|套|人次|GWh|GW|个百分点)?')

# B52（2026-11-11 用户拍板）：问财原文命中通道。
# 研报/新闻的摘要类记录（metric=summary/source_original…）没有结构化数值字段，
# 但正文常直接写出「总营收录得 4.56 亿元」「共交付 216 台」。与 B51 同口径：
# 同实体 + 同值 + 单位同义（架/台、亿元/亿）即可作为出处，不再要求结构化列。
_TEXT_QUANTITY_RE = re.compile(
    r'(\d[\d,]*(?:\.\d+)?(?:[eE][-+]?\d+)?)\s*(万亿元|亿元|万元|万颗|亿颗|颗|亿|万|元|%|％|个百分点|架|台|辆|家|倍|万吨|吨|GWh|GW|套|人次)?')
_TEXT_UNIT_SCALES = {'元': 1.0, '万': 1e4, '万元': 1e4, '亿': 1e8, '亿元': 1e8, '万亿元': 1e12,
                     '颗': 1.0, '万颗': 1e4, '亿颗': 1e8}
_TEXT_UNIT_ALIASES = {'架': {'架', '台'}, '台': {'台', '架'}, '%': {'%', '％'}, '％': {'%', '％'}}
_NARRATIVE_METRICS = {'summary', 'source_original', 'content', 'text', 'excerpt', 'quote', '摘要', '原文', '正文'}
# B57：公告/年报类记录整篇存在 value 里，metric 记的是**文档类型**而不是指标名
# （问财 announcement 频道统一写 event）。这类只能走原文命中，不该被指标族挡在门外。
_DOCUMENT_METRICS = {'event', 'announcement', '公告', '年报', 'annual_report'}
_CHANGE_WORD_RE = re.compile(r'增长|下降|降低|提升|减少|增加|回落|上升')
# B57：正文常用简称（「亿航」指「亿航智能」），旧逻辑按全名精确匹配，导致同一家
# 公司的数字被判成「无此实体」。只在简称 + 常见企业后缀能唯一拼出全名时才归一。
_ENTITY_SUFFIXES = ('智能', '股份', '科技', '集团', '动力', '航空', '信息', '电子', '控股', '重工',
                    '精密', '新材', '光电', '通信', '软件', '医药', '能源', '环保', '机械', '电器',
                    '汽车', '银行', '证券', '保险', '数据', '网络', '传媒', '材料', '装备')
_COMPANY_NAME_RE = re.compile(
    r'[\u4e00-\u9fff]{2,10}(?:股份|集团|控股|公司|科技|智能|动力|航空|电子|信息|通信|能源|材料|'
    r'医药|环保|机械|汽车|银行|证券|保险)')


def _resolve_entity(name: str | None, known: set[str]) -> str | None:
    """把正文里的简称归一到已知实体全名；无法唯一确定时返回 None（不猜）。"""
    if not name:
        return None
    if name in known:
        return name
    for suffix in _ENTITY_SUFFIXES:
        candidate = name + suffix
        if candidate in known:
            return candidate
    return None


def _entity_attribution_gap(before: str, known: set[str]) -> int | None:
    """数字到最近一次「主体点名」的字符距离；整段没点名返回 None（B57）。"""
    end = -1
    for entity in known:
        index = before.rfind(entity)
        if index >= 0:
            end = max(end, index + len(entity))
    for match in _COMPANY_NAME_RE.finditer(before):
        end = max(end, match.end())
    return None if end < 0 else len(before) - end


def _entity_before(text: str, known: set[str]) -> str | None:
    """取数字前最近出现的实体；全名未直接出现时尝试简称归一。"""
    mentioned = [(text.rfind(e), e) for e in known if e in text]
    if mentioned:
        return max(mentioned)[1]
    # 简称归一：只采纳「唯一对应一个实体」的简称。
    # 旧实现按迭代顺序 setdefault，多个「中国X」共享前缀「中国」时会把
    # 「中国向 ITU 提交…」错误归到「中国神华」，随后数值必然绑不上（实测
    # 2026-11-20 商业航天：20 万颗卫星被记成中国神华的 20）。
    heads: dict[str, set[str]] = defaultdict(set)
    for entity in known:
        for length in range(len(entity) - 1, 1, -1):
            head = entity[:length]
            if head in text:
                heads[head].add(entity)
                break
    _GENERIC_HEADS = {"中国", "美国", "全国", "全球", "行业", "公司", "集团", "其中", "以上", "同比", "环比"}
    candidates = [
        (head, next(iter(entities)))
        for head, entities in heads.items()
        if len(entities) == 1 and head not in _GENERIC_HEADS
    ]
    if not candidates:
        return None
    longest = max(candidates, key=lambda item: len(item[0]))
    same_len = [item for item in candidates if len(item[0]) == len(longest[0])]
    return longest[1] if len(same_len) == 1 else None


def _table_value_matches_year(text: str, pos: int, number: str, year: int) -> bool:
    """公告正文里的 Markdown 财务表：按表头列定位数字所属期间（B57）。

    年报表格形如 `|  | 2025年 | 2024年 | 本年比上年增减 | 2023年 |`，
    一行里并排多期数值。旧逻辑取「数字前最近的年份」，落在表头最后一列（2023），
    于是 2025 年的 123.10 亿元被判错期。这里改为：找到表头 → 定位 claim 年份所在列
    → 要求该列单元格与本数字完全一致。列对不上就不认。
    """
    line_start = text.rfind('\n', 0, pos) + 1
    line_end = text.find('\n', pos)
    if line_end == -1:
        line_end = len(text)
    line = text[line_start:line_end]
    if line.count('|') < 3:
        return False
    header = ''
    cursor = line_start
    for _ in range(8):
        prev_end = text.rfind('\n', 0, cursor)
        if prev_end <= 0:
            break
        prev_start = text.rfind('\n', 0, prev_end) + 1
        candidate = text[prev_start:prev_end]
        if candidate.count('|') >= 2 and re.search(r'20\d{2}\s*年', candidate):
            header = candidate
            break
        cursor = prev_start
    if not header:
        return False
    header_cells = [cell.strip() for cell in header.strip('|').split('|')]
    year_columns = [index for index, cell in enumerate(header_cells)
                    for found in re.findall(r'(20\d{2})\s*年', cell) if int(found) == year]
    if len(year_columns) != 1:
        return False
    cells = [cell.strip() for cell in line.strip('|').split('|')]
    if year_columns[0] >= len(cells):
        return False
    values = re.findall(r'\d[\d,]*(?:\.\d+)?', cells[year_columns[0]].replace(' ', ''))
    if len(values) != 1:
        return False
    return values[0].replace(',', '') == number.replace(',', '')


def _text_quote_supports(value: float, unit: str | None, tolerance: float, family: str | None,
                         entity: str | None, year: int | None, refs: list[dict], context: str, *,
                         is_change: bool = False, probabilistic: bool = False,
                         segment: bool = False) -> bool:
    """原文命中：同实体问财记录的正文里出现同值同义单位，即视为有据。"""
    if probabilistic or segment or family == 'localization_rate' or not unit:
        return False
    families = {metric_family(family)} if family else set()
    if family and family.endswith('_yoy'):
        families.add('revenue' if family == 'revenue_yoy' else 'net_profit')
    global_claim = bool(re.search(r"全球|世界|global", context, re.I))
    for ref in refs:
        raw_text = ref.get('value')
        if not isinstance(raw_text, str) or len(raw_text) < 12:
            continue
        try:
            float(raw_text)
            continue                      # 纯数值记录交给结构化通道，不做子串匹配
        except (TypeError, ValueError):
            pass
        actual_entity = ref.get('entity') or ref.get('entity_name')
        if entity and actual_entity and actual_entity != entity:
            continue
        if entity and not actual_entity and entity not in raw_text:
            # 行业级口径（如「商业航天发射 50 次」）的问财摘要记录常常 entity=None，
            # 但原文明确出现该行业/主体名。旧逻辑把 entity 与 None 直接判不等，
            # 把有原文依据的行业统计全部打成无据（实测 2026-11-20：119 条）。
            continue
        if global_claim and actual_entity in ("中国", "国内", "全国", "中国市场"):
            continue
        metric_label = str(ref.get('metric') or '')
        actual_metric = metric_family(metric_label)
        narrative = (metric_label.casefold() in _NARRATIVE_METRICS
                     or metric_label.casefold() in _DOCUMENT_METRICS or not actual_metric)
        if not narrative and families and actual_metric not in families:
            continue
        text = raw_text.replace(',', '')
        for m in _TEXT_QUANTITY_RE.finditer(text):
            number, found_unit = m.group(1).replace('−', '-'), m.group(2)
            try:
                shown = float(number)
            except ValueError:
                continue
            if not found_unit:
                # B57：公告/年报原文里的财务行常把单位写在表头或行首（「营业收入（元）」
                # 「| 加权平均净资产收益率（%）| 0.56 |」），数字本身紧跟不到单位。
                # 金额按「元」还原、比率要求同行标签带 % 才认；数值 + 实体 + 期间
                # 三重约束不变，纯整数（年份/代码/股数）仍被下限挡住。
                if unit in _TEXT_UNIT_SCALES and abs(shown) >= 1000:
                    displayed = shown / _TEXT_UNIT_SCALES[unit]
                elif unit in ('%', '％'):
                    label = text[max(0, m.start() - 40):m.start()]
                    if '%' not in label and '％' not in label:
                        continue
                    displayed = shown
                else:
                    continue
            elif unit in _TEXT_UNIT_SCALES and found_unit in _TEXT_UNIT_SCALES:
                displayed = shown * _TEXT_UNIT_SCALES[found_unit] / _TEXT_UNIT_SCALES[unit]
            elif found_unit in _TEXT_UNIT_ALIASES.get(unit, {unit}):
                displayed = shown
            else:
                continue
            if abs(displayed - value) > tolerance:
                continue
            if year is not None:
                # 取数字前最近的一个年份做判定：摘要类记录 period_end 是发布日，
                # 不能用期间字段兜底（「2025 年发布、讲 2024 年交付」必须按 2024 认）。
                near_years = re.findall(r'(20\d{2})\s*(?:财年|年度|年)', text[max(0, m.start() - 80):m.start()])
                if near_years:
                    if int(near_years[-1]) != year and not _table_value_matches_year(
                            text, m.start(), m.group(1), year):
                        continue
                else:
                    period = str(ref.get('period') or ref.get('period_end') or '')
                    if narrative or not period.startswith(str(year)):
                        continue
            window = text[max(0, m.start() - 40):m.end() + 40]
            if families and not any(
                    term.casefold() in window.casefold()
                    for term, fam in CLAIM_METRICS.items() if fam in families):
                continue
            if is_change and not _CHANGE_WORD_RE.search(text[max(0, m.start() - 16):m.start()]):
                continue
            return True
    return False



def _as_dict(value: Any) -> dict:
    return value.model_dump(mode='json') if hasattr(value, 'model_dump') else dict(value)


# Numeric thousands separators and decimal points do not end a claim clause.
_CLAUSE_BOUNDARY = re.compile(r'[。；;\n！？!?，]|(?<!\d),|,(?!\d)|(?<!\d)\.|\.(?!\d)')
_CAUSAL = re.compile(r'证明|证实|必然|表明|反映|意味着|说明了|导致|归因于|源于|驱动(?!因素|因子|变量|机制|模型|分析|的(?:汽车|车辆))|印证|利润分配.*重构|利润池.*转移|(?:说明|体现)(?=.*(?:议价权|应收|存货|利润池|业务|分部))')
_UNCERTAIN_CAUSE = re.compile(r'假设|可能|或许|待验证|不能证明|并不证明|不能表明|不能说明|不意味着|并不意味着|不足以|无法|未必|不代表')
_ASSUMPTION_INPUT = re.compile(r'假设|如果|若|设定|敏感性')
_SCENARIO_OUTPUT = re.compile(r'(?<!准)则|因此|从而|由此|导致|使得|会使|推算|测算|计算得|可得|分析显示|模型结果|推演结果|敏感性结果|结果为|输出')


_REPORT_CLAUSE_END = re.compile(r"[。；;\n！？!?]")


def retain_supported_claims(text: str, is_supported: Callable[[str], bool], *,
                            check_context: bool = False) -> str:
    """Keep independently supported clauses, including their punctuation."""
    kept = []
    start = 0
    for boundary in _REPORT_CLAUSE_END.finditer(text):
        clause = text[start:boundary.start()].strip()
        candidate = clause + boundary.group()
        if clause and is_supported(clause) and (not check_context or is_supported("".join(kept) + candidate)):
            kept.append(candidate)
        start = boundary.end()
    tail = text[start:].strip()
    if tail and is_supported(tail) and (not check_context or is_supported("".join(kept) + tail)):
        kept.append(tail)
    return "".join(kept).strip()


def _claim_clauses(text: str) -> list[tuple[int, int, str]]:
    spans = []
    start = 0
    for boundary in _CLAUSE_BOUNDARY.finditer(text):
        spans.append((start, boundary.start(), text[start:boundary.start()].strip()))
        start = boundary.end()
    spans.append((start, len(text), text[start:].strip()))
    return spans


def _scope_matches_claim(context: str, scope: str) -> bool:
    scope = (scope or "consolidated").strip()
    segment_claim = bool(re.search(r"分部|分业务|[\u4e00-\u9fff]{2,12}(?:业务|板块)", context)) and not re.search(r"主营业务|公司业务|业务整体", context)
    if segment_claim:
        if scope in ("consolidated", "parent", "group", "unknown", "segment"):
            return False
        if scope in context or scope.casefold() in context.casefold():
            return True
        if scope.startswith("battery") and "电池" in context:
            return True
        if scope.startswith("auto") and "汽车" in context:
            return True
        return False
    return scope in ("consolidated", "parent", "group", "")


def _claimed_duration(context: str) -> str | None:
    if re.search(r"前三季度|三季报", context):
        return "ytd_q3"
    if re.search(r"上半年|半年度|中报|半年报", context):
        return "half_year"
    if re.search(r"一季报", context):
        return "q1"
    quarter_match = re.search(r"第?([一二三四1-4])季度", context)
    if quarter_match:
        q = "一二三四".find(quarter_match.group(1)) + 1 if quarter_match.group(1) in "一二三四" else int(quarter_match.group(1))
        return "q1" if q == 1 else "quarter"
    if re.search(r"单季|当季", context):
        return "quarter"
    if re.search(r"全年|年度|年报", context):
        return "annual"
    return None


def _row_matches_token(row: tuple, token: str) -> bool:
    _, period, _, _ = row
    end_date = period[1]
    iso_match = _ISO_DATE.search(token)
    if iso_match:
        try:
            return end_date == date.fromisoformat(iso_match.group(1))
        except ValueError:
            return False
    year_match = re.search(r'((?:19|20)\d{2})', token)
    if year_match:
        return end_date.year == int(year_match.group(1))
    return False


def _change_across_entities(context: str, local_prefix: str, refs: list[dict], family: str | None,
                            unit: str, value: float, tolerance: float) -> str | None:
    """同一个变化量换实体重算，只有唯一归属才认（B57）。

    「增速变化 -11.29 个百分点」这类断言没有自己的记录，它等于同一实体两期增速之差。
    旧逻辑只按「数字前最近的实体」算，一旦归属错就判无据；这里对**绑定证据里出现过的
    实体**逐个用 `_verified_change` 重算（该函数仍强制两期可比、年度口径、方向一致），
    恰好一处命中才采纳，多处命中=归属不明，仍判无据。
    """
    entities = {str(ref.get('entity') or ref.get('entity_name')) for ref in refs} - {'', 'None'}
    families = [family] if family else sorted(
        {metric_family(str(ref.get('metric') or '')) for ref in refs} - {None, ''})
    hits: list[str] = []
    for entity in entities:
        for candidate in families:
            computed = _verified_change(context, local_prefix, refs, candidate, entity, unit)
            if computed is not None and abs(computed - value) <= tolerance:
                hits.append(entity)
                break
    return hits[0] if len(hits) == 1 else None


def _verified_change(context: str, local_prefix: str, refs: list[dict], family: str | None,
                     entity: str | None, unit: str | None) -> float | None:
    """Recompute an unambiguous comparison from bound comparable observations."""
    if not family or not entity:
        return None
    named = list(dict.fromkeys(m.group(0) for m in _NAMED_PERIOD.finditer(context)))
    selected_periods = named[-2:] if len(named) >= 2 else []
    rows = {}
    for ref in refs:
        if (ref.get('entity') or ref.get('entity_name')) != entity or metric_family(str(ref.get('metric', ''))) != family:
            continue
        scope = str(ref.get('scope') or 'consolidated')
        if not _scope_matches_claim(context, scope):
            continue
        period = measurement_period(ref)
        if period is None or ref.get('conflicted') or any('conflict' in issue for issue in ref.get('issues', [])):
            continue
        if selected_periods and not any(str(period[1]) == label if '-' in label else period[1].year == int(label[:4]) for label in selected_periods):
            continue
        try:
            if isinstance(ref.get('value'), bool):
                continue
            value = float(ref['value'])
        except (ValueError, TypeError, KeyError):
            continue
        if not math.isfinite(value):
            continue
        source_unit = str(ref.get('unit') or '')
        points = _rate_points(value, source_unit)
        if points is not None:
            value, dimension = points, 'percent'
        elif source_unit in _MONEY_SCALES:
            value, dimension = value * _MONEY_SCALES[source_unit], 'money'
        elif source_unit:
            dimension = source_unit
        else:
            continue
        key = (period, comparable_key(ref, include_year=False), dimension, value)
        rows[key] = (ref, period, value, dimension)
    # Duplicate identical evidence is harmless; conflicting or extra observations
    # cannot acquire a winner merely because one pair matches the prose number.
    if len(rows) != 2:
        return None
    r1, r2 = list(rows.values())
    if comparable_key(r1[0], include_year=False) != comparable_key(r2[0], include_year=False) or r1[3] != r2[3]:
        return None

    # Check claimed duration vs observation duration
    claimed_dur = _claimed_duration(context)
    if claimed_dur is not None:
        if r1[1][2] != claimed_dur and not (claimed_dur == "quarter" and r1[1][2] in ("quarter", "q1")):
            return None
    else:
        has_iso = bool(_ISO_DATE.search(context))
        if not has_iso and family in ("revenue", "parent_net_profit", "net_profit", "operating_cash_flow",
                                      "gross_margin", "net_margin", "revenue_yoy", "net_profit_yoy",
                                      "cash_to_net_profit"):
            if r1[1][2] != "annual":
                return None

    # Determine from_row (base) and to_row (target)
    from_to = re.search(
        r'从\s*((?:19|20)\d{2}(?:年|-\d{2}-\d{2})?)\s*(?:到|至)\s*((?:19|20)\d{2}(?:年|-\d{2}-\d{2})?)',
        context
    )
    if not from_to:
        from_to = re.search(
            r'((?:19|20)\d{2}(?:年|-\d{2}-\d{2})?)\s*(?:到|至)\s*((?:19|20)\d{2}(?:年|-\d{2}-\d{2})?)',
            context
        )

    compare = None
    if not from_to:
        compare = re.search(
            r'((?:19|20)\d{2}(?:年|-\d{2}-\d{2})?).*?(?:较|比|相比)\s*((?:19|20)\d{2}(?:年|-\d{2}-\d{2})?)',
            context
        )

    if from_to:
        token_from, token_to = from_to.group(1), from_to.group(2)
        if _row_matches_token(r1, token_from) and _row_matches_token(r2, token_to):
            from_row, to_row = r1, r2
        elif _row_matches_token(r2, token_from) and _row_matches_token(r1, token_to):
            from_row, to_row = r2, r1
        else:
            return None
    elif compare:
        token_to, token_from = compare.group(1), compare.group(2)
        if _row_matches_token(r1, token_from) and _row_matches_token(r2, token_to):
            from_row, to_row = r1, r2
        elif _row_matches_token(r2, token_from) and _row_matches_token(r1, token_to):
            from_row, to_row = r2, r1
        else:
            return None
    elif len(named) >= 2:
        token_from, token_to = named[-2], named[-1]
        if _row_matches_token(r1, token_from) and _row_matches_token(r2, token_to):
            from_row, to_row = r1, r2
        elif _row_matches_token(r2, token_from) and _row_matches_token(r1, token_to):
            from_row, to_row = r2, r1
        else:
            earlier, later = sorted([r1, r2], key=lambda row: row[1][1])
            from_row, to_row = earlier, later
    elif len(named) == 1:
        earlier, later = sorted([r1, r2], key=lambda row: row[1][1])
        label = named[0]
        # The single named change year must be the current observation (later period).
        if not _row_matches_token(later, label):
            return None
        from_row, to_row = earlier, later
    else:
        earlier, later = sorted([r1, r2], key=lambda row: row[1][1])
        from_row, to_row = earlier, later

    if from_row[1] == to_row[1]:
        return None

    delta = to_row[2] - from_row[2]
    if unit is None:
        change = delta
    elif unit == '个百分点':
        if from_row[3] != 'percent':
            return None
        change = delta
    elif unit in ('%', '％'):
        if from_row[2] == 0:
            return None
        change = delta / abs(from_row[2]) * 100
    elif from_row[3] == 'money' and unit in _MONEY_SCALES:
        change = delta / _MONEY_SCALES[unit]
    elif from_row[3] == unit:
        change = delta
    else:
        return None
    directions = list(re.finditer(r'下降|降低|减少|回落|上升|提升|提高|增长|增加|持平|相对变化|相对变动|变化|变动', local_prefix))
    direction = directions[-1].group(0) if directions else ''
    if direction in ('下降', '降低', '减少', '回落'):
        return abs(change) if delta < 0 else None
    if direction in ('上升', '提升', '提高', '增长', '增加'):
        return abs(change) if delta > 0 else None
    if direction == '持平':
        return 0.0 if delta == 0 else None
    return change


_SECURITY_CODE = re.compile(r'\d{6}(?:\.(?:SZ|SH|BJ))?', re.I)


def _is_security_code(text: str, match: 're.Match[str]') -> bool:
    """A six-digit ticker is an identifier, never a measured quantity."""
    if match.group(2):
        return False
    raw = match.group(1).replace(',', '')
    if raw.startswith(('+', '-', '−')) or not (raw.isdigit() and len(raw) == 6):
        return False
    after = text[match.end():]
    if re.match(r'\s*\.(?:SZ|SH|BJ)(?![A-Za-z])', after, re.I):
        return True
    return bool(re.search(r'[（(]\s*$', text[:match.start()]))


# ── 非财务量纲与披露语境豁免（2026-11-09）──────────────────────────────────
# 低空/半导体基线里 36%–57% 的 unsupported_quantity 不是编造数字：
#   A 计数与物理量纲（"样本仅 3 家""1000 米以下空域"）本就不是财务断言；
#   C 披露与归因（"双值冲突未仲裁""为国家发改委口径，非本报告测算"
#     "超出 1% 容差"）是在说明缺口或引用外部来源，不是无据断言。
# 这里只把**明确属于上述语义**的数字排除；财务数字一律继续走证据核验，
# 避免借豁免放过真实缺口（如"PB 中位数 8.52 倍"仍会被要求计算记录）。
_NON_FINANCIAL_UNITS = {
    # 仅限"样本计数/文档结构"这类非业务量。台/套/辆/吨/人次是业务规模，
    # 仍必须走证据核验（"预计出货 6 万台"不能被当成计数放过）。
    '家', '项', '条', '个', '次', '款', '座', '人',
}
# QUANTITY_RE 不收录长度/计件单位，需看数字紧邻的后缀（"1000米"）。
_NON_FINANCIAL_TAIL = re.compile(r'\s*(?:米|公里|千米|年|月|日|页|章|节|项|个|次|人|款|座)')

# C1 外部归因：明确的第三方口径/来源，不是本报告测算
_DISCLOSURE_ATTRIBUTION = re.compile(
    r'非本报告测算|研报口径|第三方预测|来源(?:为|是|[:：])|引自|转引'
    r'|(?:报告|研报|机构|券商|媒体|协会)称'
    r'|(?:国家|发改委|工信部|协会|机构|券商|研究院|证券|咨询|统计局).{0,14}口径'
    r'|[（(][^（）()]{2,24}(?:研究院|证券|咨询|数据|信息|部|委|局|协会|银行|大学)[^（）()]{0,10}[）)]'
)
# C2 冲突披露：同一指标多值且明确标注冲突（不是引用其中一个值当结论）
# B23-T11：补「来源冲突…未消解」写法——报告附录用它披露 ROE 两源差异，
# 旧正则只认「多源冲突」「未仲裁/未解决」，把诚实披露误判成无据断言。
_DISCLOSURE_CONFLICT = re.compile(
    r'(?:双值|两组|两个|多个|多源|来源).{0,12}冲突|冲突.{0,8}未(?:仲裁|解决|消解)'
    r'|contradicted|contradiction|标记(?:为)?conflicted'
)
# C3 方法学参数：容差/阈值是校验规则参数，不是观测量
_DISCLOSURE_METHOD = re.compile(r'容差|阈值')

# 派生合计（P0-1 残余②，2026-11-10）：正文条款明示「合计/总和」时，
# 数值不必逐条等于某一条证据，可以等于一组同族同期成分之和。
_AGGREGATE_CLAIM = re.compile(r'合计|总计|总和|之和|加总|共计')


def _clause_at(text: str, pos: int) -> str:
    """取 pos 所在的句子片段（含逗号内部），用于判断披露语境。"""
    start = max(text.rfind('。', 0, pos), text.rfind('；', 0, pos), text.rfind('\n', 0, pos)) + 1
    ends = [x for x in (text.find('。', pos), text.find('；', pos), text.find('\n', pos)) if x != -1]
    return text[start:min(ends) if ends else len(text)]


def _non_financial_quantity(unit: str | None, text: str, end: int) -> bool:
    if unit and unit in _NON_FINANCIAL_UNITS:
        return True
    return bool(_NON_FINANCIAL_TAIL.match(text[end:end + 6]))


def _disclosed_quantity(text: str, start: int) -> bool:
    clause = _clause_at(text, start)
    if _DISCLOSURE_ATTRIBUTION.search(clause):
        return True
    if _DISCLOSURE_CONFLICT.search(clause):
        return True
    return bool(_DISCLOSURE_METHOD.search(clause) and re.search(r'超出|超过|容差|阈值', clause))


def _verified_aggregate(context: str, refs: list[dict], value: float, unit: str | None,
                        tolerance: float, family: str | None, year: int | None) -> bool:
    """派生合计通道（P0-1 残余②）：放行「真合计」，拦下「错合计」。

    条件全部满足才算支撑：
    1. 条款明示合计/总和语言（_AGGREGATE_CLAIM）；
    2. 条款点名 ≥2 个证据库实体（四家公司合计但一个名字不写，不放）；
    3. 每个点名实体恰好一个同指标族、同期间、无冲突的金额观测；
    4. 成分按声明单位换算后求和，与断言值之差在容差内（容差外再加
       每成分 0.005 亿元的显示舍入余量——各成分按两位小数展示时，
       舍入和与精确和天然差至多 n×0.005）。
    中位数/均值等其它派生口径不在本通道内，仍按无据拦截（诚实边界）。
    """
    if not _AGGREGATE_CLAIM.search(context):
        return False
    if unit is not None and unit not in _MONEY_SCALES:
        return False
    scale = _MONEY_SCALES.get(unit, 1.0)
    known = {str(r.get('entity') or r.get('entity_name') or '') for r in refs} - {''}
    mentioned = [e for e in known if e in context]
    if len(mentioned) < 2:
        return False
    claimed_family = metric_family(family) if family else None
    totals: dict[str, float] = {}
    for ref in refs:
        ent = str(ref.get('entity') or ref.get('entity_name') or '')
        if ent not in mentioned:
            continue
        if ref.get('issues') and 'period_conflict' in ref['issues']:
            continue
        if claimed_family and metric_family(str(ref.get('metric') or '')) != claimed_family:
            continue
        if year:
            period = str(ref.get('period') or ref.get('period_end') or '')
            if not period.startswith(str(year)):
                continue
        if not claim_period_matches(context, ref, year, family):
            continue
        try:
            actual = float(ref.get('value'))
        except (TypeError, ValueError):
            continue
        if not math.isfinite(actual):
            continue
        source_unit = str(ref.get('unit') or '')
        if source_unit not in _MONEY_SCALES:
            return False  # 混入非金额成分，合计无意义
        base = actual * _MONEY_SCALES[source_unit]
        if ent in totals and abs(totals[ent] - base) > max(abs(base), 1.0) * 1e-9:
            return False  # 同一实体出现多个不同观测，合计歧义
        totals[ent] = base
    if len(totals) != len(mentioned):
        return False
    extra = 0.005 * 1e8 * len(totals)  # 每成分两位小数展示的舍入余量（元）
    total = sum(totals.values())
    claim_base = value * scale
    return abs(total - claim_base) <= tolerance * scale + extra


_DERIVED_MEDIAN = re.compile(r'中位数|中位|中枢')
_DERIVED_SHARE = re.compile(r'占比|比重|份额')
_DERIVED_RANGE = re.compile(r'区间|介于')
_DERIVED_SUM = re.compile(r'合计|总计|总和|之和|加总|共计|总市值')
# 泛称的受限变体白名单：只允许「同一定义族内的口径变体」互相支撑。
# 例如正文写「市盈率中位数」时，证据可能是 PE(TTM)；但绝不允许
# revenue 泛称去匹配 revenue_yoy（增速是另一个指标）。
_FAMILY_VARIANTS: dict[str, set[str]] = {
    'pe': {'pe', 'pe_ttm', 'pe_dynamic', 'pe_lyr', 'pe_static'},
}
# 「四家公司合计」里的中文数量：用于防子集凑和（成分数必须 ≥ 声明数）
_CN_COUNT = {'一': 1, '二': 2, '两': 2, '三': 3, '四': 4, '五': 5,
             '六': 6, '七': 7, '八': 8, '九': 9, '十': 10}


def _display_value(actual: float, source_unit: str, target_unit: str | None) -> float | None:
    """把证据值换算到断言所用单位；不可换算返回 None。"""
    if target_unit in _MONEY_SCALES and source_unit in _MONEY_SCALES:
        return actual * _MONEY_SCALES[source_unit] / _MONEY_SCALES[target_unit]
    if target_unit in ('%', '％'):
        return _rate_points(actual, source_unit)
    if target_unit == source_unit:
        return actual
    return None


_REMOVAL_ENTRY = re.compile(r"(P-[\w-]+)\s*因质量问题被整段移除(?:（([^）]*)）)?")


# ── 披露精度与跨单位等价（P-11/P-12）────────────────────────────────────
_NUMBER_IN_TEXT = re.compile(r"([-+]?\d[\d,]*(?:\.\d+)?)")
MONEY_METRIC_FAMILIES = frozenset({
    'revenue', 'net_profit', 'parent_net_profit', 'operating_cash_flow',
    'rd_expense', 'rd_investment', 'market_cap', 'circulating_market_cap',
})


def decimal_step_from_text(value: Any) -> Decimal | None:
    """末位单位：'16.20%' → 0.01，'16.2%' → 0.1，'100万元' → 1（单位内的末位）。"""
    if not isinstance(value, str):
        return None
    match = re.fullmatch(
        r"\s*([-+]?\d[\d,]*(?:\.\d+)?)\s*(?:%|％|元|千元|万元|百万元|千万元|亿元|万亿元|倍)?\s*",
        value,
    )
    if not match:
        return None
    decimals = match.group(1).partition(".")[2]
    return Decimal(1).scaleb(-len(decimals))


def disclosure_text(record: Any) -> str | None:
    """从 raw_fields 里找与已存数值一致的原始披露字符串。"""
    raw = _as_dict(record).get("raw_fields") or {}
    if not isinstance(raw, dict):
        return None
    candidates = [raw.get(str(_as_dict(record).get("metric", "") or "")), raw.get("value"),
                  raw.get("指标值"), raw.get("数值")]
    candidates.extend(value for value in raw.values() if isinstance(value, str))
    target = _as_dict(record).get("value")
    for text in candidates:
        if not isinstance(text, str):
            continue
        step = decimal_step_from_text(text)
        if step is None:
            continue
        try:
            if Decimal(_NUMBER_IN_TEXT.search(text).group(1).replace(",", "")) == Decimal(str(target)):
                return text
        except (AttributeError, InvalidOperation, ValueError, TypeError):
            continue
    return None


def disclosure_step(record: Any) -> Decimal | None:
    text = disclosure_text(record)
    return decimal_step_from_text(text) if text else None


def inferred_step(record: Any) -> Decimal | None:
    """已存数值的兜底精度（仅用于「来源值」本身，不用于我方重算结果）。"""
    value = _as_dict(record).get("value")
    if isinstance(value, bool) or not isinstance(value, (int, float, Decimal)):
        return None
    text = repr(float(value)) if not isinstance(value, Decimal) else str(value)
    step = decimal_step_from_text(text)
    if step is not None:
        return step
    try:
        exponent = (Decimal(text) if isinstance(value, Decimal) else Decimal(repr(float(value)))).normalize().as_tuple().exponent
    except (InvalidOperation, ValueError):
        return None
    return Decimal(1).scaleb(exponent)


def record_step(record: Any) -> Decimal | None:
    """已存值的精度：优先原始披露字符串，其次数值本身的十进制表示。"""
    return disclosure_step(record) or inferred_step(record)


def round_to_step(value: Decimal, step: Decimal) -> Decimal:
    return (value / step).quantize(Decimal("1"), rounding=ROUND_HALF_UP) * step


def matches_disclosed(stored: Decimal, target: Decimal,
                      stored_step: Decimal | None, target_step: Decimal | None) -> bool | None:
    """按更精细侧舍入到低精度侧，判断两个数是否只是披露精度差异。"""
    if stored == target:
        return True
    if stored_step is None or target_step is None:
        return None
    if stored_step == target_step:
        return False
    if stored_step > target_step:
        return round_to_step(target, stored_step) == stored
    return round_to_step(stored, target_step) == target


def rounding_verdict(records: list[Any], values: list[Decimal]) -> bool | None:
    """同一口径多条记录：True 等价，False 实质冲突，None 精度不可确认（保守拦）。"""
    steps: list[Decimal | None] = [record_step(record) for record in records]
    if any(step is None for step in steps):
        return None
    if len(set(values)) <= 1:
        return True
    precise = min(steps, key=lambda step: step)
    reference_index = next(index for index, step in enumerate(steps) if step == precise)
    reference = values[reference_index]
    for index, (value, step) in enumerate(zip(values, steps)):
        if index == reference_index:
            continue
        if matches_disclosed(value, reference, step, precise) is False:
            return False
    return True


def money_value_yuan(record: Any) -> Decimal | None:
    """把记录值换到元；单位不可信或非金额单位返回 None。"""
    data = _as_dict(record)
    provenance = str(data.get("unit_provenance") or "").strip().casefold()
    if provenance in {"unknown", "legacy_unknown"}:
        return None
    scale = money_scale(data.get("unit"))
    if scale is None:
        return None
    value = data.get("value")
    if isinstance(value, bool) or value is None:
        return None
    try:
        return Decimal(str(value)) * scale
    except (InvalidOperation, ValueError, TypeError):
        return None


def _unit_identity(record: Any, money_metric: bool) -> tuple:
    data = _as_dict(record)
    if money_metric and money_scale(data.get("unit")) is not None:
        return ("money", str(data.get("currency") or "CNY"))
    return ("unit", str(data.get("unit")))


def _group_verdict(records: list[Any], values: list[Decimal]) -> bool | None:
    if len(values) <= 1 or len(set(values)) <= 1:
        return True
    return rounding_verdict(records, values)


def _cross_unit_verdict(records: list[Any]) -> bool | None:
    """金额跨单位：先换算到元，再用同一套披露精度规则比较。"""
    values: list[Decimal] = []
    steps: list[Decimal | None] = []
    for record in records:
        data = _as_dict(record)
        scale = money_scale(data.get("unit"))
        value = money_value_yuan(record)
        if scale is None or value is None:
            return None
        values.append(value)
        step = record_step(record)
        steps.append(step * scale if step is not None else None)
    if any(step is None for step in steps):
        return None
    if len(set(values)) <= 1:
        return True
    # 换算到元之后，精度步长也必须一起换算，不能再按原单位重算一次。
    return _weighted_verdict(values, steps)


def _weighted_verdict(values: list[Decimal], steps: list[Decimal]) -> bool | None:
    precise = min(steps)
    reference_index = next(index for index, step in enumerate(steps) if step == precise)
    reference = values[reference_index]
    for index, (value, step) in enumerate(zip(values, steps)):
        if index == reference_index:
            continue
        if matches_disclosed(value, reference, step, precise) is False:
            return False
    return True


def measurement_conflict_verdict(records: list[Any]) -> bool | None:
    """同一测量口径的一组记录是否构成冲突。

    True  = 等价（含披露精度舍入等价、跨单位换算后相等）；
    False = 实质冲突；
    None  = 精度/单位不可确认，调用方应按保守门禁处理。
    非金额单位不同（如 % 与 倍）不合并比较，沿用原有分组边界。
    """
    if not records:
        return True
    data = _as_dict(records[0])
    money_metric = metric_family(str(data.get("metric") or "")) in MONEY_METRIC_FAMILIES
    buckets: dict[tuple, list[Any]] = {}
    for record in records:
        buckets.setdefault(_unit_identity(record, money_metric), []).append(record)

    pending = False
    money_records: list[Any] = []
    for identity, bucket in buckets.items():
        if identity[0] == "money":
            money_records.extend(bucket)
            continue
        values = []
        for record in bucket:
            try:
                values.append(Decimal(str(_as_dict(record).get("value"))))
            except (InvalidOperation, ValueError, TypeError):
                return None
        verdict = _group_verdict(bucket, values)
        if verdict is False:
            return False
        if verdict is None:
            pending = True

    if money_records:
        units = {str(_as_dict(record).get("unit")) for record in money_records}
        if len(money_records) > 1 and len(set(_as_dict(record).get("value") for record in money_records)) > 1:
            if any(money_scale(_as_dict(record).get("unit")) is None for record in money_records):
                pending = True
            elif len(units) > 1:
                verdict = _cross_unit_verdict(money_records)
                if verdict is False:
                    return False
                if verdict is None:
                    pending = True
            else:
                values = []
                for record in money_records:
                    try:
                        values.append(Decimal(str(_as_dict(record).get("value"))))
                    except (InvalidOperation, ValueError, TypeError):
                        return None
                verdict = _group_verdict(money_records, values)
                if verdict is False:
                    return False
                if verdict is None:
                    pending = True
    return None if pending else True


def substantive_removal_ids(gap_text: str) -> list[str]:
    """「段落资料缺口」文本里算**实质内容损失**的段落 id（B23-T10）。

    原因只有「与其他段落重复」的条目不算损失——去重不是内容缺失。
    chapter_writer 生成该文本，report_fusion 用它判断是否阻塞交付。
    """
    lost: list[str] = []
    for pid, reason in _REMOVAL_ENTRY.findall(str(gap_text or "")):
        reasons = [r for r in re.split(r"[、,，]", reason or "") if r.strip()]
        if reasons and all("重复" in r for r in reasons):
            continue
        lost.append(pid)
    return lost


def _sample_names(financial_ratios: Any) -> set[str]:
    """样本清单 = financial_ratios 的 company 集合（B32 用户口径）。

    只有具备完整财务输入的公司才进 financial_ratios，所以「样本」的定义是
    「有完整财务输入的公司」——比「证据池里出现过的所有公司」更可核验。
    """
    if not isinstance(financial_ratios, (list, tuple)):
        return set()
    return {str(r.get("company") or "").strip() for r in financial_ratios
            if isinstance(r, dict) and str(r.get("company") or "").strip()}


def _tier_names(financial_ratios: Any, tier_key: str) -> set[str]:
    """梯队子集：按 valuation_tier 字段过滤（B32 用户口径）。"""
    if not isinstance(financial_ratios, (list, tuple)):
        return set()
    return {str(r.get("company") or "").strip() for r in financial_ratios
            if isinstance(r, dict) and str(r.get("valuation_tier") or "").strip() == tier_key
            and str(r.get("company") or "").strip()}


def _declared_component_count(context: str) -> int | None:
    """从「四家公司合计」「5 家样本合计」这类措辞里读出声明的成分数量。

    读不出返回 None（调用方按默认下限处理）。
    """
    text = context or ''
    match = re.search(r'([一二两三四五六七八九十]|\d{1,2})\s*家', text)
    if match:
        token = match.group(1)
        if token.isdigit():
            count = int(token)
            return count if 2 <= count <= 50 else None
        return _CN_COUNT.get(token)
    return None


def _verified_derived_statistic(context: str, refs: list[dict], value: float,
                                unit: str | None, tolerance: float,
                                family: str | None, year: int | None,
                                sample: set[str] | None = None) -> bool:
    """派生统计量通道（B23-T3）：合计 / 中位数 / 区间。

    背景（SEMI-Q4 实测）：报告核心结论大量使用派生量（「样本总市值
    16,548.65亿元」「PE 中位数 54.8 倍」「毛利率中枢 40.95%」），它们不可能
    由单条证据支撑，旧校验一律判 unsupported → 160 条假阳性、12 张指标卡被
    删除、报告永久「受限草稿」。

    重建条件（必须全部满足，缺一即保持拦截）：
    1. 上下文有明确统计量措辞（中位数/中枢、合计/总计、区间/介于）；
    2. 有指标族线索（family 非空）——否则任意数值都可能碰巧命中；
    3. 成分同指标族、同期间、单位可换算、无期间冲突；
    4. 合计/中位数成分 ≥3，区间成分 ≥2；
    5. 重建值与断言值在「绝对容差 或 1% 相对」内（区间要求命中端点）。

    不放行：占比/比重/份额（需要分子分母配对，留给专门通道），因此仍按
    无据拦截——这是诚实边界，不是遗漏。

    B32：`sample` 非空时按样本清单过滤成分——「4 家样本合计」只在样本内求和，
    不许用全库（38 家）的合计冒充样本（25 家）的合计。
    """
    import statistics

    text = context or ''
    if _DERIVED_SHARE.search(text):
        return False
    if _DERIVED_MEDIAN.search(text):
        kind = 'median'
    elif _DERIVED_RANGE.search(text):
        kind = 'range'
    elif _DERIVED_SUM.search(text):
        kind = 'sum'
    else:
        return False
    if not family:
        return False
    claimed_family = metric_family(family)
    allowed_families = _FAMILY_VARIANTS.get(claimed_family, {claimed_family})

    comps: dict[str, float] = {}
    used_families: set[str] = set()
    for ref in refs:
        if ref.get('issues') and 'period_conflict' in ref['issues']:
            continue
        record_family = metric_family(str(ref.get('metric') or ''))
        if record_family not in allowed_families:
            continue
        used_families.add(record_family)
        if year:
            period = str(ref.get('period') or ref.get('period_end') or '')
            if not period.startswith(str(year)):
                continue
        if not claim_period_matches(context, ref, year, family):
            continue
        try:
            actual = float(ref.get('value'))
        except (TypeError, ValueError):
            continue
        if not math.isfinite(actual):
            continue
        displayed = _display_value(actual, str(ref.get('unit') or ''), unit)
        if displayed is None or not math.isfinite(displayed):
            continue
        key = str(ref.get('entity') or ref.get('entity_name') or ref.get('record_id') or '')
        if not key:
            continue
        # B32：样本清单过滤——只有样本内的公司才计入子集统计。
        # 没有 entity 的记录（key 退化为 record_id）不会匹配样本，自然被排除。
        if sample is not None and key not in sample:
            continue
        if key in comps and abs(comps[key] - displayed) > max(abs(displayed), 1.0) * 1e-9:
            return False  # 同实体多个不同观测，派生口径歧义
        comps[key] = displayed

    values = list(comps.values())
    if len(used_families) > 1:
        return False  # 混用不同口径（PE(TTM) 与 PE(动态)），派生量无意义
    if kind == 'sum':
        declared = _declared_component_count(text)
        # 声明了「四家公司合计」就必须真有 ≥4 个成分——防子集凑和；
        # 未声明数量时要求 ≥3（单值/双值巧合不做放行）。
        if declared is not None:
            if len(values) < declared:
                return False
        elif len(values) < 3:
            return False
        # 每成分两位小数展示的舍入余量
        margin = max(tolerance, abs(value) * 0.01) + 0.005 * len(values)
        return abs(sum(values) - value) <= margin
    if kind == 'median':
        if len(values) < 3:
            return False
        margin = max(tolerance, abs(value) * 0.01)
        return abs(statistics.median(values) - value) <= margin
    # range：断言值必须命中区间端点（中间值不算，避免「区间 5%-10%」被宽范围放行）
    if len(values) < 2:
        return False
    margin = max(tolerance, abs(value) * 0.01)
    return min(abs(value - min(values)), abs(value - max(values))) <= margin


def aggregate_component_ids(text: str, records: list[Any]) -> list[str]:
    """派生合计绑定（P0-1 残余②）：为「合计/总和」断言找成分记录。

    返回与条款点名的 ≥2 实体、同指标族对应的成分 record_id 列表；
    数值是否真为这些成分之和，由 quantity_issues 的派生合计通道
    独立复核——绑定只扩候选池，错和仍会被拦。中位数等其它派生
    口径不绑定、不放行。
    """
    refs = [_as_dict(r) for r in records]
    out: list[str] = []
    for _start, _end, clause in _claim_clauses(text):
        if not _AGGREGATE_CLAIM.search(clause):
            continue
        context = clause[-100:]
        matches = [(term, fam) for term, fam in CLAIM_METRICS.items()
                   if term.casefold() in context.casefold()]
        if not matches:
            continue
        _term, family = max(matches, key=lambda item: len(item[0]))
        mentioned = {e for e in (str(r.get('entity') or r.get('entity_name') or '') for r in refs)
                     if e and e in clause}
        if len(mentioned) < 2:
            continue
        for ref in refs:
            ent = str(ref.get('entity') or ref.get('entity_name') or '')
            if ent not in mentioned:
                continue
            if metric_family(str(ref.get('metric') or '')) != family:
                continue
            if ref.get('issues') and 'period_conflict' in ref['issues']:
                continue
            rid = ref.get('record_id')
            if rid and rid not in out:
                out.append(rid)
    return out


def _structured_binds(refs: list[dict], *, value: float, unit: str | None, tolerance: float,
                      family: str | None, entity: str | None, context: str,
                      year: int | None, probabilistic: bool) -> bool:
    """结构化数值通道：同实体/同指标族/同期间/单位换算后比对。"""
    for ref in refs:
        try:
            actual = float(ref.get('value'))
        except (TypeError, ValueError):
            continue
        if ref.get('issues') and 'period_conflict' in ref['issues']:
            continue
        actual_entity = ref.get('entity') or ref.get('entity_name')
        if entity and actual_entity != entity:
            continue
        if re.search(r"全球|世界|global", context, re.I) and actual_entity in ("中国", "国内", "全国", "中国市场"):
            continue
        if (family in {'nev_sales', 'bev_sales', 'phev_sales'}
                and actual_entity in ("中国", "国内", "全国", "中国市场")
                and re.search(r"美国|日本|德国|韩国|欧洲|欧盟|印度|英国|法国", context)):
            continue
        segment_claim = bool(re.search(r"分部|分业务|[\u4e00-\u9fff]{2,12}(?:业务|板块)", context)) and not re.search(r"主营业务|公司业务|业务整体", context)
        if segment_claim:
            scope = str(ref.get("scope") or "consolidated")
            if scope in ("consolidated", "parent", "group", "unknown", "segment") or scope not in context:
                continue
        actual_metric = metric_family(str(ref.get('metric') or ''))
        # Explicit ratio labels remain distinct; a generic profit is not parent profit.
        if family and metric_family(family) != actual_metric:
            continue
        # SEMI-F4：国产化率断言的来源类型白名单——媒体新闻/事件/行情财务
        # 即使数值相同也不能作为出处。
        if family == "localization_rate" and str(ref.get("domain") or "").lower() not in LOCALIZATION_SOURCE_DOMAINS:
            continue
        if probabilistic:
            continue
        period = str(ref.get('period') or ref.get('period_end') or '')
        if year and not period.startswith(str(year)):
            continue
        if not claim_period_matches(context, ref, year, family):
            continue
        source_unit = str(ref.get('unit') or '')
        if unit in ('%', '％') and _rate_points(actual, source_unit) is not None:
            displayed = _rate_points(actual, source_unit)
        else:
            try:
                displayed = convert_unit_value(actual, source_unit, unit)
            except (TypeError, ValueError):
                continue
        if abs(displayed - value) <= tolerance:
            return True
    return False


def _verified_growth(refs: list[dict], family: str, entity: str | None, year: int | None) -> float | None:
    """B53 增速派生通道：同实体、同口径相邻两年的水平值算出同比增速。

    只在两个年度各有唯一观测、单位一致、且都是年度口径时成立；
    多值/缺年/季度口径一律不给结论（宁可拦下，不猜）。
    """
    if not entity or year is None or family not in ('revenue_yoy', 'net_profit_yoy'):
        return None
    base = 'revenue' if family == 'revenue_yoy' else 'net_profit'
    series: dict[tuple[int, str], set[float]] = {}
    for ref in refs:
        if (ref.get('entity') or ref.get('entity_name')) != entity:
            continue
        if metric_family(str(ref.get('metric') or '')) != base:
            continue
        if ref.get('issues') and 'period_conflict' in ref['issues']:
            continue
        if str(ref.get('period_type') or '').lower() in ('quarter', 'month', 'ytd_month', 'half_year'):
            continue
        period = str(ref.get('period') or ref.get('period_end') or '')
        m = re.match(r'(20\d{2})', period)
        if not m:
            continue
        try:
            value = float(ref.get('value'))
        except (TypeError, ValueError):
            continue
        series.setdefault((int(m.group(1)), str(ref.get('unit') or '')), set()).add(round(value, 6))
    for (cur_year, cur_unit), cur_values in series.items():
        if cur_year != year or len(cur_values) != 1:
            continue
        prev_values = series.get((year - 1, cur_unit))
        if not prev_values or len(prev_values) != 1:
            continue
        cur_value, prev_value = next(iter(cur_values)), next(iter(prev_values))
        if prev_value == 0:
            continue
        return (cur_value - prev_value) / abs(prev_value) * 100
    return None


def _parallel_header_family(context: str) -> str | None:
    """识别「A 与 B 同向：公司 value」这类并列指标表头。

    生成文本常写成「研发费用率与毛利率梯度同向：中航光电9.78%对应毛利率29.44%」。
    数字 9.78 前面最近的指标词是「毛利率」，但真正归属是表头的第一个指标
    「研发费用率」；旧逻辑按最近位置选 family，导致有效数据被判 unsupported。
    仅在「最后一个冒号后面只有实体名、没有数字」时生效，避免误伤表格/多值句。
    """
    cut = max(context.rfind("："), context.rfind(":"))
    if cut <= 0:
        return None
    tail = context[cut + 1:].strip()
    if not tail or len(tail) > 12 or re.search(r"\d", tail):
        return None
    header = context[:cut]
    terms = [(header.casefold().rfind(term.casefold()), len(term), family)
             for term, family in CLAIM_METRICS.items() if term.casefold() in header.casefold()]
    if len({family for _, _, family in terms}) < 2:
        return None
    if not re.search(r"与|和|及|、", header):
        return None
    first = min(terms, key=lambda item: (item[0], -item[1]))
    return first[2]


def quantity_issues(text: str, evidence: list[Any], *, universe: list[Any] = (),
                    assumption_note: str | None = None, kind: str = '', location: str = '',
                    sample_universe: list[Any] | None = None) -> list[dict]:
    """Fail closed on a numeric claim without matching measurement semantics.

    Rounding tolerance is half the displayed final digit, never a percentage of
    the claim. A matching real ID by itself is insufficient.

    B32：`sample_universe` = financial_ratios，用于子集统计核验。
    「N 家样本合计」按样本清单过滤成分；「成熟盈利 N 家中位数」按梯队过滤。
    不传时行为与之前完全一致（全库）。
    """
    text = _EVIDENCE_HASH.sub(lambda match: " " * len(match.group()), mask_chart_references(text))
    refs = [row for e in evidence if "review_excluded" not in ((row := _as_dict(e)).get("issues") or [])]
    all_refs = [row for e in universe if "review_excluded" not in ((row := _as_dict(e)).get("issues") or [])] or refs
    known_entities = {str(e.get('entity') or e.get('entity_name') or '') for e in all_refs} - {''}
    issues = []
    clauses = _claim_clauses(text)
    iso_dates = _valid_iso_dates(text)
    # An added annual observation disproves an unqualified statement that the
    # same company's entire financial series is missing that year. A revenue
    # record alone cannot disprove a narrower claim about net profit or ROE.
    for sentence in re.split(r"[。；;\n]", text):
        if not re.search(r"财务(?:数据|序列|报表)?", sentence):
            continue
        if any(term in sentence for term in ("营收", "营业收入", "净利润", "净资产收益率", "ROE", "roe")):
            continue
        match = re.search(r"(20\d{2})\s*[-—–至~]\s*(20\d{2})\s*(?:年度|年)?\s*(?:数据)?(?:缺失|缺少|未覆盖)", sentence)
        if not match:
            continue
        first, last = sorted((int(match.group(1)), int(match.group(2))))
        if last - first > 20:
            continue
        candidates = [ref for ref in all_refs if str(ref.get("domain") or "").lower() in {"financials", "domain.financials"}
            and (name := str(ref.get("entity") or ref.get("entity_name") or "")) and name in sentence
            and str(ref.get("period") or ref.get("period_end") or "")[:4].isdigit()
            and first <= int(str(ref.get("period") or ref.get("period_end"))[:4]) <= last]
        if candidates:
            issues.append(dict(code="contradictory_coverage", severity="error", location=location,
                claim=sentence.strip(), evidence_ids=[ref.get("record_id") for ref in candidates],
                suggestion="补充记录与缺失期间表述不一致，请重新核对具体指标和年度。"))
    for start, _, clause_text in clauses:
        if _CAUSAL.search(clause_text) and not _UNCERTAIN_CAUSE.search(clause_text):
            attributed = bool(re.search(r"据|称|认为|预计|预测", text[max(0, start - 35):start] + clause_text))
            direct_support = False
            for ref in refs:
                value = ref.get("value")
                if not isinstance(value, str) or clause_text not in value:
                    continue
                offset = value.index(clause_text)
                opinion = ref.get("domain") in {"news", "events", "reports"} and bool(
                    re.search(r"预计|预测|认为|观点|展望", value[max(0, offset - 35):offset])
                )
                if attributed or not opinion:
                    direct_support = True
                    break
            if not direct_support:
                issues.append(dict(code="unsupported_causal_claim", severity="error", location=location,
                    claim=clause_text, evidence_ids=[r.get("record_id") for r in refs],
                    suggestion="补充直接证据，或在该因果子句中明确标记为待验证假设。"))
        direction = re.search(r"下降|下滑|降低|减少|回落|上升|提升|提高|增长|增加|持平", clause_text)
        forecast = bool(re.search(r"未来|将持续|将继续|势必", clause_text))
        qualitative_comparison = bool(direction and not QUANTITY_RE.search(
            _NAMED_PERIOD.sub("", clause_text)) and len(_NAMED_PERIOD.findall(clause_text)) >= 2)
        continuous = bool(direction and re.search(r"持续|连续", clause_text))
        unbounded_rank = bool(re.search(r"(?:行业|市场|同业|同行)(?:中)?(?:领先|第一|最高)", clause_text))
        if (unbounded_rank or (direction and (forecast or qualitative_comparison or continuous))) and not re.search(
            r"假设|如果|可能|或许|待验证|无法|不足以|不一定|是否|不能|风险在于|目标是", clause_text
        ):
            entities = [name for name in known_entities if name in clause_text]
            entity = max(entities, key=len, default=None)
            matches = [term for term in CLAIM_METRICS if term.casefold() in clause_text.casefold()]
            family = CLAIM_METRICS[max(matches, key=len)] if matches else None
            direction_text = clause_text.replace("下滑", "下降")
            measured = (
                not (forecast or continuous or unbounded_rank)
                and _verified_change(direction_text, direction_text, refs, family, entity, None) is not None
            )
            if not measured:
                issues.append(dict(code="unsupported_direction_claim", severity="error", location=location,
                    claim=clause_text, evidence_ids=[r.get("record_id") for r in refs],
                    suggestion="补充同口径观测，或明确区分已观察变化与待验证假设。"))
    for match in QUANTITY_RE.finditer(text):
        if any(start <= match.start() < end for start, end, _ in iso_dates):
            continue
        if _is_security_code(text, match):
            continue
        raw, unit = match.groups()
        if _non_financial_quantity(unit, text, match.end()):
            continue
        if _disclosed_quantity(text, match.start()):
            continue
        raw = raw.replace(',', '').replace('−', '-')
        value = float(raw)
        if unit is None and (1900 <= value <= 2099 and value.is_integer()):
            continue
        if unit is None and re.search(r"(?:图|表|第)\s*$", text[:match.start()]):
            continue
        precision = Decimal(raw).as_tuple().exponent
        tolerance = 0.5 * 10 ** precision + 1e-9
        before = text[:match.start()]
        clause = re.split(r'[。；;\n]', before)[-1]
        context = clause[-100:]
        selected = [(context.casefold().rfind(term.casefold()), len(term), family)
                    for term, family in CLAIM_METRICS.items() if term.casefold() in context.casefold()]
        # A longer measurement phrase wins when terms overlap at the same end.
        selected_metric = max(selected, key=lambda x: (x[0] + x[1], x[1])) if selected else None
        family = selected_metric[2] if selected_metric else None
        parallel_family = _parallel_header_family(context)
        if parallel_family:
            family = parallel_family
        metric_tail = context[selected_metric[0] + selected_metric[1]:] if selected_metric else ""
        if family in ("revenue", "net_profit", "parent_net_profit") and re.search(r"同比|增速|增长率", metric_tail):
            family = "revenue_yoy" if family == "revenue" else "net_profit_yoy"
        if unit is None:
            if family in ("pe", "pe_ttm", "pe_dynamic", "pe_lyr", "pb", "ps", "cash_to_net_profit"):
                unit = "倍"
            elif family and (family.endswith("margin") or family.endswith("_yoy") or family in ("roe", "debt_ratio")):
                unit = "%"
            else:
                units = {r.get("unit") for r in refs if metric_family(str(r.get("metric"))) == family}
                unit = next(iter(units)) if len(units) == 1 else None
            if not family and value.is_integer() and 0 <= value <= 10:
                continue
        mentioned = [(before.rfind(e), e) for e in known_entities if e in before]
        entity = max(mentioned)[1] if mentioned else _entity_before(before, known_entities)
        explicit = re.search(r'([\u4e00-\u9fff]{2,12})\s*(?:20\d{2})年', context)
        if explicit and not entity:
            # B57：旧实现把「当季同比由2025年…」里的「当季同比由」当成公司名，
            # 于是数字永远绑不上。只有能归一到已知实体的才采纳。
            candidate = explicit.group(1).removeprefix('公司')
            resolved = _resolve_entity(candidate, known_entities)
            if resolved:
                entity = resolved
            elif not re.search(r'同比|环比|增速|增长|下降|上升|营收|收入|利润|毛利|净利|产量|销量|'
                               r'规模|季度|月度|年度|累计|读数|指标', candidate):
                # 看不出是「主体」还是「指标短语」时按主体处理（fail closed）：
                # 宁可绑不上，也不能让 entity=None 去蹭别家记录。
                entity = candidate
        named_periods = list(_NAMED_PERIOD.finditer(context))
        year = int(named_periods[-1].group(1)) if named_periods else None
        local_clause = next((part for start, end, part in clauses if start <= match.start() < end), "")
        # SEMI-F4：句中有「国产化率」类词时强制归入该族——即使数字出现在指标词
        # 之前（「45%的国产化率」），也必须由同族结构化证据支撑，不能被任意同值
        # 百分比（毛利率、同比增速等）放行。
        if family is None and _LOCALIZATION_RATE_RE.search(local_clause):
            family = "localization_rate"
        scenario_context = kind in ('scenario', 'methodology', 'risk') and bool(
            assumption_note or re.search(r'情景假设|敏感性', text))
        probabilistic = bool(re.search(r'概率|胜率|目标价|目标市值', context))
        # An explicit input assumption is not a licence for another clause's
        # forecast output. This contract has no verified scenario-model channel;
        # a hypothetical result cannot borrow matching historical observations.
        if scenario_context and _ASSUMPTION_INPUT.search(text) and _SCENARIO_OUTPUT.search(local_clause):
            issues.append(dict(code='unsupported_sensitivity_output', severity='error', location=location,
                claim=match.group(0), metric=family, entity=entity, year=year,
                evidence_ids=[r.get('record_id') for r in refs],
                suggestion='补充可重算的敏感性模型、输入来源和公式；输入假设不能替代派生结果依据。'))
            continue
        is_assumption = scenario_context and _ASSUMPTION_INPUT.search(local_clause)
        if is_assumption and not probabilistic:
            continue
        supported = False
        local_start = next((start for start, end, _ in clauses if start <= match.start() < end), 0)
        local_prefix = text[local_start:match.start()]
        change_tail = local_prefix if re.search(r'相对变化|相对变动', local_prefix) else metric_tail
        is_level = bool(re.search(r'(?:下降|降低|上升|提高|提升|增长|减少|回落)(?:至|到|为)\s*$', change_tail))
        growth_observation = family in ('revenue_yoy', 'net_profit_yoy') and selected_metric and selected_metric[2] in ('revenue', 'net_profit', 'parent_net_profit')
        is_change = unit == '个百分点' or (not is_level and not growth_observation and bool(re.search(
            r'下降|降低|减少|回落|上升|提高|提升|增长|增加|持平|相对变化|相对变动|变化|变动', change_tail)))
        if is_change:
            computed = _verified_change(context, local_prefix, refs, family, entity, str(unit or ''))
            supported = computed is not None and abs(computed - value) <= tolerance
            if not supported and unit in ('%', '％'):
                grown = _verified_growth(all_refs, family, entity, year)
                supported = grown is not None and abs(grown - value) <= tolerance
            if not supported and unit == '个百分点':
                # B57：百分点差值按「同实体两期之差」逐实体重算，唯一归属才认。
                matched_entity = _change_across_entities(
                    context, local_prefix, refs, family, unit, value, tolerance)
                if matched_entity:
                    entity, supported = matched_entity, True
        if not supported and not is_change:
            # 引用宽窄由融合层 `_split_uncited` 分诊（未引用=warning，无据=error），
            # 这里只用本节证据，避免把「未引用」洗成「已支持」。
            supported = _structured_binds(refs, value=value, unit=unit, tolerance=tolerance,
                family=family, entity=entity, context=context, year=year, probabilistic=probabilistic)
        if not supported:
            # B52：结构化通道绑不上时，回落到「问财记录原文命中」——同实体 + 同值
            # + 单位同义即可（研报/新闻的 summary 记录没有数值列，但原文写明了）。
            segment_text = bool(re.search(r"分部|分业务|[\u4e00-\u9fffA-Za-z0-9]{2,12}(?:业务|板块)", context)) and not re.search(
                r"主营业务|公司业务|业务整体", context)
            supported = _text_quote_supports(value, unit or '', tolerance, family, entity, year,
                refs, context, is_change=is_change, probabilistic=probabilistic, segment=segment_text)
        if not supported and not is_change:
            # 派生合计通道（P0-1 残余②）：条款明示合计且点名 ≥2 实体时，
            # 允许「成分之和」支撑断言；错和、缺成分、中位数等仍被拦。
            supported = _verified_aggregate(context, refs, value, unit, tolerance, family, year)
        if not supported and not is_change:
            # B23-T3 派生统计量通道：合计（未点名实体）/ 中位数 / 区间。
            # 用同族同期成分重建后比对；占比不重建，保持拦截。
            # B32：子集统计按样本清单/梯队过滤后再重建。
            sample_filter = None
            if sample_universe:
                matched_tier = next(
                    (t for t in {str(r.get("valuation_tier") or "").strip()
                                 for r in sample_universe if isinstance(r, dict)}
                     if t and t in context),
                    None,
                )
                if matched_tier:
                    sample_filter = _tier_names(sample_universe, matched_tier)
                elif "样本" in context:
                    sample_filter = _sample_names(sample_universe)
            supported = _verified_derived_statistic(
                context, refs, value, unit, tolerance, family, year, sample=sample_filter
            )
        # 只有「归属来源遥远」时才允许改判：数字前 20 字内出现主体名（全称或简称），
        # 说明归属是显式的——此时按原实体 fail closed，绝不改判（B57）。
        attribution_gap = _entity_attribution_gap(before, known_entities)
        if entity and entity in before:
            own_gap = len(before) - (before.rfind(entity) + len(entity))
            attribution_gap = own_gap if attribution_gap is None else min(attribution_gap, own_gap)
        if not supported and entity and (attribution_gap is None or attribution_gap > 20):
            # B57：一句里点名多家公司时，「数字前最近的实体」未必是归属。实测：
            # 「亿航智能仅有美元股价…未纳入对照。…禁止将单一标的19.18倍PE外推」——
            # 19.18 倍其实是**宗申动力**的 pe_dynamic，却被判给了亿航。
            # 在本句内枚举其他已知实体，只有恰好一家能绑上才改判（多命中=归属不明）。
            # 候选实体 = 正文点到的 + 引用记录里的（免责声明常只说「单一标的」，
            # 真正的归属只能从它引用的那条记录反推）。
            alternatives = [name for name in known_entities
                            if name != entity and (name in text
                            or any((r.get('entity') or r.get('entity_name')) == name for r in refs))]
            hits = []
            for name in alternatives:
                if _structured_binds(refs, value=value, unit=unit, tolerance=tolerance,
                        family=family, entity=name, context=context, year=year,
                        probabilistic=probabilistic):
                    hits.append(name)
                    continue
                if _text_quote_supports(value, unit or '', tolerance, family, name, year,
                        refs, context, is_change=is_change, probabilistic=probabilistic,
                        segment=segment_text):
                    hits.append(name)
            if len(hits) == 1:
                entity, supported = hits[0], True
        if not supported:
            issues.append(dict(code='unsupported_quantity', severity='error', location=location,
                claim=match.group(0), metric=family, entity=entity, year=year,
                evidence_ids=[r.get('record_id') for r in refs],
                suggestion='补充同实体、同指标定义、同期间和单位的证据；否则从草稿删除该断言。'))
    return issues


# ---------------------------------------------------------------------------
# 数值断言证据可见性诊断（2026-11-15 任务 1：先量化，再放宽）。
# 对融合层上报的 unsupported_quantity 条目，对照**全库**证据回答「有据吗、为什么绑不上」。
# 分类语义与 scripts/diagnose_quantity_issues.py（CLI 薄封装）共用本函数。
# 注意：这是**诊断**而非放行——命中项仍需人工/标注通道复核（弱命中会显式降级）。
# ---------------------------------------------------------------------------

# 未入 _TEXT_UNIT_SCALES 的货币口径：命中数字但币种不可换算（亿美元↔亿元）。
_CURRENCY_UNIT_RE = re.compile(r'亿美元|万美元|美元')
# 文本型字段优先级：narrative 记录的正文可能落在 value / summary / source_original。
_DIAG_TEXT_FIELDS = ('value', 'summary', 'source_original', 'content')
# claim/正文里数字后紧跟的币种后缀（QUANTITY_RE/_TEXT_QUANTITY_RE 的单位表都不含美元系）。
_CURRENCY_SUFFIX_RE = re.compile(r'(万亿元|亿元|万元|万|亿|元|千)?美元')


def _split_currency(unit: str | None) -> tuple[str | None, bool]:
    """拆出 (基准量纲, 是否美元口径)。'亿美元'→('亿',True)；'亿元'→('亿元',False)。"""
    if not unit:
        return None, False
    if unit.endswith('美元'):
        base = unit[:-2]
        return (base if base in _TEXT_UNIT_SCALES else ('元' if not base else base)), True
    return unit, False


def _claim_number_unit(claim: str) -> tuple[float | None, str | None, float]:
    """从 claim（如「8848.34亿元」「1659亿美元」）解析数值、单位与容差（半位小数）。"""
    m = QUANTITY_RE.search(claim or '')
    if not m:
        return None, None, 0.0
    raw = m.group(1).replace(',', '').replace('−', '-')
    try:
        value = float(raw)
    except ValueError:
        return None, None, 0.0
    decimals = len(raw.split('.')[1]) if '.' in raw else 0
    unit = m.group(2)
    tail = (claim or '')[m.end():]
    cm = _CURRENCY_SUFFIX_RE.match(tail)
    if cm:
        # 「1659亿美元」：QUANTITY_RE 的单位表没有美元系，group(2) 为空；
        # 数字后紧跟的「亿美元」才是完整口径。
        unit = (cm.group(1) or '') + '美元'
    return value, unit, 0.5 * 10 ** -decimals + 1e-9


def _unit_compatible(claim_unit: str | None, record_unit: str | None) -> bool:
    if not claim_unit or not record_unit:
        return False
    if claim_unit == record_unit:
        return True
    return record_unit in _TEXT_UNIT_ALIASES.get(claim_unit, {claim_unit})


def _structured_hits(value: float, unit: str | None, tolerance: float,
                     universe: list[dict]) -> list[dict]:
    """结构化通道命中：数值在容差内匹配（口径可按量纲换算或同义；不跨币种）。"""
    claim_base, claim_usd = _split_currency(unit)
    hits = []
    for ref in universe:
        if 'review_excluded' in (ref.get('issues') or []):
            continue
        rv = ref.get('value')
        if isinstance(rv, str) or not isinstance(rv, (int, float)) or isinstance(rv, bool):
            continue
        ref_base, ref_usd = _split_currency(ref.get('unit'))
        if claim_usd != ref_usd:
            continue
        if claim_base in _TEXT_UNIT_SCALES and ref_base in _TEXT_UNIT_SCALES:
            same = abs(value * _TEXT_UNIT_SCALES[claim_base] - rv * _TEXT_UNIT_SCALES[ref_base]) <= max(
                tolerance * max(_TEXT_UNIT_SCALES[claim_base], _TEXT_UNIT_SCALES[ref_base]), 1e-6)
        elif _unit_compatible(unit, ref.get('unit')):
            same = abs(value - rv) <= tolerance
        else:
            continue
        if same:
            hits.append(ref)
    return hits


def family_entity_matches(entity: object, entity_names: list, original: str) -> bool:
    """断言主体是否就是硬需求点名的实体。

    issue.entity 为空或 junk（「样本」「四家公司」这类聚合主体）一律不算；
    issue.entity 命中需求实体名单，或原文以「实体名+年份」直接点名时才算。
    """
    name = str(entity or '').strip()
    if not name or name not in {str(n) for n in entity_names}:
        return False
    return True


def _text_hits(value: float, unit: str | None, tolerance: float, universe: list[dict],
               entity: str | None, known_entities: set[str], year: int | None,
               ) -> tuple[list[dict], list[dict]]:
    """文本通道命中与币种错配命中。

    弱匹配约束（计划审查重点）：数字+同义单位出现之外，实体/期间至少一项对得上；
    两者都对不上视为「数字恰好出现」，不计入命中。币种错配（亿元↔亿美元）单独返回，
    由调用方显式降级，不冒充有据。
    """
    hits, mismatch = [], []
    entity_junk = bool(entity) and entity not in known_entities
    claim_base, claim_usd = _split_currency(unit)
    for ref in universe:
        if 'review_excluded' in (ref.get('issues') or []):
            continue
        actual_entity = ref.get('entity') or ref.get('entity_name')
        matched_entity = bool(entity) and not entity_junk and actual_entity == entity
        found_hit = found_mismatch = matched_period = False
        for field in _DIAG_TEXT_FIELDS:
            raw_text = ref.get(field)
            if not isinstance(raw_text, str) or len(raw_text) < 12:
                continue
            try:
                float(raw_text)
                continue                      # 纯数值记录交给结构化通道
            except (TypeError, ValueError):
                pass
            text = raw_text.replace(',', '')
            for m in _TEXT_QUANTITY_RE.finditer(text):
                try:
                    shown = float(m.group(1).replace('−', '-'))
                except ValueError:
                    continue
                found_unit = m.group(2)
                # 正文里「1659亿美元」会被 _TEXT_QUANTITY_RE 只吃到「亿」，
                # 紧随其后的「美元」才是币种后缀，补上后再比较（基准量纲取
                # _TEXT_QUANTITY_RE 已捕获的单位，缺省时取后缀自带的量纲）。
                cm = _CURRENCY_SUFFIX_RE.match(text[m.end():m.end() + 4])
                if cm:
                    found_unit = (m.group(2) or cm.group(1) or '') + '美元'
                window = text[max(0, m.start() - 60):m.start()]
                if not matched_period and year is not None:
                    near = re.findall(r'(20\d{2})\s*(?:财年|年度|年)', window)
                    period = str(ref.get('period') or ref.get('period_end') or '')
                    matched_period = bool(near and int(near[-1]) == year) or (
                        not near and period.startswith(str(year)))
                ref_base, ref_usd = _split_currency(found_unit)
                same_value = False
                if claim_usd != ref_usd:
                    # 跨币种：数字相同才是错配候选（亿元↔亿美元），量纲也须同级
                    scale_same = ((claim_base is None and ref_base is None)
                                  or claim_base == ref_base
                                  or (claim_base in _TEXT_UNIT_SCALES and ref_base in _TEXT_UNIT_SCALES
                                      and _TEXT_UNIT_SCALES[claim_base] == _TEXT_UNIT_SCALES[ref_base]))
                    if scale_same and abs(shown - value) <= tolerance:
                        found_mismatch = True   # 币种不可换算：待人工裁决
                elif claim_base in _TEXT_UNIT_SCALES and ref_base in _TEXT_UNIT_SCALES:
                    displayed = shown * _TEXT_UNIT_SCALES[ref_base] / _TEXT_UNIT_SCALES[claim_base]
                    same_value = abs(displayed - value) <= tolerance
                elif _unit_compatible(unit, found_unit):
                    same_value = abs(shown - value) <= tolerance
                if same_value:
                    found_hit = True
        if found_hit and (matched_entity or matched_period or entity_junk or not entity):
            hits.append(ref)
        if found_mismatch and (matched_entity or matched_period or entity_junk or not entity):
            mismatch.append(ref)
    return hits, mismatch


def diagnose_quantity_claim_detail(issue: dict, universe: list[dict], *,
                                   chapter_evidence: set[str] | frozenset[str] | None = None,
                                   requirement_rows: list[dict] | None = None,
                                   ) -> tuple[str, list[str]]:
    """对单条 unsupported_quantity 断言做证据可见性分类。

    返回 (类别, 命中证据 record_id 列表)。类别：value_exact_structured /
    text_quote_only / unit_currency_mismatch / chapter_scope_only / absent / protected。
    全离线、零配额。record_id 按证据强度排序（结构化 > 文本 > 币种错配）。
    """
    claim = str(issue.get('claim') or '')
    original = str(issue.get('original') or claim)
    value, unit, tolerance = _claim_number_unit(claim)
    if value is None:
        return 'absent', []
    if unit is None:
        # claim 只存了数字（QUANTITY_RE 单位表不含美元系），口径从 original 恢复：
        # 找到 claim 数字在原文中的位置，看其后是否紧跟「亿美元/万美元/美元」。
        probe = claim if claim in original else (str(claim).strip())
        if probe not in original:
            num = QUANTITY_RE.search(claim)
            probe = num.group(1) if num else ''
        idx = original.find(probe) if probe else -1
        if idx >= 0:
            cm = _CURRENCY_SUFFIX_RE.match(original[idx + len(probe):idx + len(probe) + 4])
            if cm:
                unit = (cm.group(1) or '') + '美元'
    # 国产化率保护按 production 的子句级语义：quantity_issues 已把命中子句的
    # family 标成 localization_rate（issue.metric），不再扫整段 original——
    # 句中 merely 提及「国产化率」的份额断言（PVD AMAT 占 85%）不能被误伤。
    if issue.get('metric') == 'localization_rate' or _LOCALIZATION_RATE_RE.search(claim):
        return 'protected', []
    # 硬需求缺口关联断言：断言主体必须就是该需求的实体（junk 聚合主体如
    # 「样本/四家公司」只是句中提及别家需求，不放也不保护），期间与指标族同时吻合。
    family = issue.get('metric')
    for row in requirement_rows or []:
        req = row.get('requirement') or row
        cov = row.get('coverage') or {}
        if not req.get('hard') or cov.get('passed') is not False:
            continue
        entity_names = req.get('entity_names') or []
        if not family_entity_matches(issue.get('entity'), entity_names, original):
            continue
        periods = [str(p)[:4] for p in (req.get('period_ends') or []) if str(p)[:4] in original]
        metric_overlap = True
        if req.get('metric_families') and family:
            metric_overlap = family in req['metric_families']
        elif family is None:
            label = str(req.get('label') or '')
            metric_overlap = any(term in original and term in label
                                 for term in CLAIM_METRICS)
        if periods and metric_overlap:
            return 'protected', []
    known_entities = {str(r.get('entity') or r.get('entity_name') or '')
                      for r in universe} - {''}
    structured = _structured_hits(value, unit, tolerance, universe)
    structured_ids = [r.get('record_id') for r in structured]
    chapter_ids = set(chapter_evidence or ())
    if structured and (not chapter_ids or (structured_ids and set(structured_ids) & chapter_ids)):
        return 'value_exact_structured', structured_ids
    textual, currency = _text_hits(value, unit, tolerance, universe,
                                   issue.get('entity'), known_entities, issue.get('year'))
    textual_ids = [r.get('record_id') for r in textual]
    currency_ids = [r.get('record_id') for r in currency]
    if textual and (not chapter_ids or (textual_ids and set(textual_ids) & chapter_ids)):
        return 'text_quote_only', structured_ids + textual_ids
    all_hit_ids = set(structured_ids) | set(textual_ids)
    if chapter_ids and all_hit_ids:
        return 'chapter_scope_only', structured_ids + textual_ids
    if currency:
        return 'unit_currency_mismatch', currency_ids
    return 'absent', []


def diagnose_quantity_claim(issue: dict, universe: list[dict], *,
                            chapter_evidence: set[str] | frozenset[str] | None = None,
                            requirement_rows: list[dict] | None = None) -> str:
    """单条断言的可见性类别（命中证据列表见 diagnose_quantity_claim_detail）。"""
    return diagnose_quantity_claim_detail(issue, universe,
                                          chapter_evidence=chapter_evidence,
                                          requirement_rows=requirement_rows)[0]
