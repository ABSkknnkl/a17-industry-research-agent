from __future__ import annotations

import json
import re
from contextvars import ContextVar
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class ArtifactWorkspace:
    """当前异步执行上下文使用的私有阶段产物目录。"""

    run_dir: Path
    path: Path


_ACTIVE_WORKSPACE: ContextVar[ArtifactWorkspace | None] = ContextVar(
    "a17_active_artifact_workspace", default=None,
)


def set_artifact_workspace(workspace: ArtifactWorkspace) -> Any:
    return _ACTIVE_WORKSPACE.set(workspace)


def reset_artifact_workspace(token: Any) -> None:
    _ACTIVE_WORKSPACE.reset(token)


def resolve_artifact_dir(run_dir: Path, revision: int | None = None) -> Path:
    """Resolve a run's current or explicitly archived artifacts; reject invalid pointers."""
    active = _ACTIVE_WORKSPACE.get()
    if revision is None and active is not None and active.run_dir.resolve() == run_dir.resolve():
        return active.path
    pointer_path = run_dir / "artifact_pointer.json"
    if not pointer_path.exists():
        if revision is not None:
            raise ValueError("该历史版本没有独立产物快照")
        return run_dir / "artifacts"
    try:
        pointer = json.loads(pointer_path.read_text(encoding="utf-8"))
        relative = pointer.get("current") if revision is None else (pointer.get("history") or {}).get(str(revision))
        if not isinstance(relative, str) or not (relative == "artifacts" or re.fullmatch(r"artifact_revisions/[1-9]\d*(?:-[0-9a-f]{32})?", relative)):
            raise ValueError("产物版本指针无效")
        target = run_dir / relative
        if not target.is_dir() or not target.resolve().is_relative_to(run_dir.resolve()):
            raise ValueError("产物版本目录不存在或越界")
        return target
    except (OSError, json.JSONDecodeError, AttributeError) as exc:
        raise ValueError("产物版本指针损坏") from exc
