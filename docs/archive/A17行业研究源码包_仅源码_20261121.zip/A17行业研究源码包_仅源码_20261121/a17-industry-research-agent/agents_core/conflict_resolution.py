from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any


def _as_dict(value: Any) -> dict:
    return value.model_dump(mode="json") if hasattr(value, "model_dump") else dict(value)


def _hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, default=str).encode()).hexdigest()


def _record_signature(record: Any) -> str:
    data = _as_dict(record)
    fields = ("record_id", "domain", "entity_name", "entity_code", "metric", "value", "unit", "unit_provenance",
              "period_start", "period_end", "period_type", "scope", "currency", "published_at", "source", "raw_fields")
    return _hash({key: data.get(key) for key in fields})


def make_resolution(dataset: Any, prepared: dict[str, Any]) -> dict[str, Any]:
    key = str(prepared.get("conflict_key") or "")
    conflict = next((item for item in dataset.conflicts if item.conflict_key == key), None)
    selected = str(prepared.get("selected_record_id") or "")
    source = prepared.get("source") or {}
    if not conflict or selected not in conflict.record_ids or _hash(_as_dict(conflict)) != _hash(prepared.get("conflict") or {}):
        raise ValueError("冲突候选已变化，不能应用旧裁决")
    if not str(prepared.get("reason") or "").strip() or not all(source.get(k) for k in ("source_id", "source_locator", "document_sha256", "literal_excerpt")):
        raise ValueError("裁决缺少可追溯原文或理由")
    records = {record.record_id: record for record in dataset.all_records()}
    if not set(conflict.record_ids).issubset(records):
        raise ValueError("冲突候选记录不完整")
    return {"conflict_key": key, "selected_record_id": selected, "conflict": _as_dict(conflict),
            "record_signatures": {rid: _record_signature(records[rid]) for rid in conflict.record_ids},
            "source": source, "reason": prepared["reason"], "actor": "本地未认证用户",
            "reviewed_at": datetime.now(timezone.utc).isoformat()}


def project_dataset(dataset: Any) -> tuple[Any, list[Any], list[dict[str, Any]]]:
    """Select reviewed observations for computation without deleting original data."""
    projected = dataset.model_copy(deep=True)
    decisions = dataset.quality_summary.get("remediation_decisions") or []
    latest = {str(d.get("conflict_key")): d for d in decisions if isinstance(d, dict) and d.get("conflict_key")}
    records = {record.record_id: record for record in dataset.all_records()}
    valid: list[dict[str, Any]] = []
    unresolved = []
    excluded_ids: set[str] = set()
    for conflict in dataset.conflicts:
        decision = latest.get(conflict.conflict_key) or {}
        ids = set(conflict.record_ids)
        selected = decision.get("selected_record_id")
        signatures = decision.get("record_signatures") or {}
        overlapping = any(other.conflict_key != conflict.conflict_key and ids.intersection(other.record_ids) for other in dataset.conflicts)
        matches = (not overlapping and selected in ids and _hash(_as_dict(conflict)) == _hash(decision.get("conflict") or {})
                   and set(signatures) == ids and ids.issubset(records)
                   and all(signatures[rid] == _record_signature(records[rid]) for rid in ids)
                   and bool(str(decision.get("reason") or "").strip())
                   and all((decision.get("source") or {}).get(k) for k in ("source_id", "source_locator", "document_sha256", "literal_excerpt")))
        if matches:
            valid.append(decision)
            excluded_ids.update(ids - {selected})
        else:
            unresolved.append(conflict)
    projected.conflicts = unresolved
    excluded = [record for record in dataset.all_records() if record.record_id in excluded_ids]
    for domain in ("industry", "companies", "financials", "macro", "industry_chain", "reports", "news"):
        setattr(projected, domain, [record for record in getattr(projected, domain) if record.record_id not in excluded_ids])
    selected_by_id = {d["selected_record_id"]: d for d in valid}
    for record in projected.all_records():
        if record.record_id in selected_by_id:
            record.raw_fields.update(selected_by_id[record.record_id]["source"])
    return projected, excluded, valid
