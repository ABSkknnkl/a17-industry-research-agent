"""Conservative checks on explicit user requests that must stay mandatory."""
from __future__ import annotations


def explicitly_requests_filing(text: str | None) -> bool:
    if text is None:
        return True
    text = text.casefold()
    return any(term in text for term in (
        "公告", "年报", "年度报告", "财务报告", "财报", "更正", "修正", "调整", "纠错",
        "追溯", "重述", "重列", "会计政策", "会计准则", "披露", "原文", "restatement",
        "annual report", "filing", "accounting policy",
    ))
