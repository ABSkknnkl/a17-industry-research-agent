"""Unit, precision and period-kind contract tests for ``financial_semantics``.

Why this file exists
--------------------
The branch carried a precise unit/precision layer the main line never had.
``_normalize_money`` in ``data_interpreter.engine`` guessed the scale from
substrings (``if "万" in unit``), so ``百万元`` was read as ``万元`` -- a factor
of 100.  These are pure-function tests: no dataset, no engine, no network.

The assertions pin the **exact** scale for every unit the sources emit, so a
future "helpful" refactor cannot silently reintroduce substring matching.
"""

from __future__ import annotations

from datetime import date
from decimal import Decimal

import pytest

from agents_core.financial_semantics import (
    MONEY_UNIT_SCALES,
    choose_display_money_unit,
    label_period_kind,
    measurement_conflict_verdict,
    money_scale,
    money_to_yi,
    money_to_yuan,
    normalize_money_unit,
    normalize_period_kind,
    period_shape,
    period_start_for,
    round_to_step,
)


class TestMoneyScaleTable:
    """The unit table must be complete and exact."""

    @pytest.mark.parametrize(
        ("unit", "scale"),
        [
            ("元", 1),
            ("千元", 1_000),
            ("万元", 10_000),
            ("百万元", 1_000_000),
            ("千万元", 10_000_000),
            ("亿元", 100_000_000),
            ("万亿元", 1_000_000_000_000),
        ],
    )
    def test_canonical_units(self, unit: str, scale: int) -> None:
        assert money_scale(unit) == scale

    def test_table_covers_every_canonical_unit(self) -> None:
        # Guard against adding a unit to the module constant but not the asserts.
        assert set(MONEY_UNIT_SCALES) == {
            "元", "千元", "万元", "百万元", "千万元", "亿元", "万亿元",
        }

    def test_prefix_aliases_resolve_to_the_same_scale(self) -> None:
        assert money_scale("万") == 10_000
        assert money_scale("亿") == 100_000_000
        assert money_scale("万亿") == 1_000_000_000_000

    def test_currency_markers_resolve_to_yuan(self) -> None:
        for marker in ("人民币", "CNY", "rmb", "¥", "人民币元"):
            assert normalize_money_unit(marker) == "元"


class TestMoneyConversion:
    """``百万元`` must never be read as ``万元``."""

    def test_baiwan_is_not_wan(self) -> None:
        assert money_to_yi(1, "百万元") == Decimal("0.01")

    def test_qianwan_is_not_wan(self) -> None:
        assert money_to_yi(1, "千万元") == Decimal("0.1")

    def test_wanyi_is_not_yi(self) -> None:
        assert money_to_yi(1, "万亿元") == Decimal("10000")

    @pytest.mark.parametrize(
        ("value", "unit", "expected_yi"),
        [
            (1_000_000_000, "元", Decimal("10")),
            (100_000, "万元", Decimal("10")),
            (10, "亿元", Decimal("10")),
        ],
    )
    def test_existing_behaviour_is_preserved(
        self, value: float, unit: str, expected_yi: Decimal
    ) -> None:
        assert money_to_yi(value, unit) == expected_yi

    def test_untrusted_units_yield_none(self) -> None:
        for unit in (None, "", "unknown", "legacy_unknown", "-", "美元"):
            assert money_to_yuan(1, unit) is None

    def test_none_value_yields_none(self) -> None:
        assert money_to_yuan(None, "亿元") is None


class TestDisplayUnitChoice:
    """One axis, one unit -- chosen from normalised yuan, never from magnitude alone."""

    def test_four_digit_yuan_uses_wan(self) -> None:
        assert choose_display_money_unit([1, 20_000], ["元", "元"]) == "万元"

    def test_mixed_scales_are_normalised_first(self) -> None:
        # 30_000 万元 = 3 亿元, so the axis must be 亿元 rather than 万元.
        assert choose_display_money_unit([1, 30_000], ["万", "万"]) == "亿元"

    def test_no_trusted_unit_returns_empty(self) -> None:
        assert choose_display_money_unit([], []) == ""
        assert choose_display_money_unit([1], ["unknown"]) == ""


class TestPeriodKind:
    """Label qualifiers win over frequency fields; year-end cumulative is annual."""

    def test_month_label_wins_over_stored_annual(self) -> None:
        assert label_period_kind("国内零售渗透率:当月值", date(2025, 9, 30)) == "month"

    def test_year_end_cumulative_is_annual(self) -> None:
        assert label_period_kind("动力电池:合计:累计值", date(2025, 12, 31)) == "annual"

    def test_year_end_cumulative_shape_is_annual(self) -> None:
        shape = period_shape(date(2025, 12, 31), "新能源汽车:销量:累计值")
        assert shape == {"period_start": date(2025, 1, 1), "period_type": "annual"}

    def test_mid_year_cumulative_shape_stays_ytd(self) -> None:
        shape = period_shape(date(2025, 9, 30), "新能源汽车:销量:累计值")
        assert shape == {"period_start": date(2025, 1, 1), "period_type": "ytd_month"}

    def test_mid_year_cumulative_stays_ytd(self) -> None:
        assert label_period_kind("动力电池:合计:累计值", date(2025, 9, 30)) == "ytd_month"

    def test_month_start_is_month_start(self) -> None:
        assert period_start_for("month", date(2025, 9, 30)) == date(2025, 9, 1)

    def test_quarter_start(self) -> None:
        assert period_start_for("quarter", date(2025, 8, 31)) == date(2025, 7, 1)

    def test_unknown_kind_does_not_invent_a_start(self) -> None:
        assert period_start_for("unknown", date(2025, 9, 30)) is None

    def test_alias_table(self) -> None:
        assert normalize_period_kind("前三季度") == "ytd_q3"
        assert normalize_period_kind("当月值") == "month"
        assert normalize_period_kind("nonsense") is None


class TestEngineNormalizeMoney:
    """The engine's 亿元 adapter must use the same table as ``money_to_yi``."""

    @staticmethod
    def _engine():
        from data_interpreter.engine import DeterministicAnalysisEngine

        return DeterministicAnalysisEngine

    def test_baiwan_is_not_wan(self) -> None:
        # Regression: substring matching read 百万元 as 万元, a factor of 100.
        assert self._engine()._normalize_money(1, "百万元") == pytest.approx(0.01)

    def test_qianwan_is_not_wan(self) -> None:
        assert self._engine()._normalize_money(1, "千万元") == pytest.approx(0.1)

    def test_wanyi_is_not_yi(self) -> None:
        assert self._engine()._normalize_money(1, "万亿元") == pytest.approx(10_000)

    @pytest.mark.parametrize(
        ("value", "unit", "expected_yi"),
        [
            (1_000_000_000, "元", 10.0),
            (100_000, "万元", 10.0),
            (10, "亿元", 10.0),
        ],
    )
    def test_existing_behaviour_is_preserved(
        self, value: float, unit: str, expected_yi: float
    ) -> None:
        assert self._engine()._normalize_money(value, unit) == pytest.approx(expected_yi)

    def test_unusual_currency_keeps_the_legacy_result(self) -> None:
        # 美元 is outside the CNY table; dropping it would shrink peer coverage,
        # so the adapter must fall back to the pre-existing behaviour.
        assert self._engine()._normalize_money(1, "亿美元") == pytest.approx(1.0)

    def test_untrusted_units_yield_none(self) -> None:
        for unit in (None, "", "unknown", "legacy_unknown"):
            assert self._engine()._normalize_money(12.0, unit) is None


class TestMoneyScalesTableUnification:
    """A4 校验与 A2 换算共用的旧表必须覆盖全部标准金额单位。"""

    @staticmethod
    def _display(actual: float, source_unit: str, target_unit: str) -> float | None:
        from agents_core.financial_semantics import _display_value

        return _display_value(actual, source_unit, target_unit)

    def test_baiwan_yuan_is_convertible(self) -> None:
        assert self._display(1, "百万元", "亿元") == pytest.approx(0.01)

    def test_qianwan_yuan_is_convertible(self) -> None:
        assert self._display(1, "千万元", "亿元") == pytest.approx(0.1)

    def test_qian_yuan_is_convertible(self) -> None:
        assert self._display(1, "千元", "万元") == pytest.approx(0.1)

    def test_wanyi_yuan_is_convertible(self) -> None:
        assert self._display(1, "万亿元", "亿元") == pytest.approx(10_000)

    def test_legacy_units_are_unchanged(self) -> None:
        assert self._display(1, "万元", "亿元") == pytest.approx(1e-4)
        assert self._display(1, "元", "亿元") == pytest.approx(1e-8)

    def test_non_money_units_stay_none(self) -> None:
        assert self._display(1, "美元", "亿元") is None
        assert self._display(3.24, "%", "亿元") is None


class TestDisclosureRounding:
    """Reported precision decides whether two numbers conflict."""

    def test_rounds_half_up(self) -> None:
        assert round_to_step(Decimal("16.15"), Decimal("0.1")) == Decimal("16.2")

    def test_cross_unit_equivalence_is_not_a_conflict(self) -> None:
        # 1 亿元 == 10_000 万元: same measurement, different display unit.
        records = [
            {"value": 1, "unit": "亿元", "metric": "营业收入"},
            {"value": 10_000, "unit": "万元", "metric": "营业收入"},
        ]
        assert measurement_conflict_verdict(records) is True

    def test_cross_unit_difference_is_a_conflict(self) -> None:
        records = [
            {"value": 1, "unit": "亿元", "metric": "营业收入"},
            {"value": 20_000, "unit": "万元", "metric": "营业收入"},
        ]
        assert measurement_conflict_verdict(records) is False

    def test_single_record_is_never_a_conflict(self) -> None:
        assert measurement_conflict_verdict(
            [{"value": 1, "unit": "亿元", "metric": "营业收入"}]
        ) is True

    def test_empty_group_is_never_a_conflict(self) -> None:
        assert measurement_conflict_verdict([]) is True
