"""净现比计算契约：分母必须可追溯，且结果与记录顺序无关。

Why this file exists
--------------------
A4 的净现比守卫（``chapter_writer.net_cash_ratio``）只允许引用 A2 **自己声明过
分母**的结果：``calculations.cash_to_net_profit.denominator_metric`` 必须等于
``parent_net_profit``，否则一律按缺口处理。

没有这个字段时，守卫会把**所有公司**判成「缺少同口径归母净利润」，正文里只能
写缺口句 —— 这是"看起来守住了、实际全丢"的静默失败。同时，``_paired_calculation``
过去用 ``sides[key] = record`` 后写覆盖，同一口径出现两条记录时分母由记录顺序决定。
"""

from __future__ import annotations

from datetime import date, datetime, timezone

from data_interpreter.engine import DeterministicAnalysisEngine
from data_interpreter.models import Domain, ResearchRecord, SourceRef, StructuredResearchDataset


def _src() -> SourceRef:
    return SourceRef(
        task_id="t", skill_id="s", query="q", trace_id="1",
        retrieved_at=datetime(2026, 9, 14, tzinfo=timezone.utc),
    )


def _company(name: str, code: str, market_cap: float) -> ResearchRecord:
    return ResearchRecord(
        record_id=f"c-{code}", domain=Domain.COMPANIES, entity_name=name,
        entity_code=code, metric="总市值", value=market_cap, unit="元", source=_src(),
    )


def _finance(record_id: str, name: str, metric: str, value: float,
             period: date = date(2025, 12, 31), unit: str = "元") -> ResearchRecord:
    return ResearchRecord(
        record_id=record_id, domain=Domain.FINANCIALS, entity_name=name,
        metric=metric, value=value, unit=unit, period_end=period, source=_src(),
    )


def _dataset(*, reversed_order: bool = False) -> StructuredResearchDataset:
    financials = [
        _finance("f-cash", "公司甲", "经营活动产生的现金流量净额", 4_0000_0000),
        _finance("f-profit", "公司甲", "归属于母公司所有者的净利润", 3_0000_0000),
    ]
    if reversed_order:
        financials.reverse()
    return StructuredResearchDataset(
        companies=[_company("公司甲", "000001.SZ", 150_0000_0000)],
        financials=financials,
    )


def _ratio(dataset: StructuredResearchDataset) -> dict:
    ratios = DeterministicAnalysisEngine().compute_financial_ratios(dataset)
    assert len(ratios) == 1
    return ratios[0]


def test_cash_ratio_declares_its_denominator() -> None:
    calculation = _ratio(_dataset())["calculations"]["cash_to_net_profit"]
    assert calculation["denominator_metric"] == "parent_net_profit"


def test_cash_ratio_keeps_both_operand_ids() -> None:
    calculation = _ratio(_dataset())["calculations"]["cash_to_net_profit"]
    assert set(calculation["input_record_ids"]) == {"f-cash", "f-profit"}
    assert calculation["formula"].startswith("operating_cash_flow/parent_net_profit")


def test_cash_ratio_is_order_invariant() -> None:
    forward = _ratio(_dataset(reversed_order=False))
    backward = _ratio(_dataset(reversed_order=True))
    assert forward["cash_to_net_profit"] == backward["cash_to_net_profit"]
    assert (forward["calculations"]["cash_to_net_profit"]["input_record_ids"]
            == backward["calculations"]["cash_to_net_profit"]["input_record_ids"])


def test_merged_net_profit_is_not_used_as_denominator() -> None:
    # 合并净利润（net_profit）不是归母净利润，不得充当分母。
    dataset = StructuredResearchDataset(
        companies=[_company("公司乙", "000002.SZ", 100_0000_0000)],
        financials=[
            _finance("g-cash", "公司乙", "经营活动产生的现金流量净额", 1_0000_0000),
            _finance("g-merged", "公司乙", "净利润", 9_0000_0000),
        ],
    )
    ratios = DeterministicAnalysisEngine().compute_financial_ratios(dataset)
    calculation = ratios[0]["calculations"].get("cash_to_net_profit")
    assert calculation is None
