"""A2 指标层的口径守卫：跨单位冲突降级 + 同比基期语义。

两个缺陷
--------
1. 同一主体、同一指标、同一观测期出现 ``1 亿元`` 与 ``20_000 万元`` 两条记录时，
   旧实现把 ``unit`` 放进分组键，于是各算一条指标、各画一条趋势 —— 读者看到的是
   两个数，实际是同一测量被拆开，其中一个必然是错的。
2. 基期 ≤0 时旧实现仍可能产出百分比（``previous and previous > 0`` 之外的分支与
   下游取整），「从亏 1 亿到赚 1 亿」会被写成「同比增长 200%」。现在显式给出
   ``change_basis``，让写作层知道这是扭亏而不是增长。
"""

from __future__ import annotations

from datetime import date, datetime, timezone

from data_interpreter.engine import DeterministicAnalysisEngine
from data_interpreter.models import (
    AnalysisRequest,
    Domain,
    ResearchRecord,
    SourceRef,
    StructuredResearchDataset,
)


def _src() -> SourceRef:
    return SourceRef(
        task_id="t", skill_id="s", query="q", trace_id="1",
        retrieved_at=datetime(2026, 9, 14, tzinfo=timezone.utc),
    )


def _rec(record_id: str, metric: str, value: float, period: date,
         unit: str = "亿元") -> ResearchRecord:
    return ResearchRecord(
        record_id=record_id, domain=Domain.FINANCIALS, entity_name="公司甲",
        metric=metric, value=value, unit=unit, period_end=period, source=_src(),
    )


def _analyze(*records: ResearchRecord):
    dataset = StructuredResearchDataset(financials=list(records))
    return DeterministicAnalysisEngine().analyze(
        dataset, AnalysisRequest(subject="测试行业", enable_semantic_analysis=False)
    )


def _metrics_by_metric(metrics):
    return [m for m in metrics if m.name == "营业收入"]


class TestCrossUnitSuppression:
    def test_conflicting_cross_unit_measurement_is_suppressed(self) -> None:
        metrics, trends, *_ = _analyze(
            _rec("a", "营业收入", 1, date(2025, 12, 31), "亿元"),
            _rec("b", "营业收入", 20_000, date(2025, 12, 31), "万元"),
        )
        assert _metrics_by_metric(metrics) == []
        assert [t for t in trends if t.metric == "营业收入"] == []

    def test_equivalent_cross_unit_measurement_is_kept(self) -> None:
        metrics, _, *_ = _analyze(
            _rec("a", "营业收入", 1, date(2025, 12, 31), "亿元"),
            _rec("b", "营业收入", 10_000, date(2025, 12, 31), "万元"),
        )
        assert len(_metrics_by_metric(metrics)) >= 1


class TestChangeBasis:
    def test_turnaround_has_no_growth_percentage(self) -> None:
        metrics, *_ = _analyze(
            _rec("p", "营业收入", -1, date(2024, 12, 31)),
            _rec("c", "营业收入", 1, date(2025, 12, 31)),
        )
        item = _metrics_by_metric(metrics)[0]
        assert item.change_pct is None
        assert item.change_basis == "turnaround"
        assert item.absolute_change == 2

    def test_zero_base_is_labelled(self) -> None:
        metrics, *_ = _analyze(
            _rec("p", "营业收入", 0, date(2024, 12, 31)),
            _rec("c", "营业收入", 1, date(2025, 12, 31)),
        )
        item = _metrics_by_metric(metrics)[0]
        assert item.change_pct is None
        assert item.change_basis == "zero_base"

    def test_positive_base_keeps_percentage_without_basis(self) -> None:
        metrics, *_ = _analyze(
            _rec("p", "营业收入", 1, date(2024, 12, 31)),
            _rec("c", "营业收入", 2, date(2025, 12, 31)),
        )
        item = _metrics_by_metric(metrics)[0]
        assert item.change_pct == 1.0
        assert item.change_basis is None
