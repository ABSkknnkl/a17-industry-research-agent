"""A2 内容守卫行为：技能里的文字规则必须真的被执行。

Why this file exists
--------------------
A2 的 skill 文档早就写着「不得给买卖评级/目标价」「当年数据不得与 2021-2025
并列」「结论不要堆原始行」。但改造前这些只是提示词里的软约束，模型不遵守就没人
拦。``analysis_guard`` 把规则变成可执行门禁，本文件锁定真实契约：

* 违规**洞察**整条隔离（``insights``），不是改写；
* 当期与历史并列的**洞察**加期间边界前缀（不删内容）；
* 行堆砌的结论压缩成首句 + 指向证据 id；
* 执行摘要只清理覆盖度模板句，不做通用去重。

执行摘要不做通用去重是**有意**的：A2 的摘要本来就允许复述，硬去重会删掉有信息
量的重复强调。这里把边界写清楚，避免后人把它当缺陷"修"成误删。
"""

from __future__ import annotations

from datetime import date

from data_interpreter.analysis_guard import (
    apply_guards,
    is_row_dump,
    normalize_insight_title,
)
from data_interpreter.models import Insight


def _insight(title: str, conclusion: str) -> Insight:
    return Insight(
        insight_id="I-1", title=title, conclusion=conclusion,
        significance="测试", confidence="medium", evidence_record_ids=["r1"],
    )


AS_OF = date(2026, 11, 15)


class TestValuationJudgementIsIsolated:
    def test_insight_with_target_price_is_dropped_and_logged(self) -> None:
        _, insights, log = apply_guards(
            executive_summary="综合来看，行业需求回暖。",
            insights=[
                _insight("估值", "当前估值处于高位，建议买入。"),
                _insight("需求", "下游需求同比增长 21%。"),
            ],
            as_of=AS_OF,
        )
        assert len(insights) == 1
        assert insights[0].title == "需求"
        assert log[0]["action"] == "isolated_valuation_judgement"
        assert "建议买入" in log[0]["matched"]


class TestMixedPeriodsAreAnnotated:
    def test_current_year_insight_gets_a_boundary_prefix(self) -> None:
        _, insights, log = apply_guards(
            executive_summary="",
            insights=[_insight("营收", "2021-2025 年营收持续增长，2026 年前三季度继续走高。")],
            as_of=AS_OF,
        )
        assert insights[0].conclusion.startswith("【当期数据，截至2026-11-15")
        assert log[0]["action"] == "period_boundary_annotated"

    def test_history_only_insight_is_untouched(self) -> None:
        original = "2021-2025 年营收由 12 亿增至 19 亿元。"
        _, insights, log = apply_guards(
            executive_summary="",
            insights=[_insight("营收", original)],
            as_of=AS_OF,
        )
        assert insights[0].conclusion == original
        assert log == []


class TestRowDumpCompression:
    def test_dump_conclusion_is_compressed(self) -> None:
        _, insights, log = apply_guards(
            executive_summary="",
            insights=[_insight(
                "逐年营收",
                "2023-12-31（年度）营收 12.3 亿、净利 1.2 亿、"
                "2024-12-31（年度）营收 15.6 亿、净利 1.8 亿、"
                "2025-12-31（年度）营收 18.9 亿。",
            )],
            as_of=AS_OF,
        )
        assert "逐年数值不在结论中罗列" in insights[0].conclusion
        assert [item["action"] for item in log] == ["compressed_data_dump_conclusion"]

    def test_row_dump_detection_needs_numbers_and_dates(self) -> None:
        assert is_row_dump("2023-12-31（年度）营收 12.3 亿、净利 1.2 亿、"
                           "2024-12-31（年度）营收 15.6 亿、净利 1.8 亿、"
                           "2025-12-31（年度）营收 18.9 亿")
        assert not is_row_dump("2025 年营收 18.9 亿元，同比增长 21%。")


class TestTitleNormalisation:
    def test_data_string_title_is_replaced(self) -> None:
        # 触发条件是「3 个以上数值」或含分号——单个日期标题属正常写法，保持原样。
        title = normalize_insight_title(
            "2023年12.3亿、2024年15.6亿、2025年18.9亿",
            "公司甲营收连续三年增长，2025 年同比增 21%。",
        )
        assert "12.3" not in title
        assert "营收" in title or "关键指标" in title

    def test_readable_title_is_kept(self) -> None:
        assert normalize_insight_title("营收数据", "公司甲营收同比增长 21%") == "营收数据"

    def test_single_date_title_is_kept(self) -> None:
        assert normalize_insight_title("2025-12-31（年度）", "公司甲营收同比增长 21%") == "2025-12-31（年度）"
