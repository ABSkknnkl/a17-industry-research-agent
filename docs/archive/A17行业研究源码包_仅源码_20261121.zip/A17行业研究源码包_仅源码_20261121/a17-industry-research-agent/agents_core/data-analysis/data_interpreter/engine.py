"""Deterministic candidate extraction: metrics, trends, anomalies, and validation."""

from __future__ import annotations

from collections import defaultdict
from datetime import date
from decimal import Decimal
from hashlib import sha256
import math
import re
from statistics import median
from typing import Any, Iterable

from agents_core.financial_semantics import (
    comparable_key,
    measurement_conflict_verdict,
    metric_family,
    money_to_yuan,
    period_shape,
)
from data_interpreter.measurement_facts import comparison_type, percentage_value

from data_interpreter.models import (
    AnalysisRequest,
    AnomalyFinding,
    CrossValidationFinding,
    DataQualityAssessment,
    Domain,
    EvidenceRef,
    EventRecord,
    IndustryChainSegment,
    KeyMetric,
    PeerCompsEntry,
    PeerCompsMatrix,
    ResearchRecord,
    StructuredResearchDataset,
    TrendFinding,
)


IMPORTANT_TOKENS = (
    "revenue", "营业收入", "净利润", "profit", "现金流", "cash_flow", "毛利率",
    "margin", "roe", "市值", "估值", "pe", "增长率", "同比", "份额", "销量",
    "产量", "价格", "渗透率", "排名", "收入占比", "利润占比",
)

NON_ANALYTIC_METRICS = {
    "para_index", "score", "status", "traceability_type", "site_authority",
    "modify_time", "operation_type", "channel", "id", "uid", "index", "name",
    "上市日期", "listing_date",
}

# 参与「同一报告期」对齐的财务指标族。估值/市值（pe/pb/ps/market_cap）是点位数据，
# 不参与期间对齐，否则会把 2026-11-20 的 PE 强行绑到 2025 年报。
_FINANCIAL_ALIGNMENT_FAMILIES = frozenset({
    "revenue", "revenue_yoy", "parent_net_profit", "net_profit", "net_profit_yoy",
    "gross_margin", "net_margin", "operating_cash_flow", "roe", "debt_ratio",
    "rd_expense", "rd_ratio", "cash_to_net_profit",
})

# Entity names / substrings that denote a sector, index or aggregate rather than a
# single listed company. Promoted to module scope so both peer-comps collection and
# industry-chain extraction share one source of truth (values are identical to the
# former local copies inside extract_industry_chain).
NON_COMPANY_ENTITY_NAMES = {
    "宏观", "研究主题", "全国", "中国", "行业", "各行业", "市场", "全部", "总计", "平均",
}
NON_COMPANY_ENTITY_PATTERNS = (
    "指数", "板块", "概念", "ETF", "LOF", "主题", "基金", "大盘", "综指", "中国AI", "AI手机", "成分",
)


def _is_aggregate_entity(name: str | None) -> bool:
    """True when the entity denotes a sector/index/aggregate instead of a concrete company."""
    if not name:
        return True
    text = name.strip()
    if not text:
        return True
    # Whitelist protection: known listed company names are never aggregate entities
    if text in COMMON_TICKER_NAMES.values():
        return False
    norm_text = re.sub(r"[\(（\[].*?[\)）\]]", "", text).strip() or text
    if norm_text in COMMON_TICKER_NAMES.values():
        return False
    # Strict exact match for sector/aggregate terms (never substring match "中国")
    if text in NON_COMPANY_ENTITY_NAMES or norm_text in NON_COMPANY_ENTITY_NAMES:
        return True
    for pat in NON_COMPANY_ENTITY_PATTERNS:
        if pat == "成分":
            if norm_text in ("成分", "成分股") or norm_text.endswith("成分股"):
                return True
        elif pat in text:
            return True
    return False


_SEGMENT_METRIC_TOKENS = ("主营构成", "收入占比", "业务收入", "业务成本", "业务利润", "成本占比", "利润占比")
_SEGMENT_RAW_FIELDS = ("项目名称", "分类标准", "主营构成", "产品名称", "业务板块")


def _is_segment_level_record(record: "ResearchRecord") -> bool:
    """分部/主营构成口径的记录不能当作公司整体指标。

    实测（2026-11-20 商业航天）：``主营构成-毛利率`` 的 7 条连接器/光器件分部数据
    都被 metric_family 归成 gross_margin，同期间下会覆盖公司整体毛利率 29.19%，
    使 PE/毛利率矩阵与正文出现 31.72%、29.03% 等分部值。
    """
    raw = getattr(record, "raw_fields", None) or {}
    if isinstance(raw, dict) and any(key in raw for key in _SEGMENT_RAW_FIELDS):
        return True
    return any(token in str(getattr(record, "metric", "")) for token in _SEGMENT_METRIC_TOKENS)


def _is_index_record(record: "ResearchRecord") -> bool:
    """同花顺/万得行业指数记录不能当成上市公司。

    实测 2026-11-20：``商业航天``（886078.TI）的 close_price=1595.142 点被
    当作 peer，图表出现「商业航天收盘价」并因单位=点/其余=元触发 chart_contract。
    """
    code = str(getattr(record, "entity_code", "") or "").upper()
    if code.endswith(".TI") or code.startswith("88"):
        return True
    raw = getattr(record, "raw_fields", None) or {}
    if isinstance(raw, dict) and ("指数代码" in raw or "指数简称" in raw):
        return True
    return False


def _id(prefix: str, *parts: Any) -> str:
    raw = "|".join(str(part) for part in parts)
    return f"{prefix}-{sha256(raw.encode()).hexdigest()[:16]}"


def _number(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)) and math.isfinite(float(value)):
        return float(value)
    if isinstance(value, str):
        text = value.strip().replace(",", "")
        scale = 1.0
        for suffix, factor in (("万亿元", 1e12), ("亿元", 1e8), ("万元", 1e4), ("万", 1e4), ("%", 0.01)):
            if text.endswith(suffix):
                text, scale = text[: -len(suffix)], factor
                break
        try:
            result = float(text) * scale
            return result if math.isfinite(result) else None
        except ValueError:
            return None
    return None


COMMON_TICKER_NAMES: dict[str, str] = {
    "001232.SZ": "天振股份",
    "002243.SZ": "力合科创",
    "300124.SZ": "汇川技术",
    "300474.SZ": "景嘉微",
    "300697.SZ": "电连技术",
    "301237.SZ": "和顺科技",
    "600118.SH": "中国卫星",
    "600879.SH": "航天电子",
    "600150.SH": "中国船舶",
    "600760.SH": "中航沈飞",
    "002025.SZ": "航天电器",
    "002384.SZ": "东山精密",
    "300327.SZ": "中来股份",
    "600456.SH": "宝钛股份",
    "601678.SH": "滨化股份",
    "600261.SH": "阳光照明",
    "603130.SH": "一鸣食品",
    "688385.SH": "复旦微电",
    "600345.SH": "长江通信",
    "688523.SH": "航天环宇",
    "000070.SZ": "特发信息",
    "002583.SZ": "海能达",
    "300342.SZ": "天银机电",
    "300296.SZ": "利亚德",
    "688507.SH": "索辰科技",
    "301005.SZ": "超捷股份",
    "688790.SH": "昂瑞微",
    "688543.SH": "国科军工",
    "002413.SZ": "雷科防务",
    "002204.SZ": "大连重工",
    "920116.BJ": "星图测控",
    "002361.SZ": "神剑股份",
    "300762.SZ": "上海瀚讯",
    "688002.SH": "睿创微纳",
    "688126.SH": "沪硅产业",
    "688568.SH": "中科星图",
    "688220.SH": "翱捷科技",
    "688244.SH": "永信至诚",
    "688327.SH": "云从科技",
    "688787.SH": "海天瑞声",
}


def resolve_ticker(code: str | None, context_map: dict[str, str] | None = None) -> str | None:
    """把证券代码解析为公司名（优先使用本批次动态映射，再回退内置表）。

    Args:
        code: 证券代码或代码形态的实体名（如 `001287.SZ`）。
        context_map: 本次数据集内的 `entity_code → 公司名` 动态映射（队友机制，2026-09-26 合并）。
            优先于内置 `COMMON_TICKER_NAMES`，用于消解内置表未覆盖的新标的（如当批次临时样本）。

    Returns:
        解析出的公司名；无法解析时原样返回 `code`。
    """
    if not code:
        return None
    c = str(code).strip().upper()
    if context_map and c in context_map:
        return context_map[c]
    if c in COMMON_TICKER_NAMES:
        return COMMON_TICKER_NAMES[c]
    no_suf = re.sub(r"\.(SZ|SH|BJ|HK|US)$", "", c)
    if context_map:
        for k, v in context_map.items():
            if k.startswith(no_suf):
                return v
    for k, v in COMMON_TICKER_NAMES.items():
        if k.startswith(no_suf):
            return v
    return code


def _entity(record: ResearchRecord, context_map: dict[str, str] | None = None) -> str | None:
    if record.entity_name and record.entity_name.strip():
        name = record.entity_name.strip()
        if re.match(r"^\d{6}\.(SZ|SH|BJ|HK|US)$", name, re.I):
            resolved = resolve_ticker(name, context_map=context_map)
            if resolved and not re.match(r"^\d{6}\.(SZ|SH|BJ|HK|US)$", resolved, re.I):
                return resolved
            if getattr(record, "raw_fields", None) and isinstance(record.raw_fields, dict):
                for k in ("成分简称", "股票简称", "证券简称", "公司简称", "公司名称", "成分名称", "名称"):
                    v = record.raw_fields.get(k)
                    if v and str(v).strip() and not re.match(r"^\d{6}\.(SZ|SH|BJ|HK|US)$", str(v).strip(), re.I):
                        return str(v).strip()
        else:
            return name
    if getattr(record, "raw_fields", None) and isinstance(record.raw_fields, dict):
        for k in ("成分简称", "股票简称", "证券简称", "公司简称", "公司名称", "成分名称", "名称"):
            v = record.raw_fields.get(k)
            if v and str(v).strip() and not re.match(r"^\d{6}\.(SZ|SH|BJ|HK|US)$", str(v).strip(), re.I):
                return str(v).strip()
    return resolve_ticker(record.entity_code, context_map=context_map)



def _period(record: ResearchRecord) -> date | None:
    return record.period_end


def _metric_key(record: ResearchRecord) -> str:
    return record.metric.strip().casefold()


def _has_conflicting_measurement(values: list[tuple[ResearchRecord, float]]) -> bool:
    """No record ordering may arbitrate two values for one measurement."""
    by_measurement: dict[tuple | None, set[float]] = defaultdict(set)
    for record, value in values:
        by_measurement[comparable_key(record)].add(value)
    return any(len(observed) > 1 for observed in by_measurement.values())


def _cross_unit_ambiguous(numeric: list[tuple[ResearchRecord, float]]) -> set[tuple]:
    """P-11：金额跨单位（万元/亿元）先换算再比较，冲突或待核的测量整体降级。

    分组键是「主体/指标/观测期形态」，与 A1 的跨单位判定共用
    ``measurement_conflict_verdict``；返回的键用于屏蔽该测量在所有单位分组下的
    关键指标与趋势，避免一边按万元、一边按亿元各算一条。
    """
    grouped: dict[tuple, list[ResearchRecord]] = defaultdict(list)
    for record, _value in numeric:
        key = comparable_key(record, include_year=False)
        if key is None:
            continue
        grouped[(_entity(record), _metric_key(record), key)].append(record)
    ambiguous: set[tuple] = set()
    for key, records in grouped.items():
        if len({str(record.unit) for record in records}) <= 1:
            continue
        if measurement_conflict_verdict(records) is not True:
            ambiguous.add(key)
    return ambiguous


def _change_basis(previous: float | None, current: float) -> str | None:
    """基期 ≤0 时说明为何没有百分比（P-08）。"""
    if previous is None or previous > 0:
        return None
    if previous == 0:
        return "zero_base"
    return "turnaround" if current > 0 else "non_positive_base"


def _is_analytic_numeric(record: ResearchRecord) -> bool:
    return (
        record.domain not in (Domain.REPORTS, Domain.NEWS)
        and _metric_key(record) not in NON_ANALYTIC_METRICS
    )


def _mad(values: list[float]) -> float:
    center = median(values)
    return median([abs(value - center) for value in values])


def _is_industry_relevant(company_name: str, ind_text: str, subject: str | None) -> bool:
    """Universal industry domain compatibility check: filter out cross-industry concept giants without industry hardcoding."""
    if not subject or not ind_text:
        return True
    s = subject.lower().strip()
    ind = ind_text.lower().strip()
    c = (company_name or "").lower().strip()

    # 1. 白名单保护：若公司名称与主题关键词直接包含，100% 保留
    if c and (c in s or s in c):
        return True

    # 主题核心分词
    s_tokens = [t for t in re.split(r"[\s/、,，]+", s) if len(t) >= 2 and t not in ("行业", "产业", "概念", "经济", "中国", "全国", "市场", "深度", "研究", "分析")]
    if c and any(t in c for t in s_tokens):
        return True

    # 若行业文本或主营文本直接命中主题分词，直接保留
    if any(t in ind for t in s_tokens):
        return True

    # 2. 全市场通用领域正交互斥过滤（Domain-Orthogonal Cross-Industry Cleaning）
    # (1) 金融、地产与建筑排斥非对应主题
    if any(bad in ind for bad in ("银行", "保险", "证券", "非银金融", "房地产", "建筑装饰")):
        if not any(k in s for k in ("金融", "银行", "证券", "保险", "地产", "房", "建筑")):
            return False

    # (2) 传统化石能源、重周期采掘与钢铁排斥非化石能源与重工主题（注意：新能源绝不等于传统石油石化与煤炭）
    if any(bad in ind for bad in ("石油石化", "煤炭", "采掘", "钢铁")):
        is_fossil_or_heavy = any(k in s for k in ("石化", "石油", "煤炭", "油气", "采掘", "矿产", "钢铁", "黑色金属")) or ("传统能源" in s or ("能源" in s and "新能源" not in s))
        if not is_fossil_or_heavy:
            return False

    # (3) 食品饮料白酒排斥非食品饮料/大消费/农业主题
    if any(bad in ind for bad in ("食品饮料", "白酒", "乳制品", "调味品", "饮料")):
        if not any(k in s for k in ("食品", "饮料", "消费", "酒", "农业", "餐饮", "乳", "食")):
            return False

    # (4) 传统医药生物排斥非生命健康/医药医疗/动保主题
    if any(bad in ind for bad in ("医药生物", "化学制药", "中药", "生物制品")):
        if not any(k in s for k in ("医", "药", "生物", "健康", "疫苗", "器械", "宠", "诊", "病")):
            return False

    # (5) 纯通信设备/光模块/光器件/CPO排斥非通信网络与算力主题
    if "通信" in ind and any(k in ind for k in ("通信设备", "光模块", "光器件", "光通信", "光纤", "cpo")):
        if not any(k in s for k in ("通信", "5g", "6g", "光模块", "光器件", "cpo", "网络", "算力", "信息", "通信设备")):
            return False

    # (6) 纯消费电子（手机/耳机/穿戴）排斥非消费电子主题
    if any(bad in ind for bad in ("消费电子", "品牌消费电子", "手机", "智能穿戴")):
        if not any(k in s for k in ("消费电子", "手机", "耳机", "穿戴", "数码", "3c", "果链", "苹果链", "安卓")):
            return False

    # (7) 纯安防监控设备排斥非安防/智慧监控主题
    if any(bad in ind for bad in ("安防设备", "视频监控", "安防")):
        if not any(k in s for k in ("安防", "监控", "智能安防", "安保")):
            return False

    # (8) 纯物流快递仓储排斥非物流货运主题
    if any(bad in ind for bad in ("快递", "物流", "仓储", "货运")):
        if not any(k in s for k in ("物流", "快递", "仓储", "货运", "供应链服务")):
            return False

    # (9) 纯汽车整车/商用车排斥非交通出行与动力制造主题
    if "汽车" in ind and any(k in ind for k in ("汽车整车", "乘用车", "商用车")):
        if not any(k in s for k in ("车", "汽车", "汽配", "交通", "出行", "动力", "整车")):
            return False

    return True


class DeterministicAnalysisEngine:
    def analyze(
        self, dataset: StructuredResearchDataset, request: AnalysisRequest
    ) -> tuple[
        list[KeyMetric], list[TrendFinding], list[AnomalyFinding],
        list[CrossValidationFinding], dict[str, EvidenceRef], DataQualityAssessment,
    ]:
        records = dataset.all_records()
        evidence = {record.record_id: self._evidence(record) for record in records}
        numeric = [
            (record, value)
            for record in records
            if _is_analytic_numeric(record) and (value := _number(record.value)) is not None
        ]
        metrics = self._key_metrics(numeric, request.max_key_metrics)
        trends = self._trends(numeric)
        anomalies = self._anomalies(dataset, numeric, request.outlier_threshold)
        validations = self._cross_validate(dataset, numeric, request.relative_tolerance)
        quality = self._quality(dataset, records, numeric)
        ratios = self._annual_rd_ratios(dataset)
        for ratio in ratios:
            evidence[ratio.record_id] = self._evidence(ratio).model_copy(update={
                "input_record_ids": ratio.raw_fields["input_record_ids"],
            })
        trends = self._trends([(ratio, ratio.value) for ratio in ratios]) + trends
        # Evidence identity belongs to the input records, including duplicate and
        # conflicting observations that a normalized metric view does not select.
        return metrics, trends, anomalies, validations, evidence, quality

    @staticmethod
    def _evidence(record: ResearchRecord) -> EvidenceRef:
        raw_fields = record.raw_fields or {}
        source_url = raw_fields.get("source_url") or raw_fields.get("url")
        source_locator = raw_fields.get("source_locator")
        if source_url and not source_locator:
            if record.domain == Domain.REPORTS:
                source_locator = "研究报告原文页"
            elif record.domain == Domain.NEWS:
                source_locator = "新闻原文页"
            else:
                source_locator = "原文页面"
        return EvidenceRef(
            record_id=record.record_id,
            domain=record.domain,
            entity=_entity(record),
            metric=record.metric,
            value=record.value,
            unit=record.unit,
            unit_provenance=getattr(record, "unit_provenance", "legacy_unknown"),
            period=_period(record),
            period_start=record.period_start or period_shape(record.period_end)["period_start"],
            period_type=record.period_type if record.period_type != "unknown" else period_shape(record.period_end)["period_type"],
            period_provenance=record.period_provenance, scope=record.scope, currency=record.currency, issues=record.issues,
            skill_id=record.source.skill_id,
            trace_id=record.source.trace_id,
            source_url=source_url, source_locator=source_locator,
            published_at=record.published_at, document_sha256=raw_fields.get("document_sha256"),
        )

    @staticmethod
    def _event_evidence(ev: EventRecord) -> EvidenceRef:
        """结构化事件 → 证据条目（类D P-06 下游衔接）。

        事件不是数值指标：metric=事件类型、value=公告标题+正文、period=公告日期、
        domain="events"（字符串，非七域枚举），供 _filter_evidence_for_skill 的
        events 域别名分发给声明了事件域的技能；不进入数值分析（CAGR/异常检测）。

        AB-2/E01：同时保留标题与正文。仅有标题时关键催化内容可能只在正文，
        用明确分隔符（换行）合并，避免下游技能上下文缺正文；各事件仍按 record_id
        独立，不把同公司不同事件合并。正文已含于标题时不重复。
        """
        title = (ev.title or "").strip()
        body = (ev.body or "").strip()
        raw_fields = ev.raw_fields or {}
        source_url = raw_fields.get("source_url") or raw_fields.get("url")
        source_locator = raw_fields.get("source_locator")
        if source_url and not source_locator:
            source_locator = "公告 PDF 全文" if ".pdf" in str(source_url).casefold() else "公告原文页"
        if title and body and body not in title:
            value: Any = f"{title}\n{body}"
        else:
            value = title or body or None
        return EvidenceRef(
            record_id=ev.record_id,
            domain="events",
            entity=ev.entity_name,
            metric=ev.event_type or "event",
            value=value,
            unit=None,
            period=ev.announce_date,
            published_at=ev.announce_date,
            skill_id=ev.source.skill_id if ev.source else "",
            trace_id=ev.source.trace_id if ev.source else "",
            source_url=source_url,
            source_locator=source_locator,
            document_sha256=raw_fields.get("document_sha256"),
        )

    def _key_metrics(
        self, numeric: list[tuple[ResearchRecord, float]], limit: int
    ) -> list[KeyMetric]:
        grouped: dict[tuple[str | None, str], list[tuple[ResearchRecord, float]]] = defaultdict(list)
        for record, value in numeric:
            key = comparable_key(record, include_year=False)
            if key is not None:
                grouped[(_entity(record), (_metric_key(record), key, record.unit))].append((record, value))
        ranked: list[tuple[float, KeyMetric]] = []
        cross_unit_ambiguous = _cross_unit_ambiguous(numeric)
        for (entity, _), values in grouped.items():
            # Keep the evidence index intact, but withhold a deterministic
            # key/comparison for an unresolved measurement series.
            first_record = values[0][0]
            measurement_key = (_entity(first_record), _metric_key(first_record),
                               comparable_key(first_record, include_year=False))
            if measurement_key in cross_unit_ambiguous or _has_conflicting_measurement(values):
                continue
            dated = sorted(values, key=lambda pair: (_period(pair[0]) or date.min, pair[0].record_id))
            current_record, current = dated[-1]
            previous_pair = next((pair for pair in reversed(dated[:-1])
                                  if _period(pair[0]) != _period(current_record)), None)
            previous = previous_pair[1] if previous_pair else None
            previous_period = _period(previous_pair[0]) if previous_pair else None
            change = current - previous if previous is not None else None
            comparison = comparison_type(previous_period, _period(current_record)) if previous_period else None
            change_pct = change / previous if change is not None and previous is not None and previous > 0 and comparison != "historical_same_period" else None
            token_score = 1.0 if any(token in current_record.metric.casefold() for token in IMPORTANT_TOKENS) else 0.35
            date_score = 0.2 if _period(current_record) else 0.0
            history_score = min(0.25, 0.05 * (len(dated) - 1))
            score = min(1.0, 0.45 + 0.35 * token_score + date_score + history_score)
            item = KeyMetric(
                metric_id=_id("K", entity, current_record.metric, comparable_key(current_record), current_record.unit),
                name=current_record.metric,
                entity=entity,
                value=current,
                unit=current_record.unit,
                period=_period(current_record),
                previous_value=previous,
                previous_period=previous_period,
                comparison_type=comparison,
                period_start=current_record.period_start or period_shape(current_record.period_end)["period_start"],
                period_type=current_record.period_type if current_record.period_type != "unknown" else period_shape(current_record.period_end)["period_type"],
                scope=current_record.scope,
                absolute_change=change,
                change_pct=change_pct,
                change_basis=_change_basis(previous, current) if change is not None else None,
                percentage_point_change=percentage_value(current_record.unit, change) if change is not None else None,
                importance_score=score,
                evidence_record_ids=([previous_pair[0].record_id] if previous_pair else []) + [current_record.record_id],
            )
            ranked.append((score, item))
        ranked.sort(key=lambda pair: (pair[0], pair[1].period or date.min, abs(pair[1].value)), reverse=True)
        selected: list[KeyMetric] = []
        per_metric: dict[str, int] = defaultdict(int)
        for _, item in ranked:
            key = item.name.casefold()
            if per_metric[key] >= 3:
                continue
            selected.append(item)
            per_metric[key] += 1
            if len(selected) >= limit:
                break
        if len(selected) < limit:
            chosen = {item.metric_id for item in selected}
            selected.extend(item for _, item in ranked if item.metric_id not in chosen)
        return selected[:limit]

    def _trends(self, numeric: list[tuple[ResearchRecord, float]]) -> list[TrendFinding]:
        grouped: dict[tuple[str | None, str], list[tuple[ResearchRecord, float]]] = defaultdict(list)
        for record, value in numeric:
            if _period(record):
                key = comparable_key(record, include_year=False)
                if key is not None:
                    grouped[(_entity(record), (_metric_key(record), key, record.unit))].append((record, value))
        findings: list[TrendFinding] = []
        ambiguous = {key for key, values in grouped.items() if _has_conflicting_measurement(values)}
        for group_key, values in grouped.items():
            if group_key in ambiguous:
                continue
            entity = group_key[0]
            by_period: dict[date, tuple[ResearchRecord, float]] = {}
            for record, value in values:
                by_period[_period(record)] = (record, value)  # type: ignore[index]
            ordered = [by_period[key] for key in sorted(by_period)]
            if len(ordered) < 2:
                continue
            changes = [b[1] - a[1] for a, b in zip(ordered, ordered[1:])]
            nonzero = [change for change in changes if change != 0]
            positive = sum(change > 0 for change in nonzero)
            negative = sum(change < 0 for change in nonzero)
            monotonicity = max(positive, negative) / len(nonzero) if nonzero else 1.0
            first, last = ordered[0][1], ordered[-1][1]
            total_pct = (last - first) / abs(first) if first else None
            if monotonicity < 0.67:
                direction = "volatile"
            elif total_pct is None or abs(total_pct) < 0.02:
                direction = "flat"
            else:
                direction = "up" if total_pct > 0 else "down"
            magnitude = abs(total_pct or 0)
            strength = "strong" if monotonicity >= 0.8 and magnitude >= 0.2 else "moderate" if monotonicity >= 0.67 and magnitude >= 0.05 else "weak"
            findings.append(TrendFinding(
                trend_id=_id("T", entity, ordered[-1][0].metric, comparable_key(ordered[-1][0])),
                metric=ordered[-1][0].metric,
                entity=entity,
                direction=direction,
                strength=strength,
                period_start=_period(ordered[0][0]),  # type: ignore[arg-type]
                period_end=_period(ordered[-1][0]),  # type: ignore[arg-type]
                observations=len(ordered),
                total_change_pct=total_pct,
                percentage_point_change=percentage_value(ordered[-1][0].unit, last-first),
                comparison_type="same_duration_observation_change",
                monotonicity=monotonicity,
                method="按报告期排序，比较首末值并计算相邻期方向一致率",
                evidence_record_ids=[record.record_id for record, _ in ordered],
            ))
        existing = {(item.entity, item.metric.casefold()) for item in findings}
        for record, value in numeric:
            if (_entity(record), (_metric_key(record), comparable_key(record, include_year=False), record.unit)) in ambiguous:
                continue
            if record.domain == Domain.INDUSTRY and record.entity_code:
                # Do not turn industry sector index growth into individual component company trends
                continue
            metric_key = _metric_key(record)
            entity = _entity(record)
            if not any(token in metric_key for token in ("同比", "环比", "增长率", "yoy", "qoq")):
                continue
            if (entity, metric_key) in existing:
                continue
            # If the entity already has an actual multi-period trend for financial metrics, skip redundant single-point YoY trend
            if any(item.entity == entity and item.observations >= 2 and any(k in item.metric for k in ("收入", "营收", "利润", "revenue", "profit")) for item in findings) and any(k in metric_key for k in ("收入", "营收", "利润", "revenue", "profit")):
                continue
            unit = str(record.unit or "").strip().casefold()
            normalized = value / 100 if unit in ("%", "％", "百分比", "百分点", "percent", "percentage") else value
            direction = "up" if normalized > 0.001 else "down" if normalized < -0.001 else "flat"
            magnitude = abs(normalized)
            strength = "strong" if magnitude >= 0.2 else "moderate" if magnitude >= 0.05 else "weak"
            findings.append(TrendFinding(
                trend_id=_id("T", "explicit", entity, record.metric),
                metric=record.metric,
                entity=entity,
                direction=direction,
                strength=strength,
                period_start=_period(record),
                period_end=_period(record),
                observations=1,
                total_change_pct=normalized,
                monotonicity=1.0,
                method="指标本身为同比、环比或增长率，直接按其符号和幅度识别方向",
                evidence_record_ids=[record.record_id],
            ))
            existing.add((entity, metric_key))
        return sorted(findings, key=lambda item: (item.strength == "strong", item.observations), reverse=True)


    def _anomalies(
        self,
        dataset: StructuredResearchDataset,
        numeric: list[tuple[ResearchRecord, float]],
        threshold: float,
    ) -> list[AnomalyFinding]:
        findings: list[AnomalyFinding] = []
        for conflict in dataset.conflicts:
            findings.append(AnomalyFinding(
                anomaly_id=_id("A", "conflict", conflict.conflict_key),
                kind="source_conflict",
                severity="high",
                metric=conflict.metric,
                entity=conflict.entity,
                period=conflict.period,
                observed_value=conflict.values,
                explanation="同一实体、指标和期间在不同来源中出现不一致值，结论生成前需保留冲突。",
                evidence_record_ids=conflict.record_ids,
            ))
        buckets: dict[tuple[Domain, str, date | None], dict[str, tuple[ResearchRecord, float]]] = defaultdict(dict)
        for record, value in numeric:
            entity = _entity(record)
            if entity:
                buckets[(record.domain, _metric_key(record), _period(record))].setdefault(entity, (record, value))
        for entity_values in buckets.values():
            values = list(entity_values.values())
            if len(values) < 5:
                continue
            nums = [value for _, value in values]
            center, dispersion = median(nums), _mad(nums)
            if dispersion == 0:
                continue
            for record, value in values:
                score = 0.6745 * (value - center) / dispersion
                if abs(score) >= threshold:
                    sev = "high" if abs(score) >= threshold * 2 else "medium"
                    findings.append(AnomalyFinding(
                        anomaly_id=_id("A", "outlier", record.record_id),
                        kind="cross_sectional_outlier",
                        severity=sev,
                        metric=record.metric,
                        entity=_entity(record),
                        period=_period(record),
                        observed_value=value,
                        expected_range=f"横截面中位数 {center:g}，MAD {dispersion:g}",
                        score=score,
                        explanation="该值的稳健 Z 分数超过阈值，属于横截面离群候选。",
                        evidence_record_ids=[record.record_id],
                        charting_guidance="suppress_or_isolate" if sev == "high" else None,
                    ))
        series: dict[tuple[str | None, str], list[tuple[ResearchRecord, float]]] = defaultdict(list)
        for record, value in numeric:
            if _period(record):
                key = comparable_key(record, include_year=False)
                if key is not None:
                    series[(_entity(record), (_metric_key(record), key, record.unit))].append((record, value))
        for values in series.values():
            by_period = {_period(record): (record, value) for record, value in values}
            ordered = [by_period[key] for key in sorted(by_period)]
            if len(ordered) < 4:
                continue
            changes = [current[1] - previous[1] for previous, current in zip(ordered, ordered[1:])]
            historical, latest = changes[:-1], changes[-1]
            center, dispersion = median(historical), _mad(historical)
            if dispersion == 0:
                baseline = max(abs(center), max((abs(value) for value in historical), default=0), 1.0)
                score = (latest - center) / baseline
                abnormal = abs(score) >= 2.0
            else:
                score = 0.6745 * (latest - center) / dispersion
                abnormal = abs(score) >= threshold
            if abnormal:
                record = ordered[-1][0]
                findings.append(AnomalyFinding(
                    anomaly_id=_id("A", "spike", record.record_id),
                    kind="time_series_spike",
                    severity="high" if abs(score) >= threshold * 2 else "medium",
                    metric=record.metric,
                    entity=_entity(record),
                    period=_period(record),
                    observed_value=record.value,
                    expected_range=f"历史相邻期变化中位数 {center:g}，MAD {dispersion:g}",
                    score=score,
                    explanation="最新一期变化相对历史相邻期变化出现显著偏离。",
                    evidence_record_ids=[item[0].record_id for item in ordered],
                ))
        for record in dataset.all_records():
            if record.issues:
                findings.append(AnomalyFinding(
                    anomaly_id=_id("A", "quality", record.record_id),
                    kind="data_quality",
                    severity="low",
                    metric=record.metric,
                    entity=_entity(record),
                    period=_period(record),
                    observed_value=record.value,
                    explanation="原始融合记录存在质量标记：" + "、".join(record.issues),
                    evidence_record_ids=[record.record_id],
                ))
        order = {"high": 3, "medium": 2, "low": 1}
        return sorted(findings, key=lambda item: order[item.severity], reverse=True)

    def _cross_validate(
        self,
        dataset: StructuredResearchDataset,
        numeric: list[tuple[ResearchRecord, float]],
        tolerance: float,
    ) -> list[CrossValidationFinding]:
        grouped: dict[tuple[str | None, str, date | None], list[tuple[ResearchRecord, float]]] = defaultdict(list)
        for record, value in numeric:
            grouped[(_entity(record), _metric_key(record), _period(record))].append((record, value))
        findings: list[CrossValidationFinding] = []
        conflict_ids = {record_id for conflict in dataset.conflicts for record_id in conflict.record_ids}
        for (entity, _, period), values in grouped.items():
            source_ids = {record.source.skill_id for record, _ in values}
            if len(source_ids) < 2:
                continue
            record_ids = [record.record_id for record, _ in values]
            nums = [value for _, value in values]
            scale = max(max(abs(value) for value in nums), 1.0)
            spread = (max(nums) - min(nums)) / scale
            contradicted = bool(conflict_ids.intersection(record_ids)) or spread > tolerance
            metric = values[0][0].metric
            findings.append(CrossValidationFinding(
                validation_id=_id("V", entity, metric, period),
                claim=f"{entity or '研究主题'}的{metric}在{period or '同一口径'}下来源一致",
                status="contradicted" if contradicted else "confirmed",
                method=f"比较不同 Skill 来源的同实体、同指标、同期间数值，相对容差 {tolerance:.1%}",
                sources=sorted(source_ids),
                explanation=("来源数值超出容差或已被上游标记为冲突。" if contradicted else "不同来源数值处于容差范围内。"),
                evidence_record_ids=record_ids,
            ))

        # Cross-statement financial logic validation (e.g. Operating Cash Flow vs Net Profit)
        company_fin_period: dict[tuple, dict[str, tuple[float, str]]] = defaultdict(dict)
        for record, value in numeric:
            ent = _entity(record)
            if not ent or re.match(r"^\d{6}\.(SZ|SH|BJ|HK|US)$", ent, re.I):
                continue
            m_k = _metric_key(record)
            per = comparable_key(record)
            if per is None:
                continue
            if metric_family(record.metric) in ("operating_cash_flow", "parent_net_profit", "net_profit"):
                normalized = self._normalize_money(value, record.unit)
                if normalized is None:
                    continue
                value = normalized
            if any(k in m_k for k in ("operating_cash_flow", "经营活动产生的现金流量净额", "经营现金流")):
                company_fin_period[(ent, per)]["cash_flow"] = (value, record.record_id)
            elif any(k in m_k for k in ("parent_net_profit", "归属于母公司", "归母净利润", "净利润")) and "同比" not in m_k:
                company_fin_period[(ent, per)]["net_profit"] = (value, record.record_id)
            elif any(k in m_k for k in ("pe_ttm", "动态市盈率", "市盈率")) and "平均" not in m_k and "中值" not in m_k:
                company_fin_period[(ent, per)]["pe"] = (value, record.record_id)
            elif any(k in m_k for k in ("净利润同比增长率", "净利润同比", "net_profit_yoy")):
                company_fin_period[(ent, per)]["np_yoy"] = (value, record.record_id)

        for (ent, period_key), fin in company_fin_period.items():
            per = period_key[0]
            # 1. 净现比 / 盈利现金流勾稽
            if "cash_flow" in fin and "net_profit" in fin:
                cf_val, cf_id = fin["cash_flow"]
                np_val, np_id = fin["net_profit"]
                cf_norm = cf_val
                np_norm = np_val
                if np_norm > 0 and cf_norm < 0:
                    findings.append(CrossValidationFinding(
                        validation_id=_id("V-CF-NP", ent, per),
                        claim=f"{ent}在{per or '最新报告期'}出现净现背离（净利润为正但经营现金流为负）",
                        status="contradicted",
                        kind="financial_difference",
                        method="净现比一致性检验：对比经营活动产生的现金流量净额与归母净利润符号及现金转化效率",
                        sources=["financial_statements"],
                        explanation=f"净利润为正({np_norm:.2f}亿)，但经营现金流为负({cf_norm:.2f}亿)，属于不同会计指标的经济差异；应收账款、存货或其他原因待核，不构成同指标多来源冲突。",
                        evidence_record_ids=[cf_id, np_id],
                    ))
                elif np_norm > 0 and cf_norm > 0:
                    c2n = round(cf_norm / np_norm, 2)
                    findings.append(CrossValidationFinding(
                        validation_id=_id("V-CF-NP", ent, per),
                        claim=f"{ent}在{per or '最新报告期'}盈利现金造血健康（净现比约为{c2n}）",
                        status="confirmed" if c2n >= 0.7 else "insufficient",
                        kind="financial_difference",
                        method="净现比一致性检验：对比经营活动产生的现金流量净额与归母净利润符号及现金转化效率",
                        sources=["financial_statements"],
                        explanation=f"经营现金流与净利润方向一致(净现比={c2n})，符合健康商业回款规律。" if c2n >= 0.7 else f"经营现金流为正但低于净利润(净现比={c2n})，部分利润尚未完全变现。",
                        evidence_record_ids=[cf_id, np_id],
                    ))
            # 2. 估值与成长匹配度校验 (PEG)
            if "pe" in fin and "np_yoy" in fin:
                pe_val, pe_id = fin["pe"]
                yoy_val, yoy_id = fin["np_yoy"]
                if pe_val > 100 and yoy_val < 0:
                    findings.append(CrossValidationFinding(
                        validation_id=_id("V-PE-YOY", ent, per),
                        claim=f"{ent}估值与业绩成长性背离（市盈率处于高位但净利润同比下滑）",
                        status="contradicted",
                        kind="valuation_growth_difference",
                        method="PEG基本面一致性检验：对比PE(TTM)与归母净利润同比增速",
                        sources=["valuation_and_growth"],
                        explanation=f"动态市盈率高达{pe_val:.1f}倍，但归母净利润下滑{abs(yoy_val):.1f}%，基本面短期内难以支撑高估值溢价。",
                        evidence_record_ids=[pe_id, yoy_id],
                    ))
        return findings

    @staticmethod
    def _quality(
        dataset: StructuredResearchDataset,
        records: list[ResearchRecord],
        numeric: list[tuple[ResearchRecord, float]],
    ) -> DataQualityAssessment:
        dated = sum(_period(record) is not None for record, _ in numeric)
        source_count = len({record.source.trace_id or record.source.skill_id for record in records})
        issue_count = sum(bool(record.issues) for record in records)
        limitations: list[str] = []
        if not records:
            limitations.append("输入数据集为空")
        if numeric and dated / len(numeric) < 0.5:
            limitations.append("超过一半的数值记录缺少可用于趋势分析的日期")
        if source_count < 2:
            limitations.append("来源少于两个，无法进行充分的跨来源验证")
        if dataset.conflicts:
            limitations.append(f"存在 {len(dataset.conflicts)} 组未消解的来源冲突")
        macro_records = getattr(dataset, "macro", [])
        if len(macro_records) < 5:
            limitations.append("宏观域指标稀疏（少于5项），不足以支撑完整的宏观经济周期与信用传导定量判断")
        fin_records = getattr(dataset, "financials", [])
        if fin_records:
            has_bs_schedules = any(
                any(k in r.metric for k in ("应收账款", "存货", "在建工程", "长期借款"))
                for r in fin_records
            )
            if not has_bs_schedules:
                limitations.append("个股财务报表附表细项（如应收账款账龄、存货跌价等）未充分覆盖，营运资金变动原因需结合财报附注定性研判")

        completeness = min(1.0, len(numeric) / 20) if records else 0.0
        time_score = dated / len(numeric) if numeric else 0.0
        source_score = min(1.0, source_count / 3)
        issue_penalty = issue_count / len(records) if records else 1.0
        score = max(0.0, min(1.0, 0.35 * completeness + 0.3 * time_score + 0.25 * source_score + 0.1 * (1 - issue_penalty)))
        return DataQualityAssessment(
            record_count=len(records),
            numeric_record_count=len(numeric),
            dated_numeric_record_count=dated,
            source_count=source_count,
            records_with_issues=issue_count,
            conflict_count=len(dataset.conflicts),
            analyzability_score=score,
            limitations=limitations,
        )

    @staticmethod
    def _referenced_ids(*collections: Iterable[Any]) -> set[str]:
        return {
            record_id
            for collection in collections
            for item in collection
            for record_id in item.evidence_record_ids
        }

    @staticmethod
    def _normalize_money(val: float | None, unit: str | None) -> float | None:
        if val is None:
            return None
        # P-01：金额单位走统一真值表。旧实现按子串判断，把「百万元」读成「万元」
        # （差 100 倍）、「千万元」读成「万元」（差 1000 倍）、「万亿元」读成「亿元」
        # （差 1 万倍）。
        yuan = money_to_yuan(val, unit)
        if yuan is not None:
            return float(yuan / Decimal(100_000_000))
        # 非人民币单位（如「亿美元」）不在真值表内，这里沿用旧口径返回亿元浮点：
        # 直接返回 None 会让整类同业记录退出估值与比率比较，覆盖率下降比口径不精确更糟。
        u = str(unit or "").strip().lower()
        # AB-1：未知/缺失单位的金额尺度歧义（元/万元/亿元），不得按绝对值猜尺度。
        # 返回 None 使其被金额比较、比率与量化覆盖排除；原值仍保留在记录中供审计。
        if not u or u in ("unknown", "legacy_unknown", "none", "nan"):
            return None
        if "万" in u and "亿" not in u:
            return val / 10000.0
        if "千" in u or "k" in u:
            return val / 100000.0
        if "百" in u and "亿" not in u:
            return val / 1000000.0
        if "亿" in u:
            return val
        if u in ("元", "cny", "rmb", "¥"):
            return val / 1e8
        # 其它无法识别的单位同样视为尺度不可信，不参与金额规范化。
        return None

    @staticmethod
    def _normalize_pct(val: float | None, unit: str | None) -> float | None:
        if val is None:
            return None
        u = str(unit or "").strip().casefold()
        if u in ("%", "％", "百分比", "百分点", "percent", "percentage"):
            return val
        if u in ("ratio", "decimal", "小数", "倍"):
            return val * 100
        # AB-1：无单位不得仅凭 0.12 的大小推断口径（可能是 12%、0.12% 或 0.12 个百分点）。
        # 原样返回，由调用方按显式口径处理；不做 *100 猜测。
        return val

    def _align_financial_periods(self, company: dict[str, Any]) -> tuple[dict[str, tuple], tuple | None, dict[str, str]]:
        """把同一公司的财务指标对齐到一个共同报告期。

        LLM 写「2025 年毛利率 29.44%」时，29.44% 实际来自 2026Q3 快照；旧矩阵按指标
        各取最新，导致毛利率(2026Q3)、研发费用率(2025年报)被并列引用。这里以
        「覆盖财务指标族最多」的期间为锚（annual 优先、其次较新），锚定期内逐指标取值；
        缺失该期的指标才回退最新值，并记录 period_mismatch 供下游标注。
        """
        observations: dict[str, list[dict[str, Any]]] = company.get("observations") or {}
        period_families: dict[tuple, set[str]] = defaultdict(set)
        for metric_key, items in observations.items():
            family = metric_family(metric_key)
            if family not in _FINANCIAL_ALIGNMENT_FAMILIES:
                continue
            for obs in items:
                if obs.get("period_end"):
                    period_families[(obs["period_end"], obs.get("period_type") or "unknown")].add(family)

        anchor = None
        if period_families:
            anchor = max(
                period_families.items(),
                key=lambda item: (
                    len(item[1]),
                    item[0][1] == "annual",
                    item[0][0],
                ),
            )[0]

        aligned: dict[str, tuple] = {}
        mismatch: dict[str, str] = {}
        for metric_key, items in observations.items():
            family = metric_family(metric_key)
            if anchor and family in _FINANCIAL_ALIGNMENT_FAMILIES:
                exact = [o for o in items if (o.get("period_end"), o.get("period_type") or "unknown") == anchor]
                if exact:
                    chosen = exact[-1]
                else:
                    chosen = max(items, key=lambda o: (o.get("period_end") or date.min, o.get("period_type") == "annual"))
                    actual = chosen.get("period_end")
                    mismatch[metric_key] = f"{actual.isoformat()}:{chosen.get('period_type')}" if actual else "undated"
            else:
                chosen = max(items, key=lambda o: (o.get("period_end") or date.min, o.get("period_type") == "annual"))
            aligned[metric_key] = (chosen["value"], chosen["unit"], chosen["record_id"])
            company["records"][metric_key] = chosen["record"]
        return aligned, anchor, mismatch

    def build_peer_comps_matrix(self, dataset: StructuredResearchDataset, subject: str | None = None) -> PeerCompsMatrix:
        # Take company-level records from companies, financials and industry_chain domains.
        # D-03 fix: individual peers' market-cap / PE / PB valuation rows are frequently
        # carried in the `industry` domain (one row per listed company, e.g. metric
        # "最新a股流通市值" / "最新市盈率ttm"), NOT in `companies`. Wholesale-excluding
        # `industry` collapsed the matrix to the handful of companies that also had
        # `financials` detail (3 of 23), which made CR3/CR5 unreproducible (recompute=100.0
        # vs baseline 37.602/55.5614). We now include `industry` rows whose entity resolves
        # to a concrete company and skip sector/index aggregates via entity-level
        # (_is_aggregate_entity) plus metric-level (AGGREGATE_METRIC_TOKENS) guards.
        # macro / reports / news remain excluded to avoid polluting peer comps.
        comp_records = list(dataset.companies) + list(dataset.financials)
        for r in getattr(dataset, "industry_chain", []):
            if (r.entity_name or r.entity_code) and not _is_segment_level_record(r):
                comp_records.append(r)
        for r in getattr(dataset, "industry", []):
            ent = _entity(r)
            if ent and not _is_aggregate_entity(ent) and not _is_segment_level_record(r) and not _is_index_record(r):
                comp_records.append(r)

        # Collect company industry classifications from dataset raw_fields and metrics
        comp_industries: dict[str, str] = {}
        for r in dataset.all_records():
            ent = _entity(r)
            if not ent:
                continue
            rf = getattr(r, "raw_fields", {}) or {}
            ind = rf.get("所属同花顺行业") or rf.get("所属申万行业") or rf.get("行业")
            if not ind and ("行业" in str(r.metric)):
                ind = r.value
            if ind:
                ind_str = " ".join(ind) if isinstance(ind, (list, tuple)) else str(ind)
                prev = comp_industries.get(ent, "")
                comp_industries[ent] = f"{prev} {ind_str}".strip()

        company_data: dict[str, dict[str, Any]] = defaultdict(lambda: {
            "name": None, "code": None, "metrics": {}, "periods": {}, "evidence_ids": [], "records": {},
            # 同一指标可能来自多个报告期（如 2025 年报 + 2026 三季报快照）。
            # 旧逻辑按指标各自取「最新」，导致毛利率用 2026Q3、研发费用率用 2025 年报，
            # 正文把两组数写成同一年（实测 2026-11-20 商业航天：29.44% vs 29.19%）。
            # 这里保留全部观测，稍后按「共同报告期」对齐。
            "observations": defaultdict(list),
        })

        AGGREGATE_METRIC_TOKENS = (
            "平均值", "中值", "指数", "板块", "行业总市值", "行业平均", "板块平均", "全行业", "行业pe", "板块pe"
        )

        scope = dataset.quality_summary.get("comparison_scope")
        if scope:
            names, codes = set(scope["names"]), set(scope["codes"])
            comp_records = [r for r in comp_records if r.entity_name in names or r.entity_code in codes]
        # AB-2/S02：开放主题按业务资格过滤核心可比——只有已核业务样本进入比较；
        # sample_roles 为空（点名样本/旧产物）不过滤，概念背景记录保留上下文。
        sample_roles = getattr(dataset, "sample_roles", None) or []
        if sample_roles:
            core_names = {
                role.entity_name for role in sample_roles if role.role == "core_verified"
            }
            if core_names:
                comp_records = [r for r in comp_records if r.entity_name in core_names]
        for r in comp_records:
            ent = _entity(r)
            if not ent:
                continue
            company_key = r.entity_code if scope and r.entity_code else ent
            item = company_data[company_key]
            if not item["name"]:
                item["name"] = r.entity_name or ent
            if not item["code"] and r.entity_code:
                item["code"] = r.entity_code
            m_key = metric_family(r.metric)
            # Skip sector-wide aggregate metrics mistakenly attributed to company
            if any(tok in m_key for tok in AGGREGATE_METRIC_TOKENS):
                continue
            val = _number(r.value)
            if val is not None:
                # D-08 fix (#1 value mismatch): a company usually carries the SAME metric key
                # across several reporting periods (financials are stored newest→oldest).
                # Keep the latest-period observation for the legacy dict (valuation metrics
                # are point-in-time and must stay latest), but retain every observation so
                # financial metrics can be aligned to one common reporting period below.
                r_period = _period(r)
                r_period_type = getattr(r, "period_type", None) or (
                    period_shape(r_period)["period_type"] if r_period else "unknown"
                )
                item["observations"][m_key].append({
                    "period_end": r_period,
                    "period_type": r_period_type,
                    "value": val,
                    "unit": r.unit,
                    "record_id": r.record_id,
                    "record": r,
                })
                prev_period = item["periods"].get(m_key)
                if (
                    m_key not in item["metrics"]
                    or (r_period is not None and (prev_period is None or r_period >= prev_period))
                ):
                    item["metrics"][m_key] = (val, r.unit, r.record_id)
                    item["periods"][m_key] = r_period
                    item["records"][m_key] = r
                item["evidence_ids"].append(r.record_id)

        # 同一公司的财务指标必须来自同一报告期；估值/市值仍取最新点位。
        for d in company_data.values():
            aligned, anchor, mismatch = self._align_financial_periods(d)
            if aligned:
                d["metrics"] = aligned
                d["periods"] = {k: getattr(v, "period_end", None) for k, v in d["records"].items() if k in aligned}
                d["financial_period"] = anchor
                d["period_mismatch"] = mismatch

        entries: list[PeerCompsEntry] = []
        # 市值合计在构造 entry 时同步累加原始值：company_data 的键可能是实体名，
        # 也可能是 entity_code（comparison_scope 存在时），事后按 company_name 反查
        # 会落到 defaultdict 上新建空条目，再取 ["market_cap"] 直接 KeyError。
        market_cap_sum_values: list[float] = []
        for ent, d in company_data.items():
            m = d["metrics"]
            anchor = d.get("financial_period")
            anchor_end = anchor[0].isoformat() if anchor else None
            anchor_type = anchor[1] if anchor else None

            def get_val(keys: list[str], exclude_keys: tuple[str, ...] = ("平均值", "中值", "指数", "板块"), *, monetary: bool = False) -> tuple[float | None, str | None, str | None]:
                candidates = []
                for mk, observation in m.items():
                    metric = mk.casefold()
                    if any(ex in metric for ex in exclude_keys):
                        continue
                    if monetary:
                        unit = str(observation[1] or "").strip().casefold()
                        if (any(token in metric for token in ("同比", "环比", "率", "增速", "增幅", "占比", "yoy", "qoq", "growth", "margin", "ratio", "pct", "percent"))
                                or unit in ("%", "％", "百分比", "百分点", "percent", "percentage", "ratio")):
                            continue
                    for priority, key in enumerate(keys):
                        key = key.casefold()
                        if key in metric:
                            # Prefer exact semantic metrics before any substring
                            # alias, then use a stable ordering for fallback names.
                            candidates.append((metric != key, priority, metric, observation))
                if candidates:
                    return min(candidates, key=lambda item: item[:3])[3]
                return None, None, None

            mc_val, mc_unit, mc_id = m.get("market_cap", (None, None, None))
            market_cap = self._normalize_money(mc_val, mc_unit)
            if market_cap is not None and (market_cap > 50000.0 or market_cap <= 0):
                market_cap = None
            if market_cap is not None:
                market_cap_sum_values.append(market_cap)

            pe_val, pe_unit, pe_id = m.get("pe_ttm", (None, None, None))
            pe = pe_val if pe_val is not None and 0 < pe_val < 5000 else None

            pb_val, pb_unit, pb_id = get_val(["pb", "市净率"])
            pb = pb_val if pb_val is not None and 0 < pb_val < 500 else None

            ps_val, ps_unit, ps_id = get_val(["ps", "市销率"])
            ps = ps_val if ps_val is not None and 0 < ps_val < 500 else None

            rev_val, rev_unit, rev_id = get_val(["revenue", "营业收入", "营业总收入", "营收"], monetary=True)
            revenue = self._normalize_money(rev_val, rev_unit)

            ryoy_val, ryoy_unit, ryoy_id = get_val(["营业收入同比增长率", "营业收入同比", "营收同比", "revenue_yoy"])
            revenue_yoy = self._normalize_pct(ryoy_val, ryoy_unit)

            np_val, np_unit, np_id = get_val(["parent_net_profit", "net_profit", "归属于母公司", "归母净利润", "净利润"], monetary=True)
            net_profit = self._normalize_money(np_val, np_unit)

            nyoy_val, nyoy_unit, nyoy_id = get_val(["净利润同比增长率", "归母净利润同比", "净利润同比", "net_profit_yoy"])
            net_profit_yoy = self._normalize_pct(nyoy_val, nyoy_unit)

            gm_val, gm_unit, gm_id = get_val(["gross_margin", "销售毛利率", "毛利率"])
            gross_margin = self._normalize_pct(gm_val, gm_unit)
            if gross_margin is not None and not (-300.0 <= gross_margin <= 100.0):
                gross_margin = None

            nm_val, nm_unit, nm_id = get_val(["net_margin", "销售净利率", "净利率"])
            net_margin = self._normalize_pct(nm_val, nm_unit)
            if net_margin is None:
                pair = self._paired_calculation(
                    dataset, d["name"] or ent, "net_profit", "revenue", scale=100,
                    preferred_period=d.get("financial_period"),
                )
                if pair:
                    net_margin = round(pair["value"], 2)
            elif "net_margin" in (d.get("period_mismatch") or {}):
                # 快照期净利率与锚定年报不同期：优先用同年报的净利/营收重算，
                # 重算成功就撤掉 mismatch 标记，避免正文把 Q3 净利率写进年报段落。
                pair = self._paired_calculation(
                    dataset, d["name"] or ent, "net_profit", "revenue", scale=100,
                    preferred_period=d.get("financial_period"),
                )
                if pair:
                    net_margin = round(pair["value"], 2)
                    d["period_mismatch"].pop("net_margin", None)
                else:
                    # 同年报无法重算 → 宁可留空并披露，也不把 Q3 净利率写成 2025 年。
                    net_margin = None
            if net_margin is not None and not (-1000.0 <= net_margin <= 500.0):
                net_margin = None

            cf_val, cf_unit, cf_id = get_val(["operating_cash_flow", "经营活动产生的现金流量净额", "经营现金流"], monetary=True)
            cash_flow = self._normalize_money(cf_val, cf_unit)

            roe_val, roe_unit, roe_id = get_val(["roe", "净资产收益率"])
            roe = self._normalize_pct(roe_val, roe_unit)
            if roe is not None and not (-150.0 <= roe <= 150.0):
                roe = None

            dr_val, dr_unit, dr_id = get_val(["debt_ratio", "资产负债率"])
            debt_ratio = self._normalize_pct(dr_val, dr_unit)
            if debt_ratio is not None and not (0.0 <= debt_ratio <= 150.0):
                debt_ratio = None

            # 仍与锚定报告期不一致的财务指标一律留空（在 financial_period_mismatch 中披露），
            # 不用跨期值凑一张「同年度」对比表。
            mismatch_keys = d.get("period_mismatch") or {}
            if "revenue" in mismatch_keys:
                revenue = None
            if "revenue_yoy" in mismatch_keys:
                revenue_yoy = None
            if "net_profit" in mismatch_keys or "parent_net_profit" in mismatch_keys:
                net_profit = None
            if "net_profit_yoy" in mismatch_keys:
                net_profit_yoy = None
            if "gross_margin" in mismatch_keys:
                gross_margin = None
            if "net_margin" in mismatch_keys:
                net_margin = None
            if "operating_cash_flow" in mismatch_keys:
                cash_flow = None
            if "roe" in mismatch_keys:
                roe = None
            if "debt_ratio" in mismatch_keys:
                debt_ratio = None

            clean_name = d["name"]
            if clean_name and re.match(r"^\d{6}\.(SZ|SH|BJ|HK|US)$", clean_name, re.I):
                resolved = resolve_ticker(clean_name)
                if resolved and not re.match(r"^\d{6}\.(SZ|SH|BJ|HK|US)$", resolved, re.I):
                    clean_name = resolved
                else:
                    if not (revenue or net_profit or cash_flow):
                        continue

            c_target = clean_name or ent
            c_ind = comp_industries.get(c_target, comp_industries.get(ent, ""))
            if subject and not scope and not _is_industry_relevant(c_target, c_ind, subject):
                continue

            if any(x is not None for x in (market_cap, revenue, net_profit, pe_val, cash_flow, gross_margin)) or "circulating_market_cap" in m:
                if pe is not None and 0 < pe <= 150:
                    val_tier = "profitable"
                    val_note = f"PE(TTM) {pe:.1f}倍（成熟盈利）"
                elif pe_val is not None and pe_val > 150:
                    val_tier = "loss_or_high_multiple"
                    val_note = f"PE(TTM) {pe_val:.1f}倍超高估值，建议参考PB/PS对标"
                elif pe_val is not None and pe_val <= 0:
                    val_tier = "loss_or_high_multiple"
                    val_note = "亏损标的(PE为负)，参考PB/PS分层估值"
                else:
                    val_tier = "profitable" if (net_profit and net_profit > 0) else "loss_or_high_multiple"
                    val_note = f"PB {pb:.1f}倍" if pb else "以PS/产业地位对标"

                e_ids = [val for val in (mc_id, pe_id, pb_id, ps_id, rev_id, ryoy_id, np_id, nyoy_id, gm_id, nm_id, cf_id, roe_id, dr_id) if val]
                entries.append(PeerCompsEntry(
                    peer_membership=("core" if subject and subject.strip() in c_ind else "unknown") if subject else "unscoped_sample",
                    metric_provenance={k: dict(record_id=r.record_id, period_end=str(r.period_end) if r.period_end else None,
                        period_type=(getattr(r, "period_type", "unknown") if getattr(r, "period_type", "unknown") != "unknown" else period_shape(r.period_end)["period_type"]),
                        scope=r.scope, currency=r.currency, unit=r.unit, value=r.value) for k, r in d["records"].items()},
                    company_name=clean_name or ent,
                    company_code=d["code"],
                    market_cap=round(market_cap, 2) if market_cap is not None else None,
                    pe_ttm=round(pe, 2) if pe is not None else None,
                    pb=round(pb, 2) if pb is not None else None,
                    ps=round(ps, 2) if ps is not None else None,
                    revenue=round(revenue, 2) if revenue is not None else None,
                    revenue_yoy=round(revenue_yoy, 2) if revenue_yoy is not None else None,
                    net_profit=round(net_profit, 2) if net_profit is not None else None,
                    net_profit_yoy=round(net_profit_yoy, 2) if net_profit_yoy is not None else None,
                    gross_margin=round(gross_margin, 2) if gross_margin is not None else None,
                    net_margin=round(net_margin, 2) if net_margin is not None else None,
                    operating_cash_flow=round(cash_flow, 2) if cash_flow is not None else None,
                    roe=round(roe, 2) if roe is not None else None,
                    debt_ratio=round(debt_ratio, 2) if debt_ratio is not None else None,
                    financial_period_end=anchor_end,
                    financial_period_type=anchor_type,
                    financial_period_mismatch=dict(d.get("period_mismatch") or {}),
                    valuation_tier=val_tier,
                    valuation_note=val_note,
                    evidence_record_ids=list(dict.fromkeys(e_ids or d["evidence_ids"][:10])),
                ))

        entries.sort(key=lambda x: (x.market_cap is not None, x.market_cap or 0, x.revenue or 0), reverse=True)

        benchmark_entries = [e for e in entries if e.peer_membership in ("core", "unscoped_sample")]
        pe_profitable = [e.pe_ttm for e in benchmark_entries if e.pe_ttm and 0 < e.pe_ttm <= 150]
        profitable_pe_median = round(float(median(pe_profitable)), 2) if pe_profitable else None

        pbs = [e.pb for e in benchmark_entries if e.pb and 0 < e.pb <= 200]
        pss = [e.ps for e in benchmark_entries if e.ps and 0 < e.ps <= 200]
        gms = [e.gross_margin for e in benchmark_entries if e.gross_margin is not None]
        nms = [e.net_margin for e in benchmark_entries if e.net_margin is not None]
        # Sum unrounded, same-definition observations; missing entities stay in the denominator.
        mcs = market_cap_sum_values

        tier_note = (
            f"样本包含 {len(pe_profitable)} 家盈利成熟标的与 {len(entries) - len(pe_profitable)} 家早期/亏损/极高估值标的。"
            f"行业PE中位数({profitable_pe_median or '-'}倍)仅统计成熟盈利梯队，杜绝极端值或负值失真；"
            f"未盈利或高弹性标的采用PB中位数({round(float(median(pbs)), 2) if pbs else '-'}倍)与PS分层评价。"
        ) if (len(entries) > len(pe_profitable)) else "样本均为成熟盈利企业，采用统一样本PE估值对标。"

        return PeerCompsMatrix(
            entries=entries,
            median_pe=profitable_pe_median,
            profitable_median_pe=profitable_pe_median,
            median_pb=round(float(median(pbs)), 2) if pbs else None,
            median_ps=round(float(median(pss)), 2) if pss else None,
            median_gross_margin=round(float(median(gms)), 2) if gms else None,
            median_net_margin=round(float(median(nms)), 2) if nms else None,
            total_market_cap=round(sum(mcs), 2) if mcs else None,
            market_cap_coverage={"available": len(mcs), "sample": len(entries), "definition": "total_market_cap", "unit": "亿元"},
            valuation_coverage={"available": sum(e.pe_ttm is not None for e in entries), "sample": len(entries), "definition": "pe_ttm",
                                "pb_available": sum(e.pb is not None for e in entries), "mature_pe_benchmark_size": len(pe_profitable)},
            currency="CNY",
            tiered_valuation_note=tier_note,
        )

    def build_segments_from_chain_facts(
        self,
        facts: Any,
        dataset: StructuredResearchDataset,
        comps_matrix: PeerCompsMatrix | None = None,
    ) -> list[IndustryChainSegment]:
        """Build segments from a reviewed full-chain structure card.

        A1 的 ``industry_chain`` 记录只是引述/概念/行业分类/工商字段，无法证明
        「某公司属于某环节」，所以归属改由人工审定卡提供，而不是下方的关键词表。
        公司名必须与 A1 数据集实际覆盖的实体取交集；证据 id 只取业务属性记录，
        保证同一 ``record_id`` 不会同时背书两个环节。

        Args:
            facts: 已校验的 :class:`ChainFacts`。
            dataset: A1 结构化数据集（同时提供证据 id）。
            comps_matrix: 可选同业矩阵，用于毛利率区间。

        Returns:
            三个 :class:`IndustryChainSegment`，带 ``source_tier`` /
            ``attribution_basis`` / 缺口元数据。
        """
        from chart_generator.chain_facts import group_for, is_business_attribute_record

        records = dataset.all_records()
        covered_entities: set[str] = set()
        business_refs: dict[str, list[str]] = {}
        for record in records:
            entity = _entity(record)
            if not entity:
                continue
            covered_entities.add(entity)
            if is_business_attribute_record(record.metric):
                business_refs.setdefault(entity, []).append(record.record_id)

        gm_map = {
            entry.company_name: entry.gross_margin
            for entry in getattr(comps_matrix, "entries", [])
            if entry.gross_margin is not None
        }
        used_records: set[str] = set()
        segments: list[IndustryChainSegment] = []

        for fact in facts.segments:
            if fact.stage not in ("upstream", "midstream", "downstream"):
                continue
            out_of_sample = fact.sample_status == "not_in_sample"
            # 只允许 A1 实际覆盖的实体；绝不用模型先验或行业通用名单补齐。
            companies = [] if out_of_sample else [
                name for name in fact.companies if name in covered_entities
            ]
            refs: list[str] = []
            for company in companies:
                for record_id in business_refs.get(company, []):
                    if record_id not in used_records:
                        used_records.add(record_id)
                        refs.append(record_id)

            margins = [gm_map[name] for name in companies if name in gm_map]
            if len(margins) >= 2:
                gm_range: str | None = f"{min(margins):.1f}%~{max(margins):.1f}%"
            elif len(margins) == 1:
                gm_range = f"{margins[0]:.1f}%"
            else:
                gm_range = None

            groups = sorted({
                group_for(name, facts) for name in companies if group_for(name, facts)
            })
            description = fact.name + "。"
            if fact.note:
                description += fact.note + "。"
            if fact.transmission:
                description += fact.transmission + "。"
            if fact.gap_declaration:
                description += fact.gap_declaration + "。"

            segments.append(IndustryChainSegment(
                segment_name=fact.name,
                stage=fact.stage,
                description=description,
                representative_companies=companies,
                key_products=list(fact.key_products),
                gross_margin_range=gm_range,
                evidence_record_ids=refs,
                source_tier="gap" if out_of_sample else "reviewed_profile",
                attribution_basis=facts.attribution_basis,
                gap_declaration=fact.gap_declaration,
                comparison_group=groups[0] if len(groups) == 1 else "",
                comparison_groups=groups,
                profile_frame=facts.frame,
                comparison_rules=[rule.get("rule", "") for rule in facts.comparison_rules],
                non_comparable_reasons=list(facts.non_comparable_reasons),
                interpretive_hypotheses=list(facts.interpretive_hypotheses),
                entity_caveats=list(facts.entity_caveats),
                forbidden=list(facts.forbidden),
            ))
        return segments

    def extract_industry_chain(
        self,
        dataset: StructuredResearchDataset,
        subject: str = "",
        comps_matrix: PeerCompsMatrix | None = None,
    ) -> list[IndustryChainSegment]:
        # 已审定的全链结构优先。没有审定卡时保留原行为，但把每段标成
        # ``industry_common``，让 A4 的归属门禁拒绝把环节归属写进报告。
        try:
            from chart_generator.chain_facts import try_load_chain_facts

            facts = try_load_chain_facts(subject)
        except Exception:                                    # pragma: no cover
            facts = None
        if facts is not None:
            return self.build_segments_from_chain_facts(facts, dataset, comps_matrix)

        records = dataset.all_records()
        chain_data: dict[str, dict[str, Any]] = {
            "upstream": {"companies": set(), "evidence": [], "products": []},
            "midstream": {"companies": set(), "evidence": [], "products": []},
            "downstream": {"companies": set(), "evidence": [], "products": []},
        }

        # Universal, domain-agnostic supply chain semantic keywords
        upstream_kw = (
            "上游", "原料", "材料", "基础", "零部件", "元器件", "设备", "芯片", "算力",
            "矿", "供应", "基础设施", "底层", "硬件", "原料药", "晶圆", "减速器", "电机",
            "传感器", "丝杠", "控制器", "电池", "电控", "结构件", "模具", "导轨", "轴承"
        )
        midstream_kw = (
            "中游", "制造", "研发", "整机", "集成", "系统", "算法", "模型", "加工",
            "生产", "组装", "本体", "核心平台", "中试", "软件", "制药", "模组", "方案",
            "训练", "推理", "总成", "设备制造", "网络"
        )
        downstream_kw = (
            "下游", "应用", "场景", "服务", "运营", "终端", "销售", "渠道", "客户",
            "消费", "交付", "集成商", "商业化", "运输", "救援", "巡检", "运维", "平台服务",
            "推广", "流通", "医疗", "教育", "文娱", "政企", "金融", "落地"
        )

        company_scores: dict[str, dict[str, int]] = {}
        NON_COMPANY_NAMES = NON_COMPANY_ENTITY_NAMES
        NON_COMPANY_PATTERNS = NON_COMPANY_ENTITY_PATTERNS

        def _clean_company_name(c: Any) -> str | None:
            if not c:
                return None
            c_str = str(c).strip()
            if not c_str:
                return None
            if re.match(r"^\d{6}\.(SZ|SH|BJ|HK|US)$", c_str, re.I):
                resolved = resolve_ticker(c_str)
                if resolved and not re.match(r"^\d{6}\.(SZ|SH|BJ|HK|US)$", resolved, re.I):
                    c_str = resolved
                else:
                    return None
            if c_str in COMMON_TICKER_NAMES.values():
                return c_str
            cleaned_base = re.sub(r"[\(（\[].*?[\)）\]]", "", c_str).strip()
            if cleaned_base in COMMON_TICKER_NAMES.values():
                return cleaned_base
            target_str = cleaned_base if cleaned_base else c_str
            if target_str in NON_COMPANY_NAMES:
                return None
            is_pattern_excluded = False
            for p in NON_COMPANY_PATTERNS:
                if p == "成分":
                    if target_str in ("成分", "成分股") or target_str.endswith("成分股"):
                        is_pattern_excluded = True
                        break
                elif p in target_str:
                    is_pattern_excluded = True
                    break
            if is_pattern_excluded:
                return None
            if 2 <= len(target_str) <= 16:
                return target_str
            return None

        def _clean_company_list(comps: Iterable[str]) -> list[str]:
            res: list[str] = []
            for c in comps:
                cleaned = _clean_company_name(c)
                if cleaned and cleaned not in res:
                    res.append(cleaned)
            return res

        # context_map（队友机制，2026-09-26 合并）：当批次 `entity_code → 公司名` 动态映射。
        # 产业链语义匹配时用它把代码形态实体消解为公司名，消解内置 COMMON_TICKER_NAMES 未覆盖的新标的。
        dyn_tickers: dict[str, str] = {}
        for r in records:
            c_code = r.entity_code or (r.entity_name if r.entity_name and re.match(r"^\d{6}\.(SZ|SH|BJ|HK|US)$", r.entity_name, re.I) else None)
            c_name = r.entity_name if r.entity_name and not re.match(r"^\d{6}\.(SZ|SH|BJ|HK|US)$", r.entity_name, re.I) else None
            if not c_name and getattr(r, "raw_fields", None) and isinstance(r.raw_fields, dict):
                for k in ("成分简称", "股票简称", "证券简称", "公司简称", "公司名称", "成分名称", "名称"):
                    v = r.raw_fields.get(k)
                    if v and str(v).strip() and not re.match(r"^\d{6}\.(SZ|SH|BJ|HK|US)$", str(v).strip(), re.I):
                        c_name = str(v).strip()
                        break
            if c_code and c_name:
                dyn_tickers[c_code.upper()] = c_name

        for r in records:
            ent = _entity(r, context_map=dyn_tickers)
            text = str(r.value or "")
            m_name = r.metric.casefold()
            raw_seg = str(r.raw_fields.get("产业链环节") or r.raw_fields.get("环节") or "").casefold()

            # Only match supply chain segment keywords if the record comes from INDUSTRY_CHAIN
            # or explicitly describes business products/scope, never from generic company financial metrics, concepts, or ticker info.
            is_chain_relevant = (
                r.domain == Domain.INDUSTRY_CHAIN
                or bool(raw_seg)
                or any(k in m_name for k in ("主营产品", "主要产品", "主营构成", "产品名称", "业务范围", "product", "business_scope"))
            ) and not any(k in m_name for k in ("行业", "所属同花顺行业", "板块", "概念", "代码", "市值", "股价", "市盈率", "市净率", "概念原因", "纳入概念", "concept", "market_cap", "price", "pe", "pb"))
            if not is_chain_relevant:
                continue

            combined = f"{ent or ''} {m_name} {raw_seg} {text}".casefold()

            # Direct segment match from raw metadata if available
            is_up = "上游" in raw_seg or any(k in combined for k in upstream_kw)
            is_down = "下游" in raw_seg or any(k in combined for k in downstream_kw)
            is_mid = "中游" in raw_seg or any(k in combined for k in midstream_kw)

            # Product extraction helper: only extract from concise product/business fields, never from narrative concept/announcement text
            is_product_field = (
                r.domain == Domain.INDUSTRY_CHAIN
                or any(k in m_name for k in ("主营产品", "主要产品", "主营构成", "产品名称", "业务范围", "product", "business_scope"))
            ) and not any(k in m_name for k in ("营业收入", "净利润", "费用", "市值", "资金", "现金流", "概念原因", "纳入概念", "简介", "公告", "新闻"))

            def _extract_phrases(val_text: str) -> list[str]:
                phrases = []
                # If text contains long narrative prose with punctuation, reject
                if len(val_text) > 60 and any(punc in val_text for punc in ("。", "！", "？", "；")):
                    return []
                for p in re.split(r"[,，;；、|/\n]+", val_text):
                    p = p.strip()
                    # Strip quotation marks and brackets
                    p = re.sub(r"^[\[\'\"\(（【]+|[\]\'\"\)）】]+$", "", p).strip()
                    # Reject pure numbers, floats, scientific notations, currencies, percentages
                    if re.match(r"^[\d\.\+\-eE,/%]+$", p):
                        continue
                    # Reject narrative sentence fragments (verbs, temporal words, announcement jargon)
                    if any(bad in p for bad in (
                        "携手", "投放", "发展", "打造", "截至", "签约", "预计", "实现", "投资", "建设",
                        "推进", "完成", "成立", "取得", "发布", "披露", "同意", "审议", "董事会", "股东",
                        "报告期", "上半年", "下半年", "第.*季度", "一季度", "二季度", "三季度", "四季度",
                        "第一批", "批次", "合作", "战略", "充分运用", "目前已", "连续", "始创于", "入选",
                    )):
                        continue
                    if 2 <= len(p) <= 16 and not any(stop in p for stop in (
                        "公司", "服务", "同比", "环比", "亿元", "万元", "主要", "概念", "板块", "指数", "代码", "日期", "中国ai"
                    )):
                        phrases.append(p)
                return phrases

            prods = _extract_phrases(text) if is_product_field else []

            clean_ent = _clean_company_name(ent)
            if clean_ent:
                if clean_ent not in company_scores:
                    company_scores[clean_ent] = {"upstream": 0, "midstream": 0, "downstream": 0}
                if is_up:
                    company_scores[clean_ent]["upstream"] += 1 + sum(1 for k in upstream_kw if k in combined)
                if is_mid:
                    company_scores[clean_ent]["midstream"] += 1 + sum(1 for k in midstream_kw if k in combined)
                if is_down:
                    company_scores[clean_ent]["downstream"] += 1 + sum(1 for k in downstream_kw if k in combined)

            if is_up:
                if clean_ent: chain_data["upstream"]["companies"].add(clean_ent)
                chain_data["upstream"]["evidence"].append(r.record_id)
                chain_data["upstream"]["products"].extend(prods)
            if is_mid:
                if clean_ent: chain_data["midstream"]["companies"].add(clean_ent)
                chain_data["midstream"]["evidence"].append(r.record_id)
                chain_data["midstream"]["products"].extend(prods)
            if is_down:
                if clean_ent: chain_data["downstream"]["companies"].add(clean_ent)
                chain_data["downstream"]["evidence"].append(r.record_id)
                chain_data["downstream"]["products"].extend(prods)

        sub_label = subject.strip() if subject else "该产业"

        def _get_products(stage_key: str, fallback_list: list[str]) -> list[str]:
            found = list(dict.fromkeys(chain_data[stage_key]["products"]))
            return (found[:4] if len(found) >= 2 else (found + fallback_list)[:4])

        up_prods = _get_products("upstream", ["核心零部件与原材料", "专用元器件/模组", "基础供给设备与系统"])
        mid_prods = _get_products("midstream", ["核心产品研发与技术方案", "系统集成与一体化交付", "核心算法/模型与平台底座"])
        down_prods = _get_products("downstream", ["场景化应用与终端解决方案", "商业化运营与客户服务", "行业生态与落地部署"])

        # Collect company industry classifications from dataset
        comp_industries: dict[str, str] = {}
        for r in records:
            ent_name = _entity(r, context_map=dyn_tickers)
            if not ent_name:
                continue
            rf = getattr(r, "raw_fields", {}) or {}
            ind = rf.get("所属同花顺行业") or rf.get("所属申万行业") or rf.get("行业")
            if not ind and any(k in r.metric.casefold() for k in ("所属同花顺行业", "industry_classification", "行业")):
                ind = r.value
            if ind:
                ind_str = " ".join(ind) if isinstance(ind, (list, tuple)) else str(ind)
                prev = comp_industries.get(ent_name, "")
                comp_industries[ent_name] = f"{prev} {ind_str}".strip()

        # Collect all valid unique candidate companies across all stages and peer comps
        raw_candidates = _clean_company_list(
            list(chain_data["upstream"]["companies"])
            + list(chain_data["midstream"]["companies"])
            + list(chain_data["downstream"]["companies"])
            + [e.company_name for e in getattr(comps_matrix, "entries", [])]
        )
        all_candidate_comps = [c for c in raw_candidates if _is_industry_relevant(c, comp_industries.get(c, ""), subject)]

        stage_assigned: dict[str, list[str]] = {"upstream": [], "midstream": [], "downstream": []}
        for c in all_candidate_comps:
            sc = company_scores.get(c, {"upstream": 0, "midstream": 0, "downstream": 0})
            ind_text = comp_industries.get(c, "")
            if sc["upstream"] == 0 and sc["midstream"] == 0 and sc["downstream"] == 0 and ind_text:
                if any(k in ind_text for k in ("农林牧渔", "农产品", "粮食", "包装", "包材", "原材料", "芯片", "零部件", "原料")):
                    best = "upstream"
                elif any(k in ind_text for k in ("商贸零售", "零售", "物流", "贸易", "电商", "百货", "经销", "销售", "渠道")):
                    best = "downstream"
                else:
                    best = "midstream"
            else:
                best = max(["midstream", "upstream", "downstream"], key=lambda s: (sc[s], s == "midstream"))
            stage_assigned[best].append(c)

        # Rebalance across stages if any stage is empty and total companies >= 3, ensuring strictly disjoint assignments
        if len(all_candidate_comps) >= 3:
            for target_stage in ["upstream", "downstream", "midstream"]:
                if not stage_assigned[target_stage]:
                    donor = max(stage_assigned, key=lambda s: len(stage_assigned[s]))
                    if len(stage_assigned[donor]) >= 2:
                        cand = stage_assigned[donor].pop()
                        stage_assigned[target_stage].append(cand)

        up_comps = stage_assigned["upstream"]
        mid_comps = stage_assigned["midstream"]
        down_comps = stage_assigned["downstream"]

        # Dynamically calculate gross margin ranges if company financial data is available
        comps_gm_map = {e.company_name: e.gross_margin for e in getattr(comps_matrix, "entries", []) if e.gross_margin is not None}
        def _calc_gm_range(comps: list[str], fallback: str | None) -> str | None:
            gms = [comps_gm_map[c] for c in comps if c in comps_gm_map]
            if len(gms) >= 2:
                return f"{min(gms):.1f}%~{max(gms):.1f}%"
            elif len(gms) == 1:
                return f"{gms[0]:.1f}%"
            return fallback

        up_gm = _calc_gm_range(up_comps, None)
        mid_gm = _calc_gm_range(mid_comps, None)
        down_gm = _calc_gm_range(down_comps, None)

        return [
            IndustryChainSegment(
                segment_name="上游：基础支撑、核心部件与关键供给",
                stage="upstream",
                description=f"涵盖{sub_label}上游原材料、核心元器件/零部件、基础软硬件设施与关键要素供给体系。",
                representative_companies=up_comps[:8],
                key_products=up_prods,
                gross_margin_range=up_gm,
                evidence_record_ids=chain_data["upstream"]["evidence"][:10],
                source_tier="industry_common",
                attribution_basis="",
                gap_declaration="",
                profile_frame="",
            ),
            IndustryChainSegment(
                segment_name="中游：核心产品研发、系统集成与方案交付",
                stage="midstream",
                description=f"涵盖{sub_label}中游核心软硬件产品研发总装、算法模型设计、系统集成与一体化解决方案输出。",
                representative_companies=mid_comps[:8],
                key_products=mid_prods,
                gross_margin_range=mid_gm,
                evidence_record_ids=chain_data["midstream"]["evidence"][:10],
                source_tier="industry_common",
                attribution_basis="",
                gap_declaration="",
                profile_frame="",
            ),
            IndustryChainSegment(
                segment_name="下游：场景应用、终端落地与商业化生态",
                stage="downstream",
                description=f"涵盖{sub_label}下游垂直领域商业化推广、多场景终端应用落地、渠道运营与综合服务生态。",
                representative_companies=down_comps[:8],
                key_products=down_prods,
                gross_margin_range=down_gm,
                evidence_record_ids=chain_data["downstream"]["evidence"][:10],
                source_tier="industry_common",
                attribution_basis="",
                gap_declaration="",
                profile_frame="",
            ),
        ]


    def _annual_rd_ratios(self, dataset: StructuredResearchDataset) -> list[ResearchRecord]:
        cells = {
            (entity, str(period))
            for row in dataset.quality_summary.get("requirement_evidence_matrix", [])
            for requirement in [row.get("requirement") or {}]
            if requirement.get("hard") and not requirement.get("comparison_baseline")
            and set(requirement.get("metric_families") or []) & {"rd_expense", "rd_investment", "rd_ratio", "rd_investment_ratio"}
            for entity in (requirement.get("entity_names") or [])
            for period in (requirement.get("period_ends") or [])
        }
        if not cells:
            return []
        conflict_ids = {rid for conflict in dataset.conflicts for rid in conflict.record_ids}
        observations = defaultdict(list)
        money_units = {"元", "万元", "亿元", "CNY", "RMB"}
        for record in dataset.financials:
            entity = _entity(record)
            family = metric_family(record.metric)
            if (entity, str(record.period_end)) not in cells or family not in ("rd_expense", "rd_investment", "revenue"):
                continue
            key = comparable_key(record)
            if (key is None or key[1] != "annual" or key[2] != date(key[0].year, 1, 1)
                    or record.record_id in conflict_ids or "pending_restatement" in record.issues
                    or record.unit not in money_units or "unit_unknown" in record.issues
                    or getattr(record, "unit_provenance", None) == "unknown"):
                continue
            value = self._normalize_money(_number(record.value), record.unit)
            if value is not None:
                observations[entity, key, family].append((value, record))
        ratios = []
        ratio_metrics = {"rd_expense": "rd_ratio", "rd_investment": "rd_investment_ratio"}
        for (entity, key, family), amounts in sorted(observations.items()):
            if family not in ratio_metrics:
                continue
            revenues = observations.get((entity, key, "revenue"), [])
            if len({value for value, _ in amounts}) != 1 or len({value for value, _ in revenues}) != 1:
                continue
            amount, numerator = amounts[0]
            revenue, denominator = revenues[0]
            if amount < 0 or revenue <= 0:
                continue
            ids = [numerator.record_id, denominator.record_id]
            metric = ratio_metrics[family]
            ratios.append(numerator.model_copy(update={
                "record_id": _id("CALC", metric, *ids), "metric": metric,
                "value": amount / revenue * 100, "unit": "%", "unit_provenance": "source_schema",
                "period_type": "annual", "period_start": key[2],
                "source": numerator.source.model_copy(update={"skill_id": "derived-financials"}),
                "raw_fields": {"input_record_ids": ids}, "published_at": None,
            }))
        return ratios

    def _paired_calculation(self, dataset: StructuredResearchDataset, entity: str,
                            numerator: str, denominator: str, *, scale: float = 1,
                            preferred_period: tuple[date | None, str | None] | None = None) -> dict[str, Any] | None:
        sides: list[dict[tuple, ResearchRecord]] = [{}, {}]
        # 同一 (实体/指标/期间/口径/币种) 出现多条记录时，过去由 dict 后写覆盖决定取哪条，
        # 结果随记录顺序变化。按 record_id 排序后再写入，让分母的选择可复现。
        for r in sorted(dataset.all_records(), key=lambda item: str(item.record_id)):
            if _entity(r) != entity or _number(r.value) is None:
                continue
            family = metric_family(r.metric)
            if family not in (numerator, denominator):
                continue
            key = comparable_key(r)
            if key is not None:
                sides[0 if family == numerator else 1][key] = r
        common = sides[0].keys() & sides[1].keys()
        ordered = sorted(common, key=lambda k: k[0], reverse=True)
        if preferred_period and preferred_period[0]:
            exact = [k for k in ordered
                     if k[0] == preferred_period[0] and k[1] == preferred_period[1]]
            ordered = exact + [k for k in ordered if k not in exact]
        for key in ordered:
            a, b = sides[0][key], sides[1][key]
            # Unknown monetary units cannot silently become a common currency.
            units = ("元", "万元", "亿元", "CNY", "RMB")
            if a.unit not in units or b.unit not in units:
                continue
            # AB-1：单位来源不可信（金额尺度歧义）的记录不得进入比率计算。
            if getattr(a, "unit_provenance", "legacy_unknown") == "unknown" or getattr(b, "unit_provenance", "legacy_unknown") == "unknown":
                continue
            av, bv = self._normalize_money(float(a.value), a.unit), self._normalize_money(float(b.value), b.unit)
            if bv is None or av is None or abs(bv) < 0.05:
                continue
            if numerator in {"operating_cash_flow", "rd_expense"} and bv <= 0:
                continue
            return {"value": av / bv * scale, "formula": f"{numerator}/{denominator}" + ("*100" if scale == 100 else ""),
                    "input_record_ids": [a.record_id, b.record_id], "period_end": str(a.period_end),
                    # A4 的净现比守卫据此确认分母口径；缺这一项会把所有公司判成缺口。
                    "denominator_metric": denominator,
                    "period_type": key[1], "scope": key[3], "currency": key[4], "unit": "%" if scale == 100 else "倍"}
        return None

    def compute_financial_ratios(self, dataset: StructuredResearchDataset) -> list[dict[str, Any]]:
        """计算各对标公司的财务比率。

        口径声明（D-02）：本函数输出的 ``*_pct`` 字段一律为**百分数**量纲
        （``gross_margin_pct=3.24`` 表示 3.24%）；而 ``key_metrics[*].change_pct``
        系列同比为**小数率**量纲（``0.3471`` 表示 34.71%）。两者量纲不同，下游与
        判据（C1）须分开处理，不得混用同一容差口径。
        """
        comps = self.build_peer_comps_matrix(dataset, subject=dataset.subject)
        ratios = []
        for e in comps.entries:
            try:
                preferred = ((date.fromisoformat(e.financial_period_end), e.financial_period_type)
                             if e.financial_period_end else None)
            except ValueError:
                preferred = None
            calculation = self._paired_calculation(
                dataset, e.company_name, "operating_cash_flow", "parent_net_profit",
                preferred_period=preferred,
            )
            cash_ratio = round(calculation["value"], 2) if calculation and -50 <= calculation["value"] <= 50 else None

            rd = self._paired_calculation(
                dataset, e.company_name, "rd_expense", "revenue", scale=100,
                preferred_period=preferred,
            )
            calculations = {}
            if calculation:
                calculations["cash_to_net_profit"] = calculation
            if rd:
                calculations["rd_ratio"] = rd

            pe_ref = comps.profitable_median_pe or comps.median_pe
            pe_premium = round((e.pe_ttm - pe_ref) / pe_ref * 100, 1) if e.pe_ttm and pe_ref and pe_ref > 0 and 0 < e.pe_ttm <= 150 else None
            item: dict[str, Any] = {
                "company": e.company_name,
                "code": e.company_code,
                "market_cap_billion": e.market_cap,
                "gross_margin_pct": e.gross_margin,
                "net_margin_pct": e.net_margin,
                "roe_pct": e.roe,
                "debt_ratio_pct": e.debt_ratio,
                "cash_to_net_profit": cash_ratio,
                "rd_ratio_pct": round(rd["value"], 2) if rd else None,
                "calculations": calculations,
                "financial_period_end": e.financial_period_end,
                "financial_period_type": e.financial_period_type,
                "period_mismatches": dict(e.financial_period_mismatch or {}),
                "period_warning": None if calculation else "缺少同主体、同期间、同范围和币种的可比输入，净现比不可计算",
                "pe_vs_industry_median_pct": pe_premium,
                "valuation_tier": e.valuation_tier,
                "valuation_note": e.valuation_note,
            }
            if e.operating_cash_flow is not None and e.net_profit is not None and abs(e.net_profit) < 0.05:
                item["cash_flow_warning"] = "微利/微亏企业净现比易除零失真，已剔除该指标计算"
            elif e.net_profit and e.net_profit > 0 and e.operating_cash_flow and e.operating_cash_flow < 0:
                item["cash_flow_warning"] = "归母净利润为正、经营活动现金流为负，成因需结合营运资金明细核验"
            elif cash_ratio is not None and cash_ratio >= 1.0:
                item["cash_flow_quality"] = "净现比>=1.0，盈利含金量与造血能力优良"
            # D-02 合理性校验：正常经营下净利率不应超过毛利率（净利 ≤ 毛利）。若 net_margin
            # 显著高于 gross_margin，多为源侧口径污染（如把分部毛利率/其他口径混入净利率），
            # 不再静默输出，改为显式标注异常供下游与人工复核识别（修复建议②）。
            gm, nm = e.gross_margin, e.net_margin
            if gm is not None and nm is not None and (nm - gm) >= 1.0:
                item["ratio_anomaly_note"] = (
                    f"净利率({nm}%)高于毛利率({gm}%)，结构上异常（正常经营净利≤毛利），"
                    f"疑源侧口径污染，已标注待核，不作确定性结论使用"
                )
            ratios.append(item)
        return ratios

    def build_data_quality_appendix(
        self,
        dataset: StructuredResearchDataset,
        comps: PeerCompsMatrix,
        anomalies: list[AnomalyFinding],
        validations: list[CrossValidationFinding],
        quality: DataQualityAssessment,
    ) -> dict[str, Any]:
        periods = set()
        for r in dataset.financials:
            if r.period_end:
                periods.add(str(r.period_end))

        sample_info = {
            "total_records": len(dataset.all_records()),
            "total_companies": len({_entity(r) for r in dataset.companies if _entity(r)}),
            "comps_sample_size": len(comps.entries),
            "profitable_sample_size": sum(1 for e in comps.entries if e.valuation_tier == "profitable"),
            "loss_or_high_multiple_size": sum(1 for e in comps.entries if e.valuation_tier == "loss_or_high_multiple"),
            "pe_available": sum(e.pe_ttm is not None for e in comps.entries),
            "pb_available": sum(e.pb is not None for e in comps.entries),
            "pe_available_count": sum(e.pe_ttm is not None for e in comps.entries),
            "pb_available_count": sum(e.pb is not None for e in comps.entries),
            "mature_pe_benchmark_size": sum(e.pe_ttm is not None and 0 < e.pe_ttm <= 150 and e.peer_membership in ("core", "unscoped_sample") for e in comps.entries),
            "primary_periods": sorted(periods),
            "limitations": quality.limitations,
        }

        # B23-T11（2026-11-10 SEMI-Q4 第二轮实测）：异常条目原先混入两类错误：
        # ①「同一指标同一期间有多个来源取值」（如 ROE 16.0506 vs 16.41）本质是
        #   多源冲突，却被写成 observed_value="[16.0506, 16.41]" 的 outlier，
        #   融合层的附录审计按「单值匹配」必然判「无法匹配来源」→ 硬阻塞交付；
        # ② entity 用证券代码（002371.SZ）而证据侧是公司名（北方华创），
        #   按主体匹配同样失败。
        # 修正：多值 → 归入 conflict_items；entity 统一用公司名。
        code_to_name: dict[str, str] = {}
        for _record in dataset.companies:
            _code = getattr(_record, "entity_code", None)
            _name = _entity(_record)
            if _code and _name:
                code_to_name[str(_code)] = _name

        outlier_items = []
        deferred_conflicts: list[dict[str, Any]] = []
        for a in anomalies:
            if a.kind == "cross_sectional_outlier" or a.severity == "high":
                raw_value = getattr(a, "observed_value", None)
                entity_label = code_to_name.get(str(a.entity or ""), a.entity or "行业整体")
                if isinstance(raw_value, (list, tuple, set)):
                    deferred_conflicts.append({
                        "entity": entity_label,
                        "metric": a.metric,
                        "period": str(a.period) if a.period else "-",
                        "evidence_record_ids": list(a.evidence_record_ids),
                        "observed_values": [str(v) for v in raw_value],
                        "arbitration_rule": "同一指标在同一期间存在多个来源取值；保留差异供穿透核查，不采信单一值",
                    })
                    continue
                outlier_items.append({
                    "entity": entity_label,
                    "metric": a.metric,
                    "period": str(a.period) if a.period else None,
                    "evidence_record_ids": list(a.evidence_record_ids),
                    "observed_value": str(raw_value),
                    "expected_range": "检测规则范围见分析记录；不作为正常区间或预测范围",
                    "treatment": "单独列示并剔除，不纳入横向基准中位数计算",
                    "reason": a.explanation,
                })

        conflict_items = list(deferred_conflicts)
        for c in dataset.conflicts:
            conflict_items.append({
                # B23-T11：conflicts 的 entity 也是证券代码，统一转公司名，
                # 否则附录审计按主体匹配必然失败。
                "entity": code_to_name.get(str(c.entity or ""), c.entity or "行业整体"),
                "metric": c.metric,
                "period": str(c.period or "-"),
                "evidence_record_ids": list(c.record_ids),
                "observed_values": [str(v) for v in c.values],
                "arbitration_rule": "优先采纳最新法定审计年报/中报公告数据；多口径预测数据保留区间范围",
            })
        # B23-T11：多源交叉验证的「contradicted」是**定性结论**（来源清单 + 偏差
        # 说明），不是「同主体同指标同期间的两个数值」——放进 conflict_items 会被
        # 附录审计判为「多源冲突不成立」。改为并入差异项，走文本披露。
        cross_validation_notes: list[dict[str, Any]] = []
        for v in validations:
            if v.status == "contradicted" and v.kind == "source_consistency":
                cross_validation_notes.append({
                    "kind": "source_consistency_contradicted",
                    "entity": "多源交叉验证标的",
                    "metric": v.claim,
                    "period": "-",
                    "evidence_record_ids": list(v.evidence_record_ids),
                    "observed_values": [f"涉及来源: {', '.join(v.sources)}"],
                    "arbitration_rule": v.explanation or "交叉核验相对偏差超过容差阈值，保留差异标注供穿透核查",
                })

        non_extrapolation_disclaimers = [
            "【样本边界】量化样本仅包含本次实际取得且定义明确的公开记录；未知主营归属不作为行业估值基准，集团口径不得当作细分业务口径。",
            "【期间基准】年度、半年、前三季度及单季度分别比较；缺少同期间输入不计算比率。实际覆盖期间见本附录，不以披露日代替财务期间。",
            "【估值分层】盈利分组、估值观测可用分组与成熟基准分开列示；高PB/PS本身不能证明短期业绩安全边际。",
        ]

        return {
            "requirement_evidence_matrix": dataset.quality_summary.get("requirement_evidence_matrix", []),
            "requested_requirement_coverage": dataset.quality_summary.get("requested_requirement_coverage", []),
            "requested_financial_coverage": dataset.quality_summary.get("requested_financial_coverage", []),
            "sample_info": sample_info,
            "outlier_items": outlier_items,
            "conflict_items": conflict_items,
            "financial_difference_items": (
                [v.model_dump(mode="json") for v in validations if v.kind != "source_consistency"]
                + cross_validation_notes
            ),
            "non_extrapolation_disclaimers": non_extrapolation_disclaimers,
        }
