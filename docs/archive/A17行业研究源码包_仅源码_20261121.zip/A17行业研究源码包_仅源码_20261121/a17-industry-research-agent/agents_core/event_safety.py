"""Whitelist structured event details before storing or exporting."""
import re
from typing import Any

_ID_FIELDS = {'task_id','call_id','request_id','trace_id','skill_id','operation','model','kind'}
_NUMBER_FIELDS = {'attempt','attempts','elapsed_ms','http_status','record_count','coverage','new_records',
                  'total_records','conflicts','budget_bytes','before_bytes','after_bytes','accepted','rejected',
                  'remaining_skill_calls','proposed_tasks'}
_BOOL_FIELDS = {'cache_hit','passed'}
_OUTCOMES = {'response','http_error','provider_error','invalid_response','failed','cancelled','success','records','success_empty'}
# 任务被拒的原因全部来自代码内常量（"duplicate skill and query" 等），不是模型输出，
# 因此可以留档；上限 200 字符防止未来有人把 query 原文塞进来。
# message 仅指 data_fetcher 里代码构造的「异常类型: 状态码」诊断串；
# 'error' 保持过滤——不变量测试证明任意 error 文本可能携带密钥。
_REASON_FIELDS = {'reason', 'message'}
_MAX_REASON_LEN = 200

def safe_event_details(details: dict[str, Any]) -> dict[str, Any]:
    safe = {}
    for key, value in details.items():
        if key in _ID_FIELDS and isinstance(value, str) and re.fullmatch(r'[A-Za-z0-9_.:-]{1,128}', value):
            safe[key] = value
        elif key in _NUMBER_FIELDS and isinstance(value, (int, float)) and not isinstance(value, bool):
            safe[key] = value
        elif key in _BOOL_FIELDS and isinstance(value, bool):
            safe[key] = value
        elif key in _REASON_FIELDS and isinstance(value, str):
            text = re.sub(r'[\x00-\x1f\x7f]', ' ', value).strip()
            safe[key] = text[:_MAX_REASON_LEN]
        elif key in {'outcome','invocation_outcome'} and isinstance(value, str) and value in _OUTCOMES:
            safe[key] = value
        elif key == 'provider_code' and isinstance(value, str) and value in {'InvalidSubscription','AuthenticationError','InternalServiceError',
                                                  'RateLimitError','InvalidParameter','ModelNotFound'}:
            safe[key] = value
        elif key == 'usage' and isinstance(value, dict):
            safe[key] = {k:v for k,v in value.items() if k in {'prompt_tokens','completion_tokens','total_tokens','cost'}
                         and isinstance(v, (int,float)) and not isinstance(v,bool) and v >= 0}
        elif key == 'usage' and value is None:
            safe[key] = None
    return safe

