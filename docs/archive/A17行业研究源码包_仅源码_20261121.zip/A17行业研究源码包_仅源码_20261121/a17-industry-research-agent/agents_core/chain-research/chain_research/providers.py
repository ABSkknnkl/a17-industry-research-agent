"""数据提供者与 run 级预算（T3，方案 §5.3 / §5.6 / §9-T3）。

═════════════════════════════════════════════════════════════════════════════
职责
═════════════════════════════════════════════════════════════════════════════

1. **问财搜索通道**（B36 2026-11-11：唯一检索源，豆包 provider 已彻底移除）：
   - ``search_raw(query, run_context)``：保留原始命中，不做域名/主题词/去数字
     等事实前过滤（v2 主路径，§5.3）。原始命中的相关性判读在后续步骤处理。
   - 多 key 轮换；「次数已用完」的 key 在 run 内排除（ctx.provider_state），
     不做跨 run / 跨天记忆（配额由服务端每日刷新，2026-11-10 用户口径）。

2. **run 级预算隔离**（§5.6）：预算挂在 RunContext，不挂在单例客户端。
   单例的 ``calls_used`` 是进程级计数，跨 run 会泄漏——本模块用
   ``RunContext.budget`` 记账，每次真实请求与重试都计数，缓存命中单列。

3. **统一错误类别**（T3 验收）：
   ``auth`` / ``budget`` / ``timeout`` / ``no_result`` / ``parse_error`` /
   ``not_relevant`` —— 凭证错误不会退化成"没有该企业"（no_result）。

4. **原文读取**：HTML/纯文本首版（PDF 走后续任务接入已有解析能力）；
   限制大小、超时、跳转次数；抓取失败与不相关分别统计。

本模块**不导入** A3 的 chart_generator 业务代码（除传输客户端的鸭子类型注入）。
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import secrets
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import httpx

from chain_research.models import (
    BudgetCounts,
    ChainScope,
    ResearchBudget,
    RunDiagnostics,
)

logger = logging.getLogger(__name__)

# ── §5.3 / §5.6 默认上限（可按请求配置，manifest 记录）────────────────────

DEFAULT_MAX_DOC_BYTES = 2 * 1024 * 1024      # 原文大小上限 2MB
DEFAULT_FETCH_TIMEOUT = 20.0                  # 原文读取超时
DEFAULT_MAX_REDIRECTS = 3                     # 跳转上限


class ProviderErrorKind(str, Enum):
    """统一错误类别（T3）。凭证错误 ≠ 无结果。"""

    AUTH = "auth"                  # 鉴权失败：key 无效/过期
    BUDGET = "budget"              # run 预算耗尽
    TIMEOUT = "timeout"            # 网络/MCP 超时
    NO_RESULT = "no_result"        # 搜索正常返回但无命中
    PARSE_ERROR = "parse_error"    # 响应解析失败
    NOT_RELEVANT = "not_relevant"  # 相关性不足（保留原始命中+丢弃理由）
    UNAVAILABLE = "unavailable"    # 提供者不可用（未配置/进程不可起）


class ProviderError(Exception):
    """提供者调用失败（统一类别）。程序错误不改写断言状态（§4.1）。"""

    def __init__(self, kind: ProviderErrorKind, message: str,
                 *, query: str = "") -> None:
        super().__init__(f"[{kind.value}] {message}")
        self.kind = kind
        self.message = message
        self.query = query


# ── run 上下文（预算隔离的载体）────────────────────────────────────────────

@dataclass
class RunContext:
    """单次研究作业的上下文：预算、诊断、scope。

    计数属于 run，不属于全局客户端（§5.6）——同进程连续/并发多 run
    各持各的 RunContext，互不透支。
    """

    run_id: str
    scope: ChainScope
    budget: ResearchBudget = field(default_factory=ResearchBudget)
    diagnostics: RunDiagnostics = field(default_factory=RunDiagnostics)
    source_policy: str = "wencai_v1"
    # provider 的 run 级私有状态（如问财 key 排除集）——随 run 创建/丢弃，
    # 不做跨 run 记忆（外部配额由服务端每日刷新，2026-11-10 用户口径）。
    provider_state: dict[str, Any] = field(default_factory=dict)

    def charge_search(self) -> None:
        """真实搜索请求（含重试）计数；超限抛 ProviderError(BUDGET)。"""
        dim = ('search_requests' if self.budget.used.search_requests >= self.budget.max_search_requests else
               'wall_seconds' if self.budget.used.wall_seconds >= self.budget.max_wall_seconds else None)
        if dim is not None:
            raise ProviderError(
                ProviderErrorKind.BUDGET,
                f"run {self.run_id} 预算耗尽（{dim}）")
        self.budget.used.search_requests += 1

    def charge_fetch(self) -> None:
        dim = ('document_fetches' if self.budget.used.document_fetches >= self.budget.max_document_fetches else
               'wall_seconds' if self.budget.used.wall_seconds >= self.budget.max_wall_seconds else None)
        if dim is not None:
            raise ProviderError(
                ProviderErrorKind.BUDGET,
                f"run {self.run_id} 预算耗尽（{dim}）")
        self.budget.used.document_fetches += 1

    def charge_llm(self) -> None:
        dim = ('llm_requests' if self.budget.used.llm_requests >= self.budget.max_llm_requests else
               'wall_seconds' if self.budget.used.wall_seconds >= self.budget.max_wall_seconds else None)
        if dim is not None:
            raise ProviderError(
                ProviderErrorKind.BUDGET,
                f"run {self.run_id} 预算耗尽（{dim}）")
        self.budget.used.llm_requests += 1

    def record_cache_hit(self) -> None:
        self.budget.used.cache_hits += 1


# ── 原始搜索结果（provider 通用契约，§5.3）────────────────────────────────

@dataclass
class RawSearchResult:
    """一次原始搜索的完整结果：保留全部命中 + 计数诊断。"""

    query: str
    hits: list[dict[str, str]]        # [{title, url, snippet, source_org, published_at}]
    raw_count: int
    charged: bool = True              # 是否消耗了预算（缓存命中 False）
    diagnostics: dict[str, Any] = field(default_factory=dict)


# ── 问财搜索提供者（B36：唯一检索底座；豆包 provider 已于 2026-11-11 移除）──

def _wencai_daily_exhausted_text(text: str) -> bool:
    """问财 key 日配额尽文案（与 data-fetcher B16.2 同源口径，独立实现避免跨包导入）。

    「您今天的次数已用完，建议升级权益…」。命中仅在**本次研究（run）内**
    跳过该 key；配额由服务端每日刷新，项目侧不做跨 run / 跨天记忆。
    """
    return "已用完" in text or ("次数" in text and "升级权益" in text)


def wencai_keys_from_env() -> list[str]:
    """从环境读取问财 key 列表（IWENCAI_API_KEY + IWENCAI_API_KEY_BACKUP，逗号/分号分隔）。"""
    import os
    import re
    raw = ",".join((os.getenv("IWENCAI_API_KEY", ""), os.getenv("IWENCAI_API_KEY_BACKUP", "")))
    return [part.strip() for part in re.split(r"[,;]+", raw) if part.strip()]


class WencaiAuthError(Exception):
    """问财鉴权失败（key 无效等，非日配额尽）。"""


class WencaiQuotaExhausted(Exception):
    """本次可用的问财 key 全部日配额尽（key 已由调用方记入 run 排除集）。"""


_WENCAI_LIST_KEYS = ("data", "datas", "items", "result", "results", "records", "list")


def _first_field(row: dict[str, Any], names: tuple[str, ...]) -> str:
    for name in names:
        value = row.get(name)
        if value not in (None, ""):
            return str(value)
    return ""


def _normalize_wencai_hit(row: Any) -> dict[str, str]:
    """问财记录 → 原始命中五元组（title/url/snippet/source_org/published_at）。

    2026-11-10 实测（news 频道）：记录字段为 title/summary/url/publish_time( epoch)/
    publish_date(可读)/name(站点作者)/data_source(管道标签)/source_original(正文摘录)——
    **无可靠来源机构字段**，来源信号靠 URL 域名（分级核验用域名判 primary/secondary）。
    published_at 优先取可读的 publish_date，回退 epoch 的 publish_time；
    其余字段按候选名防御性映射，不做清洗（§5.3）。
    """
    if not isinstance(row, dict):
        return {"title": "", "url": "", "snippet": "", "source_org": "", "published_at": ""}
    return {
        "title": _first_field(row, ("title", "newsTitle", "notice_title", "report_title")),
        "url": _first_field(row, ("url", "news_url", "notice_url", "report_url", "link")),
        "snippet": _first_field(row, ("summary", "content", "snippet", "abstract", "digest", "description")),
        "source_org": _first_field(row, ("source_org", "source", "mediaName", "media_name",
                                         "publisher", "siteName", "site_name", "info_source")),
        "published_at": _first_field(row, ("published_at", "publish_date", "publish_time", "publishTime",
                                           "notice_date", "report_date", "time", "date")),
    }


class WencaiSearchTransport:
    """问财 SkillHub 综合搜索传输（/v1/comprehensive/search，同步，鸭子类型注入）。

    - 多 key 轮换：「次数已用完」401/额度壳 → 该 key 记入 ``exclude_keys``
      （调用方持有、按 run 生命周期），换下一把；其余 401/403 也换下一把。
    - **不做跨 run 记忆**：本类不维护任何 key 状态，排除集完全由调用方传入。
    - ``client`` 参数仅供测试注入 httpx.MockTransport；生产走惰性 httpx.Client。
    """

    def __init__(self, keys: list[str], *, base_url: str = "https://openapi.iwencai.com",
                 channel: str = "news", endpoint: str = "/v1/comprehensive/search",
                 timeout: float = 30.0, client: httpx.Client | None = None) -> None:
        self._keys = list(keys)
        self._base_url = base_url.rstrip("/")
        self._channel = channel
        self._endpoint = endpoint
        self._timeout = timeout
        self._client = client

    def has_available_keys(self, excluded: set[str]) -> bool:
        """还有未被排除的 key 吗（供 provider 零请求快速失败）。"""
        return any(key not in excluded for key in self._keys)

    def _http(self) -> httpx.Client:
        if self._client is None:
            self._client = httpx.Client(timeout=self._timeout, trust_env=False)
        return self._client

    def _post(self, query: str, count: int, key: str) -> httpx.Response:
        return self._http().post(
            f"{self._base_url}{self._endpoint}",
            json={"query": query, "channels": [self._channel],
                  "app_id": "AIME_SKILL", "size": int(count)},
            headers={
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json",
                "X-Claw-Call-Type": "normal",
                "X-Claw-Skill-Id": f"{self._channel}-search",
                "X-Claw-Skill-Version": "1.0.0",
                "X-Claw-Plugin-Id": "none",
                "X-Claw-Plugin-Version": "none",
                "X-Claw-Trace-Id": secrets.token_hex(32),
            },
        )

    def search_sync(self, query: str, *, count: int = 10,
                    exclude_keys: set[str] | None = None) -> list[dict[str, str]]:
        """一次原始搜索；命中「次数已用完」的 key 会加入 exclude_keys。"""
        excluded = exclude_keys if exclude_keys is not None else set()
        candidates = [key for key in self._keys if key not in excluded]
        if not candidates:
            raise WencaiQuotaExhausted("问财 key 在本次研究内已全部排除")
        quota_hit = False
        last_auth = ""
        for key in candidates:
            response = self._post(query, count, key)
            if response.status_code in (401, 403):
                if _wencai_daily_exhausted_text(response.text):
                    excluded.add(key)           # 日配额尽：run 内不再使用该 key
                    quota_hit = True
                    continue
                last_auth = f"HTTP {response.status_code}"
                continue                        # key 无效：换下一把，如实上抛
            if response.status_code >= 400:
                raise ValueError(f"问财搜索 HTTP {response.status_code}")
            data = response.json()              # JSONDecodeError(ValueError) → PARSE_ERROR
            if not isinstance(data, dict):
                raise ValueError("问财搜索响应不是对象")
            code = data.get("status_code", data.get("code"))
            if code not in (0, "0", None):
                msg = str(data.get("message") or data.get("msg") or "")
                if "额度" in msg or "已用完" in msg:
                    excluded.add(key)
                    quota_hit = True
                    continue
                raise ValueError(f"问财搜索响应壳错误码 {code}：{msg[:80]}")
            rows = next((data[name] for name in _WENCAI_LIST_KEYS
                         if isinstance(data.get(name), list)), None)
            if rows is None:
                raise ValueError("问财搜索响应缺少记录列表")
            return [_normalize_wencai_hit(row) for row in rows[:int(count)]]
        if quota_hit:
            raise WencaiQuotaExhausted("问财 key 当日配额尽（已在本次研究内排除）")
        raise WencaiAuthError(f"问财鉴权失败（{last_auth or '未知原因'}）")


class WencaiSearchProvider:
    """问财搜索提供者（统一 ``search_raw`` 契约，§5.3）。

    - 原始命中保留不过滤（§5.3）；真实请求计费入 run 预算（每次 search_raw 计 1，
      key 间切换属于 provider 内部故障转移，不重复计费）；
    - 「次数已用完」的 key 在 **run 内**跳过：排除集存 ``ctx.provider_state``，
      随 run 丢弃；配额由服务端每日刷新，不做跨 run 记忆（2026-11-10 用户口径）；
    - 全部 key 已排除时零请求、不占预算、如实上抛 ProviderError(AUTH)。
    """

    def __init__(self, transport: WencaiSearchTransport | None, *,
                 unavailable_reason: str = "") -> None:
        self._transport = transport
        self._unavailable_reason = unavailable_reason

    @property
    def available(self) -> bool:
        return self._transport is not None

    async def search_raw(self, query: str, ctx: RunContext, *,
                         count: int = 10) -> RawSearchResult:
        if self._transport is None:
            raise ProviderError(
                ProviderErrorKind.UNAVAILABLE,
                self._unavailable_reason or "问财搜索未配置", query=query)
        excluded: set[str] = ctx.provider_state.setdefault("wencai_excluded_keys", set())
        if not self._transport.has_available_keys(excluded):
            raise ProviderError(
                ProviderErrorKind.AUTH,
                f"run {ctx.run_id} 问财 key 当日配额尽（全部 key 已在本研究内排除）",
                query=query)
        ctx.charge_search()
        try:
            hits = await asyncio.to_thread(
                self._transport.search_sync, query, count=count, exclude_keys=excluded)
        except ProviderError:
            raise
        except WencaiQuotaExhausted as exc:
            raise ProviderError(
                ProviderErrorKind.AUTH, f"问财 key 当日配额尽：{exc}", query=query) from exc
        except WencaiAuthError as exc:
            raise ProviderError(
                ProviderErrorKind.AUTH, f"问财鉴权失败：{exc}", query=query) from exc
        except (TimeoutError, httpx.TimeoutException) as exc:
            raise ProviderError(
                ProviderErrorKind.TIMEOUT, f"问财搜索超时：{exc}", query=query) from exc
        except httpx.HTTPError as exc:
            raise ProviderError(
                ProviderErrorKind.UNAVAILABLE,
                f"问财网络错误：{type(exc).__name__}: {exc}", query=query) from exc
        except ValueError as exc:
            raise ProviderError(
                ProviderErrorKind.PARSE_ERROR,
                f"问财响应处理失败：{type(exc).__name__}: {exc}", query=query) from exc
        return RawSearchResult(
            query=query, hits=hits, raw_count=len(hits), charged=True,
            diagnostics={"kept": len(hits), "discarded": {},   # v2 不丢弃原始命中
                         "excluded_keys": len(excluded), "channel": self._transport._channel},
        )


# ── 巨潮公告提供者（B36 2026-11-11：公告原文直查兜底）────────────────────────
# 背景（run-20261111083441 实测）：问财 announcement 频道返回的上交所静态公告
# 链接被瑞数反爬拦截（返回 HTML 挑战页，Referer 无效），公告 PDF 一条都抓不到。
# 巨潮资讯（cninfo）是法定信息披露平台：全文检索接口 + static.cninfo.com.cn
# 直链 PDF 可稳定下载并经 fitz 提取（实测 2026-11-11）。作为公告佐证轮的
# 兜底检索源——不是第三方搜索引擎，是公告原文的官方出处通道。

def _clean_cninfo_title(title: Any) -> str:
    """巨潮命中标题带 <em> 高亮标签，清洗为纯文本。"""
    return str(title or "").replace("<em>", "").replace("</em>", "").strip()


class CninfoAnnouncementTransport:
    """巨潮公告同步传输：全文检索 → 公告 PDF 直链。"""

    SEARCH_URL = "http://www.cninfo.com.cn/new/fulltextSearch/full"
    STATIC_BASE = "http://static.cninfo.com.cn/"

    def __init__(self, *, timeout: float = 20.0) -> None:
        self._timeout = timeout

    def search_sync(self, query: str, *, count: int = 4) -> list[dict[str, str]]:
        response = httpx.post(
            self.SEARCH_URL,
            data={"searchkey": query, "sdate": "", "edate": "", "isfulltext": "false",
                  "sortName": "nothing", "sortType": "desc", "pageNum": "1"},
            headers={"User-Agent": "Mozilla/5.0 (compatible; chain-research/2.0)",
                     "Content-Type": "application/x-www-form-urlencoded"},
            timeout=self._timeout, trust_env=False, follow_redirects=True)
        if response.status_code >= 400:
            raise ValueError(f"巨潮检索 HTTP {response.status_code}")
        data = response.json()
        # 公告按发布时间倒序（run-20261111085922 教训：接口默认排序混入 2023 年
        # 老公告；主营业务核验应优先最新披露）。
        candidates = sorted(
            (ann for ann in (data.get("announcements") or [])
             if ann.get("adjunctUrl")),
            key=lambda a: int(a.get("announcementTime") or 0), reverse=True)
        rows: list[dict[str, str]] = []
        for ann in candidates[:int(count)]:
            adjunct = str(ann.get("adjunctUrl") or "")
            title = _clean_cninfo_title(ann.get("announcementTitle"))
            published = ""
            ts = ann.get("announcementTime")
            if ts:
                try:
                    from datetime import datetime, timedelta, timezone
                    published = datetime.fromtimestamp(
                        int(ts) / 1000, tz=timezone(timedelta(hours=8))).strftime("%Y-%m-%d")
                except (TypeError, ValueError, OSError, OverflowError):
                    published = str(ts)
            rows.append({
                "title": title,
                "url": self.STATIC_BASE + adjunct,
                "snippet": title,               # 公告无摘要，标题即线索
                "source_org": "巨潮资讯网",
                "published_at": published,
            })
        return rows


class CninfoAnnouncementProvider:
    """巨潮公告提供者（统一 ``search_raw`` 契约）。

    0 命中是正常结果（返回空 hits，不报错）；检索计费入 run 预算。
    """

    def __init__(self, transport: CninfoAnnouncementTransport | None) -> None:
        self._transport = transport

    @property
    def available(self) -> bool:
        return self._transport is not None

    async def search_raw(self, query: str, ctx: RunContext, *,
                         count: int = 4) -> RawSearchResult:
        if self._transport is None:
            raise ProviderError(
                ProviderErrorKind.UNAVAILABLE, "巨潮公告通道未配置", query=query)
        ctx.charge_search()
        try:
            rows = await asyncio.to_thread(
                self._transport.search_sync, query, count=count)
        except ProviderError:
            raise
        except (TimeoutError, httpx.TimeoutException) as exc:
            raise ProviderError(
                ProviderErrorKind.TIMEOUT, f"巨潮检索超时：{exc}", query=query) from exc
        except httpx.HTTPError as exc:
            raise ProviderError(
                ProviderErrorKind.UNAVAILABLE,
                f"巨潮网络错误：{type(exc).__name__}: {exc}", query=query) from exc
        except ValueError as exc:
            raise ProviderError(
                ProviderErrorKind.PARSE_ERROR, f"巨潮响应解析失败：{exc}", query=query) from exc
        except Exception as exc:              # noqa: BLE001
            raise ProviderError(
                ProviderErrorKind.PARSE_ERROR,
                f"巨潮响应处理失败：{type(exc).__name__}: {exc}", query=query) from exc
        return RawSearchResult(
            query=query, hits=rows, raw_count=len(rows), charged=True,
            diagnostics={"kept": len(rows), "discarded": {}},
        )


# ── 原文读取提供者 ─────────────────────────────────────────────────────────

@dataclass
class SourceDocument:
    """读取到的原文文档（保留原始文本与定位基础，不先按数字规则清洗）。"""

    url: str
    final_url: str
    content_type: str
    text: str                          # 提取的纯文本（保留数字/型号/否定词）
    content_hash: str
    bytes_read: int
    title: str = ""


def _extract_text(content: bytes, content_type: str) -> str:
    """HTML → 粗提纯文本；纯文本直通。不做数字/型号清洗（§5.3）。"""
    text: str
    if "html" in content_type.lower():
        from .document_text import html_body
        text = html_body(content.decode("utf-8", errors="replace"))
    elif 'pdf' in content_type.lower() or content.startswith(b'%PDF'):
        import fitz
        with fitz.open(stream=content, filetype='pdf') as doc:
            text = '\n'.join(page.get_text() for page in doc)
    else:
        text = content.decode("utf-8", errors="replace")
    # 只做空白规整，保留一切内容字符
    return "\n".join(line.strip() for line in text.splitlines() if line.strip())


class DocumentFetchProvider:
    """HTTP(S) 原文读取：限制大小/超时/跳转；只允许 http(s)（§5.3）。"""

    def __init__(self, *, max_bytes: int = DEFAULT_MAX_DOC_BYTES,
                 timeout: float = DEFAULT_FETCH_TIMEOUT,
                 max_redirects: int = DEFAULT_MAX_REDIRECTS) -> None:
        self._max_bytes = max_bytes
        self._timeout = timeout
        self._max_redirects = max_redirects

    async def fetch(self, url: str, ctx: RunContext) -> SourceDocument:
        if not url.startswith(("http://", "https://")):
            raise ProviderError(
                ProviderErrorKind.NOT_RELEVANT,
                f"仅允许 HTTP(S) 来源：{url}", query=url)
        ctx.charge_fetch()
        try:
            async with httpx.AsyncClient(
                    timeout=self._timeout,
                    trust_env=False,
                    follow_redirects=True,
                    max_redirects=self._max_redirects,
                    headers={"User-Agent": "Mozilla/5.0 (compatible; chain-research/2.0)"}) as client:
                async with client.stream("GET", url) as resp:
                    if resp.status_code >= 400:
                        raise ProviderError(
                            ProviderErrorKind.NO_RESULT,
                            f"HTTP {resp.status_code}：{url}", query=url)
                    ct = resp.headers.get("content-type", "text/plain")
                    # 公告 PDF（年报/招股书常 2-8MB）：PDF 下载上限放宽 4 倍
                    is_pdf = ("pdf" in ct.lower()
                              or url.lower().split("?")[0].endswith(".pdf"))
                    byte_limit = self._max_bytes * 4 if is_pdf else self._max_bytes
                    chunks: list[bytes] = []
                    total = 0
                    async for chunk in resp.aiter_bytes():
                        total += len(chunk)
                        if total > byte_limit:
                            raise ProviderError(
                                ProviderErrorKind.PARSE_ERROR,
                                f"文档超过 {byte_limit} 字节上限：{url}",
                                query=url)
                        chunks.append(chunk)
                    content = b"".join(chunks)
        except httpx.TimeoutException as exc:
            raise ProviderError(
                ProviderErrorKind.TIMEOUT, f"原文读取超时：{url}", query=url) from exc
        except httpx.TooManyRedirects as exc:
            raise ProviderError(
                ProviderErrorKind.NOT_RELEVANT,
                f"跳转超过 {self._max_redirects} 次：{url}", query=url) from exc
        except httpx.HTTPError as exc:
            raise ProviderError(
                ProviderErrorKind.UNAVAILABLE,
                f"网络错误：{type(exc).__name__}: {url}", query=url) from exc

        text = _extract_text(content, ct)
        if not text.strip():
            raise ProviderError(
                ProviderErrorKind.PARSE_ERROR, f"文档无有效文本：{url}", query=url)
        digest = hashlib.sha256(content).hexdigest()[:32]
        title = ""
        if "html" in ct.lower() and content:
            import re
            m = re.search(rb"<title[^>]*>(.*?)</title>", content,
                          flags=re.S | re.I)
            if m:
                title = m.group(1).decode("utf-8", errors="replace").strip()
        return SourceDocument(
            url=url, final_url=str(resp.request.url), content_type=ct,
            text=text, content_hash=digest, bytes_read=len(content), title=title)


# ── KB 候选富化提供者（只读种子/候选适配，§8）──────────────────────────────

class KbEnrichmentProvider:
    """旧 KB 的 candidate enrichment 通道。

    KB 命中只产生候选（candidate），不产生 supported；
    KB 不命中不得删人，也不允许「KB 放行」跳过来源要求（§5.4）。
    首版注入一个查询回调，避免本包依赖 chart_kb 具体实现。
    """

    def __init__(self, lookup: Any | None = None) -> None:
        self._lookup = lookup

    async def find_aliases(self, company: str, ctx: RunContext) -> list[str]:
        """查公司别名/候选产品（候选级，只作检索线索）。"""
        if self._lookup is None:
            return []
        ctx.record_cache_hit()        # 本地 KB 查询记缓存命中，不占真实请求
        try:
            result = await asyncio.to_thread(self._lookup, company)
        except Exception as exc:      # noqa: BLE001
            logger.warning("KB 富化查询失败（%s）：%s", company, exc)
            return []
        return list(result or [])
