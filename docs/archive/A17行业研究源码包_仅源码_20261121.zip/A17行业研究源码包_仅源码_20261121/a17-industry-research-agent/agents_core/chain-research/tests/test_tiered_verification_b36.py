"""B36 分级核验 → B51 来源政策（2026-11-11 用户拍板）。

用户口径（B51）：
- **不再验证证据权威性**——只要是问财检索链路取回的原文，verify 判定
  supported + in_scope + 时效通过，即可 supported；
- 不再要求「≥1 primary 或 ≥2 独立 secondary」；
- `evidence.source_tier` 仍按 verify 结果落档，但**只作展示/审计标签**，不参与准入。

场景：
- 单一来源（含 unverified/invalid 档）→ supported（verifier=wencai_source_v1）
- 多来源 → 引用优先 primary，并附一条不同 source_family 证据便于追溯
- verify 判否 / 越界 → 仍 unresolved（实质性判定未被放宽）
- evidence.source_tier 按文档落地，不改变准入结论

全部离线假传输/假 LLM，不触发真实问财/网络。
"""

import asyncio
from types import SimpleNamespace

from chain_research import ChainResearchRequest, ChainScope, ResearchBudget
from chain_research.service import ChainResearchService
from chain_research.store import ChainStore

QUOTE = '甲公司提供笔记本处理器。'


def make_env(tier_by_url: dict[str, str], texts: dict[str, str], *,
             supported: bool = True, in_scope: bool = True):
    class Search:
        async def search_raw(self, query, ctx, count):
            ctx.charge_search()
            return SimpleNamespace(hits=[{'url': u, 'title': '来源文档', 'snippet': ''}
                                         for u in tier_by_url])

    class Fetch:
        async def fetch(self, url, ctx):
            ctx.charge_fetch()
            return SimpleNamespace(text=texts[url])

    async def llm(task, payload):
        if task == 'discover':
            return {'queries': ['甲公司 处理器'],
                    'activities': [{'name': '测试部件制造', 'stage': 'upstream'}]}
        if task == 'gap_queries':
            return {'queries': []}
        if task == 'extract':
            return {'claims': [{'subject': '甲公司', 'subject_type': 'organization',
                                'predicate': 'offers', 'object': '笔记本处理器',
                                'object_type': 'product', 'role': '部件供应商', 'quote': QUOTE}]}
        tier = tier_by_url.get(payload.get('document_url', ''), 'invalid')
        return {'source_tier': tier,
                'checks': [{'id': c['id'], 'supported': supported, 'in_scope': in_scope,
                            'primary_source': tier == 'primary',
                            'reason': '原文明确供货关系'} for c in payload['checks']]}

    return Search(), Fetch(), llm


def run_research(tmp_path, tier_by_url: dict[str, str], texts: dict[str, str], **kwargs):
    search, fetch, llm = make_env(tier_by_url, texts, **kwargs)
    request = ChainResearchRequest(run_id='r', scope=ChainScope(scope_id='s', subject='低空经济', as_of='2026-11'),
        budget=ResearchBudget(max_search_requests=10, max_document_fetches=8, max_llm_requests=16))
    return asyncio.run(ChainResearchService(search, fetch, llm, ChainStore(tmp_path)).research(request))


def test_single_unverified_source_supports_claim(tmp_path):
    """B51：单条问财来源（未分档）即足以 support，不再要求 primary 或双来源。"""
    urls = ['https://a.example/news']
    tiers = {u: 'invalid' for u in urls}          # 旧政策下必判 unresolved
    texts = {u: QUOTE + '背景补充。' * 40 for u in urls}
    bundle = run_research(tmp_path, tiers, texts)
    supported = bundle.supported_assertions()
    assert len(supported) == 1
    claim = supported[0]
    assert claim.verification.verifier_version == 'wencai_source_v1'
    assert len(claim.verification.supporting_evidence_ids) == 1
    assert claim.verification.supporting_evidence_ids[0] in claim.evidence_ids
    evs = {e.evidence_id: e for e in bundle.evidence}
    assert evs[claim.verification.supporting_evidence_ids[0]].source_tier == 'unverified'


def test_two_sources_keep_second_family_for_traceability(tmp_path):
    """多来源时不设门槛，但保留第二条不同 family 的证据用于追溯。"""
    urls = ['https://a.example/news', 'https://b.example/report']
    tiers = {u: 'secondary' for u in urls}
    texts = {u: QUOTE + '背景补充。' * 40 for u in urls}
    bundle = run_research(tmp_path, tiers, texts)
    supported = bundle.supported_assertions()
    assert len(supported) == 1
    claim = supported[0]
    assert claim.verification.verifier_version == 'wencai_source_v1'
    assert len(claim.verification.supporting_evidence_ids) == 2
    evs = {e.evidence_id: e for e in bundle.evidence}
    assert {evs[eid].source_tier for eid in claim.verification.supporting_evidence_ids} == {'secondary'}
    assert len({evs[eid].source_family for eid in claim.verification.supporting_evidence_ids}) == 2


def test_primary_preferred_as_primary_citation(tmp_path):
    """引用顺序优先 primary（展示友好），但 secondary 同样计入，不再互斥。"""
    urls = ['https://a.example/news', 'https://official.example/announce']
    tiers = {'https://a.example/news': 'secondary', 'https://official.example/announce': 'primary'}
    texts = {u: QUOTE + '背景补充。' * 40 for u in urls}
    bundle = run_research(tmp_path, tiers, texts)
    supported = bundle.supported_assertions()
    assert len(supported) == 1
    claim = supported[0]
    evs = {e.evidence_id: e for e in bundle.evidence}
    first = evs[claim.verification.supporting_evidence_ids[0]]
    assert first.source_tier == 'primary'
    assert first.url == 'https://official.example/announce'
    assert {e.source_tier for e in bundle.evidence} == {'primary', 'secondary'}


def test_verify_rejection_still_unresolved(tmp_path):
    """放宽的只有来源权威度；verify 判否仍是 unresolved。"""
    urls = ['https://a.example/news']
    tiers = {u: 'primary' for u in urls}
    texts = {u: QUOTE + '背景补充。' * 40 for u in urls}
    bundle = run_research(tmp_path, tiers, texts, supported=False)
    assert bundle.supported_assertions() == []
    assert all(a.status == 'unresolved' for a in bundle.assertions)
    assert all(a.verification.method == 'unverified' for a in bundle.assertions)


def test_out_of_scope_still_unresolved(tmp_path):
    """in_scope 仍为准入条件：越界断言不因来源是 primary 而放行。"""
    urls = ['https://official.example/announce']
    tiers = {u: 'primary' for u in urls}
    texts = {u: QUOTE + '背景补充。' * 40 for u in urls}
    bundle = run_research(tmp_path, tiers, texts, in_scope=False)
    assert bundle.supported_assertions() == []
