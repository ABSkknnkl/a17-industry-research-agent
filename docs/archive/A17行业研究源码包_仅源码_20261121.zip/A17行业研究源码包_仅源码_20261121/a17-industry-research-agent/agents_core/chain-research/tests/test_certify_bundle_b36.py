"""B36-P7：人工审阅认证链图（certify_bundle）测试。

2026-11-11 用户拍板选项 A：chain_delivery=complete 的 verified 走人工审阅——
certify_bundle 是全库唯一 release_status='verified' 赋值点，仅在人工批准最终
报告并确认链图时调用。
"""
from chain_research.models import (
    ChainAssertion, ChainEntity, ChainEvidence, ChainKnowledgeBundle,
    ChainQualityReport, ChainResearchRequest, ChainScope, ChainStructure,
    BundleManifest, Predicate, Verification,
)
from chain_research.service import certify_bundle
from chain_research.store import ChainStore


def make_bundle(run_id: str = "r-cert", status: str = "partial") -> ChainKnowledgeBundle:
    scope = ChainScope(scope_id="s", subject="测试", as_of="2026-11-11")
    ent_a = ChainEntity(entity_id="ent-a", entity_type="organization", canonical_name="甲公司")
    ent_b = ChainEntity(entity_id="ent-b", entity_type="activity", canonical_name="测试部件制造")
    ev = ChainEvidence(evidence_id="ev-1", document_id="doc-1", url="https://example.org/a",
                       title="公告", document_kind="other", content_hash="h" * 32,
                       source_family="example.org", locator="document", quote="甲公司制造测试部件。",
                       source_tier="primary")
    claim = ChainAssertion(assertion_id="a1", subject_id="ent-a", object_id="ent-b",
                           predicate=Predicate.PARTICIPATES_IN,
                           verification=Verification(method="model_assisted", verifier_version="tiered_scope_v1:primary",
                                                     rationale="公告明确", supporting_evidence_ids=["ev-1"]),
                           evidence_ids=["ev-1"], status="supported")
    quality = ChainQualityReport(release_status=status,
        coverage_values={"supported_assertions": 1},
        unresolved=["行业结构完整性尚未独立确认", "a1:关系未获支持"])
    return ChainKnowledgeBundle(run_id=run_id, scope=scope, entities=[ent_a, ent_b],
        assertions=[claim], evidence=[ev],
        structure=ChainStructure(structure_id="st1", scope_id="s", activity_ids=[], required_activity_ids=[],
                                 coverage_basis="llm_candidate_only", unresolved=[]),
        quality=quality,
        manifest=BundleManifest(run_id=run_id, scope_subject="测试", research_strategy="profile_guided"))


def test_certify_upgrades_partial_to_verified(tmp_path):
    store = ChainStore(tmp_path)
    store.save_bundle(make_bundle(status="partial"))
    result = certify_bundle(store.v2_dir / "bundle.json", store, reviewer_note="验收确认")
    assert result is not None and result.quality.release_status == "verified"
    assert result.revision == 2                                  # revision+1
    assert any("人工审阅确认链图" in n for n in result.manifest.notes)
    assert result.quality.coverage_values.get("certified_by_review") is True
    # 未决列表：结构完整性条目替换为已确认语义，断言级未决保留
    assert result.quality.unresolved[0] == "结构完整性已由人工审阅确认"
    assert "a1:关系未获支持" in result.quality.unresolved
    # 落盘可回读
    assert store.load_bundle().quality.release_status == "verified"


def test_certify_draft_also_upgrades_and_keeps_head(tmp_path):
    store = ChainStore(tmp_path)
    store.save_bundle(make_bundle(status="draft"))
    result = certify_bundle(store.v2_dir / "bundle.json", store)
    assert result.quality.release_status == "verified"


def test_certify_verified_is_noop_and_missing_returns_none(tmp_path):
    store = ChainStore(tmp_path)
    store.save_bundle(make_bundle(status="verified"))
    result = certify_bundle(store.v2_dir / "bundle.json", store)
    assert result is not None and result.revision == 1           # 不重复操作
    assert certify_bundle(store.v2_dir / "nope.json", store) is None
