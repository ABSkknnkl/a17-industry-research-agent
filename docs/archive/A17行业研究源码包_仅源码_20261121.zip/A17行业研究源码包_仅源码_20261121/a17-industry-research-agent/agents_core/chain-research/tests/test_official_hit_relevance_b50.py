"""B50 红测：公告佐证轮不得把「别家公司的公告」当成目标公司的证据。

实测（run-20261111192127，低空经济）：`corroborate_announcements` 用
「大疆 主营业务 公告」查询问财 announcement 频道，返回的是

    上海电影：关于股票交易异常波动暨风险提示性公告
    圣泉集团：关于使用部分闲置募集资金进行现金管理的进展公告
    中原内配：关于在美国设立全资孙公司的公告
    ...

这些命中的 URL 会被逐条抓全文、存文档、再送 verify（budget 白耗），
但它们根本不是目标公司的公告。公告标题普遍以「公司名：」署名，因此
可以用「署名主体是否等于目标公司（或其别名）」作最低门槛。

判定刻意保守：**只有明确署名给别家才丢弃**；无署名前缀的标题一律保留，
避免把「关于回购公司股份的公告」这类合法标题误杀。
"""

from __future__ import annotations

from chain_research.service import official_hit_belongs_to_company


def _hit(title: str, summary: str = "") -> dict:
    return {"title": title, "summary": summary, "url": "http://example.com/a.pdf"}


def test_same_company_announcement_kept() -> None:
    assert official_hit_belongs_to_company(_hit("北方华创：2024年年度报告"), "北方华创")


def test_other_company_announcement_dropped() -> None:
    assert not official_hit_belongs_to_company(
        _hit("上海电影：关于股票交易异常波动暨风险提示性公告"), "大疆")
    assert not official_hit_belongs_to_company(
        _hit("圣泉集团：关于使用部分闲置募集资金进行现金管理的进展公告"), "亿航")


def test_other_issuer_mention_is_not_target_company_disclosure() -> None:
    assert not official_hit_belongs_to_company(
        _hit("某甲公司：年度报告", "低空市场上，纵横股份也提供无人机产品。"),
        "纵横股份",
    )


def test_alias_can_authorize_a_hit() -> None:
    """签名可能是全称，目标名是简称：别名命中即保留。"""
    assert official_hit_belongs_to_company(
        _hit("宗申动力：关于控股子公司获得生产许可证的公告"),
        "宗申", aliases=["宗申动力"],
    )


def test_company_name_anywhere_in_body_kept() -> None:
    """标题无署名但摘要提到目标公司：保留（不能只看标题）。"""
    assert official_hit_belongs_to_company(
        _hit("关于开通无人机物流航线的公告", "该航线由亿航智能提供整机"),
        "亿航智能",
    )


def test_no_signature_is_kept_conservatively() -> None:
    """没有「公司名：」署名的标题无法判断归属，一律保留，避免误杀。"""
    assert official_hit_belongs_to_company(_hit("关于回购公司股份的公告"), "大疆")


def test_full_width_and_half_width_colons_both_work() -> None:
    assert not official_hit_belongs_to_company(_hit("中微公司:2025年年度报告"), "北方华创")
    assert official_hit_belongs_to_company(_hit("中微公司:2025年年度报告"), "中微公司")


def test_empty_title_is_kept() -> None:
    """空标题不在这里判死（下游按长度与可读性处理）。"""
    assert official_hit_belongs_to_company(_hit(""), "大疆")
