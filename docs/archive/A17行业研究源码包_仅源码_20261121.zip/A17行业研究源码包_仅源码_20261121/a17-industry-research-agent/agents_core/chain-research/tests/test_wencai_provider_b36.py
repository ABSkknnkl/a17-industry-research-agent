"""B36-P1 验收：问财搜索提供者（providers.py 接缝，2026-11-10）。

验收点：
- 统一 search_raw 契约：原始命中五元组映射、run 预算计费
- 「次数已用完」的 key 在 **run 内**排除，同 run 后续检索不再触碰；
  新 run 从头尝试全部 key（无跨 run 记忆——配额服务端每日刷新）
- 全部 key 排除后零请求、不占预算、ProviderError(AUTH)
- 超时/解析/网络错误映射到统一错误类别；未配置 → UNAVAILABLE

全部离线（httpx.MockTransport），不触发真实问财。
"""

from __future__ import annotations

import httpx
import pytest

from chain_research import (
    ChainScope,
    ProviderError,
    ProviderErrorKind,
    ResearchBudget,
    RunContext,
    WencaiSearchProvider,
    WencaiSearchTransport,
)

pytestmark = pytest.mark.anyio

EXHAUSTED_BODY = "您今天的次数已用完，建议您[升级权益](https://search.10jqka.com.cn/activepage)获取更多额度。"

NEWS_OK_BODY = {"status_code": 0, "data": [
    {"title": "低空经济产业规模测算", "summary": "2026年低空经济规模超万亿",
     "url": "https://news.example/lowaltitude", "publish_time": 1731200000,
     "publish_date": "2026-11-10 02:52:00", "source": "证券时报"},
]}


def make_ctx(run_id: str, **budget_kw) -> RunContext:
    scope = ChainScope(scope_id=f"sc-{run_id}", subject="低空经济", as_of="2026-11")
    return RunContext(run_id=run_id, scope=scope, budget=ResearchBudget(**budget_kw))


def wire(keys: list[str], handler) -> WencaiSearchProvider:
    transport = WencaiSearchTransport(
        keys, client=httpx.Client(transport=httpx.MockTransport(handler)))
    return WencaiSearchProvider(transport)


async def test_search_raw_maps_hits_and_charges_budget_once():
    seen = []

    def handler(req):
        seen.append(req.headers["Authorization"])
        return httpx.Response(200, json=NEWS_OK_BODY)

    provider = wire(["k1"], handler)
    ctx = make_ctx("r1")
    result = await provider.search_raw("低空经济 产业链", ctx)
    assert result.raw_count == 1 and result.charged
    hit = result.hits[0]
    assert hit["title"] == "低空经济产业规模测算"
    assert hit["url"] == "https://news.example/lowaltitude"
    assert hit["snippet"] == "2026年低空经济规模超万亿"
    assert hit["source_org"] == "证券时报"
    assert hit["published_at"] == "2026-11-10 02:52:00"   # 可读 publish_date 优先于 epoch
    assert ctx.budget.used.search_requests == 1     # 一次 search_raw 计 1
    assert seen == ["Bearer k1"]


async def test_quota_exhausted_key_excluded_within_run_fresh_next_run():
    seen = []

    def handler(req):
        auth = req.headers["Authorization"]
        seen.append(auth)
        if auth == "Bearer k1":
            return httpx.Response(401, text=EXHAUSTED_BODY)
        return httpx.Response(200, json=NEWS_OK_BODY)

    provider = wire(["k1", "k2"], handler)
    ctx = make_ctx("r1")
    first = await provider.search_raw("低空经济", ctx)
    assert seen == ["Bearer k1", "Bearer k2"]        # k1 尽 → 立即换 k2
    assert first.hits
    assert ctx.provider_state["wencai_excluded_keys"] == {"k1"}
    second = await provider.search_raw("低空经济 政策", ctx)
    assert second.hits
    assert seen == ["Bearer k1", "Bearer k2", "Bearer k2"]   # 同 run 不再碰 k1
    assert ctx.budget.used.search_requests == 2
    fresh_ctx = make_ctx("r2")
    await provider.search_raw("低空经济", fresh_ctx)
    # 新 run 从头尝试（无跨 run 记忆）：k1 被再次请求，仍配额尽 → 再落 k2
    assert seen == ["Bearer k1", "Bearer k2", "Bearer k2", "Bearer k1", "Bearer k2"]


async def test_all_keys_exhausted_raises_auth_not_no_result():
    def handler(req):
        return httpx.Response(401, text=EXHAUSTED_BODY)

    provider = wire(["k1", "k2"], handler)
    ctx = make_ctx("r1")
    with pytest.raises(ProviderError) as exc:
        await provider.search_raw("低空经济", ctx)
    assert exc.value.kind is ProviderErrorKind.AUTH   # 凭证错误 ≠ no_result


async def test_all_excluded_fast_fails_without_http_or_budget():
    calls = []

    def handler(req):
        calls.append(req.headers["Authorization"])
        return httpx.Response(401, text=EXHAUSTED_BODY)

    provider = wire(["k1"], handler)
    ctx = make_ctx("r1")
    with pytest.raises(ProviderError):
        await provider.search_raw("q", ctx)
    assert len(calls) == 1 and ctx.budget.used.search_requests == 1
    with pytest.raises(ProviderError) as exc:
        await provider.search_raw("q", ctx)
    assert exc.value.kind is ProviderErrorKind.AUTH
    assert len(calls) == 1                            # 零 HTTP
    assert ctx.budget.used.search_requests == 1       # 不占预算


async def test_shell_quota_exhaustion_also_excludes_key():
    seen = []

    def handler(req):
        auth = req.headers["Authorization"]
        seen.append(auth)
        if auth == "Bearer k1":
            return httpx.Response(200, json={"status_code": 403,
                                             "message": "额度不足，请升级权益"})
        return httpx.Response(200, json=NEWS_OK_BODY)

    provider = wire(["k1", "k2"], handler)
    ctx = make_ctx("r1")
    result = await provider.search_raw("低空经济", ctx)
    assert result.hits
    assert seen == ["Bearer k1", "Bearer k2"]
    assert ctx.provider_state["wencai_excluded_keys"] == {"k1"}


async def test_timeout_maps_to_timeout_kind():
    def handler(req):
        raise httpx.ConnectTimeout("timed out")

    provider = wire(["k1"], handler)
    ctx = make_ctx("r1")
    with pytest.raises(ProviderError) as exc:
        await provider.search_raw("q", ctx)
    assert exc.value.kind is ProviderErrorKind.TIMEOUT


async def test_bad_json_maps_to_parse_error_kind():
    def handler(req):
        return httpx.Response(200, text="<html>not json</html>")

    provider = wire(["k1"], handler)
    ctx = make_ctx("r1")
    with pytest.raises(ProviderError) as exc:
        await provider.search_raw("q", ctx)
    assert exc.value.kind is ProviderErrorKind.PARSE_ERROR


async def test_network_error_maps_to_unavailable_kind():
    def handler(req):
        raise httpx.ConnectError("boom")

    provider = wire(["k1"], handler)
    ctx = make_ctx("r1")
    with pytest.raises(ProviderError) as exc:
        await provider.search_raw("q", ctx)
    assert exc.value.kind is ProviderErrorKind.UNAVAILABLE


async def test_budget_exhausted_raises_budget_kind_without_http():
    calls = []

    def handler(req):
        calls.append(1)
        return httpx.Response(200, json=NEWS_OK_BODY)

    provider = wire(["k1"], handler)
    ctx = make_ctx("r1", max_search_requests=0)
    with pytest.raises(ProviderError) as exc:
        await provider.search_raw("q", ctx)
    assert exc.value.kind is ProviderErrorKind.BUDGET
    assert not calls


async def test_unavailable_without_transport():
    provider = WencaiSearchProvider(None)
    ctx = make_ctx("r1")
    with pytest.raises(ProviderError) as exc:
        await provider.search_raw("q", ctx)
    assert exc.value.kind is ProviderErrorKind.UNAVAILABLE
