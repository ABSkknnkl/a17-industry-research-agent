"""B36-P6：巨潮公告兜底提供者（cninfo）测试。

背景（run-20261111083441 实测）：问财 announcement 命中的 sse 公告直链被瑞数反爬
拦截（返回 HTML 挑战页），公告 PDF 一条都抓不到；巨潮资讯是法定信息披露平台，
全文检索 + static.cninfo 直链 PDF 可稳定下载并经 fitz 提取。

验收点：
- search_raw 契约：命中映射五元组（<em> 清洗、直链拼接、epoch 毫秒 → 日期）
- 0 命中返回空结果不报错
- HTTP/网络/解析错误映射到统一 ProviderError 类别
- 检索计费入 run 预算
"""
import asyncio

import httpx
import pytest

from chain_research.models import ChainScope, ResearchBudget
from chain_research.providers import (
    CninfoAnnouncementProvider,
    CninfoAnnouncementTransport,
    ProviderError,
    ProviderErrorKind,
    RunContext,
)


def make_ctx(run_id: str = "r1") -> RunContext:
    return RunContext(run_id, ChainScope(scope_id="s", subject="测试", as_of="2026-11-11"),
                      ResearchBudget(max_search_requests=5, max_llm_requests=5))


class FakeTransport(CninfoAnnouncementTransport):
    """假巨潮传输：返回预置响应或注入错误。"""

    def __init__(self, announcements=None, *, error=None, status_code=200):
        self.announcements = announcements or []
        self.error = error
        self.status_code = status_code
        self.queries: list[str] = []

    def search_sync(self, query, *, count=4):
        self.queries.append(query)
        if self.error is not None:
            raise self.error
        if self.status_code >= 400:
            raise ValueError(f"巨潮检索 HTTP {self.status_code}")
        return [
            {
                "title": str(a.get("announcementTitle", "")).replace("<em>", "").replace("</em>", ""),
                "url": self.STATIC_BASE + a["adjunctUrl"],
                "snippet": str(a.get("announcementTitle", "")).replace("<em>", "").replace("</em>", ""),
                "source_org": "巨潮资讯网",
                "published_at": a.get("published_at", ""),
            }
            for a in self.announcements[:count]
        ]


ANN = {"announcementTitle": "<em>纵横股份</em>：2026年第三季度报告",
       "adjunctUrl": "finalpage/2026-10-31/1225648939.PDF",
       "announcementTime": 1793433600000, "published_at": "2026-10-31"}


def test_hits_mapped_with_clean_title_and_direct_url():
    provider = CninfoAnnouncementProvider(FakeTransport([ANN]))
    ctx = make_ctx()
    result = asyncio.run(provider.search_raw("纵横股份", ctx))
    assert result.raw_count == 1
    hit = result.hits[0]
    assert hit["title"] == "纵横股份：2026年第三季度报告"          # <em> 已清洗
    assert hit["url"] == "http://static.cninfo.com.cn/finalpage/2026-10-31/1225648939.PDF"
    assert hit["source_org"] == "巨潮资讯网"
    assert hit["published_at"] == "2026-10-31"
    assert ctx.budget.used.search_requests == 1                    # 计费入 run 预算


def test_zero_hits_is_normal_empty_result():
    provider = CninfoAnnouncementProvider(FakeTransport([]))
    result = asyncio.run(provider.search_raw("亿航智能", make_ctx()))
    assert result.raw_count == 0 and result.hits == []


def test_http_error_maps_to_parse_error():
    provider = CninfoAnnouncementProvider(FakeTransport(status_code=503))
    with pytest.raises(ProviderError) as ei:
        asyncio.run(provider.search_raw("q", make_ctx()))
    assert ei.value.kind == ProviderErrorKind.PARSE_ERROR


def test_network_error_maps_to_unavailable():
    provider = CninfoAnnouncementProvider(
        FakeTransport(error=httpx.ConnectError("connection refused")))
    with pytest.raises(ProviderError) as ei:
        asyncio.run(provider.search_raw("q", make_ctx()))
    assert ei.value.kind == ProviderErrorKind.UNAVAILABLE


def test_unconfigured_transport_is_unavailable_without_charging():
    provider = CninfoAnnouncementProvider(None)
    ctx = make_ctx()
    with pytest.raises(ProviderError) as ei:
        asyncio.run(provider.search_raw("q", ctx))
    assert ei.value.kind == ProviderErrorKind.UNAVAILABLE
    assert ctx.budget.used.search_requests == 0                    # 零请求不占预算
