"""Conservative, non-factual limitations that can accompany a data gap."""

LIMITATIONS = {
    "coverage": "受资料覆盖限制，本项结论仅供参考，不应据此推断行业整体趋势。",
    "relationship": "相关关系尚待独立核验，本报告不据此作出确定性判断。",
}
