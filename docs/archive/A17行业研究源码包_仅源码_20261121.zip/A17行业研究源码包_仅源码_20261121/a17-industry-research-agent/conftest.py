import os
import pytest


@pytest.fixture(autouse=True)
def isolate_unit_tests_from_live_network(monkeypatch, request, tmp_path):
    """
    Auto-isolate unit tests from ambient .env credentials to prevent accidental slow
    network calls or timeouts. End-to-end integration tests (like test_full_chain_integration)
    and tests marked with @pytest.mark.live keep real credentials.
    """
    # If the test is explicitly testing live external API or full chain integration, keep keys
    if "live" in request.keywords or "test_full_chain_integration" in request.node.nodeid:
        return

    # TestClient may run the application lifespan, including interrupted-run
    # recovery. Never let that recovery scan the developer's live tasks.
    from types import SimpleNamespace
    import backend.app.core.storage as storage_mod
    isolated_runs = tmp_path.parent / f"{tmp_path.name}-isolated-runs"
    isolated_runs.mkdir()
    isolated_project = tmp_path.parent / f"{tmp_path.name}-isolated-project"
    monkeypatch.setattr(storage_mod, "settings", SimpleNamespace(DATA_DIR=isolated_runs, PROJECT_ROOT=isolated_project))
    monkeypatch.setattr(storage_mod.storage, "base_dir", isolated_runs)

    # For all standard unit and regression tests, disable remote LLM calls so they run offline & instant
    monkeypatch.setenv("LLM_API_KEY", "")
    monkeypatch.setenv("OPENAI_API_KEY", "")
    monkeypatch.setenv("BATCH_SKILLS", "false")
    # 2026-10-20：联网补漏会起真实网络调用。测试里必须关掉，
    # 否则某个全链路用例会真的发起外部请求，拖垮后续用例。
    # 2026-11-11：豆包 provider 已移除，联网补漏仅剩博查（SEARCH_PROVIDER=bocha）。
    monkeypatch.setenv("SEARCH_PROVIDER", "none")
    monkeypatch.setenv("BOCHA_API_KEY", "")
    monkeypatch.setenv("ENABLE_WEB_SEARCH_FOR_CHAIN", "0")
